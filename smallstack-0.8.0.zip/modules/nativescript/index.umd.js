(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@smallstack/core-common'), require('underscore'), require('minimongo')) :
	typeof define === 'function' && define.amd ? define(['exports', '@smallstack/core-common', 'underscore', 'minimongo'], factory) :
	(factory((global['smallstack-nativescript'] = global['smallstack-nativescript'] || {}),global._smallstack_coreCommon,global.underscore,global.minimongo));
}(this, (function (exports,_smallstack_coreCommon,_,minimongo) { 'use strict';

var NativescriptDataBridge = (function () {
    function NativescriptDataBridge(ddpClientLibrary, host, port, ssl, connectedCB) {
        if (host === void 0) { host = "localhost"; }
        if (port === void 0) { port = 3000; }
        if (ssl === void 0) { ssl = false; }
        var _this = this;
        this.connected = false;
        this.connectionCallbacks = {};
        this.mockedSessionObj = {};
        if (connectedCB)
            this.onConnectionChange(connectedCB);
        this.ddpClient = new ddpClientLibrary({
            host: host,
            port: port,
            ssl: ssl,
            autoReconnect: true,
            autoReconnectTimer: 15000,
            maintainCollections: true,
            ddpVersion: '1',
            useSockJs: false
        });
        _smallstack_coreCommon.Logger.info("DataBridge", "Connecting to " + host + ":" + port + ", ssl:" + ssl + "!");
        this.ddpClient.connect(function (error, wasReconnect) {
            if (error)
                _smallstack_coreCommon.Logger.error("DataBridge", error);
            else {
                _smallstack_coreCommon.Logger.info("DataBridge", "Successfully connected to " + host + ":" + port + "!");
                _this.connected = true;
                _.each(_this.connectionCallbacks, function (cb) {
                    cb(_this.connected);
                });
            }
        });
    }
    NativescriptDataBridge.prototype.onConnectionChange = function (cbFn) {
        var handleId = _.uniqueId();
        this.connectionCallbacks[handleId] = cbFn;
        cbFn(this.connected);
        return handleId;
    };
    NativescriptDataBridge.prototype.onConnect = function (cbFn, onceOnly) {
        var _this = this;
        if (onceOnly === void 0) { onceOnly = true; }
        var handleId = this.onConnectionChange(function (connected) {
            if (connected) {
                cbFn();
                if (onceOnly)
                    delete _this.connectionCallbacks[handleId];
            }
        });
    };
    NativescriptDataBridge.prototype.isConnected = function () {
        return this.connected;
    };
    NativescriptDataBridge.prototype.subscribe = function (publicationName, parameters, options, callbackFns) {
        this.ddpClient.subscribe(publicationName, [parameters, options], function () {
            callbackFns.onReady();
        });
    };
    NativescriptDataBridge.prototype.callMethod = function (methodName, parameters, callbackFn) {
        this.ddpClient.call(methodName, [parameters], callbackFn);
    };
    NativescriptDataBridge.prototype.getCurrentUserId = function () {
        throw new Error("NOT YET IMPLEMENTED");
    };
    NativescriptDataBridge.prototype.userAuthenticated = function () {
        throw new Error("NOT YET IMPLEMENTED");
    };
    NativescriptDataBridge.prototype.logout = function (callbackFn) {
        throw new Error("NOT YET IMPLEMENTED");
    };
    NativescriptDataBridge.prototype.getSessionVariable = function (key) {
        return this.mockedSessionObj[key];
    };
    NativescriptDataBridge.prototype.setSessionVariable = function (key, value) {
        this.mockedSessionObj[key] = value;
    };
    NativescriptDataBridge.prototype.isClient = function () {
        return true;
    };
    NativescriptDataBridge.prototype.isServer = function () {
        return false;
    };
    NativescriptDataBridge.prototype.instance = function () {
        return _smallstack_coreCommon.IOC.get("dataBridge");
    };
    NativescriptDataBridge.prototype.addServerMethod = function (name, func) {
        throw new Error("You cannot implement server methods within a nativescript application!");
    };
    NativescriptDataBridge.prototype.reactiveContext = function (fn) {
        throw new Error("NOT YET IMPLEMENTED");
    };
    NativescriptDataBridge.prototype.getDDPClient = function () {
        return this.ddpClient;
    };
    return NativescriptDataBridge;
}());

var NativescriptCollection = (function () {
    function NativescriptCollection(name, minimongoCollection) {
        this.name = name;
        this.minimongoCollection = minimongoCollection;
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
    }
    NativescriptCollection.prototype.find = function (selector, options) {
        return this.minimongoCollection.find(selector, options);
    };
    NativescriptCollection.prototype.findOne = function (selector, options) {
        return this.minimongoCollection.find(selector, options)[0];
    };
    NativescriptCollection.prototype.insert = function (document, callback) {
        throw new Error("NOT SUPPORTED!");
    };
    NativescriptCollection.prototype.update = function (selector, updateOperation, callback) {
        throw new Error("NOT SUPPORTED!");
    };
    NativescriptCollection.prototype.upsert = function (selector, updateOperation, callback) {
        throw new Error("NOT SUPPORTED!");
    };
    NativescriptCollection.prototype.remove = function (selector, callback) {
        throw new Error("NOT SUPPORTED!");
    };
    NativescriptCollection.prototype.subscribe = function (publicationName, parameters, options, callback) {
        var _this = this;
        this.dataBridge.onConnect(function () {
            _this.dataBridge.getDDPClient().subscribe(publicationName, [parameters, options], function () {
                _smallstack_coreCommon.Logger.info("NativescriptCollection", "Successfully subscribed to " + publicationName);
                _.each(_this.dataBridge.getDDPClient().collections[_this.name], function (doc) {
                    _this.minimongoCollection.upsert(doc);
                });
                callback();
            });
        });
    };
    NativescriptCollection.prototype.subscribeForeignKeys = function (cursor, foreignKeys, callback) {
        throw new Error("NOT SUPPORTED!");
    };
    NativescriptCollection.prototype.getQueryCount = function (queryName, parameters, callback) {
        throw new Error("NOT SUPPORTED!");
    };
    NativescriptCollection.prototype.getCollectionName = function () {
        return this.name;
    };
    NativescriptCollection.prototype.getForeignCollection = function (type) {
        throw new Error("NOT SUPPORTED!");
    };
    NativescriptCollection.prototype.getForeignGetter = function () {
        throw new Error("NOT SUPPORTED!");
    };
    NativescriptCollection.prototype.getServiceName = function () {
        throw new Error("NOT IMPLEMENTED YET!");
    };
    NativescriptCollection.prototype.getQueries = function () {
        throw new Error("NOT IMPLEMENTED YET!");
    };
    return NativescriptCollection;
}());

var NativescriptCollectionService = (function () {
    function NativescriptCollectionService() {
        this._collections = {};
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
        this.localDB = new minimongo.MemoryDb();
    }
    NativescriptCollectionService.prototype.getCollectionByName = function (name) {
        if (this._collections[name])
            return this._collections[name];
        return this.createCollection(name);
    };
    NativescriptCollectionService.prototype.getAllCollections = function () {
        return this.dataBridge.getDDPClient().collections;
    };
    NativescriptCollectionService.prototype.registerCollection = function (name, collection) {
        this._collections[name] = collection;
    };
    NativescriptCollectionService.prototype.addPublisher = function (collectionName, name, mongoSelector, mongoOptions) {
        throw new Error("Cannot add publisher in nativescript app!");
    };
    NativescriptCollectionService.prototype.addPublisherMethod = function (name, fn) {
        throw new Error("Cannot add publisher method in nativescript app!");
    };
    NativescriptCollectionService.prototype.executePublisherMethod = function (methodName, params) {
        throw new Error("Cannot execute publisher method in nativescript app!");
    };
    NativescriptCollectionService.prototype.subscribeForeignKeys = function (baseCollection, cursor, expands, callback) {
        throw new Error("NOT YET IMPLEMENTED!");
    };
    NativescriptCollectionService.prototype.createCollection = function (name, transformFn) {
        this.localDB.addCollection(name);
        var collection = new NativescriptCollection(name, this.localDB[name]);
        this.registerCollection(name, collection);
        return collection;
    };
    return NativescriptCollectionService;
}());

var NativescriptMediaService = (function (_super) {
    __extends(NativescriptMediaService, _super);
    function NativescriptMediaService() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.s3Region = "eu-central-1";
        _this.s3Protocol = "https";
        return _this;
    }
    NativescriptMediaService.prototype.setS3BucketName = function (bucketName) {
        this.s3BucketName = bucketName;
    };
    NativescriptMediaService.prototype.setS3Region = function (region) {
        this.s3Region = region;
    };
    NativescriptMediaService.prototype.setS3Protocol = function (protocol) {
        this.s3Protocol = protocol;
    };
    NativescriptMediaService.prototype.storeMediaFromDataUrl = function (media, dataUrlString, mediaFormat) {
        throw new Error("Storing Medias is not yet supported in nativescript apps!");
    };
    NativescriptMediaService.prototype.storeMediaFromURL = function (media, url, mediaFormat) {
        throw new Error("Storing Medias is not yet supported in nativescript apps!");
    };
    NativescriptMediaService.prototype.getUrlForMediaId = function (mediaId, mediaFormatName) {
        return this.s3Protocol + "://s3." + this.s3Region + ".amazonaws.com/" + this.s3BucketName + "/" + mediaId + "_" + mediaFormatName;
    };
    return NativescriptMediaService;
}(_smallstack_coreCommon.MediaService));

var NativescriptCursorResolver = (function () {
    function NativescriptCursorResolver() {
    }
    NativescriptCursorResolver.prototype.resolve = function (cursor, options, callback) {
        var ModelConstructor = options.ModelConstructor;
        cursor.fetch(function (models) {
            var transformedModels = [];
            _.each(models, function (model) {
                transformedModels.push(ModelConstructor.fromDocument(model));
            });
            callback(transformedModels);
        });
        return null;
    };
    return NativescriptCursorResolver;
}());

exports.NativescriptDataBridge = NativescriptDataBridge;
exports.NativescriptCollectionService = NativescriptCollectionService;
exports.NativescriptMediaService = NativescriptMediaService;
exports.NativescriptCollection = NativescriptCollection;
exports.NativescriptCursorResolver = NativescriptCursorResolver;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=index.umd.js.map
