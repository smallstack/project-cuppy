import { MediaService, Media, MediaFormat } from "@smallstack/core-common";
export declare class NativescriptMediaService extends MediaService {
    private s3BucketName;
    private s3Region;
    private s3Protocol;
    setS3BucketName(bucketName: string): void;
    setS3Region(region: string): void;
    setS3Protocol(protocol: "http" | "https"): void;
    storeMediaFromDataUrl(media: Media, dataUrlString: string, mediaFormat: MediaFormat): boolean;
    storeMediaFromURL(media: Media, url: string, mediaFormat: MediaFormat): boolean;
    getUrlForMediaId(mediaId: string, mediaFormatName: string): string;
}
