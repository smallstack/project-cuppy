import { CollectionsService, Collection, PublisherMethodParameters, PublisherMethodResult } from "@smallstack/core-common";
export declare class NativescriptCollectionService implements CollectionsService {
    private _collections;
    private dataBridge;
    private localDB;
    constructor();
    getCollectionByName<T>(name: string): Collection<T>;
    getAllCollections(): {
        [name: string]: Collection<any>;
    };
    registerCollection(name: any, collection: any): void;
    addPublisher(collectionName: string, name: string, mongoSelector?: any, mongoOptions?: any): void;
    addPublisherMethod(name: any, fn: (params: PublisherMethodParameters) => PublisherMethodResult): void;
    executePublisherMethod(methodName: string, params: PublisherMethodParameters): PublisherMethodResult;
    subscribeForeignKeys(baseCollection: Collection<any>, cursor: any, expands: string[], callback?: () => void): void;
    createCollection<ModelClass>(name: string, transformFn?: Function): any;
}
