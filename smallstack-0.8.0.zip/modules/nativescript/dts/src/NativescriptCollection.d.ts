import { Collection, QueryOptions } from "@smallstack/core-common";
export declare class NativescriptCollection<T> implements Collection<T> {
    private name;
    private minimongoCollection;
    private dataBridge;
    constructor(name: string, minimongoCollection: any);
    find(selector?: any, options?: any): any;
    findOne(selector?: any, options?: any): any;
    insert(document: T, callback?: (error: Error, savedId: string) => void): string;
    update(selector: any, updateOperation: any, callback?: (error: Error, updatedDocuments: number) => void): number;
    upsert(selector: any, updateOperation: any, callback?: (error: Error, numbersAffectedOrInsertId: {
        numberAffected?: number;
        insertedId?: string;
    }) => void): {
        numberAffected?: number;
        insertedId?: string;
    };
    remove(selector: any, callback?: (error: Error, removedDocuments: number) => void): number;
    subscribe(publicationName: string, parameters: any, options: QueryOptions, callback?: () => void): void;
    subscribeForeignKeys(cursor: any, foreignKeys: any, callback?: any): void;
    getQueryCount(queryName: string, parameters: any, callback?: (count: number) => void): void;
    getCollectionName(): string;
    getForeignCollection(type: string): string;
    getForeignGetter(): string;
    getServiceName(): string;
    getQueries(): {
        [queryName: string]: any;
    };
}
