import { CursorResolver, SmallstackModelStatic } from "@smallstack/core-common";
export declare class NativescriptCursorResolver<ModelClass> implements CursorResolver<ModelClass> {
    resolve(cursor: any, options: {
        ModelConstructor?: SmallstackModelStatic;
    }, callback?: (models: ModelClass[]) => void): ModelClass[];
}
