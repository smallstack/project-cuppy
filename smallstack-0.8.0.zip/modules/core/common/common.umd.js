(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('underscore')) :
	typeof define === 'function' && define.amd ? define(['exports', 'underscore'], factory) :
	(factory((global['smallstack-core-common'] = global['smallstack-core-common'] || {}),global._));
}(this, (function (exports,_) { 'use strict';

var GoogleAnalyticsService = (function () {
    function GoogleAnalyticsService() {
    }
    GoogleAnalyticsService.prototype.track = function (path, options) {
    };
    GoogleAnalyticsService.prototype.event = function (eventName, options) {
    };
    return GoogleAnalyticsService;
}());

var MultiAnalyticsService = (function () {
    function MultiAnalyticsService() {
        this.googleAnalyticsService = new GoogleAnalyticsService();
    }
    MultiAnalyticsService.prototype.track = function (path, options) {
        this.googleAnalyticsService.track(path, options);
    };
    MultiAnalyticsService.prototype.event = function (eventName, options) {
        this.googleAnalyticsService.event(eventName, options);
    };
    return MultiAnalyticsService;
}());

var GeneratedConfigurationService = (function () {
    function GeneratedConfigurationService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedConfigurationService.instance = function () {
        return IOC.get("configurationService");
    };
    GeneratedConfigurationService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("configuration");
    };
    GeneratedConfigurationService.prototype.getConfiguration = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "scope": "everywhere" }, "getConfiguration", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedConfigurationService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedConfigurationService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "key": model["key"], "value": model["value"], "scope": model["scope"] } }, callback);
    };
    GeneratedConfigurationService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedConfigurationService;
}());

var __extends$3 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ConfigurationService$$1 = (function (_super) {
    __extends$3(ConfigurationService$$1, _super);
    function ConfigurationService$$1() {
        var _this = _super.call(this) || this;
        _this.configuration = {};
        _this.envPrefix = "SMALLSTACK_CONFIGURATION_";
        _this.envServerPrefix = "SMALLSTACK_CONFIGURATION_SERVER_";
        _this.functionCallbacks = {};
        _this.envIsRead = false;
        _this.onEnvReadCallbacks = [Function];
        var that = _this;
        if (_this.dataBridge.isServer()) {
            _this.collectionsService.getCollectionByName("configuration").find({}).forEach(function (doc) {
                that.set(doc.key, doc.value, doc.scope);
            });
            Logger.debug("ConfigurationService", "Configuration from database read!");
            _this.processEnvConf();
            _this.dataBridge.addServerMethod("client-configuration", function () {
                return that.collectionsService.getCollectionByName("configuration").find({ "scope": "everywhere" }).fetch();
            });
        }
        return _this;
    }
    ConfigurationService$$1.prototype.initOnClient = function (done) {
        var _this = this;
        if (this.dataBridge.isClient()) {
            this.dataBridge.callMethod("client-configuration", {}, function (error, configuration) {
                if (error)
                    done(error, false);
                else {
                    console.log("YEAH, got this : ", configuration);
                    _.each(configuration, function (configuration) {
                        _this.set(configuration.key, configuration.value);
                    });
                    done(undefined, true);
                }
            });
        }
    };
    ConfigurationService$$1.prototype.set = function (key, value, scope) {
        if (this.dataBridge.isClient() && scope !== undefined)
            throw new Error("You should not set the scope on client side, its 'everywhere' by default!");
        key = key.toLowerCase();
        if (this.dataBridge.isServer()) {
            if (scope === undefined)
                scope = "server";
            this.collectionsService.getCollectionByName("configuration").upsert({ key: key }, { $set: { key: key, value: value, scope: scope } });
        }
        Logger.debug("ConfigurationService", "Setting Configuration : " + key + " = " + value + ", context:" + scope);
        this.configuration[key] = value;
        for (var funcKey in this.functionCallbacks[key]) {
            try {
                this.functionCallbacks[key][funcKey](value);
            }
            catch (e) {
                Logger.error("ConfigurationService", "Error while calling onSet callback!", e);
            }
        }
    };
    ConfigurationService$$1.prototype.unset = function (key) {
        key = key.toLowerCase();
        if (this.dataBridge.isServer()) {
            this.collectionsService.getCollectionByName("configuration").remove({ key: key });
        }
        Logger.debug("ConfigurationService", "Removing Configuration : " + key);
        if (this.contains(key))
            delete this.configuration[key];
        for (var funcKey in this.functionCallbacks[key]) {
            try {
                this.functionCallbacks[key][funcKey](undefined);
            }
            catch (e) {
                Logger.error("ConfigurationService", "Error while calling onSet callback!", e);
            }
        }
    };
    ConfigurationService$$1.prototype.get = function (key, defaultValue) {
        if (this.dataBridge.isServer()) {
            var dbConfig = this.collectionsService.getCollectionByName("configuration").findOne({ key: key });
            if (dbConfig)
                return dbConfig.value;
        }
        key = key.toLowerCase();
        if (this.contains(key))
            return this.configuration[key];
        else {
            if (this.dataBridge.isClient) {
                this.set(key, defaultValue);
                return this.configuration[key];
            }
            if (this.dataBridge.isServer())
                return defaultValue;
        }
    };
    ConfigurationService$$1.prototype.onSet = function (key, func) {
        key = key.toLowerCase();
        if (this.contains(key)) {
            try {
                func(this.get(key));
            }
            catch (e) {
                Logger.error("ConfigurationService", "Error while calling onSet callback!", e);
            }
        }
        if (this.functionCallbacks[key] === undefined)
            this.functionCallbacks[key] = [func];
        else
            this.functionCallbacks[key].push(func);
    };
    ConfigurationService$$1.prototype.onEnvironmentRead = function (func) {
        if (this.envIsRead) {
            try {
                func();
            }
            catch (e) {
                Logger.error("ConfigurationService", "Error while calling onEnvironmentRead callback!", e);
            }
        }
        else
            this.onEnvReadCallbacks.push(func);
    };
    ConfigurationService$$1.prototype.contains = function (key) {
        key = key.toLowerCase();
        return this.configuration[key] !== undefined;
    };
    ConfigurationService$$1.prototype.convertKey = function (key) {
        return key.toLowerCase().replace(/_/g, ".");
    };
    ConfigurationService$$1.prototype.processEnvConf = function () {
        if (this.dataBridge.isServer()) {
            this.envIsRead = true;
            Logger.debug("ConfigurationService", "Reading environment variables...");
            for (var key in process.env) {
                if (key.indexOf(this.envServerPrefix) === 0) {
                    var realKey = this.convertKey(key.substring(this.envServerPrefix.length));
                    Logger.debug("ConfigurationService", "Reading server env configuration : " + key + "=" + process.env[key]);
                    this.set(realKey, process.env[key], "server");
                }
                else if (key.indexOf(this.envPrefix) === 0) {
                    var realKey = this.convertKey(key.substring(this.envPrefix.length));
                    Logger.debug("ConfigurationService", "Reading env configuration : " + key + "=" + process.env[key]);
                    this.set(realKey, process.env[key], "everywhere");
                }
            }
            _.each(this.onEnvReadCallbacks, function (func) {
                try {
                    func();
                }
                catch (e) {
                    Logger.error("ConfigurationService", "Error while calling onEnvironmentRead callback!", e);
                }
            });
            this.onEnvReadCallbacks = [Function];
            Logger.debug("ConfigurationService", "Configuration read!");
        }
    };
    ConfigurationService$$1.instance = function () {
        return IOC.get("configurationService");
    };
    return ConfigurationService$$1;
}(GeneratedConfigurationService));
ConfigurationService$$1.scopes = {
    SERVER: "server",
    EVERYWHERE: "everywhere"
};

var GeneratedConfiguration = (function () {
    function GeneratedConfiguration() {
        this._hasSubDocuments = false;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedConfiguration.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["key"] = doc["key"];
        model["value"] = doc["value"];
        model["scope"] = doc["scope"];
        return model;
    };
    GeneratedConfiguration.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["key"] = this["key"];
        doc["value"] = this["value"];
        doc["scope"] = this["scope"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedConfiguration.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedConfiguration.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedConfiguration.getModelName = function () {
        return "Configuration";
    };
    GeneratedConfiguration.prototype.getModelName = function () {
        return "Configuration";
    };
    GeneratedConfiguration.getModelClass = function () {
        return IOC.get("Configuration");
    };
    GeneratedConfiguration.prototype.getModelClass = function () {
        return IOC.get("Configuration");
    };
    GeneratedConfiguration.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete Configuration with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed Configuration with ID '" + that.id + "'!");
            };
        }
        return ConfigurationService$$1.instance().delete(this, callback);
    };
    GeneratedConfiguration.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update Configuration with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated Configuration with ID '" + _this.id + "'!");
            };
        }
        return ConfigurationService$$1.instance().update(this, callback);
    };
    GeneratedConfiguration.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save Configuration!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved Configuration!");
                }
            };
        }
        if (this.dataBridge.isClient())
            ConfigurationService$$1.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = ConfigurationService$$1.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedConfiguration.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "key": {
                "type": String,
                "index": true,
                "unique": true
            },
            "value": {
                "type": String
            },
            "scope": {
                "type": String,
                "allowedValues": ["server", "everywhere"]
            },
        };
    };
    return GeneratedConfiguration;
}());
GeneratedConfiguration.enums = {
    "scope": { "SERVER": "server", "EVERYWHERE": "everywhere" }
};

var __extends$2 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Configuration$$1 = (function (_super) {
    __extends$2(Configuration$$1, _super);
    function Configuration$$1() {
        return _super.apply(this, arguments) || this;
    }
    return Configuration$$1;
}(GeneratedConfiguration));
IOC.register("Configuration", Configuration$$1);

var __extends$1 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var GeneratedConfigurationCollection = (function (_super) {
    __extends$1(GeneratedConfigurationCollection, _super);
    function GeneratedConfigurationCollection() {
        var _this = _super.call(this) || this;
        _this.name = "configuration";
        _this.createCollection();
        _this.configureAllowDenyRules();
        _this.createSearchIndex();
        _this.collectionsService.registerCollection("configuration", _this);
        _this.createPublications();
        return _this;
    }
    GeneratedConfigurationCollection.prototype.createPublications = function () {
        if (this.dataBridge.isServer()) {
            this.collectionsService.addPublisher("configuration", "getConfiguration", { "scope": "everywhere" }, {});
        }
    };
    GeneratedConfigurationCollection.prototype.createSearchIndex = function () {
        if (Package["easysearch:core"]) {
            Logger.debug("EasySearch", "Creating search index for collection 'configuration' and fields 'key,value,scope,_id'!");
            this._easySearchIndex = new EasySearch.Index({
                collection: this._collection,
                fields: ["key", "value", "scope", "_id"],
                engine: new EasySearch.MongoDB()
            });
        }
    };
    GeneratedConfigurationCollection.prototype.createCollection = function () {
        this._collection = this.collectionsService.createCollection("configuration", function (doc) {
            return Configuration$$1.fromDocument(doc);
        });
    };
    GeneratedConfigurationCollection.prototype.configureAllowDenyRules = function () {
        var allow = this.getCollectionAllowRules();
        if (allow !== undefined)
            this._collection.allow(allow);
        else {
            var deny = this.getCollectionDenyRules();
            if (deny !== undefined)
                this._collection.deny(deny);
            else
                console.warn("No allow/deny rules set for collection : configuration");
        }
    };
    GeneratedConfigurationCollection.prototype.getCollectionAllowRules = function () {
        var that = this;
        return {
            insert: function (userId, doc) {
                return (userId && doc.ownerId === userId);
            },
            update: function (userId, doc, fields, modifier) {
                return doc.ownerId === userId;
            },
            remove: function (userId, doc) {
                return doc.ownerId === userId;
            },
            fetch: ['ownerId']
        };
    };
    GeneratedConfigurationCollection.prototype.getCollectionDenyRules = function () {
        return undefined;
    };
    GeneratedConfigurationCollection.prototype.getSchema = function () {
        return GeneratedConfiguration.getSchema();
    };
    GeneratedConfigurationCollection.prototype.getForeignCollection = function (typeName) {
        switch (typeName) {
        }
        return undefined;
    };
    GeneratedConfigurationCollection.prototype.getForeignGetter = function () {
        return "getConfigurationsByIds";
    };
    GeneratedConfigurationCollection.getForeignGetter = function () {
        return "getConfigurationsByIds";
    };
    GeneratedConfigurationCollection.prototype.getModelName = function () {
        return "Configuration";
    };
    GeneratedConfigurationCollection.prototype.getServiceName = function () {
        return "configurationService";
    };
    GeneratedConfigurationCollection.prototype.getQueries = function () {
        return GeneratedConfigurationCollection.queries;
    };
    GeneratedConfigurationCollection.prototype.getCollectionName = function () {
        return "configuration";
    };
    GeneratedConfigurationCollection.getCollection = function () {
        return IOC.get("collectionsService").getCollectionByName("configuration");
    };
    return GeneratedConfigurationCollection;
}(BaseCollection$$1));
GeneratedConfigurationCollection.queries = {
    "getConfiguration": { name: "getConfiguration", parameters: {} }
};
GeneratedConfigurationCollection.expandables = {};

var __extends = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ConfigurationCollection = (function (_super) {
    __extends(ConfigurationCollection, _super);
    function ConfigurationCollection() {
        return _super.call(this) || this;
    }
    return ConfigurationCollection;
}(GeneratedConfigurationCollection));

var BootstrapHooks$$1 = (function () {
    function BootstrapHooks$$1() {
        var _this = this;
        this.bootstrapHookSenderFns = {};
        this.bootstrapHookReceiverFns = {};
        this.initLevelService = InitLevelService.instance();
        this.dataBridge = IOC.get("dataBridge");
        if (this.dataBridge.isServer()) {
            this.dataBridge.addServerMethod("bootstrap", function (params) {
                var data = {};
                _.each(_this.bootstrapHookSenderFns, function (fn, name) {
                    data[name] = fn(params[name]);
                });
                return data;
            });
        }
        if (this.dataBridge.isClient()) {
            this.initLevelService.addInitLevelFn(10, "Bootstrap", function (done) {
                var params = {};
                _.each(_this.bootstrapHookReceiverFns, function (obj, name) {
                    if (obj.params)
                        params[name] = obj.params;
                });
                _this.dataBridge.callMethod("bootstrap", params, function (error, result) {
                    if (error)
                        done(error, false);
                    else {
                        Logger.debug("BootstrapHooks", "got bootstrap data : ", result);
                        _.each(_this.bootstrapHookReceiverFns, function (obj, name) {
                            if (result[name] === undefined)
                                Logger.error("BootstrapHooks", "no data found for bootstrap hook '" + name + "'!");
                            else
                                obj.fn(result[name]);
                        });
                        done(undefined, true);
                    }
                });
            });
        }
    }
    BootstrapHooks$$1.prototype.registerBootstrapHookSender = function (name, fn) {
        if (!this.dataBridge.isServer())
            throw new Error("bootstrap hook senders shall only be registered on the server!");
        Logger.debug("BootstrapHooks", "registering bootstrap hook sender: " + name);
        this.bootstrapHookSenderFns[name] = fn;
    };
    BootstrapHooks$$1.prototype.registerBootstrapHookReceiver = function (name, params, fn) {
        if (this.dataBridge.isServer())
            throw new Error("bootstrap hook receivers shall only be registered on clients!");
        Logger.debug("BootstrapHooks", "registering bootstrap hook receiver: " + name);
        this.bootstrapHookReceiverFns[name] = { fn: fn, params: params };
    };
    return BootstrapHooks$$1;
}());

var Logger = (function () {
    function Logger() {
    }
    Logger.log = function (level, moduleName, message, stacktrace) {
        if (this.loggingModule(level, moduleName)) {
            if (moduleName.length > this.loggerMaxLength)
                this.loggerMaxLength = moduleName.length;
            var delta = this.loggerMaxLength - moduleName.length;
            if (delta > 0) {
                for (var i = 0; i < delta; i++) {
                    moduleName = moduleName + " ";
                }
            }
            var consoleLevel = level === "debug" ? "log" : level;
            if (typeof console !== "undefined" && typeof console[consoleLevel] === "function") {
                if (stacktrace)
                    console[consoleLevel](moduleName + " " + message, stacktrace);
                else
                    console[consoleLevel](moduleName + " " + message);
            }
        }
    };
    Logger.info = function (moduleName, message, stacktrace) {
        this.log("info", moduleName, message, stacktrace);
    };
    Logger.warning = function (moduleName, message, stacktrace) {
        this.log("warn", moduleName, message, stacktrace);
    };
    Logger.error = function (moduleName, message, stacktrace) {
        this.log("error", moduleName, message, stacktrace);
    };
    Logger.debug = function (moduleName, message, stacktrace) {
        this.log("debug", moduleName, message, stacktrace);
    };
    Logger.loggingModule = function (level, moduleName) {
        if (this.debugMode)
            return true;
        if (level === "debug" && this.debugModules.indexOf(moduleName) === -1)
            return false;
        return true;
    };
    Logger.printSmallstackLogo = function () {
        console.log(" ");
        console.log("                        _  _       _                 _    ");
        console.log(" ___  _ __ ___    __ _ | || | ___ | |_   __ _   ___ | | __");
        console.log("/ __|| '_ ` _ \\  / _` || || |/ __|| __| / _` | / __|| |/ /");
        console.log("\\__ \\| | | | | || (_| || || |\\__ \\| |_ | (_| || (__ |   < ");
        console.log("|___/|_| |_| |_| \\__,_||_||_||___/ \\__| \\__,_| \\___||_|\\_\\");
        console.log("visit us on https://smallstack.io!");
        console.log(" ");
    };
    return Logger;
}());
Logger.loggerMaxLength = 20;
Logger.debugModules = [];
Logger.debugMode = false;

var IOC = (function () {
    function IOC() {
        this.container = {};
        this.onRegisterCallbacks = {};
        this._id = _.uniqueId().toString();
    }
    IOC.prototype.register = function (id, value) {
        this.container[id] = value;
        Logger.debug("IOC", "registered Object with ID: " + id + ", Type:" + typeof value);
        if (this.onRegisterCallbacks[id]) {
            _.each(this.onRegisterCallbacks[id], function (fn) {
                fn(value);
            });
        }
        return value;
    };
    IOC.register = function (id, value) {
        return IOC.instance().register(id, value);
    };
    IOC.prototype.get = function (id) {
        if (this.isRegistered(id))
            return this.container[id];
        else
            throw new Error("Could not find an ioc instance for id : '" + id + "'!");
    };
    IOC.get = function (id) {
        return IOC.instance().get(id);
    };
    IOC.prototype.isRegistered = function (id) {
        return this.container[id] !== undefined;
    };
    IOC.isRegistered = function (id) {
        return IOC.instance().isRegistered(id);
    };
    IOC.instance = function () {
        if (IOC._instance === undefined)
            IOC._instance = new IOC();
        return IOC._instance;
    };
    IOC.prototype.onRegister = function (id, callback) {
        if (this.isRegistered(id))
            callback(this.get(id));
        if (!this.onRegisterCallbacks[id])
            this.onRegisterCallbacks[id] = [];
        this.onRegisterCallbacks[id].push(callback);
    };
    IOC.onRegister = function (id, callback) {
        IOC.instance().onRegister(id, callback);
    };
    IOC.prototype.getIOCID = function () {
        return this._id;
    };
    return IOC;
}());

var InitLevelService = (function () {
    function InitLevelService() {
        this.initLevels = {};
        this.executableLevels = [];
    }
    InitLevelService.prototype.addInitLevelFn = function (level, identifier, fn) {
        if (level < 0 || level > 100)
            throw new Error("InitLevel should be between 0 and 100 (both inclusive)!");
        if (this.initLevels[level] === undefined)
            this.initLevels[level] = [];
        Logger.debug("InitLevelService", "Added '" + identifier + "' on init level " + level);
        this.initLevels[level].push({ fn: fn, identifier: identifier });
    };
    InitLevelService.prototype.execute = function () {
        var _this = this;
        for (var lvl = 0; lvl <= 100; lvl++) {
            _.each(this.initLevels[lvl], function (executable) {
                _this.executableLevels.push({
                    identifier: executable.identifier,
                    fn: function () {
                        Logger.debug("InitLevelService", "Executing '" + executable.identifier + "'!");
                        var now = Date.now();
                        executable.fn(function (error, success) {
                            Logger.debug("InitLevelService", "Execution of '" + executable.identifier + "' took " + (Date.now() - now) + "ms!");
                            if (error)
                                throw error;
                            if (success)
                                _this.next();
                            else
                                throw new Error("An init level execution failed!");
                        });
                    }
                });
            }, this);
        }
        this.next();
    };
    InitLevelService.prototype.next = function () {
        var executable = this.executableLevels.shift();
        if (executable)
            executable.fn();
    };
    InitLevelService.instance = function () {
        return IOC.get("initLevelService");
    };
    return InitLevelService;
}());

function Autowired(injectionKey) {
    return function decoratorFactory(target, decoratedPropertyame) {
        var dependencyName = injectionKey !== undefined ? injectionKey : decoratedPropertyame;
        if (IOC.isRegistered(dependencyName))
            target[decoratedPropertyame] = IOC.get(dependencyName);
        else {
            IOC.onRegister(dependencyName, function (injectable) {
                target[decoratedPropertyame] = injectable;
            });
        }
    };
}

(function (PadDirection) {
    PadDirection[PadDirection["RIGHT"] = 0] = "RIGHT";
    PadDirection[PadDirection["LEFT"] = 1] = "LEFT";
})(exports.PadDirection || (exports.PadDirection = {}));
var Utils = (function () {
    function Utils() {
    }
    Utils.isNonEmptyString = function (string) {
        return _.isString(string) && !_.isUndefined(string) && !_.isEmpty(string) && string !== null && string !== undefined;
    };
    Utils.isEmptyString = function (string) {
        return !Utils.isNonEmptyString(string);
    };
    Utils.isMobile = function () {
        var userAgent = navigator.userAgent || navigator.vendor || window["opera"];
        if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(userAgent) ||
            /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(userAgent.substr(0, 4)))
            return true;
        return false;
    };
    Utils.stringEndsWith = function (string, suffix) {
        return string.indexOf(suffix, string.length - suffix.length) !== -1;
    };
    Utils.getUrlParameterByName = function (name, url) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(url);
        return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    };
    Utils.check = function (property, type, name, callback) {
        if (typeof property !== type) {
            var error = new Error(name + " is not of type " + type + ", rather of type : " + typeof property);
            if (callback)
                callback(error);
            throw error;
        }
    };
    Utils.createUrlConformIdFromInput = function (input, maxLength) {
        if (input === undefined)
            return "";
        input = input.replace(/[üÜ]/g, "ue");
        input = input.replace(/[äÄ]/g, "ae");
        input = input.replace(/[öÖ]/g, "oe");
        input = input.replace(/[ß]/g, "ss");
        input = input.replace(/ /g, "_");
        input = input.replace(/[^a-zA-Z0-9\_\-]/g, "").toLowerCase();
        if (maxLength)
            return input.substring(0, maxLength);
        return input;
    };
    Utils.unflattenJSON = function (data) {
        "use strict";
        if (Object(data) !== data || Array.isArray(data))
            return data;
        var regex = /\.?([^.\[\]]+)|\[(\d+)\]/g, resultholder = {};
        for (var p in data) {
            var cur = resultholder, prop = "", m;
            while (m = regex.exec(p)) {
                cur = cur[prop] || (cur[prop] = (m[2] ? [] : {}));
                prop = m[2] || m[1];
            }
            cur[prop] = data[p];
        }
        return resultholder[""] || resultholder;
    };
    Utils.flattenJSON = function (data) {
        var result = {};
        function recurse(cur, prop) {
            if (Object(cur) !== cur) {
                result[prop] = cur;
            }
            else if (Array.isArray(cur)) {
                for (var i = 0, l = cur.length; i < l; i++)
                    recurse(cur[i], prop + "[" + i + "]");
                if (l == 0)
                    result[prop] = [];
            }
            else {
                var isEmpty$$1 = true;
                for (var p in cur) {
                    isEmpty$$1 = false;
                    recurse(cur[p], prop ? prop + "." + p : p);
                }
                if (isEmpty$$1 && prop)
                    result[prop] = {};
            }
        }
        recurse(data, "");
        return result;
    };
    Utils.prettyPrintJson = function (object, maxLength) {
        if (object === undefined)
            return "-";
        var str = object;
        if (_.isObject(object)) {
            str = JSON.stringify(object, undefined, 4);
        }
        if (maxLength && str.length > maxLength)
            return str.substring(0, (maxLength - 6)) + " (...)";
        return str;
    };
    Utils.dasherize = function (str) {
        return str.replace(/[A-Z]/g, function (char, index) {
            return (index !== 0 ? '-' : '') + char.toLowerCase();
        });
    };
    Utils.decapitalize = function (str) {
        return str.charAt(0).toLowerCase() + str.slice(1);
    };
    Utils.capitalize = function (str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    };
    Utils.spaceBeforeUppercase = function (str) {
        return str.replace(/([A-Z])/g, ' $1').trim();
    };
    Utils.padString = function (str, maxLength, direction, fillingCharacter) {
        if (direction === void 0) { direction = exports.PadDirection.LEFT; }
        if (fillingCharacter === void 0) { fillingCharacter = ' '; }
        length = str.length;
        var padlen = length - str.length;
        if (fillingCharacter.length > 1)
            fillingCharacter = fillingCharacter.charAt(0);
        switch (direction) {
            case exports.PadDirection.RIGHT:
                for (var i = 0; i < padlen; i++) {
                    str = str + fillingCharacter;
                }
                return str;
            default:
                for (var i = 0; i < padlen; i++) {
                    str = fillingCharacter + str;
                }
                return str;
        }
    };
    Utils.convertHexToRGB = function (colorAsHex) {
        colorAsHex = colorAsHex.replace('#', '');
        if (colorAsHex.length !== 6)
            throw new Error("Please provide hex colors in 6-digit format!");
        var r = parseInt(colorAsHex.substring(0, 2), 16);
        var g = parseInt(colorAsHex.substring(2, 4), 16);
        var b = parseInt(colorAsHex.substring(4, 6), 16);
        return { r: r, g: g, b: b };
    };
    Utils.isValidUrlName = function (url) {
        return /\b((?=[a-z0-9-]{1,63}\.)(xn--)?[a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,63}\b/.test(url);
    };
    Utils.dataURLtoBlob = function (dataurl) {
        var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1], bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }
        return new Blob([u8arr], { type: mime });
    };
    Utils.blobToDataURL = function (blob, callback) {
        var a = new FileReader();
        a.onload = function (e) { callback(e.target.result); };
        a.readAsDataURL(blob);
    };
    Utils.imageUrlToBlob = function (url, callback) {
        var image = new Image();
        image.onerror = function () {
            console.error("Could not convert url to blob: ", url);
        };
        image.onload = function () {
            var canvas = document.createElement("canvas");
            canvas.width = this.width;
            canvas.height = this.height;
            var ctx = canvas.getContext("2d");
            ctx.drawImage(this, 0, 0);
            canvas.toBlob(function (blob) {
                callback(blob);
            });
        };
        image.src = url;
    };
    return Utils;
}());

var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var BaseCollection$$1 = (function () {
    function BaseCollection$$1() {
    }
    BaseCollection$$1.prototype.find = function (selector, options) {
        if (selector === void 0) { selector = {}; }
        if (options === void 0) { options = {}; }
        Logger.debug("MeteorBaseCollection", this.getCollectionName() + " -> Find Query : " + selector, { selector: selector, options: options });
        return this._collection.find(selector, options);
    };
    BaseCollection$$1.prototype.findOne = function (selector, options) {
        return this._collection.findOne(selector, options);
    };
    BaseCollection$$1.prototype.insert = function (document, callback) {
        return this._collection.insert(document.toDocument(), callback);
    };
    BaseCollection$$1.prototype.update = function (selector, updateOperation, callback) {
        return this._collection.update(selector, updateOperation, callback);
    };
    BaseCollection$$1.prototype.upsert = function (selector, updateOperation, callback) {
        return this._collection.upsert(selector, updateOperation, callback);
    };
    BaseCollection$$1.prototype.remove = function (selector, callback) {
        return this._collection.remove(selector, callback);
    };
    BaseCollection$$1.prototype.subscribe = function (publicationName, parameters, options, callback) {
        var _this = this;
        Logger.debug("MeteorBaseCollection", "Subscribing to " + publicationName);
        this.dataBridge.subscribe(publicationName, parameters, options, {
            onStop: function (error) {
                if (error)
                    throw error;
                else
                    throw new Error("An unknown error occured while subscribing to : " + _this.getCollectionName() + "->" + publicationName);
            },
            onError: function (error) {
                if (error)
                    throw error;
                else
                    throw new Error("An unknown error occured while subscribing to : " + _this.getCollectionName() + "->" + publicationName);
            },
            onReady: function () {
                callback();
            }
        });
    };
    BaseCollection$$1.prototype.subscribeForeignKeys = function (cursor, foreignKeys, callback) {
        this.collectionsService.subscribeForeignKeys(this, cursor, foreignKeys, callback);
    };
    BaseCollection$$1.prototype.getQueryCount = function (queryName, parameters, callback) {
        this.dataBridge.callMethod("server-counts", { queryName: queryName, parameters: parameters }, function (error, count) {
            if (error)
                Logger.error("BaseCollection", "Could not get counts for query " + queryName, error);
            else
                callback(count);
        });
    };
    return BaseCollection$$1;
}());
__decorate([
    Autowired()
], BaseCollection$$1.prototype, "collectionsService", void 0);
__decorate([
    Autowired()
], BaseCollection$$1.prototype, "typesystem", void 0);
__decorate([
    Autowired()
], BaseCollection$$1.prototype, "dataBridge", void 0);

var QueryUtils = (function () {
    function QueryUtils() {
    }
    QueryUtils.interpolate = function (selector, context) {
        var _this = this;
        if (selector !== undefined) {
            var selectorString = JSON.stringify(selector);
            if (selectorString !== undefined) {
                selectorString = selectorString.replace(/_currentLoggedInUser_/g, context.userId);
                var match = selectorString.match(/\"\:([a-zA-Z\[\]\:]{2,})\"/g);
                if (match !== null) {
                    _.forEach(match, function (ma) {
                        var param = ma.split(":")[1];
                        param = param.replace("\"", "");
                        if (context.parameters && context.parameters[param]) {
                            var regex = new RegExp(_this.escapeRegExp(ma), "g");
                            selectorString = selectorString.replace(regex, JSON.stringify(context.parameters[param]));
                        }
                        else {
                            var errorMsg = "Expected missing parameter '" + param + "' while interpolating query!";
                            console.error(errorMsg, ", selector : ", selector, ", context : ", context);
                            return new Error(errorMsg + " - " + JSON.stringify(selector));
                        }
                    });
                }
                selector = JSON.parse(selectorString);
            }
            else {
                selector = {};
            }
        }
        else
            selector = {};
        return selector;
    };
    QueryUtils.escapeRegExp = function (str) {
        return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
    };
    QueryUtils.convertQueryOptionsToMongoSelector = function (queryOptions, sorting) {
        var selectorOptions = { sort: sorting, reactive: (queryOptions && queryOptions.reactive === true) };
        if (queryOptions && queryOptions.currentPage && queryOptions.entriesPerPage)
            selectorOptions.skip = ((queryOptions.currentPage - 1) * queryOptions.entriesPerPage);
        if (queryOptions && queryOptions.entriesPerPage)
            selectorOptions.limit = queryOptions.entriesPerPage;
        return selectorOptions;
    };
    return QueryUtils;
}());

var QueryObject$$1 = (function () {
    function QueryObject$$1() {
        this.isSubscribed = false;
        this.cursorResolver = IOC.get("cursorResolver");
        this.typesystem = IOC.get("typesystem");
    }
    QueryObject$$1.prototype.create = function (selector, subscriptionName, queryOptions, parameters, sorting, collection) {
        this.queryOptions = queryOptions || {};
        this.queryOptions.currentPage = this.queryOptions.currentPage || 1;
        this.queryOptions.entriesPerPage = this.queryOptions.entriesPerPage || 10;
        this.sorting = sorting;
        this.subscriptionName = subscriptionName;
        this.selector = selector;
        this.parameters = parameters;
        this.collection = collection;
        this.ModelConstructor = this.typesystem.getTypeByCollectionName(this.collection.getCollectionName()).getModel();
        return this;
    };
    QueryObject$$1.prototype.getSelector = function () {
        return this.selector;
    };
    QueryObject$$1.prototype.getCursor = function () {
        return this.collection.find(this.selector, QueryUtils.convertQueryOptionsToMongoSelector(this.queryOptions, this.sorting));
    };
    QueryObject$$1.prototype.getModels = function (callback) {
        return this.cursorResolver.resolve(this.getCursor(), { ModelConstructor: this.ModelConstructor }, callback);
    };
    QueryObject$$1.prototype.getModel = function (index, callback) {
        return this.getModels(function (models) {
            callback(models[index]);
        })[index];
    };
    QueryObject$$1.prototype.subscribe = function (onReadyCallback) {
        var _this = this;
        Logger.debug("QueryObject", "Subscribing to '" + this.subscriptionName + "'!");
        this.collection.subscribe(this.subscriptionName, this.parameters, QueryUtils.convertQueryOptionsToMongoSelector(this.queryOptions, this.sorting), function (error) {
            _this.isSubscribed = error === undefined;
            onReadyCallback(error, _this);
        });
    };
    QueryObject$$1.prototype.expand = function (foreignKeys, callback) {
        this.collection.subscribeForeignKeys(this.getCursor(), foreignKeys, callback);
    };
    QueryObject$$1.prototype.getCount = function (callback) {
        this.collection.getQueryCount(this.subscriptionName, this.parameters, callback);
    };
    QueryObject$$1.prototype.getPage = function (pageNumber, callback) {
        var _this = this;
        this.queryOptions.currentPage = pageNumber;
        this.subscribe(function () {
            callback(_this.getModels());
        });
    };
    QueryObject$$1.prototype.getNextPage = function (callback) {
        var _this = this;
        if (this.hasNextPage()) {
            this.queryOptions.currentPage++;
            this.subscribe(function () {
                callback(_this.getModels());
            });
        }
        else {
            Logger.warning("QueryObject", "No next page available!");
            callback([]);
        }
    };
    QueryObject$$1.prototype.getCurrentPage = function (callback) {
        var _this = this;
        this.subscribe(function () {
            callback(_this.getModels());
        });
    };
    QueryObject$$1.prototype.getPreviousPage = function (callback) {
        var _this = this;
        if (this.hasPreviousPage()) {
            this.queryOptions.currentPage--;
            this.subscribe(function () {
                callback(_this.getModels());
            });
        }
        else {
            Logger.warning("QueryObject", "No previous page available!");
            callback([]);
        }
    };
    QueryObject$$1.prototype.hasNextPage = function () {
        return true;
    };
    QueryObject$$1.prototype.hasPreviousPage = function () {
        return this.queryOptions.currentPage > 1;
    };
    return QueryObject$$1;
}());

var Type$$1 = (function () {
    function Type$$1() {
    }
    Type$$1.fromDocument = function (doc) {
        var type = new Type$$1();
        _.extend(type, doc);
        type.name = doc.model.name;
        return type;
    };
    Type$$1.prototype.getServiceName = function () {
        if (this.service.name)
            return this.service.name;
        return this.collection.name.charAt(0).toUpperCase() + this.collection.name.slice(1) + "Service";
    };
    Type$$1.prototype.getModelName = function () {
        if (this.model.name)
            return this.model.name;
        throw new Error("No model name given! How did that happen...");
    };
    Type$$1.prototype.getService = function () {
        var serviceName = this.getServiceName();
        serviceName = serviceName.charAt(0).toLowerCase() + serviceName.slice(1);
        return IOC.get(serviceName);
    };
    Type$$1.prototype.getCollectionName = function () {
        if (this.collection)
            return this.collection.name;
        return undefined;
    };
    Type$$1.prototype.getModel = function () {
        return IOC.get(this.getModelName());
    };
    Type$$1.prototype.getServiceQueryByName = function (name) {
        return _.find(this.service.queries, function (query) { return query.name === name; });
    };
    Type$$1.prototype.getSchemaEntryByName = function (name) {
        return _.find(this.model.schema, function (schemaEntry) { return schemaEntry.name === name; });
    };
    return Type$$1;
}());

var Typesystem$$1 = (function () {
    function Typesystem$$1() {
        this._types = {};
    }
    Typesystem$$1.prototype.addType = function (type) {
        Logger.debug("Typesystem", "Adding type '" + type.name + "'!");
        this._types[type.name] = type;
    };
    Typesystem$$1.prototype.getTypeByName = function (name) {
        return this._types[name];
    };
    Typesystem$$1.prototype.getTypeByCollectionName = function (collectionName) {
        return _.find(this._types, function (type) {
            return type.collection && type.collection.name === collectionName;
        });
    };
    Typesystem$$1.prototype.getAllTypes = function () {
        return _.values(this._types);
    };
    Typesystem$$1.instance = function () {
        return IOC.get("typesystem");
    };
    return Typesystem$$1;
}());

var GeneratedEmailService = (function () {
    function GeneratedEmailService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedEmailService.instance = function () {
        return IOC.get("emailService");
    };
    GeneratedEmailService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("emails");
    };
    GeneratedEmailService.prototype.getAllMails = function (parameters, queryOptions) {
        return new QueryObject$$1().create({}, "getAllMails", queryOptions, parameters, { "createdAt": -1 }, this.getCollection());
    };
    GeneratedEmailService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedEmailService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "createdAt": model["createdAt"], "sentAt": model["sentAt"], "from": model["from"], "to": model["to"], "toUserIds": model["toUserIds"], "cc": model["cc"], "bcc": model["bcc"], "subjects": model["subjects"], "contents": model["contents"], "htmlMail": model["htmlMail"], "status": model["status"] } }, callback);
    };
    GeneratedEmailService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedEmailService;
}());

var __extends$5 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var EmailService = (function (_super) {
    __extends$5(EmailService, _super);
    function EmailService() {
        return _super.apply(this, arguments) || this;
    }
    return EmailService;
}(GeneratedEmailService));

var GeneratedEmail = (function () {
    function GeneratedEmail() {
        this.htmlMail = false;
        this.status = "CREATED";
        this._hasSubDocuments = true;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedEmail.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["createdAt"] = doc["createdAt"];
        model["sentAt"] = doc["sentAt"];
        model["from"] = doc["from"];
        model["to"] = doc["to"];
        model["toUserIds"] = doc["toUserIds"];
        model["cc"] = doc["cc"];
        model["bcc"] = doc["bcc"];
        model["subjects"] = doc["subjects"];
        model["contents"] = doc["contents"];
        model["htmlMail"] = doc["htmlMail"];
        model["status"] = doc["status"];
        return model;
    };
    GeneratedEmail.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["createdAt"] = this["createdAt"];
        doc["sentAt"] = this["sentAt"];
        doc["from"] = this["from"];
        doc["to"] = this["to"];
        doc["toUserIds"] = this["toUserIds"];
        doc["cc"] = this["cc"];
        doc["bcc"] = this["bcc"];
        doc["subjects"] = this["subjects"];
        doc["contents"] = this["contents"];
        doc["htmlMail"] = this["htmlMail"];
        doc["status"] = this["status"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedEmail.prototype.addToUserIds = function (ids) {
        if (this.toUserIds === undefined)
            this.toUserIds = [];
        _.each(ids, function (id) {
            if (!_.contains(this.toUserIds, id))
                this.toUserIds.push(id);
        }, this);
    };
    GeneratedEmail.prototype.getToUsers = function (options) {
        return IOC.get("userService").getUsersByIds({ ids: this.toUserIds }, options);
    };
    GeneratedEmail.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedEmail.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedEmail.getModelName = function () {
        return "Email";
    };
    GeneratedEmail.prototype.getModelName = function () {
        return "Email";
    };
    GeneratedEmail.getModelClass = function () {
        return IOC.get("Email");
    };
    GeneratedEmail.prototype.getModelClass = function () {
        return IOC.get("Email");
    };
    GeneratedEmail.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete Email with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed Email with ID '" + that.id + "'!");
            };
        }
        return EmailService.instance().delete(this, callback);
    };
    GeneratedEmail.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update Email with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated Email with ID '" + _this.id + "'!");
            };
        }
        return EmailService.instance().update(this, callback);
    };
    GeneratedEmail.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save Email!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved Email!");
                }
            };
        }
        if (this.dataBridge.isClient())
            EmailService.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = EmailService.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedEmail.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "createdAt": {
                "type": Date
            },
            "sentAt": {
                "type": Date,
                "optional": true
            },
            "from": {
                "type": String
            },
            "to": {
                "type": [String],
                "optional": true
            },
            "toUserIds": {
                "type": [String],
                "optional": true
            },
            "cc": {
                "type": [String],
                "optional": true
            },
            "bcc": {
                "type": [String],
                "optional": true
            },
            "subjects": {
                "type": Object,
                "blackbox": true
            },
            "contents": {
                "type": Object,
                "blackbox": true
            },
            "htmlMail": {
                "type": Boolean,
                "defaultValue": false,
                "optional": true
            },
            "status": {
                "type": String,
                "allowedValues": ["CREATED", "SCHEDULED", "SENDING", "SENT"],
                "defaultValue": "CREATED"
            },
        };
    };
    return GeneratedEmail;
}());
GeneratedEmail.enums = {
    "status": { "CREATED": "CREATED", "SCHEDULED": "SCHEDULED", "SENDING": "SENDING", "SENT": "SENT" }
};

var __extends$4 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Email$$1 = (function (_super) {
    __extends$4(Email$$1, _super);
    function Email$$1() {
        return _super.apply(this, arguments) || this;
    }
    return Email$$1;
}(GeneratedEmail));
IOC.register("Email", Email$$1);

var GeneratedEmailTemplatesService = (function () {
    function GeneratedEmailTemplatesService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedEmailTemplatesService.instance = function () {
        return IOC.get("emailTemplatesService");
    };
    GeneratedEmailTemplatesService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("emailtemplates");
    };
    GeneratedEmailTemplatesService.prototype.getAllTemplates = function (parameters, queryOptions) {
        return new QueryObject$$1().create({}, "getAllTemplates", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedEmailTemplatesService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedEmailTemplatesService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "name": model["name"], "from": model["from"], "subjects": model["subjects"], "contents": model["contents"], "htmlMail": model["htmlMail"], "systemTemplate": model["systemTemplate"] } }, callback);
    };
    GeneratedEmailTemplatesService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedEmailTemplatesService;
}());

var __extends$7 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var EmailTemplatesService = (function (_super) {
    __extends$7(EmailTemplatesService, _super);
    function EmailTemplatesService() {
        return _super.apply(this, arguments) || this;
    }
    return EmailTemplatesService;
}(GeneratedEmailTemplatesService));

var GeneratedEmailTemplate = (function () {
    function GeneratedEmailTemplate() {
        this.htmlMail = false;
        this.systemTemplate = false;
        this._hasSubDocuments = false;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedEmailTemplate.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["name"] = doc["name"];
        model["from"] = doc["from"];
        model["subjects"] = doc["subjects"];
        model["contents"] = doc["contents"];
        model["htmlMail"] = doc["htmlMail"];
        model["systemTemplate"] = doc["systemTemplate"];
        return model;
    };
    GeneratedEmailTemplate.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["name"] = this["name"];
        doc["from"] = this["from"];
        doc["subjects"] = this["subjects"];
        doc["contents"] = this["contents"];
        doc["htmlMail"] = this["htmlMail"];
        doc["systemTemplate"] = this["systemTemplate"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedEmailTemplate.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedEmailTemplate.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedEmailTemplate.getModelName = function () {
        return "EmailTemplate";
    };
    GeneratedEmailTemplate.prototype.getModelName = function () {
        return "EmailTemplate";
    };
    GeneratedEmailTemplate.getModelClass = function () {
        return IOC.get("EmailTemplate");
    };
    GeneratedEmailTemplate.prototype.getModelClass = function () {
        return IOC.get("EmailTemplate");
    };
    GeneratedEmailTemplate.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete EmailTemplate with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed EmailTemplate with ID '" + that.id + "'!");
            };
        }
        return EmailTemplatesService.instance().delete(this, callback);
    };
    GeneratedEmailTemplate.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update EmailTemplate with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated EmailTemplate with ID '" + _this.id + "'!");
            };
        }
        return EmailTemplatesService.instance().update(this, callback);
    };
    GeneratedEmailTemplate.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save EmailTemplate!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved EmailTemplate!");
                }
            };
        }
        if (this.dataBridge.isClient())
            EmailTemplatesService.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = EmailTemplatesService.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedEmailTemplate.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "name": {
                "type": String
            },
            "from": {
                "type": String
            },
            "subjects": {
                "type": Object,
                "blackbox": true
            },
            "contents": {
                "type": Object,
                "blackbox": true
            },
            "htmlMail": {
                "type": Boolean,
                "defaultValue": false,
                "optional": true
            },
            "systemTemplate": {
                "type": Boolean,
                "defaultValue": false,
                "optional": true
            },
        };
    };
    return GeneratedEmailTemplate;
}());

var __extends$6 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var EmailTemplate$$1 = (function (_super) {
    __extends$6(EmailTemplate$$1, _super);
    function EmailTemplate$$1() {
        return _super.apply(this, arguments) || this;
    }
    return EmailTemplate$$1;
}(GeneratedEmailTemplate));
IOC.register("EmailTemplate", EmailTemplate$$1);

var GeneratedLocalizationService = (function () {
    function GeneratedLocalizationService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedLocalizationService.instance = function () {
        return IOC.get("localizationService");
    };
    GeneratedLocalizationService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("localizations");
    };
    GeneratedLocalizationService.prototype.getLocalizationsForLanguage = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "language": parameters.languageKey }, "getLocalizationsForLanguage", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedLocalizationService.prototype.getLocalizationForLanguage = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "key": parameters.key, "language": parameters.languageKey }, "getLocalizationForLanguage", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedLocalizationService.prototype.getLocalizations = function (parameters, queryOptions) {
        return new QueryObject$$1().create({}, "getLocalizations", queryOptions, parameters, { "key": 1 }, this.getCollection());
    };
    GeneratedLocalizationService.prototype.getLocalizedTextsByIds = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": { "$in": parameters.ids } }, "getLocalizedTextsByIds", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedLocalizationService.prototype.getLocalizedTextById = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": parameters.id }, "getLocalizedTextById", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedLocalizationService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedLocalizationService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "key": model["key"], "value": model["value"], "language": model["language"] } }, callback);
    };
    GeneratedLocalizationService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedLocalizationService;
}());

var TextReplacer = (function () {
    function TextReplacer() {
    }
    TextReplacer.replace = function (content, context) {
        if (context) {
            _.each(context, function (value, key) {
                content = content.replace("${" + key + "}", value);
            });
        }
        return content;
    };
    return TextReplacer;
}());

var __extends$8 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var LocalizationService$$1 = (function (_super) {
    __extends$8(LocalizationService$$1, _super);
    function LocalizationService$$1() {
        var _this = _super.call(this) || this;
        _this.defaultLanguageChains = {};
        _this.localizationIsLoaded = false;
        _this.localizationCache = {};
        _this.configurationService = IOC.get("configurationService");
        _this.languageService = IOC.get("languageService");
        var that = _this;
        if (_this.dataBridge.isServer()) {
            _this.dataBridge.addServerMethod("setUserLanguage", function (languageKey) {
                that.setUserLanguage(languageKey);
            });
            _this.dataBridge.addServerMethod("getLocalizationForLanguage", function (languageKey) {
                if (languageKey === that.getFallbackLanguage())
                    return that.getCollection().find({ language: languageKey }, { limit: 50000 }).fetch();
                else
                    return that.getCollection().find({ $or: [{ language: languageKey }, { language: that.getFallbackLanguage() }] }, { limit: 50000 }).fetch();
            });
        }
        return _this;
    }
    LocalizationService$$1.prototype.getUserLanguage = function (userOrUserId) {
        if (typeof userOrUserId === "string") {
            var user = this.collectionsService.getCollectionByName("users").findOne(userOrUserId);
            if (!user)
                throw new Error("No synced user found with ID '" + userOrUserId + "'!");
            return user.profile.language;
        }
        else if (userOrUserId !== undefined && userOrUserId !== null && userOrUserId.profile && userOrUserId.profile.language !== undefined)
            return userOrUserId.profile.language;
        return undefined;
    };
    LocalizationService$$1.prototype.getCurrentLanguage = function () {
        if (this.dataBridge.isClient()) {
            var userLanguage = this.getUserLanguage(this.dataBridge.getCurrentUserId());
            if (userLanguage !== undefined)
                return userLanguage;
            var sessionLang = this.dataBridge.getSessionVariable("currentLanguage");
            if (sessionLang !== undefined)
                return sessionLang;
            var browserLanguage = this.getBrowserLanguage();
            if (browserLanguage !== undefined)
                return browserLanguage.split("-")[0];
        }
        return this.getFallbackLanguage();
    };
    LocalizationService$$1.prototype.setCurrentLanguage = function (languageKey) {
        if (this.dataBridge.userAuthenticated()) {
            if (this.dataBridge.isServer()) {
                this.setUserLanguage(languageKey);
            }
            else {
                this.dataBridge.callMethod("setUserLanguage", languageKey, function (error, success) {
                    if (error)
                        throw error;
                });
            }
        }
        else
            this.dataBridge.setSessionVariable("currentLanguage", languageKey);
    };
    LocalizationService$$1.prototype.setUserLanguage = function (languageKey) {
        if (this.dataBridge.isServer()) {
            if (this.dataBridge.userAuthenticated()) {
                if (this.isAvailableLanguageKey(languageKey)) {
                    throw new Error("NOT IMPLEMENTED YET!");
                }
                else {
                    throw new Error("501 - This is not a valid language key : " + languageKey);
                }
            }
            else {
                throw new Error("501 - No user logged in, so cannot set user language!");
            }
        }
        else
            throw new Error("501 - User Language can only be set on server side!");
    };
    LocalizationService$$1.prototype.getBrowserLanguage = function () {
        if (this.dataBridge.isClient())
            return navigator.language || navigator["userLanguage"];
        else
            throw new Error("501 - Cannot detect browser language on server!");
    };
    LocalizationService$$1.prototype.isAvailableLanguageKey = function (languageKey) {
        return true;
    };
    LocalizationService$$1.prototype.getFallbackLanguage = function () {
        return this.configurationService.get("defaultLanguage", "en");
    };
    LocalizationService$$1.prototype.getTranslation = function (key, options) {
        if (options === undefined)
            options = {};
        if (options.language === undefined)
            options.language = this.getCurrentLanguage();
        var value;
        if (this.localizationCache[options.language] && this.localizationCache[options.language][key])
            value = this.localizationCache[options.language][key];
        else {
            var translation = this.getCollection().findOne({
                "language": options.language,
                "key": key
            });
            if (translation) {
                this.addToCache(options.language, key, translation.value);
                value = translation.value;
            }
            else {
                var translationFallback = this.getCollection().findOne({
                    "language": this.getFallbackLanguage(),
                    "key": key
                });
                if (translationFallback)
                    value = translationFallback.value;
                else {
                    if (this.localizationCache[this.getFallbackLanguage()] && this.localizationCache[this.getFallbackLanguage()][key])
                        value = this.localizationCache[this.getFallbackLanguage()][key];
                }
            }
        }
        if (!value) {
            if (options.showMissingKey)
                return "_" + options.language + ":" + key + "_";
            else
                return undefined;
        }
        if (options && options.replacers)
            value = TextReplacer.replace(value, options.replacers);
        return value;
    };
    LocalizationService$$1.prototype.t = function (key, options) {
        return this.getTranslation(key, options);
    };
    LocalizationService$$1.t = function (key, options) {
        return LocalizationService$$1.instance().getTranslation(key, options);
    };
    LocalizationService$$1.prototype.addTranslation = function (languageKey, newTrans) {
        var _this = this;
        if (this.dataBridge.isServer()) {
            if (this.collectionsService.getCollectionByName("languages").findOne({ key: languageKey }) === undefined)
                return;
            _.map(Utils.flattenJSON(newTrans), function (value, key) {
                if (!value)
                    console.error("No value for key : ", key);
                _this.getCollection().upsert({ language: languageKey, key: key }, { $set: { language: languageKey, key: key, value: value } });
            });
        }
        else {
            _.map(Utils.flattenJSON(newTrans), function (value, key) {
                _this.addToCache(languageKey, key, value);
            });
        }
    };
    LocalizationService$$1.prototype.addToCache = function (languageId, key, value) {
        if (!this.localizationCache[languageId])
            this.localizationCache[languageId] = {};
        this.localizationCache[languageId][key] = value;
    };
    return LocalizationService$$1;
}(GeneratedLocalizationService));

var GeneratedLanguageService = (function () {
    function GeneratedLanguageService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedLanguageService.instance = function () {
        return IOC.get("languageService");
    };
    GeneratedLanguageService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("languages");
    };
    GeneratedLanguageService.prototype.getAllLanguages = function (parameters, queryOptions) {
        return new QueryObject$$1().create({}, "getAllLanguages", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedLanguageService.prototype.getLanguageByKey = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "key": parameters.key }, "getLanguageByKey", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedLanguageService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedLanguageService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "key": model["key"], "fallback": model["fallback"] } }, callback);
    };
    GeneratedLanguageService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedLanguageService;
}());

var __extends$9 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var LanguageService = (function (_super) {
    __extends$9(LanguageService, _super);
    function LanguageService() {
        return _super.apply(this, arguments) || this;
    }
    LanguageService.prototype.isLanguage = function (languageKey) {
        if (!this.dataBridge.isServer())
            throw new Error("LanguageService.isLanguage only works serverside!");
        var languages = this.getAllLanguages({}, { entriesPerPage: 1000 }).getModels();
        return _.find(languages, function (language) { return language.key === languageKey; }) !== undefined;
    };
    return LanguageService;
}(GeneratedLanguageService));

var GeneratedLanguage = (function () {
    function GeneratedLanguage() {
        this._hasSubDocuments = false;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedLanguage.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["key"] = doc["key"];
        model["fallback"] = doc["fallback"];
        return model;
    };
    GeneratedLanguage.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["key"] = this["key"];
        doc["fallback"] = this["fallback"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedLanguage.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedLanguage.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedLanguage.getModelName = function () {
        return "Language";
    };
    GeneratedLanguage.prototype.getModelName = function () {
        return "Language";
    };
    GeneratedLanguage.getModelClass = function () {
        return IOC.get("Language");
    };
    GeneratedLanguage.prototype.getModelClass = function () {
        return IOC.get("Language");
    };
    GeneratedLanguage.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete Language with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed Language with ID '" + that.id + "'!");
            };
        }
        return LanguageService.instance().delete(this, callback);
    };
    GeneratedLanguage.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update Language with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated Language with ID '" + _this.id + "'!");
            };
        }
        return LanguageService.instance().update(this, callback);
    };
    GeneratedLanguage.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save Language!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved Language!");
                }
            };
        }
        if (this.dataBridge.isClient())
            LanguageService.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = LanguageService.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedLanguage.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "key": {
                "type": String
            },
            "fallback": {
                "type": [String],
                "optional": true
            },
        };
    };
    return GeneratedLanguage;
}());

var __extends$12 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Language$$1 = (function (_super) {
    __extends$12(Language$$1, _super);
    function Language$$1() {
        return _super.apply(this, arguments) || this;
    }
    return Language$$1;
}(GeneratedLanguage));
IOC.register("Language", Language$$1);

var __extends$11 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var GeneratedLanguagesCollection = (function (_super) {
    __extends$11(GeneratedLanguagesCollection, _super);
    function GeneratedLanguagesCollection() {
        var _this = _super.call(this) || this;
        _this.name = "languages";
        _this.createCollection();
        _this.configureAllowDenyRules();
        _this.createSearchIndex();
        _this.collectionsService.registerCollection("languages", _this);
        _this.createPublications();
        return _this;
    }
    GeneratedLanguagesCollection.prototype.createPublications = function () {
        if (this.dataBridge.isServer()) {
            this.collectionsService.addPublisher("languages", "getAllLanguages", {}, {});
            this.collectionsService.addPublisher("languages", "getLanguageByKey", { "key": ":key" }, {});
        }
    };
    GeneratedLanguagesCollection.prototype.createSearchIndex = function () {
        if (Package["easysearch:core"]) {
            Logger.debug("EasySearch", "Creating search index for collection 'languages' and fields 'key,fallback,_id'!");
            this._easySearchIndex = new EasySearch.Index({
                collection: this._collection,
                fields: ["key", "fallback", "_id"],
                engine: new EasySearch.MongoDB()
            });
        }
    };
    GeneratedLanguagesCollection.prototype.createCollection = function () {
        this._collection = this.collectionsService.createCollection("languages", function (doc) {
            return Language$$1.fromDocument(doc);
        });
    };
    GeneratedLanguagesCollection.prototype.configureAllowDenyRules = function () {
        var allow = this.getCollectionAllowRules();
        if (allow !== undefined)
            this._collection.allow(allow);
        else {
            var deny = this.getCollectionDenyRules();
            if (deny !== undefined)
                this._collection.deny(deny);
            else
                console.warn("No allow/deny rules set for collection : languages");
        }
    };
    GeneratedLanguagesCollection.prototype.getCollectionAllowRules = function () {
        var that = this;
        return {
            insert: function (userId, doc) {
                return (userId && doc.ownerId === userId);
            },
            update: function (userId, doc, fields, modifier) {
                return doc.ownerId === userId;
            },
            remove: function (userId, doc) {
                return doc.ownerId === userId;
            },
            fetch: ['ownerId']
        };
    };
    GeneratedLanguagesCollection.prototype.getCollectionDenyRules = function () {
        return undefined;
    };
    GeneratedLanguagesCollection.prototype.getSchema = function () {
        return GeneratedLanguage.getSchema();
    };
    GeneratedLanguagesCollection.prototype.getForeignCollection = function (typeName) {
        switch (typeName) {
        }
        return undefined;
    };
    GeneratedLanguagesCollection.prototype.getForeignGetter = function () {
        return "getLanguagesByIds";
    };
    GeneratedLanguagesCollection.getForeignGetter = function () {
        return "getLanguagesByIds";
    };
    GeneratedLanguagesCollection.prototype.getModelName = function () {
        return "Language";
    };
    GeneratedLanguagesCollection.prototype.getServiceName = function () {
        return "languageService";
    };
    GeneratedLanguagesCollection.prototype.getQueries = function () {
        return GeneratedLanguagesCollection.queries;
    };
    GeneratedLanguagesCollection.prototype.getCollectionName = function () {
        return "languages";
    };
    GeneratedLanguagesCollection.getCollection = function () {
        return IOC.get("collectionsService").getCollectionByName("languages");
    };
    return GeneratedLanguagesCollection;
}(BaseCollection$$1));
GeneratedLanguagesCollection.queries = {
    "getAllLanguages": { name: "getAllLanguages", parameters: {} },
    "getLanguageByKey": { name: "getLanguageByKey", parameters: { key: "key" } }
};
GeneratedLanguagesCollection.expandables = {};

var __extends$10 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var LanguagesCollection = (function (_super) {
    __extends$10(LanguagesCollection, _super);
    function LanguagesCollection() {
        return _super.call(this) || this;
    }
    return LanguagesCollection;
}(GeneratedLanguagesCollection));

var GeneratedLocalizedText = (function () {
    function GeneratedLocalizedText() {
        this._hasSubDocuments = false;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedLocalizedText.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["key"] = doc["key"];
        model["value"] = doc["value"];
        model["language"] = doc["language"];
        return model;
    };
    GeneratedLocalizedText.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["key"] = this["key"];
        doc["value"] = this["value"];
        doc["language"] = this["language"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedLocalizedText.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedLocalizedText.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedLocalizedText.getModelName = function () {
        return "LocalizedText";
    };
    GeneratedLocalizedText.prototype.getModelName = function () {
        return "LocalizedText";
    };
    GeneratedLocalizedText.getModelClass = function () {
        return IOC.get("LocalizedText");
    };
    GeneratedLocalizedText.prototype.getModelClass = function () {
        return IOC.get("LocalizedText");
    };
    GeneratedLocalizedText.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete LocalizedText with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed LocalizedText with ID '" + that.id + "'!");
            };
        }
        return LocalizationService$$1.instance().delete(this, callback);
    };
    GeneratedLocalizedText.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update LocalizedText with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated LocalizedText with ID '" + _this.id + "'!");
            };
        }
        return LocalizationService$$1.instance().update(this, callback);
    };
    GeneratedLocalizedText.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save LocalizedText!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved LocalizedText!");
                }
            };
        }
        if (this.dataBridge.isClient())
            LocalizationService$$1.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = LocalizationService$$1.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedLocalizedText.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "key": {
                "type": String
            },
            "value": {
                "type": String,
                "optional": true
            },
            "language": {
                "type": String
            },
        };
    };
    return GeneratedLocalizedText;
}());

var __extends$15 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var LocalizedText$$1 = (function (_super) {
    __extends$15(LocalizedText$$1, _super);
    function LocalizedText$$1() {
        return _super.apply(this, arguments) || this;
    }
    return LocalizedText$$1;
}(GeneratedLocalizedText));
IOC.register("LocalizedText", LocalizedText$$1);

var __extends$14 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var GeneratedLocalizationsCollection = (function (_super) {
    __extends$14(GeneratedLocalizationsCollection, _super);
    function GeneratedLocalizationsCollection() {
        var _this = _super.call(this) || this;
        _this.name = "localizations";
        _this.createCollection();
        _this.configureAllowDenyRules();
        _this.createSearchIndex();
        _this.collectionsService.registerCollection("localizations", _this);
        _this.createPublications();
        return _this;
    }
    GeneratedLocalizationsCollection.prototype.createPublications = function () {
        if (this.dataBridge.isServer()) {
            this.collectionsService.addPublisher("localizations", "getLocalizationsForLanguage", { "language": ":languageKey" }, {});
            this.collectionsService.addPublisher("localizations", "getLocalizationForLanguage", { "key": ":key", "language": ":languageKey" }, {});
            this.collectionsService.addPublisher("localizations", "getLocalizations", {}, {});
            this.collectionsService.addPublisher("localizations", "getLocalizedTextsByIds", { "_id": { "$in": ":ids:string[]" } }, {});
            this.collectionsService.addPublisher("localizations", "getLocalizedTextById", { "_id": ":id:string" }, {});
        }
    };
    GeneratedLocalizationsCollection.prototype.createSearchIndex = function () {
        if (Package["easysearch:core"]) {
            Logger.debug("EasySearch", "Creating search index for collection 'localizations' and fields 'key,value,language,_id'!");
            this._easySearchIndex = new EasySearch.Index({
                collection: this._collection,
                fields: ["key", "value", "language", "_id"],
                engine: new EasySearch.MongoDB()
            });
        }
    };
    GeneratedLocalizationsCollection.prototype.createCollection = function () {
        this._collection = this.collectionsService.createCollection("localizations", function (doc) {
            return LocalizedText$$1.fromDocument(doc);
        });
    };
    GeneratedLocalizationsCollection.prototype.configureAllowDenyRules = function () {
        var allow = this.getCollectionAllowRules();
        if (allow !== undefined)
            this._collection.allow(allow);
        else {
            var deny = this.getCollectionDenyRules();
            if (deny !== undefined)
                this._collection.deny(deny);
            else
                console.warn("No allow/deny rules set for collection : localizations");
        }
    };
    GeneratedLocalizationsCollection.prototype.getCollectionAllowRules = function () {
        var that = this;
        return {
            insert: function (userId, doc) {
                return (userId && doc.ownerId === userId);
            },
            update: function (userId, doc, fields, modifier) {
                return doc.ownerId === userId;
            },
            remove: function (userId, doc) {
                return doc.ownerId === userId;
            },
            fetch: ['ownerId']
        };
    };
    GeneratedLocalizationsCollection.prototype.getCollectionDenyRules = function () {
        return undefined;
    };
    GeneratedLocalizationsCollection.prototype.getSchema = function () {
        return GeneratedLocalizedText.getSchema();
    };
    GeneratedLocalizationsCollection.prototype.getForeignCollection = function (typeName) {
        switch (typeName) {
        }
        return undefined;
    };
    GeneratedLocalizationsCollection.prototype.getForeignGetter = function () {
        return "getLocalizedTextsByIds";
    };
    GeneratedLocalizationsCollection.getForeignGetter = function () {
        return "getLocalizedTextsByIds";
    };
    GeneratedLocalizationsCollection.prototype.getModelName = function () {
        return "LocalizedText";
    };
    GeneratedLocalizationsCollection.prototype.getServiceName = function () {
        return "localizationService";
    };
    GeneratedLocalizationsCollection.prototype.getQueries = function () {
        return GeneratedLocalizationsCollection.queries;
    };
    GeneratedLocalizationsCollection.prototype.getCollectionName = function () {
        return "localizations";
    };
    GeneratedLocalizationsCollection.getCollection = function () {
        return IOC.get("collectionsService").getCollectionByName("localizations");
    };
    return GeneratedLocalizationsCollection;
}(BaseCollection$$1));
GeneratedLocalizationsCollection.queries = {
    "getLocalizationsForLanguage": { name: "getLocalizationsForLanguage", parameters: { languageKey: "languageKey" } },
    "getLocalizationForLanguage": { name: "getLocalizationForLanguage", parameters: { key: "key", languageKey: "languageKey" } },
    "getLocalizations": { name: "getLocalizations", parameters: {} },
    "getLocalizedTextsByIds": { name: "getLocalizedTextsByIds", parameters: { ids: "ids" } },
    "getLocalizedTextById": { name: "getLocalizedTextById", parameters: { id: "id" } }
};
GeneratedLocalizationsCollection.expandables = {};

var __extends$13 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var LocalizationsCollection = (function (_super) {
    __extends$13(LocalizationsCollection, _super);
    function LocalizationsCollection() {
        return _super.call(this) || this;
    }
    return LocalizationsCollection;
}(GeneratedLocalizationsCollection));

var GeneratedI18nText = (function () {
    function GeneratedI18nText() {
        this._hasSubDocuments = false;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedI18nText.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["language"] = doc["language"];
        model["value"] = doc["value"];
        return model;
    };
    GeneratedI18nText.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["language"] = this["language"];
        doc["value"] = this["value"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedI18nText.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedI18nText.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedI18nText.getModelName = function () {
        return "I18nText";
    };
    GeneratedI18nText.prototype.getModelName = function () {
        return "I18nText";
    };
    GeneratedI18nText.getModelClass = function () {
        return IOC.get("I18nText");
    };
    GeneratedI18nText.prototype.getModelClass = function () {
        return IOC.get("I18nText");
    };
    GeneratedI18nText.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "language": {
                "type": String
            },
            "value": {
                "type": String
            },
        };
    };
    return GeneratedI18nText;
}());

var __extends$16 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var I18nText$$1 = (function (_super) {
    __extends$16(I18nText$$1, _super);
    function I18nText$$1() {
        return _super.apply(this, arguments) || this;
    }
    return I18nText$$1;
}(GeneratedI18nText));
IOC.register("I18nText", I18nText$$1);

function initLanguages(languages) {
    var languageService = LanguageService.instance();
    var savedLanguages = {};
    languageService.getAllLanguages().getModels().forEach(function (lang) {
        savedLanguages[lang.key] = lang;
    });
    _.each(languages, function (language) {
        var savedLanguage = savedLanguages[language.key];
        if (!savedLanguage)
            language.save();
        else {
            savedLanguage.fallback = language.fallback;
            savedLanguage.update();
        }
    });
}

var GeneratedPushNotificationService = (function () {
    function GeneratedPushNotificationService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedPushNotificationService.instance = function () {
        return IOC.get("pushNotificationService");
    };
    GeneratedPushNotificationService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("pushnotifications");
    };
    GeneratedPushNotificationService.prototype.getAllPushNotifications = function (parameters, queryOptions) {
        return new QueryObject$$1().create({}, "getAllPushNotifications", queryOptions, parameters, { "createdAt": 1 }, this.getCollection());
    };
    GeneratedPushNotificationService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedPushNotificationService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "subjects": model["subjects"], "contents": model["contents"], "createdAt": model["createdAt"], "sentAt": model["sentAt"], "reachedCount": model["reachedCount"], "sent": model["sent"] } }, callback);
    };
    GeneratedPushNotificationService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedPushNotificationService;
}());

var __extends$17 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var DeviceTypes$$1 = {
    "ios": "ios",
    "android": "android",
    "amazon": "amazon",
    "windowsphonempns": "windowsphonempns",
    "chromeapporextension": "chromeapporextension",
    "chromewebpush": "chromewebpush",
    "windowsphonewns": "windowsphonewns",
    "safari": "safari",
    "firefox": "firefox",
    "macos": "macos"
};
var PushNotificationService$$1 = (function (_super) {
    __extends$17(PushNotificationService$$1, _super);
    function PushNotificationService$$1() {
        var _this = _super.call(this) || this;
        _this.oneSignalApiUrl = "https://onesignal.com/api/v1";
        _this.configurationService = ConfigurationService$$1.instance();
        _this.configurationService.onSet("onesignal.appid", function (appId) {
            _this.appId = appId;
        });
        _this.configurationService.onSet("onesignal.restapikey", function (restapikey) {
            _this.restApiKey = restapikey;
        });
        return _this;
    }
    PushNotificationService$$1.prototype.sendNotification = function (pushNotification, includedSegments) {
        if (includedSegments === void 0) { includedSegments = ["Active Users"]; }
        if (!this.dataBridge.isServer())
            throw new Error("403 - You can send notifications only serverside!");
        var response = request.post(this.oneSignalApiUrl + "/notifications", {
            data: {
                app_id: this.appId,
                contents: pushNotification.contents,
                headings: pushNotification.subjects,
                included_segments: includedSegments
            },
            headers: {
                "Content-Type": "application/json; charset=utf-8",
                "Authorization": "Basic " + this.restApiKey
            }
        });
        if (response.statusCode === 200) {
            pushNotification.sentAt = new Date();
            pushNotification.reachedCount = response.data.recipients;
            pushNotification.update();
        }
    };
    PushNotificationService$$1.prototype.registerDevice = function (identifier, deviceType, ISOlanguage) {
        if (!this.dataBridge.isServer())
            throw new Error("403 - You can register devices only serverside!");
        var response = request.post(this.oneSignalApiUrl + "/players", {
            data: {
                app_id: this.appId,
                device_type: this.signalOneDeviceMapping(deviceType),
                identifier: identifier,
                language: ISOlanguage,
                created_at: new Date()
            }
        });
        if (response.statusCode !== 200)
            throw new Error(response.statusCode + "Could not add device!" + JSON.stringify(response.content));
    };
    PushNotificationService$$1.prototype.signalOneDeviceMapping = function (deviceString) {
        switch (deviceString) {
            case "ios": return 0;
            case "android": return 1;
            case "amazon": return 2;
            case "windowsphonempns": return 3;
            case "chromeapporextension": return 4;
            case "chromewebpush": return 5;
            case "windowsphonewns": return 6;
            case "safari": return 7;
            case "firefox": return 8;
            case "macos": return 9;
            default:
                throw new Error("device type '" + deviceString + "' is unknown. Known types are : " + _.keys(DeviceTypes$$1));
        }
    };
    return PushNotificationService$$1;
}(GeneratedPushNotificationService));

var ConsoleNotifier = (function () {
    function ConsoleNotifier() {
    }
    ConsoleNotifier.prototype.log = function (title, message, level) {
        switch (level) {
            case "debug":
                console.debug(title + " - " + message);
                break;
            case "error":
                console.error(title + " - " + message);
                break;
            case "warn":
                console.warn(title + " - " + message);
                break;
            case "info":
            case "success":
            default:
                console.log(title + " - " + message);
        }
    };
    ConsoleNotifier.prototype.info = function (title, message) {
        this.log(title, message, "info");
    };
    ConsoleNotifier.prototype.success = function (title, message) {
        this.log(title, message, "success");
    };
    ConsoleNotifier.prototype.debug = function (title, message) {
        this.log(title, message, "debug");
    };
    ConsoleNotifier.prototype.warn = function (title, message) {
        this.log(title, message, "warn");
    };
    ConsoleNotifier.prototype.error = function (title, message) {
        this.log(title, message, "error");
    };
    ConsoleNotifier.prototype.confirmation = function (title, message, callback) {
        throw new Error("Console Notifier cannot ask questions!");
    };
    return ConsoleNotifier;
}());

var NotificationService$$1 = (function () {
    function NotificationService$$1() {
        this.console = new ConsoleNotifier();
    }
    NotificationService$$1.instance = function () {
        return IOC.get("notificationService");
    };
    NotificationService$$1.prototype.getStandardCallback = function (errorMsg, successMsg) {
        if (errorMsg === undefined)
            errorMsg = "Error";
        if (successMsg === undefined)
            successMsg = "Successful";
        var that = this;
        return function (error, result) {
            if (error !== undefined)
                that.getStandardErrorPopup(error, errorMsg);
            else
                that.notification.success(successMsg + (result !== undefined ? " [" + result + "]" : ""));
        };
    };
    NotificationService$$1.prototype.getStandardErrorPopup = function (error, additionalText) {
        Logger.error("UI", "Error : ", error);
        var detailedMessage = "";
        if (!Utils.isEmptyString(error.statusText))
            detailedMessage += error.statusText + "<br>";
        if (!Utils.isEmptyString(error.responseText))
            detailedMessage += error.responseText + "<br>";
        if (!Utils.isEmptyString(error.error))
            detailedMessage += error.error + "<br>";
        if (!Utils.isEmptyString(error.reason))
            detailedMessage += error.reason + "<br>";
        if (typeof error.reason === "object")
            detailedMessage += JSON.stringify(error.reason) + "<br>";
        if (!Utils.isEmptyString(error.message))
            detailedMessage += error.message + "<br>";
        if (!Utils.isEmptyString(error.details))
            detailedMessage += error.details + "<br>";
        this.popup.error(additionalText + "<br><small>Details : " + detailedMessage + "</small>");
    };
    NotificationService$$1.prototype.setConsoleNotifier = function (notifier) {
        this.console = notifier;
    };
    NotificationService$$1.prototype.setPopupNotifier = function (notifier) {
        this.popup = notifier;
    };
    NotificationService$$1.prototype.setNotificationNotifier = function (notifier) {
        this.notification = notifier;
    };
    return NotificationService$$1;
}());

var GeneratedNavigationEntry = (function () {
    function GeneratedNavigationEntry() {
        this.requiresAuthentication = true;
        this.visibility = "alwaysVisible";
        this.abstract = false;
        this.defaultRoute = false;
        this.trackingEnabled = true;
        this._hasSubDocuments = true;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedNavigationEntry.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["label"] = doc["label"];
        model["i18nLabel"] = doc["i18nLabel"];
        model["icon"] = doc["icon"];
        model["route"] = doc["route"];
        model["requiresAuthentication"] = doc["requiresAuthentication"];
        model["loginRoute"] = doc["loginRoute"];
        model["requiredRole"] = doc["requiredRole"];
        model["templateUrl"] = doc["templateUrl"];
        model["controllerName"] = doc["controllerName"];
        model["pageId"] = doc["pageId"];
        model["visibility"] = doc["visibility"];
        model["index"] = doc["index"];
        model["type"] = doc["type"];
        model["stateName"] = doc["stateName"];
        model["abstract"] = doc["abstract"];
        model["defaultRoute"] = doc["defaultRoute"];
        model["substateOfId"] = doc["substateOfId"];
        model["badge"] = doc["badge"];
        model["trackingEnabled"] = doc["trackingEnabled"];
        model["redirectTo"] = doc["redirectTo"];
        return model;
    };
    GeneratedNavigationEntry.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["label"] = this["label"];
        doc["i18nLabel"] = this["i18nLabel"];
        doc["icon"] = this["icon"];
        doc["route"] = this["route"];
        doc["requiresAuthentication"] = this["requiresAuthentication"];
        doc["loginRoute"] = this["loginRoute"];
        doc["requiredRole"] = this["requiredRole"];
        doc["templateUrl"] = this["templateUrl"];
        doc["controllerName"] = this["controllerName"];
        doc["pageId"] = this["pageId"];
        doc["visibility"] = this["visibility"];
        doc["index"] = this["index"];
        doc["type"] = this["type"];
        doc["stateName"] = this["stateName"];
        doc["abstract"] = this["abstract"];
        doc["defaultRoute"] = this["defaultRoute"];
        doc["substateOfId"] = this["substateOfId"];
        doc["badge"] = this["badge"];
        doc["trackingEnabled"] = this["trackingEnabled"];
        doc["redirectTo"] = this["redirectTo"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedNavigationEntry.prototype.getSubstateOf = function (options) {
        return IOC.get("navigationService").getNavigationEntryById({ id: this.substateOfId }, options);
    };
    GeneratedNavigationEntry.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedNavigationEntry.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedNavigationEntry.getModelName = function () {
        return "NavigationEntry";
    };
    GeneratedNavigationEntry.prototype.getModelName = function () {
        return "NavigationEntry";
    };
    GeneratedNavigationEntry.getModelClass = function () {
        return IOC.get("NavigationEntry");
    };
    GeneratedNavigationEntry.prototype.getModelClass = function () {
        return IOC.get("NavigationEntry");
    };
    GeneratedNavigationEntry.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete NavigationEntry with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed NavigationEntry with ID '" + that.id + "'!");
            };
        }
        return NavigationService$$1.instance().delete(this, callback);
    };
    GeneratedNavigationEntry.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update NavigationEntry with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated NavigationEntry with ID '" + _this.id + "'!");
            };
        }
        return NavigationService$$1.instance().update(this, callback);
    };
    GeneratedNavigationEntry.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save NavigationEntry!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved NavigationEntry!");
                }
            };
        }
        if (this.dataBridge.isClient())
            NavigationService$$1.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = NavigationService$$1.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedNavigationEntry.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "label": {
                "type": String,
                "optional": true
            },
            "i18nLabel": {
                "type": String,
                "optional": true
            },
            "icon": {
                "type": String,
                "optional": true
            },
            "route": {
                "type": String
            },
            "requiresAuthentication": {
                "type": Boolean,
                "defaultValue": true
            },
            "loginRoute": {
                "type": String,
                "optional": true
            },
            "requiredRole": {
                "type": String,
                "optional": true
            },
            "templateUrl": {
                "type": String,
                "optional": true
            },
            "controllerName": {
                "type": String,
                "optional": true
            },
            "pageId": {
                "type": String,
                "optional": true
            },
            "visibility": {
                "type": String,
                "allowedValues": ["alwaysVisible", "alwaysHidden", "onlyAnonymous", "onlyAuthenticated"],
                "defaultValue": "alwaysVisible"
            },
            "index": {
                "type": Number
            },
            "type": {
                "type": String,
                "optional": true
            },
            "stateName": {
                "type": String
            },
            "abstract": {
                "type": Boolean,
                "defaultValue": false,
                "optional": true
            },
            "defaultRoute": {
                "type": Boolean,
                "defaultValue": false,
                "optional": true
            },
            "substateOfId": {
                "type": String,
                "optional": true
            },
            "badge": {
                "type": Number,
                "optional": true
            },
            "trackingEnabled": {
                "type": Boolean,
                "defaultValue": true
            },
            "redirectTo": {
                "type": String,
                "optional": true
            },
        };
    };
    return GeneratedNavigationEntry;
}());
GeneratedNavigationEntry.enums = {
    "visibility": { "ALWAYSVISIBLE": "alwaysVisible", "ALWAYSHIDDEN": "alwaysHidden", "ONLYANONYMOUS": "onlyAnonymous", "ONLYAUTHENTICATED": "onlyAuthenticated" },
};

var __extends$21 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var NavigationEntry$$1 = (function (_super) {
    __extends$21(NavigationEntry$$1, _super);
    function NavigationEntry$$1() {
        var _this = _super.apply(this, arguments) || this;
        _this.subEntriesAvailable = false;
        return _this;
    }
    NavigationEntry$$1.new = function () {
        return new NavigationEntry$$1();
    };
    NavigationEntry$$1.prototype.setLabel = function (label) {
        this.label = label;
        return this;
    };
    NavigationEntry$$1.prototype.getLabel = function () {
        return this.label;
    };
    NavigationEntry$$1.prototype.setI18nLabel = function (label) {
        this.i18nLabel = label;
        return this;
    };
    NavigationEntry$$1.prototype.getI18nLabel = function () {
        return this.i18nLabel;
    };
    NavigationEntry$$1.prototype.setRoute = function (route) {
        if (route.charAt(0) !== "/")
            throw new Error("Route for NavigationEntry has to start with a '/'!");
        this.route = route;
        return this;
    };
    NavigationEntry$$1.prototype.getRoute = function () {
        if (this.route === undefined && this.abstract !== true)
            throw new Error("No route set for navigation entry : " + JSON.stringify(this, null, 2));
        return this.route;
    };
    NavigationEntry$$1.prototype.setRequiresAuthentication = function (requiresAuthentication, loginRoute) {
        this.requiresAuthentication = requiresAuthentication;
        if (loginRoute !== undefined)
            this.loginRoute = loginRoute;
        return this;
    };
    NavigationEntry$$1.prototype.doesRequireAuthentication = function () {
        return this.requiresAuthentication;
    };
    NavigationEntry$$1.prototype.setRequiredRole = function (requiredRole) {
        this.requiredRole = requiredRole;
        return this;
    };
    NavigationEntry$$1.prototype.getRequiredRole = function () {
        return this.requiredRole;
    };
    NavigationEntry$$1.prototype.setVisible = function (visible) {
        if (visible)
            this.setVisibility(NavigationEntry$$1.enums.visibility.ALWAYSVISIBLE);
        else
            this.setVisibility(NavigationEntry$$1.enums.visibility.ALWAYSHIDDEN);
        return this;
    };
    NavigationEntry$$1.prototype.setVisibility = function (visibility) {
        this.visibility = visibility;
        return this;
    };
    NavigationEntry$$1.prototype.isVisible = function () {
        if (this.visibility === NavigationEntry$$1.enums.visibility.ALWAYSVISIBLE)
            return true;
        if (this.visibility === NavigationEntry$$1.enums.visibility.ALWAYSHIDDEN)
            return false;
        if (this.visibility === NavigationEntry$$1.enums.visibility.ONLYANONYMOUS)
            return !this.dataBridge.userAuthenticated();
        if (this.visibility === NavigationEntry$$1.enums.visibility.ONLYAUTHENTICATED)
            return this.dataBridge.userAuthenticated();
        return true;
    };
    NavigationEntry$$1.prototype.setIndex = function (index) {
        this.index = index;
        return this;
    };
    NavigationEntry$$1.prototype.getIndex = function () {
        return this.index;
    };
    NavigationEntry$$1.prototype.setType = function (type) {
        this.type = type;
        return this;
    };
    NavigationEntry$$1.prototype.getType = function () {
        return this.type;
    };
    NavigationEntry$$1.prototype.setIcon = function (icon) {
        this.icon = icon;
        return this;
    };
    NavigationEntry$$1.prototype.getIcon = function () {
        if (this.icon === undefined)
            Logger.debug("NavigationEntry", "No icon set for route : " + this.getLabel());
        return this.icon;
    };
    NavigationEntry$$1.prototype.setDefaultRoute = function (defaultRoute) {
        this.defaultRoute = defaultRoute;
        return this;
    };
    NavigationEntry$$1.prototype.isDefaultRoute = function () {
        return this.defaultRoute;
    };
    NavigationEntry$$1.prototype.setChildOfRoute = function (parentRoute) {
        this.childOfRoute = parentRoute;
        return this;
    };
    NavigationEntry$$1.prototype.getChildOfRoute = function () {
        return this.childOfRoute;
    };
    NavigationEntry$$1.prototype.setPageId = function (pageId) {
        this.pageId = pageId;
        return this;
    };
    NavigationEntry$$1.prototype.hasSubEntries = function () {
        return this.subEntriesAvailable;
    };
    NavigationEntry$$1.prototype.setSubEntriesAvailable = function (hasSubEntries) {
        this.subEntriesAvailable = hasSubEntries;
        return this;
    };
    NavigationEntry$$1.prototype.setComponent = function (component) {
        this.component = component;
        return this;
    };
    NavigationEntry$$1.prototype.getComponent = function () {
        return this.component;
    };
    NavigationEntry$$1.prototype.setRedirectTo = function (redirectTo) {
        this.redirectTo = redirectTo;
        return this;
    };
    NavigationEntry$$1.prototype.getRedirectTo = function () {
        return this.redirectTo;
    };
    return NavigationEntry$$1;
}(GeneratedNavigationEntry));

var __extends$20 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var GeneratedNavigationCollection = (function (_super) {
    __extends$20(GeneratedNavigationCollection, _super);
    function GeneratedNavigationCollection() {
        var _this = _super.call(this) || this;
        _this.name = "navigation";
        _this.createCollection();
        _this.configureAllowDenyRules();
        _this.createSearchIndex();
        _this.collectionsService.registerCollection("navigation", _this);
        _this.createPublications();
        return _this;
    }
    GeneratedNavigationCollection.prototype.createPublications = function () {
        if (this.dataBridge.isServer()) {
            this.collectionsService.addPublisher("navigation", "getNavigationForType", { "type": ":type" }, {});
            this.collectionsService.addPublisher("navigation", "getNavigationEntryById", { "_id": ":id:string" }, {});
        }
    };
    GeneratedNavigationCollection.prototype.createSearchIndex = function () {
        if (Package["easysearch:core"]) {
            Logger.debug("EasySearch", "Creating search index for collection 'navigation' and fields 'label,i18nLabel,icon,route,requiresAuthentication,loginRoute,requiredRole,templateUrl,controllerName,pageId,visibility,index,type,stateName,abstract,defaultRoute,substateOfId,badge,trackingEnabled,redirectTo,_id'!");
            this._easySearchIndex = new EasySearch.Index({
                collection: this._collection,
                fields: ["label", "i18nLabel", "icon", "route", "requiresAuthentication", "loginRoute", "requiredRole", "templateUrl", "controllerName", "pageId", "visibility", "index", "type", "stateName", "abstract", "defaultRoute", "substateOfId", "badge", "trackingEnabled", "redirectTo", "_id"],
                engine: new EasySearch.MongoDB()
            });
        }
    };
    GeneratedNavigationCollection.prototype.createCollection = function () {
        this._collection = this.collectionsService.createCollection("navigation", function (doc) {
            return NavigationEntry$$1.fromDocument(doc);
        });
    };
    GeneratedNavigationCollection.prototype.configureAllowDenyRules = function () {
        var allow = this.getCollectionAllowRules();
        if (allow !== undefined)
            this._collection.allow(allow);
        else {
            var deny = this.getCollectionDenyRules();
            if (deny !== undefined)
                this._collection.deny(deny);
            else
                console.warn("No allow/deny rules set for collection : navigation");
        }
    };
    GeneratedNavigationCollection.prototype.getCollectionAllowRules = function () {
        var that = this;
        return {
            insert: function (userId, doc) {
                return (userId && doc.ownerId === userId);
            },
            update: function (userId, doc, fields, modifier) {
                return doc.ownerId === userId;
            },
            remove: function (userId, doc) {
                return doc.ownerId === userId;
            },
            fetch: ['ownerId']
        };
    };
    GeneratedNavigationCollection.prototype.getCollectionDenyRules = function () {
        return undefined;
    };
    GeneratedNavigationCollection.prototype.getSchema = function () {
        return GeneratedNavigationEntry.getSchema();
    };
    GeneratedNavigationCollection.prototype.getForeignCollection = function (typeName) {
        switch (typeName) {
            case "substateOfId":
                return this.typesystem.getTypeByName("NavigationEntry").getCollectionName();
        }
        return undefined;
    };
    GeneratedNavigationCollection.prototype.getForeignGetter = function () {
        return "getNavigationEntriesByIds";
    };
    GeneratedNavigationCollection.getForeignGetter = function () {
        return "getNavigationEntriesByIds";
    };
    GeneratedNavigationCollection.prototype.getModelName = function () {
        return "NavigationEntry";
    };
    GeneratedNavigationCollection.prototype.getServiceName = function () {
        return "navigationService";
    };
    GeneratedNavigationCollection.prototype.getQueries = function () {
        return GeneratedNavigationCollection.queries;
    };
    GeneratedNavigationCollection.prototype.getCollectionName = function () {
        return "navigation";
    };
    GeneratedNavigationCollection.getCollection = function () {
        return IOC.get("collectionsService").getCollectionByName("navigation");
    };
    return GeneratedNavigationCollection;
}(BaseCollection$$1));
GeneratedNavigationCollection.queries = {
    "getNavigationForType": { name: "getNavigationForType", parameters: { type: "type" } },
    "getNavigationEntryById": { name: "getNavigationEntryById", parameters: { id: "id" } }
};
GeneratedNavigationCollection.expandables = { "substateOfId": "substateOfId" };

var __extends$19 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var NavigationCollection = (function (_super) {
    __extends$19(NavigationCollection, _super);
    function NavigationCollection() {
        return _super.call(this) || this;
    }
    return NavigationCollection;
}(GeneratedNavigationCollection));

var GeneratedNavigationService = (function () {
    function GeneratedNavigationService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedNavigationService.instance = function () {
        return IOC.get("navigationService");
    };
    GeneratedNavigationService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("navigation");
    };
    GeneratedNavigationService.prototype.getNavigationForType = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "type": parameters.type }, "getNavigationForType", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedNavigationService.prototype.getNavigationEntryById = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": parameters.id }, "getNavigationEntryById", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedNavigationService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedNavigationService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "label": model["label"], "i18nLabel": model["i18nLabel"], "icon": model["icon"], "route": model["route"], "requiresAuthentication": model["requiresAuthentication"], "loginRoute": model["loginRoute"], "requiredRole": model["requiredRole"], "templateUrl": model["templateUrl"], "controllerName": model["controllerName"], "pageId": model["pageId"], "visibility": model["visibility"], "index": model["index"], "type": model["type"], "stateName": model["stateName"], "abstract": model["abstract"], "defaultRoute": model["defaultRoute"], "substateOfId": model["substateOfId"], "badge": model["badge"], "trackingEnabled": model["trackingEnabled"], "redirectTo": model["redirectTo"] } }, callback);
    };
    GeneratedNavigationService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedNavigationService;
}());

var __extends$18 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var NavigationService$$1 = (function (_super) {
    __extends$18(NavigationService$$1, _super);
    function NavigationService$$1() {
        var _this = _super.call(this) || this;
        _this.navigation = [];
        _this.dbNavigation = [];
        _this.layouts = {};
        _this.onNavigationEntryAddFns = [];
        _this.navigationInitialized = false;
        _this.configurationService = IOC.get("configurationService");
        _this.rolesService = IOC.get("rolesService");
        return _this;
    }
    NavigationService$$1.getCurrent = function () {
        return IOC.get("navigationService");
    };
    NavigationService$$1.prototype.setModel = function (model) {
        var _this = this;
        this.navigation = [];
        _.each(model, function (navigationEntry) {
            _this.addNavigationEntry(NavigationEntry$$1.fromDocument(navigationEntry));
        }, this);
    };
    NavigationService$$1.prototype.addNavigationEntry = function (navigationEntry) {
        var _this = this;
        if (!(navigationEntry instanceof NavigationEntry$$1)) {
            navigationEntry = NavigationEntry$$1.fromDocument(navigationEntry);
        }
        this.navigation.push(navigationEntry);
        this.processNavigationEntry(navigationEntry);
        _.each(this.onNavigationEntryAddFns, function (cb) {
            _this.executeCallback(cb, navigationEntry);
        });
    };
    NavigationService$$1.prototype.processNavigationEntry = function (navigationEntry) {
        if (navigationEntry.stateName === undefined)
            navigationEntry.stateName = navigationEntry.route;
        Logger.debug("NavigationService", "mapping  route : " + navigationEntry.getRoute() + ", label : " + navigationEntry.getLabel());
    };
    NavigationService$$1.prototype.getEntryByRoute = function (route) {
        for (var n = 0; n < this.navigation.length; n++) {
            if (this.navigation[n].getRoute() === route)
                return this.navigation[n];
        }
        Logger.error("NavigationService", "Could not find navigation entry by route '" + route + "', available routes are : ", this.navigation);
        return undefined;
    };
    NavigationService$$1.prototype.getNavigationEntries = function () {
        return _.union(this.navigation, this.dbNavigation);
    };
    NavigationService$$1.prototype.getCodeNavigationEntries = function () {
        return this.navigation;
    };
    NavigationService$$1.prototype.getDBNavigationEntries = function () {
        return this.dbNavigation;
    };
    NavigationService$$1.prototype.getNavigationEntriesForNavigationType = function (navType) {
        var filteredNavEntries = [];
        _.each(this.getNavigationEntries(), function (navigationEntry) {
            if (navigationEntry.getType() === navType)
                filteredNavEntries.push(navigationEntry);
        });
        return filteredNavEntries;
    };
    NavigationService$$1.prototype.setLayout = function (id, url) {
        this.layouts[id] = url;
    };
    NavigationService$$1.prototype.getEntryByStateName = function (stateName) {
        var ent = _.find(this.getNavigationEntries(), function (entry) {
            return entry.stateName === stateName;
        });
        return ent;
    };
    NavigationService$$1.prototype.onNavigationEntryAdd = function (fn, thisArg) {
        var _this = this;
        this.onNavigationEntryAddFns.push({ fn: fn, thisArg: thisArg });
        _.each(this.navigation, function (navigationEntry) {
            _this.executeCallback({ fn: fn, thisArg: thisArg }, navigationEntry);
        });
    };
    NavigationService$$1.prototype.getDefaultNavigatioNentry = function () {
        var defaultEntry = _.find(this.navigation, function (entry) { return entry.isDefaultRoute(); });
        if (defaultEntry)
            return defaultEntry;
        throw new Error("No route is declared as default route!");
    };
    NavigationService$$1.prototype.executeCallback = function (cb, arg) {
        if (cb.thisArg)
            cb.fn.bind(cb.thisArg)(arg);
        else
            cb.fn(arg);
    };
    return NavigationService$$1;
}(GeneratedNavigationService));

var GeneratedMediaService = (function () {
    function GeneratedMediaService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedMediaService.instance = function () {
        return IOC.get("mediaService");
    };
    GeneratedMediaService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("medias");
    };
    GeneratedMediaService.prototype.getMediaByIds = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": { "$in": parameters.ids }, "ownerId": this.dataBridge.getCurrentUserId() }, "getMediaByIds", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedMediaService.prototype.getMediaById = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": parameters.id }, "getMediaById", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedMediaService.prototype.getAllMedias = function (parameters, queryOptions) {
        return new QueryObject$$1().create({}, "getAllMedias", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedMediaService.prototype.getMediasByTag = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "tags": parameters.tag }, "getMediasByTag", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedMediaService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedMediaService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "ownerId": model["ownerId"], "createdAt": model["createdAt"], "contentType": model["contentType"], "availableFormatIds": model["availableFormatIds"], "tags": model["tags"] } }, callback);
    };
    GeneratedMediaService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedMediaService;
}());

var GeneratedMediaFormatService = (function () {
    function GeneratedMediaFormatService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedMediaFormatService.instance = function () {
        return IOC.get("mediaFormatService");
    };
    GeneratedMediaFormatService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("mediaformats");
    };
    GeneratedMediaFormatService.prototype.getMediaFormatByName = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "name": parameters.name }, "getMediaFormatByName", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedMediaFormatService.prototype.getAllMediaFormats = function (parameters, queryOptions) {
        return new QueryObject$$1().create({}, "getAllMediaFormats", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedMediaFormatService.prototype.getMediaFormatsByIds = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": { "$in": parameters.ids } }, "getMediaFormatsByIds", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedMediaFormatService.prototype.getMediaFormatById = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": parameters.id }, "getMediaFormatById", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedMediaFormatService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedMediaFormatService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "name": model["name"], "preprocessed": model["preprocessed"], "command": model["command"], "parameters": model["parameters"], "isDefault": model["isDefault"] } }, callback);
    };
    GeneratedMediaFormatService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedMediaFormatService;
}());

var __extends$24 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MediaFormatService = (function (_super) {
    __extends$24(MediaFormatService, _super);
    function MediaFormatService() {
        return _super.apply(this, arguments) || this;
    }
    MediaFormatService.prototype.createFormat = function (name, command, parameters, preprocessed, isDefault) {
        this.getCollection().upsert({
            name: name
        }, {
            "$set": {
                name: name,
                isDefault: isDefault,
                preprocessed: preprocessed,
                command: command,
                parameters: parameters
            }
        });
        return this.getCollection().findOne({ name: name });
    };
    return MediaFormatService;
}(GeneratedMediaFormatService));

var GeneratedMediaFormat = (function () {
    function GeneratedMediaFormat() {
        this.preprocessed = true;
        this.isDefault = false;
        this._hasSubDocuments = false;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedMediaFormat.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["name"] = doc["name"];
        model["preprocessed"] = doc["preprocessed"];
        model["command"] = doc["command"];
        model["parameters"] = doc["parameters"];
        model["isDefault"] = doc["isDefault"];
        return model;
    };
    GeneratedMediaFormat.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["name"] = this["name"];
        doc["preprocessed"] = this["preprocessed"];
        doc["command"] = this["command"];
        doc["parameters"] = this["parameters"];
        doc["isDefault"] = this["isDefault"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedMediaFormat.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedMediaFormat.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedMediaFormat.getModelName = function () {
        return "MediaFormat";
    };
    GeneratedMediaFormat.prototype.getModelName = function () {
        return "MediaFormat";
    };
    GeneratedMediaFormat.getModelClass = function () {
        return IOC.get("MediaFormat");
    };
    GeneratedMediaFormat.prototype.getModelClass = function () {
        return IOC.get("MediaFormat");
    };
    GeneratedMediaFormat.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete MediaFormat with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed MediaFormat with ID '" + that.id + "'!");
            };
        }
        return MediaFormatService.instance().delete(this, callback);
    };
    GeneratedMediaFormat.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update MediaFormat with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated MediaFormat with ID '" + _this.id + "'!");
            };
        }
        return MediaFormatService.instance().update(this, callback);
    };
    GeneratedMediaFormat.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save MediaFormat!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved MediaFormat!");
                }
            };
        }
        if (this.dataBridge.isClient())
            MediaFormatService.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = MediaFormatService.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedMediaFormat.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "name": {
                "type": String,
                "unique": true
            },
            "preprocessed": {
                "type": Boolean,
                "defaultValue": true
            },
            "command": {
                "type": String,
                "allowedValues": ["resize", "scale", "blur", "cover"],
                "optional": true
            },
            "parameters": {
                "type": Object,
                "optional": true,
                "blackbox": true
            },
            "isDefault": {
                "type": Boolean,
                "defaultValue": false,
                "optional": true
            },
        };
    };
    return GeneratedMediaFormat;
}());
GeneratedMediaFormat.enums = {
    "command": { "RESIZE": "resize", "SCALE": "scale", "BLUR": "blur", "COVER": "cover" },
};

var __extends$23 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MediaFormat$$1 = (function (_super) {
    __extends$23(MediaFormat$$1, _super);
    function MediaFormat$$1() {
        return _super.apply(this, arguments) || this;
    }
    MediaFormat$$1.byName = function (name) {
        var mediaFormat = MediaFormatService.instance().getMediaFormatByName({ name: name }).getModels()[0];
        if (!mediaFormat)
            throw new Error("No mediaformat '" + name + "' defined!");
        return mediaFormat;
    };
    return MediaFormat$$1;
}(GeneratedMediaFormat));
MediaFormat$$1.defaultFormats = {
    "original": "original"
};
IOC.register("MediaFormat", MediaFormat$$1);

var __extends$22 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MediaService$$1 = (function (_super) {
    __extends$22(MediaService$$1, _super);
    function MediaService$$1() {
        var _this = _super.call(this) || this;
        IOC.onRegister("configurationService", function (configurationService) {
            _this.configurationService = configurationService;
        });
        if (_this.dataBridge.isServer())
            _this.jimp = Npm.require("jimp");
        return _this;
    }
    MediaService$$1.prototype.decodeBase64Image = function (dataString) {
        var matches = dataString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
        if (!matches || matches.length !== 3) {
            throw new Error("501 - Invalid input string!");
        }
        return {
            buffer: new Buffer(matches[2], 'base64'),
            type: matches[1]
        };
    };
    MediaService$$1.prototype.processImage = function (typedBuffer, mediaFormat) {
        if (this.dataBridge.isServer()) {
            if (!this.jimp)
                throw new Error("jimp package not included!");
            if (typedBuffer === undefined)
                throw new Error("typedBuffer is undefined!");
            var readImage = Meteor.wrapAsync(this.jimp.read, this.jimp);
            var image = undefined;
            try {
                image = readImage(typedBuffer.buffer);
            }
            catch (e) {
                Logger.error("AbstractMediaService", "Could not read buffer, probably wrong media type! Trying again with 'image/jpg'...");
                throw e;
            }
            switch (mediaFormat.command) {
                case MediaFormat$$1.enums.command.COVER:
                    this.checkParameter("height", mediaFormat);
                    this.checkParameter("width", mediaFormat);
                    Meteor.wrapAsync(image.cover, image)(mediaFormat.parameters.width, mediaFormat.parameters.height);
                    return this.imageToBuffer(image, typedBuffer.type.split("/")[1]);
                case MediaFormat$$1.enums.command.RESIZE:
                    this.checkParameter("height", mediaFormat);
                    this.checkParameter("width", mediaFormat);
                    var width = mediaFormat.parameters.width;
                    var height = mediaFormat.parameters.height;
                    if (mediaFormat.parameters.keepAspectRatio) {
                        var widthRatio = width / image.width();
                        var heightRatio = height / image.height();
                        var ratio = Math.min(widthRatio, heightRatio);
                        if (ratio < 1)
                            Meteor.wrapAsync(image.scale, image)(ratio);
                    }
                    else {
                        Meteor.wrapAsync(image.resize, image)(width, height);
                    }
                    return this.imageToBuffer(image, typedBuffer.type.split("/")[1]);
                default:
                    throw new Meteor.Error("501", "Unknown mediaformat command : " + mediaFormat.command);
            }
        }
        else
            throw new Meteor.Error("501", "Processing images is only available on server-side!");
    };
    MediaService$$1.prototype.checkParameter = function (name, mediaFormat) {
        if (!mediaFormat)
            throw new Error("501 - MediaFormat required for processing image!");
        if (!mediaFormat.parameters)
            throw new Error("501 - MediaFormat.parameters required for processing image!");
        if (!mediaFormat.parameters[name])
            throw new Error("501 - MediaFormat.parameters." + name + " required for command : " + mediaFormat.command);
    };
    MediaService$$1.prototype.imageToBuffer = function (image, type) {
        if (!image)
            throw new Error("501 - No image given for buffer output writing!");
        if (typeof type !== 'string' || type.length === 0)
            throw new Error("501 - No type given for buffer output writing!");
        switch (type) {
            case "jpeg":
            case "jpg":
                type = this.jimp.MIME_JPEG;
                break;
            case "png":
                type = this.jimp.MIME_PNG;
                break;
            default:
                throw new Error("Unsupported media type: " + type);
        }
        return Meteor.wrapAsync(image.getBuffer, image)(type);
    };
    return MediaService$$1;
}(GeneratedMediaService));

var GeneratedUploadedFileService = (function () {
    function GeneratedUploadedFileService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedUploadedFileService.instance = function () {
        return IOC.get("uploadedFileService");
    };
    GeneratedUploadedFileService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("uploadedfiles");
    };
    GeneratedUploadedFileService.prototype.getUploadedFilesByIds = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": { "$in": parameters.ids }, "ownerId": this.dataBridge.getCurrentUserId() }, "getUploadedFilesByIds", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedUploadedFileService.prototype.getFileById = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": parameters.id }, "getFileById", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedUploadedFileService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedUploadedFileService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "ownerId": model["ownerId"], "createdAt": model["createdAt"], "contentType": model["contentType"] } }, callback);
    };
    GeneratedUploadedFileService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedUploadedFileService;
}());

var __extends$25 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var UploadedFileService = (function (_super) {
    __extends$25(UploadedFileService, _super);
    function UploadedFileService() {
        return _super.apply(this, arguments) || this;
    }
    return UploadedFileService;
}(GeneratedUploadedFileService));

var __extends$27 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var GeneratedMediaformatsCollection = (function (_super) {
    __extends$27(GeneratedMediaformatsCollection, _super);
    function GeneratedMediaformatsCollection() {
        var _this = _super.call(this) || this;
        _this.name = "mediaformats";
        _this.createCollection();
        _this.configureAllowDenyRules();
        _this.createSearchIndex();
        _this.collectionsService.registerCollection("mediaformats", _this);
        _this.createPublications();
        return _this;
    }
    GeneratedMediaformatsCollection.prototype.createPublications = function () {
        if (this.dataBridge.isServer()) {
            this.collectionsService.addPublisher("mediaformats", "getMediaFormatByName", { "name": ":name" }, {});
            this.collectionsService.addPublisher("mediaformats", "getAllMediaFormats", {}, {});
            this.collectionsService.addPublisher("mediaformats", "getMediaFormatsByIds", { "_id": { "$in": ":ids:string[]" } }, {});
            this.collectionsService.addPublisher("mediaformats", "getMediaFormatById", { "_id": ":id:string" }, {});
        }
    };
    GeneratedMediaformatsCollection.prototype.createSearchIndex = function () {
        if (Package["easysearch:core"]) {
            Logger.debug("EasySearch", "Creating search index for collection 'mediaformats' and fields 'name,preprocessed,command,parameters,isDefault,_id'!");
            this._easySearchIndex = new EasySearch.Index({
                collection: this._collection,
                fields: ["name", "preprocessed", "command", "parameters", "isDefault", "_id"],
                engine: new EasySearch.MongoDB()
            });
        }
    };
    GeneratedMediaformatsCollection.prototype.createCollection = function () {
        this._collection = this.collectionsService.createCollection("mediaformats", function (doc) {
            return MediaFormat$$1.fromDocument(doc);
        });
    };
    GeneratedMediaformatsCollection.prototype.configureAllowDenyRules = function () {
        var allow = this.getCollectionAllowRules();
        if (allow !== undefined)
            this._collection.allow(allow);
        else {
            var deny = this.getCollectionDenyRules();
            if (deny !== undefined)
                this._collection.deny(deny);
            else
                console.warn("No allow/deny rules set for collection : mediaformats");
        }
    };
    GeneratedMediaformatsCollection.prototype.getCollectionAllowRules = function () {
        var that = this;
        return {
            insert: function (userId, doc) {
                return (userId && doc.ownerId === userId);
            },
            update: function (userId, doc, fields, modifier) {
                return doc.ownerId === userId;
            },
            remove: function (userId, doc) {
                return doc.ownerId === userId;
            },
            fetch: ['ownerId']
        };
    };
    GeneratedMediaformatsCollection.prototype.getCollectionDenyRules = function () {
        return undefined;
    };
    GeneratedMediaformatsCollection.prototype.getSchema = function () {
        return GeneratedMediaFormat.getSchema();
    };
    GeneratedMediaformatsCollection.prototype.getForeignCollection = function (typeName) {
        switch (typeName) {
        }
        return undefined;
    };
    GeneratedMediaformatsCollection.prototype.getForeignGetter = function () {
        return "getMediaFormatsByIds";
    };
    GeneratedMediaformatsCollection.getForeignGetter = function () {
        return "getMediaFormatsByIds";
    };
    GeneratedMediaformatsCollection.prototype.getModelName = function () {
        return "MediaFormat";
    };
    GeneratedMediaformatsCollection.prototype.getServiceName = function () {
        return "mediaFormatService";
    };
    GeneratedMediaformatsCollection.prototype.getQueries = function () {
        return GeneratedMediaformatsCollection.queries;
    };
    GeneratedMediaformatsCollection.prototype.getCollectionName = function () {
        return "mediaformats";
    };
    GeneratedMediaformatsCollection.getCollection = function () {
        return IOC.get("collectionsService").getCollectionByName("mediaformats");
    };
    return GeneratedMediaformatsCollection;
}(BaseCollection$$1));
GeneratedMediaformatsCollection.queries = {
    "getMediaFormatByName": { name: "getMediaFormatByName", parameters: { name: "name" } },
    "getAllMediaFormats": { name: "getAllMediaFormats", parameters: {} },
    "getMediaFormatsByIds": { name: "getMediaFormatsByIds", parameters: { ids: "ids" } },
    "getMediaFormatById": { name: "getMediaFormatById", parameters: { id: "id" } }
};
GeneratedMediaformatsCollection.expandables = {};

var __extends$26 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MediaformatsCollection = (function (_super) {
    __extends$26(MediaformatsCollection, _super);
    function MediaformatsCollection() {
        return _super.call(this) || this;
    }
    return MediaformatsCollection;
}(GeneratedMediaformatsCollection));

var GeneratedMedia = (function () {
    function GeneratedMedia() {
        this.availableFormatIds = [];
        this.tags = [];
        this._hasSubDocuments = true;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedMedia.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["ownerId"] = doc["ownerId"];
        model["createdAt"] = doc["createdAt"];
        model["contentType"] = doc["contentType"];
        model["availableFormatIds"] = doc["availableFormatIds"];
        model["tags"] = doc["tags"];
        return model;
    };
    GeneratedMedia.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["ownerId"] = this["ownerId"];
        doc["createdAt"] = this["createdAt"];
        doc["contentType"] = this["contentType"];
        doc["availableFormatIds"] = this["availableFormatIds"];
        doc["tags"] = this["tags"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedMedia.prototype.getOwner = function (options) {
        return IOC.get("userService").getUserById({ id: this.ownerId }, options);
    };
    GeneratedMedia.prototype.addAvailableFormatIds = function (ids) {
        if (this.availableFormatIds === undefined)
            this.availableFormatIds = [];
        _.each(ids, function (id) {
            if (!_.contains(this.availableFormatIds, id))
                this.availableFormatIds.push(id);
        }, this);
    };
    GeneratedMedia.prototype.getAvailableFormats = function (options) {
        return IOC.get("mediaFormatService").getMediaFormatsByIds({ ids: this.availableFormatIds }, options);
    };
    GeneratedMedia.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedMedia.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedMedia.getModelName = function () {
        return "Media";
    };
    GeneratedMedia.prototype.getModelName = function () {
        return "Media";
    };
    GeneratedMedia.getModelClass = function () {
        return IOC.get("Media");
    };
    GeneratedMedia.prototype.getModelClass = function () {
        return IOC.get("Media");
    };
    GeneratedMedia.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete Media with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed Media with ID '" + that.id + "'!");
            };
        }
        return MediaService$$1.instance().delete(this, callback);
    };
    GeneratedMedia.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update Media with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated Media with ID '" + _this.id + "'!");
            };
        }
        return MediaService$$1.instance().update(this, callback);
    };
    GeneratedMedia.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save Media!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved Media!");
                }
            };
        }
        if (this.dataBridge.isClient())
            MediaService$$1.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = MediaService$$1.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedMedia.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "ownerId": {
                "type": String,
                "optional": true
            },
            "createdAt": {
                "type": Date
            },
            "contentType": {
                "type": String,
                "optional": true
            },
            "availableFormatIds": {
                "type": [String],
                "defaultValue": [],
                "optional": true
            },
            "tags": {
                "type": [String],
                "defaultValue": [],
                "optional": true
            },
        };
    };
    return GeneratedMedia;
}());

var __extends$30 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Media$$1 = (function (_super) {
    __extends$30(Media$$1, _super);
    function Media$$1() {
        return _super.apply(this, arguments) || this;
    }
    return Media$$1;
}(GeneratedMedia));
IOC.register("Media", Media$$1);

var __extends$29 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var GeneratedMediasCollection = (function (_super) {
    __extends$29(GeneratedMediasCollection, _super);
    function GeneratedMediasCollection() {
        var _this = _super.call(this) || this;
        _this.name = "medias";
        _this.createCollection();
        _this.configureAllowDenyRules();
        _this.createSearchIndex();
        _this.collectionsService.registerCollection("medias", _this);
        _this.createPublications();
        return _this;
    }
    GeneratedMediasCollection.prototype.createPublications = function () {
        if (this.dataBridge.isServer()) {
            this.collectionsService.addPublisher("medias", "getMediaByIds", { "_id": { "$in": ":ids:string[]" }, "ownerId": "_currentLoggedInUser_" }, {});
            this.collectionsService.addPublisher("medias", "getMediaById", { "_id": ":id:string" }, {});
            this.collectionsService.addPublisher("medias", "getAllMedias", {}, {});
            this.collectionsService.addPublisher("medias", "getMediasByTag", { "tags": ":tag" }, {});
        }
    };
    GeneratedMediasCollection.prototype.createSearchIndex = function () {
        if (Package["easysearch:core"]) {
            Logger.debug("EasySearch", "Creating search index for collection 'medias' and fields 'ownerId,createdAt,contentType,tags,_id'!");
            this._easySearchIndex = new EasySearch.Index({
                collection: this._collection,
                fields: ["ownerId", "createdAt", "contentType", "tags", "_id"],
                engine: new EasySearch.MongoDB()
            });
        }
    };
    GeneratedMediasCollection.prototype.createCollection = function () {
        this._collection = this.collectionsService.createCollection("medias", function (doc) {
            return Media$$1.fromDocument(doc);
        });
    };
    GeneratedMediasCollection.prototype.configureAllowDenyRules = function () {
        var allow = this.getCollectionAllowRules();
        if (allow !== undefined)
            this._collection.allow(allow);
        else {
            var deny = this.getCollectionDenyRules();
            if (deny !== undefined)
                this._collection.deny(deny);
            else
                console.warn("No allow/deny rules set for collection : medias");
        }
    };
    GeneratedMediasCollection.prototype.getCollectionAllowRules = function () {
        var that = this;
        return {
            insert: function (userId, doc) {
                return (userId && doc.ownerId === userId);
            },
            update: function (userId, doc, fields, modifier) {
                return doc.ownerId === userId;
            },
            remove: function (userId, doc) {
                return doc.ownerId === userId;
            },
            fetch: ['ownerId']
        };
    };
    GeneratedMediasCollection.prototype.getCollectionDenyRules = function () {
        return undefined;
    };
    GeneratedMediasCollection.prototype.getSchema = function () {
        return GeneratedMedia.getSchema();
    };
    GeneratedMediasCollection.prototype.getForeignCollection = function (typeName) {
        switch (typeName) {
            case "ownerId":
                return this.typesystem.getTypeByName("User").getCollectionName();
            case "availableFormatIds":
                return this.typesystem.getTypeByName("MediaFormat").getCollectionName();
        }
        return undefined;
    };
    GeneratedMediasCollection.prototype.getForeignGetter = function () {
        return "getMediaByIds";
    };
    GeneratedMediasCollection.getForeignGetter = function () {
        return "getMediaByIds";
    };
    GeneratedMediasCollection.prototype.getModelName = function () {
        return "Media";
    };
    GeneratedMediasCollection.prototype.getServiceName = function () {
        return "mediaService";
    };
    GeneratedMediasCollection.prototype.getQueries = function () {
        return GeneratedMediasCollection.queries;
    };
    GeneratedMediasCollection.prototype.getCollectionName = function () {
        return "medias";
    };
    GeneratedMediasCollection.getCollection = function () {
        return IOC.get("collectionsService").getCollectionByName("medias");
    };
    return GeneratedMediasCollection;
}(BaseCollection$$1));
GeneratedMediasCollection.queries = {
    "getMediaByIds": { name: "getMediaByIds", parameters: { ids: "ids" } },
    "getMediaById": { name: "getMediaById", parameters: { id: "id" } },
    "getAllMedias": { name: "getAllMedias", parameters: {} },
    "getMediasByTag": { name: "getMediasByTag", parameters: { tag: "tag" } }
};
GeneratedMediasCollection.expandables = { "ownerId": "ownerId", "availableFormatIds": "availableFormatIds" };

var __extends$28 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MediasCollection = (function (_super) {
    __extends$28(MediasCollection, _super);
    function MediasCollection() {
        return _super.call(this) || this;
    }
    return MediasCollection;
}(GeneratedMediasCollection));

var GeneratedUploadedFile = (function () {
    function GeneratedUploadedFile() {
        this._hasSubDocuments = true;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedUploadedFile.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["ownerId"] = doc["ownerId"];
        model["createdAt"] = doc["createdAt"];
        model["contentType"] = doc["contentType"];
        return model;
    };
    GeneratedUploadedFile.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["ownerId"] = this["ownerId"];
        doc["createdAt"] = this["createdAt"];
        doc["contentType"] = this["contentType"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedUploadedFile.prototype.getOwner = function (options) {
        return IOC.get("userService").getUserById({ id: this.ownerId }, options);
    };
    GeneratedUploadedFile.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedUploadedFile.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedUploadedFile.getModelName = function () {
        return "UploadedFile";
    };
    GeneratedUploadedFile.prototype.getModelName = function () {
        return "UploadedFile";
    };
    GeneratedUploadedFile.getModelClass = function () {
        return IOC.get("UploadedFile");
    };
    GeneratedUploadedFile.prototype.getModelClass = function () {
        return IOC.get("UploadedFile");
    };
    GeneratedUploadedFile.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete UploadedFile with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed UploadedFile with ID '" + that.id + "'!");
            };
        }
        return UploadedFileService.instance().delete(this, callback);
    };
    GeneratedUploadedFile.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update UploadedFile with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated UploadedFile with ID '" + _this.id + "'!");
            };
        }
        return UploadedFileService.instance().update(this, callback);
    };
    GeneratedUploadedFile.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save UploadedFile!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved UploadedFile!");
                }
            };
        }
        if (this.dataBridge.isClient())
            UploadedFileService.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = UploadedFileService.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedUploadedFile.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "ownerId": {
                "type": String,
                "optional": true
            },
            "createdAt": {
                "type": Date
            },
            "contentType": {
                "type": String,
                "optional": true
            },
        };
    };
    return GeneratedUploadedFile;
}());

var __extends$31 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var UploadedFile$$1 = (function (_super) {
    __extends$31(UploadedFile$$1, _super);
    function UploadedFile$$1() {
        return _super.apply(this, arguments) || this;
    }
    return UploadedFile$$1;
}(GeneratedUploadedFile));
IOC.register("UploadedFile", UploadedFile$$1);

var GeneratedUserService = (function () {
    function GeneratedUserService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedUserService.instance = function () {
        return IOC.get("userService");
    };
    GeneratedUserService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("users");
    };
    GeneratedUserService.prototype.getUsersByIds = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": { "$in": parameters.ids } }, "getUsersByIds", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedUserService.prototype.getUserById = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": parameters.id }, "getUserById", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedUserService.prototype.getAllUsers = function (parameters, queryOptions) {
        return new QueryObject$$1().create({}, "getAllUsers", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedUserService.prototype.getMyUser = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": this.dataBridge.getCurrentUserId() }, "getMyUser", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedUserService.prototype.updateProfileDetails = function (newValues, callback) {
        if (IOC.isRegistered("analyticsService"))
            IOC.get("analyticsService").event("updateProfileDetails", { category: "methodcall" });
        this.dataBridge.callMethod("users-updateProfileDetails", { newValues: newValues }, callback);
    };
    GeneratedUserService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedUserService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "profile": model["profile"], "emails": model["emails"], "createdAt": model["createdAt"], "services": model["services"], "roleIds": model["roleIds"] } }, callback);
    };
    GeneratedUserService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedUserService;
}());

var __extends$33 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var UserService$$1 = (function (_super) {
    __extends$33(UserService$$1, _super);
    function UserService$$1() {
        var _this = _super.call(this) || this;
        _this.onCreateUserFns = [];
        _this.onCreateDemoUserFns = [];
        _this.avatarOrder = ["facebook", "googleplus", "linkedin", "twitter"];
        _this.mediaService = IOC.get("mediaService");
        return _this;
    }
    UserService$$1.prototype.transformUser = function (user) {
        if (user === undefined)
            return undefined;
        return User$$1.fromDocument(user);
    };
    UserService$$1.prototype.transformUsers = function (users) {
        var that = this;
        var transformedUsers = [];
        _.each(users, function (user) {
            transformedUsers.push(that.transformUser(user));
        });
        return transformedUsers;
    };
    UserService$$1.prototype.onCreateUser = function (callback) {
        this.onCreateUserFns.push(callback);
    };
    UserService$$1.prototype.executeOnCreateUserFunctions = function (user) {
        _.each(this.onCreateUserFns, function (fn) {
            var returnedUser = fn(user);
            if (returnedUser === undefined) {
                console.warn("One onCreateUser function did not return a user! Ignoring results!");
            }
            else
                user = returnedUser;
        });
        return user;
    };
    UserService$$1.prototype.onCreateDemoUser = function (func) {
        this.onCreateDemoUserFns.push(func);
    };
    UserService$$1.prototype.executeOnCreateDemoUserFunctions = function (user) {
        _.each(this.onCreateDemoUserFns, function (fn) {
            var returnedUser = fn(user);
            if (returnedUser === undefined) {
                console.warn("One onCreateDemoUser function did not return a user! Ignoring results!");
            }
            else
                user = returnedUser;
        });
        return user;
    };
    UserService$$1.prototype.getAvatarUrlForUser = function (user, mediaFormatName) {
        if (mediaFormatName === void 0) { mediaFormatName = "squaredthumbnail"; }
        if (user !== null && user !== undefined) {
            if (user.profile && user.profile.avatarUrl)
                return user.profile.avatarUrl;
            if (user.profile && user.profile.avatarId)
                return this.mediaService.getUrlForMediaId(user.profile.avatarId, mediaFormatName);
            for (var s = 0; s < this.avatarOrder.length; s++) {
                var serviceId = this.avatarOrder[s];
                switch (serviceId) {
                    case "facebook":
                        var avatarUrl = this.getFacebookAvatar(user);
                        if (avatarUrl !== undefined) {
                            return avatarUrl;
                        }
                        break;
                    case "googleplus":
                        var avatarUrl = this.getGoogleAvatar(user);
                        if (avatarUrl !== undefined) {
                            return avatarUrl;
                        }
                        break;
                    case "twitter":
                        var avatarUrl = this.getTwitterAvatar(user);
                        if (avatarUrl !== undefined) {
                            return avatarUrl;
                        }
                        break;
                    case "linkedin":
                        var avatarUrl = this.getLinkedInAvatar(user);
                        if (avatarUrl !== undefined) {
                            return avatarUrl;
                        }
                        break;
                }
            }
        }
        return this.getDefaultAvatarUrl();
    };
    UserService$$1.prototype.getDefaultAvatarUrl = function () {
        return "/img/default-avatar.png";
    };
    UserService$$1.prototype.getAvatarUrlForUserId = function (userId, callback) {
        if (userId === null || userId === undefined) {
            callback(this.getDefaultAvatarUrl());
            return;
        }
        var that = this;
        IOC.get("userService").getUserById({ id: userId }, function (user) {
            callback(that.getAvatarUrlForUser(user));
        });
    };
    UserService$$1.prototype.getFacebookAvatar = function (user) {
        if (user.services && user.services.facebook && user.services.facebook.id) {
            return "https://graph.facebook.com/" + user.services.facebook.id + "/picture?width=200&height=200";
        }
        return undefined;
    };
    UserService$$1.prototype.getGoogleAvatar = function (user) {
        if (user.services && user.services.google && user.services.google.picture) {
            return user.services.google.picture;
        }
        return undefined;
    };
    UserService$$1.prototype.getTwitterAvatar = function (user) {
        if (user.services && user.services.twitter && user.services.twitter.profile_image_url_https) {
            return user.services.twitter.profile_image_url_https;
        }
        return undefined;
    };
    UserService$$1.prototype.getLinkedInAvatar = function (user) {
        if (user.services && user.services.linkedin && user.services.linkedin.pictureUrl) {
            return user.services.linkedin.pictureUrl;
        }
        return undefined;
    };
    UserService$$1.prototype.getCurrentUser = function () {
        var userId = this.dataBridge.getCurrentUserId();
        if (!userId)
            return undefined;
        return this.getUserById({ id: userId }).getModels()[0];
    };
    return UserService$$1;
}(GeneratedUserService));

var GeneratedRolesService = (function () {
    function GeneratedRolesService() {
        this.collectionsService = IOC.get("collectionsService");
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedRolesService.instance = function () {
        return IOC.get("rolesService");
    };
    GeneratedRolesService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("roles");
    };
    GeneratedRolesService.prototype.getRoleByName = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "name": parameters.name }, "getRoleByName", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedRolesService.prototype.getRoleById = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": parameters.id }, "getRoleById", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedRolesService.prototype.getRolesByIds = function (parameters, queryOptions) {
        return new QueryObject$$1().create({ "_id": { "$in": parameters.ids } }, "getRolesByIds", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedRolesService.prototype.getAllRoles = function (parameters, queryOptions) {
        return new QueryObject$$1().create({}, "getAllRoles", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedRolesService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedRolesService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "name": model["name"], "subRoleIds": model["subRoleIds"] } }, callback);
    };
    GeneratedRolesService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedRolesService;
}());

var GeneratedRole = (function () {
    function GeneratedRole() {
        this.subRoleIds = [];
        this._hasSubDocuments = true;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedRole.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["name"] = doc["name"];
        model["subRoleIds"] = doc["subRoleIds"];
        return model;
    };
    GeneratedRole.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["name"] = this["name"];
        doc["subRoleIds"] = this["subRoleIds"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedRole.prototype.addSubRoleIds = function (ids) {
        if (this.subRoleIds === undefined)
            this.subRoleIds = [];
        _.each(ids, function (id) {
            if (!_.contains(this.subRoleIds, id))
                this.subRoleIds.push(id);
        }, this);
    };
    GeneratedRole.prototype.getSubRoles = function (options) {
        return IOC.get("rolesService").getRolesByIds({ ids: this.subRoleIds }, options);
    };
    GeneratedRole.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedRole.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedRole.getModelName = function () {
        return "Role";
    };
    GeneratedRole.prototype.getModelName = function () {
        return "Role";
    };
    GeneratedRole.getModelClass = function () {
        return IOC.get("Role");
    };
    GeneratedRole.prototype.getModelClass = function () {
        return IOC.get("Role");
    };
    GeneratedRole.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete Role with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed Role with ID '" + that.id + "'!");
            };
        }
        return RolesService$$1.instance().delete(this, callback);
    };
    GeneratedRole.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update Role with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated Role with ID '" + _this.id + "'!");
            };
        }
        return RolesService$$1.instance().update(this, callback);
    };
    GeneratedRole.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save Role!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved Role!");
                }
            };
        }
        if (this.dataBridge.isClient())
            RolesService$$1.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = RolesService$$1.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedRole.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "name": {
                "type": String,
                "index": true,
                "unique": true
            },
            "subRoleIds": {
                "type": [String],
                "defaultValue": [],
                "optional": true
            },
        };
    };
    return GeneratedRole;
}());

var __extends$35 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Role$$1 = (function (_super) {
    __extends$35(Role$$1, _super);
    function Role$$1() {
        return _super.apply(this, arguments) || this;
    }
    return Role$$1;
}(GeneratedRole));
IOC.register("Role", Role$$1);

var __extends$34 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var RolesService$$1 = (function (_super) {
    __extends$34(RolesService$$1, _super);
    function RolesService$$1() {
        var _this = _super.call(this) || this;
        if (_this.dataBridge.isClient()) {
            IOC.get("initLevelService").addInitLevelFn(5, "RolesSync", function (cb) {
                IOC.get("rolesService").getAllRoles({}).subscribe(function () {
                    cb(undefined, true);
                });
            });
        }
        return _this;
    }
    RolesService$$1.prototype.createRole = function (roleName, subRoleNames) {
        var _this = this;
        if (subRoleNames === void 0) { subRoleNames = []; }
        var role = this.getRoleByName({ name: roleName }).getModels()[0];
        if (role !== undefined) {
            Logger.debug("RolesService", "Role '" + roleName + "' already exists!");
            return role;
        }
        else {
            Logger.debug("RolesService", "Creating role '" + roleName + "'!");
            var subRoleIds_1 = [];
            _.each(subRoleNames, function (subRoleName) {
                var role = _this.getRoleByName({ name: subRoleName }).getModels()[0];
                if (role)
                    subRoleIds_1.push(role.id);
                else {
                    var subRole = new Role$$1();
                    subRole.name = subRoleName;
                    _this.save(subRole);
                    subRoleIds_1.push(subRole.id);
                }
            });
            var role_1 = new Role$$1();
            role_1.name = roleName;
            role_1.subRoleIds = subRoleIds_1;
            role_1.save();
            return role_1;
        }
    };
    RolesService$$1.prototype.userHasRole = function (user, roleName) {
        var _this = this;
        if (typeof user === "string")
            user = this.collectionsService.getCollectionByName("users").findOne(user);
        if (!user) {
            Logger.error("RolesService", "No user given while calling rolesService.userHasRole!");
            return false;
        }
        if (!roleName) {
            Logger.error("RolesService", "No roleName given while calling rolesService.userHasRole!");
            return false;
        }
        var role = this.getRoleByName({ name: roleName }).getModels()[0];
        if (!role) {
            Logger.error("RolesService", "Role '" + roleName + "' not found while calling rolesService.userHasRole!");
            return false;
        }
        if (!(user.roleIds instanceof Array)) {
            Logger.error("RolesService", "User has no role array attached!");
            return false;
        }
        if (user.roleIds.indexOf(role.id) !== -1)
            return true;
        if (user.roleIds.indexOf(this.getAdministratorRole().id) !== -1) {
            Logger.debug("RolesService", "User is administrator, returning true for role '" + roleName + "'!");
            return true;
        }
        var foundSubRole = false;
        _.each(user.roleIds, function (userRoleId) {
            _.each(_this.getAllSubRoles(_this.getById(userRoleId)), function (subRole) {
                if (subRole.name === roleName)
                    foundSubRole = true;
            });
        });
        if (foundSubRole)
            return true;
        return false;
    };
    RolesService$$1.userHasRole = function (user, roleName) {
        return RolesService$$1.instance().userHasRole(user, roleName);
    };
    RolesService$$1.prototype.getAllSubRoles = function (role) {
        var _this = this;
        var subRoles = [];
        if (role !== undefined) {
            _.each(role.subRoleIds, function (subRoleId) {
                var subRole = _this.getById(subRoleId);
                if (!subRole)
                    throw new Error("Could not find role with ID '" + subRoleId + "'!");
                subRoles.push(subRole);
                subRoles = subRoles.concat(_this.getAllSubRoles(_this.getRoleById({ id: subRoleId }).getModels[0]));
            });
        }
        return subRoles;
    };
    RolesService$$1.prototype.isRole = function (roleName) {
        return this.getByName(roleName) !== undefined;
    };
    RolesService$$1.prototype.getById = function (roleId) {
        return this.getRoleById({ id: roleId }).getModels()[0];
    };
    RolesService$$1.prototype.getByName = function (roleName) {
        return this.getRoleByName({ name: roleName }).getModels()[0];
    };
    RolesService$$1.prototype.checkRole = function (userId, roleName) {
        if (!userId)
            throw new Error("No userId given while calling 'RolesService.checkRole'!");
        if (!roleName)
            throw new Error("No roleName given while calling 'RolesService.checkRole'!");
        var user = this.collectionsService.getCollectionByName("users").findOne(userId);
        if (!user)
            throw new Error("User with ID '" + userId + "' not found while calling 'RolesService.checkRole'!");
        if (!this.userHasRole(user, roleName))
            throw new Error("User with ID '" + userId + "' doesn't have the role '" + roleName + "'!");
    };
    RolesService$$1.checkRole = function (userId, roleName) {
        RolesService$$1.instance().checkRole(userId, roleName);
    };
    RolesService$$1.prototype.getAdministratorRole = function () {
        return this.getRoleByName({ name: "administrator" }).getModels()[0];
    };
    return RolesService$$1;
}(GeneratedRolesService));

var GeneratedUser = (function () {
    function GeneratedUser() {
        this.roleIds = [];
        this._hasSubDocuments = true;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedUser.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["profile"] = doc["profile"];
        model["emails"] = doc["emails"];
        model["createdAt"] = doc["createdAt"];
        model["services"] = doc["services"];
        model["roleIds"] = doc["roleIds"];
        return model;
    };
    GeneratedUser.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["profile"] = this["profile"];
        doc["emails"] = this["emails"];
        doc["createdAt"] = this["createdAt"];
        doc["services"] = this["services"];
        doc["roleIds"] = this["roleIds"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedUser.prototype.addRoleIds = function (ids) {
        if (this.roleIds === undefined)
            this.roleIds = [];
        _.each(ids, function (id) {
            if (!_.contains(this.roleIds, id))
                this.roleIds.push(id);
        }, this);
    };
    GeneratedUser.prototype.getRoles = function (options) {
        return IOC.get("rolesService").getRolesByIds({ ids: this.roleIds }, options);
    };
    GeneratedUser.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedUser.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedUser.getModelName = function () {
        return "User";
    };
    GeneratedUser.prototype.getModelName = function () {
        return "User";
    };
    GeneratedUser.getModelClass = function () {
        return IOC.get("User");
    };
    GeneratedUser.prototype.getModelClass = function () {
        return IOC.get("User");
    };
    GeneratedUser.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not delete User with ID '" + that.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully removed User with ID '" + that.id + "'!");
            };
        }
        return UserService$$1.instance().delete(this, callback);
    };
    GeneratedUser.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not update User with ID '" + _this.id + "'!");
                else
                    NotificationService$$1.instance().notification.success("Successfully updated User with ID '" + _this.id + "'!");
            };
        }
        return UserService$$1.instance().update(this, callback);
    };
    GeneratedUser.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    NotificationService$$1.instance().getStandardErrorPopup(error, "Could not save User!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    NotificationService$$1.instance().notification.success("Successfully saved User!");
                }
            };
        }
        if (this.dataBridge.isClient())
            UserService$$1.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = UserService$$1.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedUser.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "profile": {
                "type": Object
            },
            "emails": {
                "type": [Object],
                "optional": true
            },
            "createdAt": {
                "type": Number
            },
            "services": {
                "type": Object,
                "optional": true
            },
            "roleIds": {
                "type": [String],
                "defaultValue": [],
                "optional": true
            },
        };
    };
    return GeneratedUser;
}());

var __extends$32 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var User$$1 = (function (_super) {
    __extends$32(User$$1, _super);
    function User$$1() {
        return _super.apply(this, arguments) || this;
    }
    User$$1.prototype.getCurrentAccountDisplayObject = function () {
        if (this.services !== undefined) {
            if (this.services.facebook && this.services.facebook.email)
                return { "icon": "facebook", "text": this.services.facebook.email };
            if (this.services.google && this.services.google.email)
                return { "icon": "google", "text": this.services.google.email };
        }
        if (this.emails !== undefined)
            return { "icon": "mail", "text": this["emails"][0].address };
        return { "icon": "none", "text": "unknown login type" };
    };
    User$$1.prototype.isVerified = function () {
        if (this.services && this.services.facebook && this.services.facebook.email)
            return true;
        if (this.services && this.services.google && this.services.google.email)
            return true;
        if (this.emails instanceof Array) {
            for (var e = 0; e < this.emails.length; e++) {
                if (!this.emails[e].verified)
                    return false;
            }
        }
        return true;
    };
    User$$1.prototype.getAvatarUrl = function (mediaFormat) {
        if (mediaFormat === void 0) { mediaFormat = "squaredthumbnail"; }
        return UserService$$1.instance().getAvatarUrlForUser(this, mediaFormat);
    };
    User$$1.prototype.hasRole = function (role) {
        return RolesService$$1.userHasRole(this, role);
    };
    User$$1.prototype.getSocialLoginType = function () {
        if (this.services) {
            if (this.services.facebook)
                return "facebook";
            if (this.services.google)
                return "google";
            if (this.services.twitter)
                return "twitter";
            if (this.services.linkedin)
                return "linkedin";
        }
        return undefined;
    };
    User$$1.prototype.getSocialLoginAccessToken = function () {
        return this.services[this.getSocialLoginType()].accessToken;
    };
    User$$1.prototype.getGender = function () {
        if (this.services.facebook) {
            if (this.services.facebook.gender === "male" || this.services.facebook.gender === "female")
                return this.services.facebook.gender;
            else
                return "other";
        }
        else if (this.services.google) {
            if (this.services.google.gender === "male" || this.services.google.gender === "female")
                return this.services.google.gender;
            else
                return "other";
        }
        else
            return "other";
    };
    User$$1.prototype.getSocialLoginId = function () {
        return this.services[this.getSocialLoginType()].id;
    };
    User$$1.prototype.getEmail = function () {
        if (this.getSocialLoginType() === "facebook")
            return this.services.facebook.email;
        if (this.getSocialLoginType() === "google")
            return this.services.google.email;
        if (this.emails instanceof Array && this.emails.length > 0) {
            var email = _.find(this.emails, function (email) { return email.verified === true; });
            if (email)
                return email.address;
            else
                return this.emails[0].address;
        }
    };
    User$$1.prototype.getDisplayName = function () {
        return this.profile.displayName;
    };
    User$$1.prototype.getTitle = function () {
        return this.profile.title;
    };
    return User$$1;
}(GeneratedUser));
IOC.register("User", User$$1);

var GeneratedAddress = (function () {
    function GeneratedAddress() {
        this._hasSubDocuments = false;
        this._isStored = false;
        this.dataBridge = IOC.get("dataBridge");
    }
    GeneratedAddress.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["street"] = doc["street"];
        model["streetNumber"] = doc["streetNumber"];
        model["zip"] = doc["zip"];
        model["city"] = doc["city"];
        return model;
    };
    GeneratedAddress.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["street"] = this["street"];
        doc["streetNumber"] = this["streetNumber"];
        doc["zip"] = this["zip"];
        doc["city"] = this["city"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    GeneratedAddress.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    GeneratedAddress.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedAddress.getModelName = function () {
        return "Address";
    };
    GeneratedAddress.prototype.getModelName = function () {
        return "Address";
    };
    GeneratedAddress.getModelClass = function () {
        return IOC.get("Address");
    };
    GeneratedAddress.prototype.getModelClass = function () {
        return IOC.get("Address");
    };
    GeneratedAddress.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "street": {
                "type": String
            },
            "streetNumber": {
                "type": String
            },
            "zip": {
                "type": Number
            },
            "city": {
                "type": String
            },
        };
    };
    return GeneratedAddress;
}());

var __extends$36 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Address$$1 = (function (_super) {
    __extends$36(Address$$1, _super);
    function Address$$1() {
        return _super.apply(this, arguments) || this;
    }
    return Address$$1;
}(GeneratedAddress));
IOC.register("Address", Address$$1);

var __extends$38 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var GeneratedUsersCollection = (function (_super) {
    __extends$38(GeneratedUsersCollection, _super);
    function GeneratedUsersCollection() {
        var _this = _super.call(this) || this;
        _this.name = "users";
        _this.createCollection();
        _this.configureAllowDenyRules();
        _this.createSearchIndex();
        _this.collectionsService.registerCollection("users", _this);
        _this.createPublications();
        return _this;
    }
    GeneratedUsersCollection.prototype.createPublications = function () {
        if (this.dataBridge.isServer()) {
            this.collectionsService.addPublisher("users", "getUsersByIds", { "_id": { "$in": ":ids" } }, { "fields": { "profile.displayName": 1, "profile.avatarUrl": 1, "profile.avatarId": 1, "services.facebook.id": 1, "services.google.picture": 1, "roleIds": 1 } });
            this.collectionsService.addPublisher("users", "getUserById", { "_id": ":id" }, { "fields": { "profile.displayName": 1, "profile.avatarUrl": 1, "profile.avatarId": 1, "services.facebook.id": 1, "user.services.google.picture": 1, "roleIds": 1 } });
            this.collectionsService.addPublisher("users", "getAllUsers", {}, { "fields": { "profile.displayName": 1, "profile.avatarUrl": 1, "profile.avatarId": 1, "services.facebook.id": 1, "user.services.google.picture": 1, "roleIds": 1 } });
            this.collectionsService.addPublisher("users", "getMyUser", { "_id": "_currentLoggedInUser_" }, { "fields": { "services.password": 0, "services.resume": 0, "services.facebook.expiresAt": 0, "services.facebook.accessToken": 0, "services.google.accessToken": 0, "services.google.idToken": 0, "services.google.expiresAt": 0, "services.google.scope": 0, "services.google.verified_email": 0, "services.email.verificationTokens": 0 } });
        }
    };
    GeneratedUsersCollection.prototype.createSearchIndex = function () {
        if (Package["easysearch:core"]) {
            Logger.debug("EasySearch", "Creating search index for collection 'users' and fields 'profile,emails,createdAt,services,_id'!");
            this._easySearchIndex = new EasySearch.Index({
                collection: this._collection,
                fields: ["profile", "emails", "createdAt", "services", "_id"],
                engine: new EasySearch.MongoDB()
            });
        }
    };
    GeneratedUsersCollection.prototype.createCollection = function () {
        this._collection = this.collectionsService.createCollection("users", function (doc) {
            return User$$1.fromDocument(doc);
        });
    };
    GeneratedUsersCollection.prototype.configureAllowDenyRules = function () {
        var allow = this.getCollectionAllowRules();
        if (allow !== undefined)
            this._collection.allow(allow);
        else {
            var deny = this.getCollectionDenyRules();
            if (deny !== undefined)
                this._collection.deny(deny);
            else
                console.warn("No allow/deny rules set for collection : users");
        }
    };
    GeneratedUsersCollection.prototype.getCollectionAllowRules = function () {
        var that = this;
        return {
            insert: function (userId, doc) {
                return (userId && doc.ownerId === userId);
            },
            update: function (userId, doc, fields, modifier) {
                return doc.ownerId === userId;
            },
            remove: function (userId, doc) {
                return doc.ownerId === userId;
            },
            fetch: ['ownerId']
        };
    };
    GeneratedUsersCollection.prototype.getCollectionDenyRules = function () {
        return undefined;
    };
    GeneratedUsersCollection.prototype.getSchema = function () {
        return GeneratedUser.getSchema();
    };
    GeneratedUsersCollection.prototype.getForeignCollection = function (typeName) {
        switch (typeName) {
            case "roleIds":
                return this.typesystem.getTypeByName("Role").getCollectionName();
        }
        return undefined;
    };
    GeneratedUsersCollection.prototype.getForeignGetter = function () {
        return "getUsersByIds";
    };
    GeneratedUsersCollection.getForeignGetter = function () {
        return "getUsersByIds";
    };
    GeneratedUsersCollection.prototype.getModelName = function () {
        return "User";
    };
    GeneratedUsersCollection.prototype.getServiceName = function () {
        return "userService";
    };
    GeneratedUsersCollection.prototype.getQueries = function () {
        return GeneratedUsersCollection.queries;
    };
    GeneratedUsersCollection.prototype.getCollectionName = function () {
        return "users";
    };
    GeneratedUsersCollection.getCollection = function () {
        return IOC.get("collectionsService").getCollectionByName("users");
    };
    return GeneratedUsersCollection;
}(BaseCollection$$1));
GeneratedUsersCollection.queries = {
    "getUsersByIds": { name: "getUsersByIds", parameters: { ids: "ids" } },
    "getUserById": { name: "getUserById", parameters: { id: "id" } },
    "getAllUsers": { name: "getAllUsers", parameters: {} },
    "getMyUser": { name: "getMyUser", parameters: {} }
};
GeneratedUsersCollection.expandables = { "roleIds": "roleIds" };

var __extends$37 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var UsersCollection = (function (_super) {
    __extends$37(UsersCollection, _super);
    function UsersCollection() {
        var _this = _super.call(this) || this;
        if (_this.dataBridge.isServer()) {
            Meteor.publish("userData", function () {
                return Meteor.users.find({ _id: this.userId }, {
                    "fields": {
                        "services.password": 0,
                        "services.resume": 0,
                        "services.facebook.expiresAt": 0,
                        "services.facebook.accessToken": 0,
                        "services.google.accessToken": 0,
                        "services.google.idToken": 0,
                        "services.google.expiresAt": 0,
                        "services.google.scope": 0,
                        "services.google.verified_email": 0,
                        "services.email.verificationTokens": 0
                    }
                });
            });
        }
        return _this;
    }
    UsersCollection.prototype.createCollection = function () {
        this._collection = Meteor.users;
        this._collection["_transform"] = function (doc) {
            return User$$1.fromDocument(doc);
        };
    };
    UsersCollection.prototype.createSearchIndex = function () {
        if (Package["easysearch:core"]) {
            this._easySearchIndex = new EasySearch.Index({
                collection: this._collection,
                fields: ["createdAt", "isTestUser", "profile.displayName", "profile.firstName", "profile.lastName"],
                engine: new EasySearch.MongoDB()
            });
        }
    };
    UsersCollection.prototype.getSchema = function () {
        var schema = _super.prototype.getSchema.call(this);
        schema.services = {
            type: Object,
            optional: true,
            blackbox: true
        };
        schema.emails = {
            type: [Object],
            optional: true
        };
        schema["emails.$.address"] = {
            type: String,
            regEx: SimpleSchema.RegEx.Email
        };
        schema["emails.$.verified"] = {
            type: Boolean
        };
        var profile = new SimpleSchema({
            firstName: {
                type: String,
                optional: true
            },
            lastName: {
                type: String,
                optional: true
            },
            displayName: {
                type: String
            },
            avatarUrl: {
                type: String,
                optional: true
            },
            avatarId: {
                type: String,
                optional: true
            },
            birthday: {
                type: Date,
                optional: true
            },
            gender: {
                type: String,
                allowedValues: ['male', 'female', 'other'],
                optional: true
            },
            state: {
                type: String,
                optional: true
            }
        });
        schema.profile = {
            type: profile,
            optional: true
        };
        schema.isTestUser = {
            type: Boolean,
            optional: true
        };
        return schema;
    };
    UsersCollection.prototype.getCollectionAllowRules = function () {
        return {
            insert: function (userId, doc) {
                return false;
            },
            update: function (userId, doc, fields, modifier) {
                return false;
            },
            remove: function (userId, doc) {
                return false;
            }
        };
    };
    return UsersCollection;
}(GeneratedUsersCollection));

var __extends$40 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var GeneratedRolesCollection = (function (_super) {
    __extends$40(GeneratedRolesCollection, _super);
    function GeneratedRolesCollection() {
        var _this = _super.call(this) || this;
        _this.name = "roles";
        _this.createCollection();
        _this.configureAllowDenyRules();
        _this.createSearchIndex();
        _this.collectionsService.registerCollection("roles", _this);
        _this.createPublications();
        return _this;
    }
    GeneratedRolesCollection.prototype.createPublications = function () {
        if (this.dataBridge.isServer()) {
            this.collectionsService.addPublisher("roles", "getRoleByName", { "name": ":name:string" }, {});
            this.collectionsService.addPublisher("roles", "getRoleById", { "_id": ":id:string" }, {});
            this.collectionsService.addPublisher("roles", "getRolesByIds", { "_id": { "$in": ":ids:string[]" } }, {});
            this.collectionsService.addPublisher("roles", "getAllRoles", {}, {});
        }
    };
    GeneratedRolesCollection.prototype.createSearchIndex = function () {
        if (Package["easysearch:core"]) {
            Logger.debug("EasySearch", "Creating search index for collection 'roles' and fields 'name,_id'!");
            this._easySearchIndex = new EasySearch.Index({
                collection: this._collection,
                fields: ["name", "_id"],
                engine: new EasySearch.MongoDB()
            });
        }
    };
    GeneratedRolesCollection.prototype.createCollection = function () {
        this._collection = this.collectionsService.createCollection("roles", function (doc) {
            return Role$$1.fromDocument(doc);
        });
    };
    GeneratedRolesCollection.prototype.configureAllowDenyRules = function () {
        var allow = this.getCollectionAllowRules();
        if (allow !== undefined)
            this._collection.allow(allow);
        else {
            var deny = this.getCollectionDenyRules();
            if (deny !== undefined)
                this._collection.deny(deny);
            else
                console.warn("No allow/deny rules set for collection : roles");
        }
    };
    GeneratedRolesCollection.prototype.getCollectionAllowRules = function () {
        var that = this;
        return {
            insert: function (userId, doc) {
                return (userId && doc.ownerId === userId);
            },
            update: function (userId, doc, fields, modifier) {
                return doc.ownerId === userId;
            },
            remove: function (userId, doc) {
                return doc.ownerId === userId;
            },
            fetch: ['ownerId']
        };
    };
    GeneratedRolesCollection.prototype.getCollectionDenyRules = function () {
        return undefined;
    };
    GeneratedRolesCollection.prototype.getSchema = function () {
        return GeneratedRole.getSchema();
    };
    GeneratedRolesCollection.prototype.getForeignCollection = function (typeName) {
        switch (typeName) {
            case "subRoleIds":
                return this.typesystem.getTypeByName("Role").getCollectionName();
        }
        return undefined;
    };
    GeneratedRolesCollection.prototype.getForeignGetter = function () {
        return "getRolesByIds";
    };
    GeneratedRolesCollection.getForeignGetter = function () {
        return "getRolesByIds";
    };
    GeneratedRolesCollection.prototype.getModelName = function () {
        return "Role";
    };
    GeneratedRolesCollection.prototype.getServiceName = function () {
        return "rolesService";
    };
    GeneratedRolesCollection.prototype.getQueries = function () {
        return GeneratedRolesCollection.queries;
    };
    GeneratedRolesCollection.prototype.getCollectionName = function () {
        return "roles";
    };
    GeneratedRolesCollection.getCollection = function () {
        return IOC.get("collectionsService").getCollectionByName("roles");
    };
    return GeneratedRolesCollection;
}(BaseCollection$$1));
GeneratedRolesCollection.queries = {
    "getRoleByName": { name: "getRoleByName", parameters: { name: "name" } },
    "getRoleById": { name: "getRoleById", parameters: { id: "id" } },
    "getRolesByIds": { name: "getRolesByIds", parameters: { ids: "ids" } },
    "getAllRoles": { name: "getAllRoles", parameters: {} }
};
GeneratedRolesCollection.expandables = { "subRoleIds": "subRoleIds" };

var __extends$39 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var RolesCollection = (function (_super) {
    __extends$39(RolesCollection, _super);
    function RolesCollection() {
        return _super.call(this) || this;
    }
    return RolesCollection;
}(GeneratedRolesCollection));

(function (BackofficeJobStatus) {
    BackofficeJobStatus[BackofficeJobStatus["IDLE"] = 0] = "IDLE";
    BackofficeJobStatus[BackofficeJobStatus["RUNNING"] = 1] = "RUNNING";
})(exports.BackofficeJobStatus || (exports.BackofficeJobStatus = {}));

function initSmallstackShared$$1(initializeCollections) {
    if (initializeCollections === void 0) { initializeCollections = true; }
    IOC.instance();
    IOC.register("typesystem", new Typesystem$$1());
    IOC.onRegister("dataBridge", function (dataBridge) {
        IOC.onRegister("collectionsService", function () {
            if (initializeCollections) {
                IOC.register("usersCollection", new UsersCollection());
                IOC.register("rolesCollection", new RolesCollection());
                IOC.register("languagesCollection", new LanguagesCollection());
                IOC.register("localizationsCollection", new LocalizationsCollection());
                IOC.register("configurationCollection", new ConfigurationCollection());
                IOC.register("mediaformatsCollection", new MediaformatsCollection());
                IOC.register("mediasCollection", new MediasCollection());
            }
            IOC.register("initLevelService", new InitLevelService());
            IOC.register("bootstrapHooks", new BootstrapHooks$$1());
            IOC.register("configurationService", new ConfigurationService$$1());
            IOC.register("mediaFormatService", new MediaFormatService());
            IOC.register("rolesService", new RolesService$$1());
            IOC.register("userService", new UserService$$1());
            IOC.register("notificationService", new NotificationService$$1());
            IOC.register("languageService", new LanguageService());
            IOC.register("localizationService", new LocalizationService$$1());
            IOC.register("emailService", new EmailService());
            IOC.register("emailTemplatesService", new EmailTemplatesService());
            if (ConfigurationService$$1.instance().get("debug.mode") === "true")
                Logger.debugMode = true;
        });
    });
}

exports.GoogleAnalyticsService = GoogleAnalyticsService;
exports.MultiAnalyticsService = MultiAnalyticsService;
exports.ConfigurationCollection = ConfigurationCollection;
exports.ConfigurationService = ConfigurationService$$1;
exports.Configuration = Configuration$$1;
exports.BootstrapHooks = BootstrapHooks$$1;
exports.InitLevelService = InitLevelService;
exports.IOC = IOC;
exports.Autowired = Autowired;
exports.Logger = Logger;
exports.Utils = Utils;
exports.BaseCollection = BaseCollection$$1;
exports.QueryObject = QueryObject$$1;
exports.QueryUtils = QueryUtils;
exports.Type = Type$$1;
exports.Typesystem = Typesystem$$1;
exports.Email = Email$$1;
exports.EmailTemplate = EmailTemplate$$1;
exports.EmailService = EmailService;
exports.EmailTemplatesService = EmailTemplatesService;
exports.LocalizationService = LocalizationService$$1;
exports.LanguageService = LanguageService;
exports.LanguagesCollection = LanguagesCollection;
exports.LocalizationsCollection = LocalizationsCollection;
exports.LocalizedText = LocalizedText$$1;
exports.Language = Language$$1;
exports.I18nText = I18nText$$1;
exports.initLanguages = initLanguages;
exports.TextReplacer = TextReplacer;
exports.DeviceTypes = DeviceTypes$$1;
exports.PushNotificationService = PushNotificationService$$1;
exports.NotificationService = NotificationService$$1;
exports.NavigationService = NavigationService$$1;
exports.NavigationEntry = NavigationEntry$$1;
exports.MediaService = MediaService$$1;
exports.MediaFormatService = MediaFormatService;
exports.UploadedFileService = UploadedFileService;
exports.MediaformatsCollection = MediaformatsCollection;
exports.MediasCollection = MediasCollection;
exports.Media = Media$$1;
exports.MediaFormat = MediaFormat$$1;
exports.UploadedFile = UploadedFile$$1;
exports.User = User$$1;
exports.UserService = UserService$$1;
exports.Role = Role$$1;
exports.Address = Address$$1;
exports.RolesService = RolesService$$1;
exports.UsersCollection = UsersCollection;
exports.RolesCollection = RolesCollection;
exports.initSmallstackShared = initSmallstackShared$$1;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=common.umd.js.map
