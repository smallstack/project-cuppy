export interface INotifier {
    info(title: string, message?: string): void;
    success(title: string, message?: string): void;
    debug(title: string, message?: string): void;
    warn(title: string, message?: string): void;
    error(title: string, message?: string): void;
    confirmation(title: string, message: string, callback: (answer: boolean) => void): void;
}
