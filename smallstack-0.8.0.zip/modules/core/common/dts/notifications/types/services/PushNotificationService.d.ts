import { GeneratedPushNotificationService } from './../generated/services/GeneratedPushNotificationService';
import { PushNotification } from '../models/PushNotification';
export declare let DeviceTypes: {
    "ios": string;
    "android": string;
    "amazon": string;
    "windowsphonempns": string;
    "chromeapporextension": string;
    "chromewebpush": string;
    "windowsphonewns": string;
    "safari": string;
    "firefox": string;
    "macos": string;
};
export declare class PushNotificationService extends GeneratedPushNotificationService<PushNotification> {
    private oneSignalApiUrl;
    private appId;
    private restApiKey;
    private configurationService;
    constructor();
    sendNotification(pushNotification: PushNotification, includedSegments?: string[]): void;
    registerDevice(identifier: string, deviceType: string, ISOlanguage: string): void;
    private signalOneDeviceMapping(deviceString);
}
