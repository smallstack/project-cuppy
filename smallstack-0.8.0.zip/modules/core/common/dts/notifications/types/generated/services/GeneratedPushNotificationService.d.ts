import { QueryOptions, QueryObject, CollectionsService, Collection, DataBridge, SmallstackModel } from "../../../../common";
import { PushNotificationService } from "../../services/PushNotificationService";
export declare class GeneratedPushNotificationService<ModelClass extends SmallstackModel> {
    protected collectionsService: CollectionsService;
    protected dataBridge: DataBridge;
    constructor();
    static instance(): PushNotificationService;
    getCollection(): Collection<ModelClass>;
    getAllPushNotifications(parameters?: {}, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    save(model: ModelClass, callback?: (error: Error, savedId: string) => void): string;
    update(model: ModelClass, callback?: (error: Error, numberOfUpdatedDocuments: number) => void): number;
    delete(model: ModelClass, callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
}
