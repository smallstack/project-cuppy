import { SmallstackModel, DataBridge } from "../../../../common";
export declare class GeneratedPushNotification implements SmallstackModel {
    protected dataBridge: DataBridge;
    id: string;
    subjects: any;
    contents: any;
    createdAt: Date;
    sentAt: Date;
    reachedCount: number;
    sent: boolean;
    private _hasSubDocuments;
    private _isStored;
    constructor();
    static fromDocument<T>(doc: any): T;
    toDocument(identifierKey?: string): {};
    hasSubDocuments(): boolean;
    isStored(): boolean;
    static getModelName(): string;
    getModelName(): string;
    static getModelClass(): any;
    getModelClass(): any;
    delete(callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
    update(callback?: (error: Error, numberOfSavedDocuments: number) => void): number;
    save(callback?: (error: Error, savedId: string) => void): string;
    static getSchema(): any;
}
