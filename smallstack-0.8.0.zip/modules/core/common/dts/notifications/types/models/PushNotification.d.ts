import { GeneratedPushNotification } from "../generated/models/GeneratedPushNotification";
export declare class PushNotification extends GeneratedPushNotification {
}
