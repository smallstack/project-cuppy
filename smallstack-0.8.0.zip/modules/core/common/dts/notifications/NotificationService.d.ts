import { INotifier } from "./INotifier";
export declare class NotificationService {
    console: INotifier;
    popup: INotifier;
    notification: INotifier;
    static instance(): NotificationService;
    constructor();
    getStandardCallback(errorMsg?: string, successMsg?: string): any;
    getStandardErrorPopup(error: Error, additionalText?: string): any;
    getStandardErrorPopup(error: Error, additionalText?: string): any;
    setConsoleNotifier(notifier: INotifier): void;
    setPopupNotifier(notifier: INotifier): void;
    setNotificationNotifier(notifier: INotifier): void;
}
