import { GeneratedEmailService } from "../generated/services/GeneratedEmailService";
import { Email } from "../models/Email";
export declare class EmailService extends GeneratedEmailService<Email> {
}
