import { GeneratedEmailTemplatesService } from "../generated/services/GeneratedEmailTemplatesService";
import { EmailTemplate } from "../models/EmailTemplate";
export declare class EmailTemplatesService extends GeneratedEmailTemplatesService<EmailTemplate> {
}
