import { QueryOptions, QueryObject, CollectionsService, Collection, DataBridge, SmallstackModel } from "../../../../common";
import { EmailTemplatesService } from "../../services/EmailTemplatesService";
export declare class GeneratedEmailTemplatesService<ModelClass extends SmallstackModel> {
    protected collectionsService: CollectionsService;
    protected dataBridge: DataBridge;
    constructor();
    static instance(): EmailTemplatesService;
    getCollection(): Collection<ModelClass>;
    getAllTemplates(parameters?: {}, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    save(model: ModelClass, callback?: (error: Error, savedId: string) => void): string;
    update(model: ModelClass, callback?: (error: Error, numberOfUpdatedDocuments: number) => void): number;
    delete(model: ModelClass, callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
}
