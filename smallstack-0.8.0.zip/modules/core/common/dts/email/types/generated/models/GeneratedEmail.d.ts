import { QueryObject, QueryOptions, SmallstackModel, DataBridge } from "../../../../common";
import { User } from "../../../../user/types/models/User";
export declare class GeneratedEmail implements SmallstackModel {
    protected dataBridge: DataBridge;
    id: string;
    createdAt: Date;
    sentAt: Date;
    from: string;
    to: string[];
    toUserIds: string[];
    cc: string[];
    bcc: string[];
    subjects: any;
    contents: any;
    htmlMail: boolean;
    status: string;
    private _hasSubDocuments;
    private _isStored;
    static enums: {
        "status": {
            "CREATED": string;
            "SCHEDULED": string;
            "SENDING": string;
            "SENT": string;
        };
    };
    constructor();
    static fromDocument<T>(doc: any): T;
    toDocument(identifierKey?: string): {};
    addToUserIds(ids: string[]): void;
    getToUsers(options?: QueryOptions): QueryObject<User>;
    hasSubDocuments(): boolean;
    isStored(): boolean;
    static getModelName(): string;
    getModelName(): string;
    static getModelClass(): any;
    getModelClass(): any;
    delete(callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
    update(callback?: (error: Error, numberOfSavedDocuments: number) => void): number;
    save(callback?: (error: Error, savedId: string) => void): string;
    static getSchema(): any;
}
