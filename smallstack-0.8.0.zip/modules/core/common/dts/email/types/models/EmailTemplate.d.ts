import { GeneratedEmailTemplate } from "../generated/models/GeneratedEmailTemplate";
export declare class EmailTemplate extends GeneratedEmailTemplate {
}
