import { GeneratedEmail } from "../generated/models/GeneratedEmail";
export declare class Email extends GeneratedEmail {
}
