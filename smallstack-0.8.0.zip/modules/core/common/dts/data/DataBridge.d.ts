import { QueryOptions } from "./QueryOptions";
export interface DataBridge {
    subscribe(publicationName: string, parameters: any, options: QueryOptions, callbackFns: {
        onStop: (error?: any) => void;
        onError: (error: any) => void;
        onReady: () => void;
    }): void;
    callMethod(methodName: any, parameters: any, callbackFns: (error: Error, result: any) => void): void;
    getCurrentUserId(): string;
    userAuthenticated(): boolean;
    logout(callbackFn: (error: Error, success?: boolean) => void): void;
    getSessionVariable(key: string): any;
    setSessionVariable(key: string, value: any): void;
    isClient(): boolean;
    isServer(): boolean;
    instance(): DataBridge;
    addServerMethod(name: string, func: Function): void;
    reactiveContext(fn: Function): any;
}
