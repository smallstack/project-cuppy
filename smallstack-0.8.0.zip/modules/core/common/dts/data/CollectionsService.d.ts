import { Collection } from "./Collection";
export interface CollectionsService {
    getCollectionByName<T>(name: string): Collection<T>;
    getAllCollections(): {
        [name: string]: Collection<any>;
    };
    registerCollection(name: any, collection: any): any;
    addPublisher(collectionName: string, name: string, mongoSelector?: any, mongoOptions?: any): any;
    addPublisherMethod(name: any, fn: (params: PublisherMethodParameters) => PublisherMethodResult): any;
    executePublisherMethod(methodName: string, params: PublisherMethodParameters): PublisherMethodResult;
    subscribeForeignKeys(baseCollection: Collection<any>, cursor: any, expands: string[], callback?: () => void): any;
    createCollection<ModelClass>(name: string, transformFn?: Function): any;
}
export interface PublisherMethodParameters {
    context: {
        userId: string;
    };
    parameters: any;
    accessObject: any;
}
export interface PublisherMethodResult {
    type: "boolean" | "selector";
    value: any;
}
