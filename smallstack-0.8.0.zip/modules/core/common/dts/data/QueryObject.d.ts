import { QueryOptions } from "./QueryOptions";
import { Collection } from "./Collection";
export declare class QueryObject<ModelClass> {
    private isSubscribed;
    private selector;
    private subscriptionName;
    private queryOptions;
    private parameters;
    private sorting;
    private collection;
    private cursorResolver;
    private ModelConstructor;
    private typesystem;
    constructor();
    create(selector: any, subscriptionName: string, queryOptions: QueryOptions, parameters: any, sorting: any, collection: Collection<ModelClass>): QueryObject<ModelClass>;
    getSelector(): string;
    getCursor(): any;
    getModels(callback?: (models: ModelClass[]) => void): ModelClass[];
    getModel(index: number, callback?: (model: ModelClass) => void): ModelClass;
    subscribe(onReadyCallback?: (error: Error, queryObject: QueryObject<ModelClass>) => void): void;
    expand(foreignKeys: string[], callback?: () => void): void;
    getCount(callback: (count: number) => void): void;
    getPage(pageNumber: number, callback: (models: ModelClass[]) => void): void;
    getNextPage(callback: (models: ModelClass[]) => void): void;
    getCurrentPage(callback: (models: ModelClass[]) => void): void;
    getPreviousPage(callback: (models: ModelClass[]) => void): void;
    hasNextPage(): boolean;
    hasPreviousPage(): boolean;
}
