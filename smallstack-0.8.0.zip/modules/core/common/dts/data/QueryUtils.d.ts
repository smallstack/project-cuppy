import { QueryOptions } from "./QueryOptions";
export declare class QueryUtils {
    static interpolate(selector: any, context: {
        userId: string;
        parameters: any;
    }): any;
    static escapeRegExp(str: string): string;
    static convertQueryOptionsToMongoSelector(queryOptions: QueryOptions, sorting: any): any;
}
