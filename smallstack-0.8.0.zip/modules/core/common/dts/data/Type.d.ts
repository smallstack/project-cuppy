import { SmallstackModelStatic } from "./SmallstackModel";
export interface TypeServiceQuery {
    selector: any;
    access: any;
    sorting: any;
    name: string;
    hasRole: string;
}
export declare class Type {
    name: string;
    collection: {
        name: string;
    };
    service: {
        name: string;
        queries: TypeServiceQuery[];
    };
    model: {
        name: string;
        schema: [{
            name: string;
            type: string;
            optional: boolean;
        }];
    };
    static fromDocument(doc: any): Type;
    getServiceName(): string;
    getModelName(): string;
    getService(): {};
    getCollectionName(): string;
    getModel(): SmallstackModelStatic;
    getServiceQueryByName(name: string): TypeServiceQuery;
    getSchemaEntryByName(name: string): any;
}
