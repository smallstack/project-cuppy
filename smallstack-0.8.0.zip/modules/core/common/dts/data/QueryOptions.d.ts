export interface QueryOptions {
    currentPage?: number;
    entriesPerPage?: number;
    reactive?: boolean;
}
