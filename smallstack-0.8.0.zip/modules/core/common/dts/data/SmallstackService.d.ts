import { Collection } from "./Collection";
import { SmallstackModel } from "./SmallstackModel";
export interface SmallstackService<ModelClass extends SmallstackModel> {
    getCollection(): Collection<ModelClass>;
    save(model: ModelClass, callback?: (error: Error, savedId: string) => void): string;
    update(model: ModelClass, callback?: (error: Error, numberOfUpdatedDocuments: number) => void): number;
    delete(model: ModelClass, callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
}
export interface SmallstackServiceStatic<ModelClass extends SmallstackModel> {
    new (): SmallstackService<ModelClass>;
    instance<T>(): T;
}
