export interface SmallstackModel {
    id: string;
    toDocument(identifierKey?: string): any;
    hasSubDocuments(): boolean;
    isStored(): boolean;
    getModelName(): string;
    getModelClass(): any;
}
export interface SmallstackModelStatic {
    new (): SmallstackModel;
    fromDocument<T>(doc: any): SmallstackModel;
    getModelName(): string;
    getModelClass(): any;
    getSchema(): any;
}
