import { SmallstackModelStatic } from "../data/SmallstackModel";
export interface CursorResolver<ModelClass> {
    resolve(cursor: any, options: {
        ModelConstructor?: SmallstackModelStatic;
    }, callback?: (models: ModelClass[]) => void): ModelClass[];
}
