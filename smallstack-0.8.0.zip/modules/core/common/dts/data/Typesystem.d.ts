import { Type } from "./Type";
export declare class Typesystem {
    private _types;
    addType(type: Type): void;
    getTypeByName(name: string): Type;
    getTypeByCollectionName(collectionName: string): Type;
    getAllTypes(): Type[];
    static instance(): Typesystem;
}
