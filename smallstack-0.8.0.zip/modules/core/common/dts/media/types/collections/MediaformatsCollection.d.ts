import { GeneratedMediaformatsCollection } from "../generated/collections/GeneratedMediaformatsCollection";
export declare class MediaformatsCollection extends GeneratedMediaformatsCollection {
    constructor();
}
