import { GeneratedMediasCollection } from "../generated/collections/GeneratedMediasCollection";
export declare class MediasCollection extends GeneratedMediasCollection {
    constructor();
}
