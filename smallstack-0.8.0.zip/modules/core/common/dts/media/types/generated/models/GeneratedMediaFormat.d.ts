import { SmallstackModel, DataBridge } from "../../../../common";
export declare class GeneratedMediaFormat implements SmallstackModel {
    protected dataBridge: DataBridge;
    id: string;
    name: string;
    preprocessed: boolean;
    command: string;
    parameters: any;
    isDefault: boolean;
    private _hasSubDocuments;
    private _isStored;
    static enums: {
        "command": {
            "RESIZE": string;
            "SCALE": string;
            "BLUR": string;
            "COVER": string;
        };
    };
    constructor();
    static fromDocument<T>(doc: any): T;
    toDocument(identifierKey?: string): {};
    hasSubDocuments(): boolean;
    isStored(): boolean;
    static getModelName(): string;
    getModelName(): string;
    static getModelClass(): any;
    getModelClass(): any;
    delete(callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
    update(callback?: (error: Error, numberOfSavedDocuments: number) => void): number;
    save(callback?: (error: Error, savedId: string) => void): string;
    static getSchema(): any;
}
