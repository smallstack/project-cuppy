import { QueryOptions, QueryObject, CollectionsService, Collection, DataBridge, SmallstackModel } from "../../../../common";
import { MediaService } from "../../services/MediaService";
export declare class GeneratedMediaService<ModelClass extends SmallstackModel> {
    protected collectionsService: CollectionsService;
    protected dataBridge: DataBridge;
    constructor();
    static instance(): MediaService;
    getCollection(): Collection<ModelClass>;
    getMediaByIds(parameters?: {
        ids: string[];
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getMediaById(parameters?: {
        id: string;
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getAllMedias(parameters?: {}, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getMediasByTag(parameters?: {
        tag: any;
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    save(model: ModelClass, callback?: (error: Error, savedId: string) => void): string;
    update(model: ModelClass, callback?: (error: Error, numberOfUpdatedDocuments: number) => void): number;
    delete(model: ModelClass, callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
}
