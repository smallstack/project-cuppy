import { Collection } from "../../../../common";
import { BaseCollection } from "../../../../common";
import { Media } from "../../models/Media";
export declare class GeneratedMediasCollection extends BaseCollection<Media> implements Collection<Media> {
    name: string;
    protected _easySearchIndex: any;
    static queries: {
        "getMediaByIds": {
            name: string;
            parameters: {
                ids: string;
            };
        };
        "getMediaById": {
            name: string;
            parameters: {
                id: string;
            };
        };
        "getAllMedias": {
            name: string;
            parameters: {};
        };
        "getMediasByTag": {
            name: string;
            parameters: {
                tag: string;
            };
        };
    };
    static expandables: {
        "ownerId": string;
        "availableFormatIds": string;
    };
    constructor();
    protected createPublications(): void;
    protected createSearchIndex(): void;
    protected createCollection(): void;
    protected configureAllowDenyRules(): void;
    protected getCollectionAllowRules(): any;
    protected getCollectionDenyRules(): any;
    protected getSchema(): any;
    getForeignCollection(typeName: string): string;
    getForeignGetter(): string;
    static getForeignGetter(): string;
    getModelName(): string;
    getServiceName(): string;
    getQueries(): {
        [queryName: string]: any;
    };
    getCollectionName(): string;
    static getCollection(): Collection<Media>;
}
