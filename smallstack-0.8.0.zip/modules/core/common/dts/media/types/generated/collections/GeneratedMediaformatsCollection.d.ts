import { Collection } from "../../../../common";
import { BaseCollection } from "../../../../common";
import { MediaFormat } from "../../models/MediaFormat";
export declare class GeneratedMediaformatsCollection extends BaseCollection<MediaFormat> implements Collection<MediaFormat> {
    name: string;
    protected _easySearchIndex: any;
    static queries: {
        "getMediaFormatByName": {
            name: string;
            parameters: {
                name: string;
            };
        };
        "getAllMediaFormats": {
            name: string;
            parameters: {};
        };
        "getMediaFormatsByIds": {
            name: string;
            parameters: {
                ids: string;
            };
        };
        "getMediaFormatById": {
            name: string;
            parameters: {
                id: string;
            };
        };
    };
    static expandables: {};
    constructor();
    protected createPublications(): void;
    protected createSearchIndex(): void;
    protected createCollection(): void;
    protected configureAllowDenyRules(): void;
    protected getCollectionAllowRules(): any;
    protected getCollectionDenyRules(): any;
    protected getSchema(): any;
    getForeignCollection(typeName: string): string;
    getForeignGetter(): string;
    static getForeignGetter(): string;
    getModelName(): string;
    getServiceName(): string;
    getQueries(): {
        [queryName: string]: any;
    };
    getCollectionName(): string;
    static getCollection(): Collection<MediaFormat>;
}
