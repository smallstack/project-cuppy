import { GeneratedMediaFormat } from "../generated/models/GeneratedMediaFormat";
export declare class MediaFormat extends GeneratedMediaFormat {
    static byName(name: string): MediaFormat;
    static defaultFormats: {
        "original": string;
    };
}
