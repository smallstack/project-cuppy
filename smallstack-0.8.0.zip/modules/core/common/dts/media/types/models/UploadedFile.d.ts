import { GeneratedUploadedFile } from "../generated/models/GeneratedUploadedFile";
export declare class UploadedFile extends GeneratedUploadedFile {
}
