import { GeneratedMedia } from "../generated/models/GeneratedMedia";
export declare class Media extends GeneratedMedia {
}
