import { GeneratedMediaService } from "../generated/services/GeneratedMediaService";
import { MediaFormat } from "../models/MediaFormat";
import { Media } from "../models/Media";
import { ConfigurationService } from "../../../common";
export declare abstract class MediaService extends GeneratedMediaService<Media> {
    protected configurationService: ConfigurationService;
    private jimp;
    constructor();
    protected decodeBase64Image(dataString: string): any;
    protected processImage(typedBuffer: any, mediaFormat: MediaFormat): any;
    private checkParameter(name, mediaFormat);
    private imageToBuffer(image, type);
    abstract storeMediaFromDataUrl(media: Media, dataUrlString: string, mediaFormat: MediaFormat): boolean;
    abstract storeMediaFromURL(media: Media, url: string, mediaFormat: MediaFormat): boolean;
    abstract getUrlForMediaId(mediaId: string, mediaFormatName: string): string;
}
