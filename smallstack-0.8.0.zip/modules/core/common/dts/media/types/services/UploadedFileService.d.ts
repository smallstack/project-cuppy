import { GeneratedUploadedFileService } from "../generated/services/GeneratedUploadedFileService";
import { UploadedFile } from "../models/UploadedFile";
export declare class UploadedFileService extends GeneratedUploadedFileService<UploadedFile> {
}
