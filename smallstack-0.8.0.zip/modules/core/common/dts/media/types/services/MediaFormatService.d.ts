import { GeneratedMediaFormatService } from "../generated/services/GeneratedMediaFormatService";
import { MediaFormat } from '../models/MediaFormat';
export declare class MediaFormatService extends GeneratedMediaFormatService<MediaFormat> {
    createFormat(name: string, command: string, parameters: any, preprocessed: boolean, isDefault: boolean): MediaFormat;
}
