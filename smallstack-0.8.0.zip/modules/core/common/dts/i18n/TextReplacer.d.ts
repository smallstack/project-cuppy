export interface TextReplacerContext {
    [key: string]: string;
}
export declare class TextReplacer {
    static replace(content: string, context: TextReplacerContext): string;
}
