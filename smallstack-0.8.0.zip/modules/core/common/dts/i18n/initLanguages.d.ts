import { Language } from "./types/models/Language";
export declare function initLanguages(languages: Language[]): void;
