import { GeneratedI18nText } from "../generated/models/GeneratedI18nText";
export declare class I18nText extends GeneratedI18nText {
}
