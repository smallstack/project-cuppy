import { GeneratedLanguage } from "../generated/models/GeneratedLanguage";
export declare class Language extends GeneratedLanguage {
}
