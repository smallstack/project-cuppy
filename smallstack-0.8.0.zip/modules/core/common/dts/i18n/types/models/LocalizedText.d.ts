import { GeneratedLocalizedText } from "../generated/models/GeneratedLocalizedText";
export declare class LocalizedText extends GeneratedLocalizedText {
}
