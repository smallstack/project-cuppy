import { Collection } from "../../../../common";
import { BaseCollection } from "../../../../common";
import { Language } from "../../models/Language";
export declare class GeneratedLanguagesCollection extends BaseCollection<Language> implements Collection<Language> {
    name: string;
    protected _easySearchIndex: any;
    static queries: {
        "getAllLanguages": {
            name: string;
            parameters: {};
        };
        "getLanguageByKey": {
            name: string;
            parameters: {
                key: string;
            };
        };
    };
    static expandables: {};
    constructor();
    protected createPublications(): void;
    protected createSearchIndex(): void;
    protected createCollection(): void;
    protected configureAllowDenyRules(): void;
    protected getCollectionAllowRules(): any;
    protected getCollectionDenyRules(): any;
    protected getSchema(): any;
    getForeignCollection(typeName: string): string;
    getForeignGetter(): string;
    static getForeignGetter(): string;
    getModelName(): string;
    getServiceName(): string;
    getQueries(): {
        [queryName: string]: any;
    };
    getCollectionName(): string;
    static getCollection(): Collection<Language>;
}
