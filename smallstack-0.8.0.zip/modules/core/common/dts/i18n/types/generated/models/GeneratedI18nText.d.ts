import { SmallstackModel, DataBridge } from "../../../../common";
export declare class GeneratedI18nText implements SmallstackModel {
    protected dataBridge: DataBridge;
    id: string;
    language: string;
    value: string;
    private _hasSubDocuments;
    private _isStored;
    constructor();
    static fromDocument<T>(doc: any): T;
    toDocument(identifierKey?: string): {};
    hasSubDocuments(): boolean;
    isStored(): boolean;
    static getModelName(): string;
    getModelName(): string;
    static getModelClass(): any;
    getModelClass(): any;
    static getSchema(): any;
}
