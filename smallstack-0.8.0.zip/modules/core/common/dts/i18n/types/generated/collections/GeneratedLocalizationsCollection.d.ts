import { Collection } from "../../../../common";
import { BaseCollection } from "../../../../common";
import { LocalizedText } from "../../models/LocalizedText";
export declare class GeneratedLocalizationsCollection extends BaseCollection<LocalizedText> implements Collection<LocalizedText> {
    name: string;
    protected _easySearchIndex: any;
    static queries: {
        "getLocalizationsForLanguage": {
            name: string;
            parameters: {
                languageKey: string;
            };
        };
        "getLocalizationForLanguage": {
            name: string;
            parameters: {
                key: string;
                languageKey: string;
            };
        };
        "getLocalizations": {
            name: string;
            parameters: {};
        };
        "getLocalizedTextsByIds": {
            name: string;
            parameters: {
                ids: string;
            };
        };
        "getLocalizedTextById": {
            name: string;
            parameters: {
                id: string;
            };
        };
    };
    static expandables: {};
    constructor();
    protected createPublications(): void;
    protected createSearchIndex(): void;
    protected createCollection(): void;
    protected configureAllowDenyRules(): void;
    protected getCollectionAllowRules(): any;
    protected getCollectionDenyRules(): any;
    protected getSchema(): any;
    getForeignCollection(typeName: string): string;
    getForeignGetter(): string;
    static getForeignGetter(): string;
    getModelName(): string;
    getServiceName(): string;
    getQueries(): {
        [queryName: string]: any;
    };
    getCollectionName(): string;
    static getCollection(): Collection<LocalizedText>;
}
