import { QueryOptions, QueryObject, CollectionsService, Collection, DataBridge, SmallstackModel } from "../../../../common";
import { LocalizationService } from "../../services/LocalizationService";
export declare class GeneratedLocalizationService<ModelClass extends SmallstackModel> {
    protected collectionsService: CollectionsService;
    protected dataBridge: DataBridge;
    constructor();
    static instance(): LocalizationService;
    getCollection(): Collection<ModelClass>;
    getLocalizationsForLanguage(parameters?: {
        languageKey: any;
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getLocalizationForLanguage(parameters?: {
        key: any;
        languageKey: any;
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getLocalizations(parameters?: {}, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getLocalizedTextsByIds(parameters?: {
        ids: string[];
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getLocalizedTextById(parameters?: {
        id: string;
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    save(model: ModelClass, callback?: (error: Error, savedId: string) => void): string;
    update(model: ModelClass, callback?: (error: Error, numberOfUpdatedDocuments: number) => void): number;
    delete(model: ModelClass, callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
}
