import { GeneratedLanguageService } from "../generated/services/GeneratedLanguageService";
import { Language } from "../models/Language";
export declare class LanguageService extends GeneratedLanguageService<Language> {
    isLanguage(languageKey: string): boolean;
}
