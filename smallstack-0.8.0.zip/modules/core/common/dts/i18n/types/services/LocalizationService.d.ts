import { GeneratedLocalizationService } from "../generated/services/GeneratedLocalizationService";
import { TextReplacerContext } from "../../TextReplacer";
import { User } from "../../../common";
import { LocalizedText } from "../models/LocalizedText";
export interface LocalizationOptions {
    showMissingKey?: boolean;
    language?: string;
    replacers?: TextReplacerContext;
}
export declare class LocalizationService extends GeneratedLocalizationService<LocalizedText> {
    private configurationService;
    private languageService;
    private defaultLanguageChains;
    private localizationIsLoaded;
    private localizationCache;
    constructor();
    getUserLanguage(userId: string): string;
    getUserLanguage(user: User): string;
    getCurrentLanguage(): string;
    setCurrentLanguage(languageKey: string): void;
    private setUserLanguage(languageKey);
    private getBrowserLanguage();
    isAvailableLanguageKey(languageKey: string): boolean;
    getFallbackLanguage(): string;
    getTranslation(key: string, options?: LocalizationOptions): string;
    t(key: string, options?: LocalizationOptions): string;
    static t(key: string, options?: LocalizationOptions): string;
    addTranslation(languageKey: string, newTrans: any): void;
    addToCache(languageId: any, key: any, value: any): void;
}
