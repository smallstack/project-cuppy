import { GeneratedLocalizationsCollection } from "../generated/collections/GeneratedLocalizationsCollection";
export declare class LocalizationsCollection extends GeneratedLocalizationsCollection {
    constructor();
}
