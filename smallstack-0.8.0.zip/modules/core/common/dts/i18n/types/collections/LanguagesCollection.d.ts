import { GeneratedLanguagesCollection } from "../generated/collections/GeneratedLanguagesCollection";
export declare class LanguagesCollection extends GeneratedLanguagesCollection {
    constructor();
}
