import { GeneratedNavigationCollection } from "../generated/collections/GeneratedNavigationCollection";
export declare class NavigationCollection extends GeneratedNavigationCollection {
    constructor();
}
