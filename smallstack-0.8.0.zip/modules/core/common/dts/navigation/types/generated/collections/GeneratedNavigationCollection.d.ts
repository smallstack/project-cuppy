import { Collection } from "../../../../common";
import { BaseCollection } from "../../../../common";
import { NavigationEntry } from "../../models/NavigationEntry";
export declare class GeneratedNavigationCollection extends BaseCollection<NavigationEntry> implements Collection<NavigationEntry> {
    name: string;
    protected _easySearchIndex: any;
    static queries: {
        "getNavigationForType": {
            name: string;
            parameters: {
                type: string;
            };
        };
        "getNavigationEntryById": {
            name: string;
            parameters: {
                id: string;
            };
        };
    };
    static expandables: {
        "substateOfId": string;
    };
    constructor();
    protected createPublications(): void;
    protected createSearchIndex(): void;
    protected createCollection(): void;
    protected configureAllowDenyRules(): void;
    protected getCollectionAllowRules(): any;
    protected getCollectionDenyRules(): any;
    protected getSchema(): any;
    getForeignCollection(typeName: string): string;
    getForeignGetter(): string;
    static getForeignGetter(): string;
    getModelName(): string;
    getServiceName(): string;
    getQueries(): {
        [queryName: string]: any;
    };
    getCollectionName(): string;
    static getCollection(): Collection<NavigationEntry>;
}
