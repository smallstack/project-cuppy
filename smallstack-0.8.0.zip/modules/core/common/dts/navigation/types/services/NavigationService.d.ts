import "../../../core/BootstrapHooks";
import "../collections/NavigationCollection";
import { GeneratedNavigationService } from "../generated/services/GeneratedNavigationService";
import { NavigationEntry } from "../models/NavigationEntry";
export declare class NavigationService extends GeneratedNavigationService<NavigationEntry> {
    private configurationService;
    private rolesService;
    private bootstrapHooks;
    private navigation;
    private dbNavigation;
    private layouts;
    private onNavigationEntryAddFns;
    private navigationInitialized;
    constructor();
    static getCurrent(): NavigationService;
    setModel(model: NavigationEntry[]): void;
    addNavigationEntry(navigationEntry: NavigationEntry): void;
    processNavigationEntry(navigationEntry: NavigationEntry): void;
    getEntryByRoute(route: string): NavigationEntry;
    getNavigationEntries(): NavigationEntry[];
    getCodeNavigationEntries(): NavigationEntry[];
    getDBNavigationEntries(): NavigationEntry[];
    getNavigationEntriesForNavigationType(navType: string): NavigationEntry[];
    setLayout(id: string, url: string): void;
    getEntryByStateName(stateName: string): NavigationEntry;
    onNavigationEntryAdd(fn: (navigationEntry: NavigationEntry) => void, thisArg?: any): void;
    getDefaultNavigatioNentry(): NavigationEntry;
    private executeCallback(cb, arg);
}
