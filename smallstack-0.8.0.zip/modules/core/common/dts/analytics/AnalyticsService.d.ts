export interface AnalyticsService {
    event(eventName: string, options?: {
        category?: string;
        action?: string;
        label?: string;
        value?: string;
    }): void;
    track(path: string, options?: any): void;
}
