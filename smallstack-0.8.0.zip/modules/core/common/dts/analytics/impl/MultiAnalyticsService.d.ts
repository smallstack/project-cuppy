import { AnalyticsService } from "../AnalyticsService";
export declare class MultiAnalyticsService implements AnalyticsService {
    private googleAnalyticsService;
    track(path: string, options?: any): void;
    event(eventName: string, options?: {
        category?: string;
        label?: string;
        value?: string;
    }): void;
}
