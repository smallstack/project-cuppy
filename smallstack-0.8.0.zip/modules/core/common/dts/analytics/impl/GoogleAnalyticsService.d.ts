import { AnalyticsService } from "../AnalyticsService";
export declare class GoogleAnalyticsService implements AnalyticsService {
    constructor();
    track(path: string, options?: any): void;
    event(eventName: string, options?: {
        category?: string;
        label?: string;
        value?: string;
    }): void;
}
