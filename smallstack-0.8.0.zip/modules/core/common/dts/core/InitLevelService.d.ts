export declare class InitLevelService {
    private initLevels;
    private executableLevels;
    addInitLevelFn(level: number, identifier: string, fn: (callback: (error: Error, success: boolean) => void) => void): void;
    execute(): void;
    private next();
    static instance(): InitLevelService;
}
