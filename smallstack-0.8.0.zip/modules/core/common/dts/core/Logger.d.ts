export declare type LoggerLevel = "info" | "debug" | "error" | "warn";
export declare class Logger {
    private static loggerMaxLength;
    private static debugModules;
    static debugMode: boolean;
    static log(level: LoggerLevel, moduleName: string, message: string, stacktrace?: any): void;
    static info(moduleName: string, message: string, stacktrace?: any): void;
    static warning(moduleName: string, message: string, stacktrace?: any): void;
    static error(moduleName: string, message: string, stacktrace?: any): void;
    static debug(moduleName: string, message: string, stacktrace?: any): void;
    static loggingModule(level: LoggerLevel, moduleName: string): boolean;
    static printSmallstackLogo(): void;
}
