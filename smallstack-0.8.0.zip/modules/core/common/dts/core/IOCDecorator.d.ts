export declare function Autowired(injectionKey?: string): any;
