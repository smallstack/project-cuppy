export declare enum PadDirection {
    RIGHT = 0,
    LEFT = 1,
}
export declare class Utils {
    static isNonEmptyString(string: any): boolean;
    static isEmptyString(string: any): boolean;
    static isMobile(): boolean;
    static stringEndsWith(string: string, suffix: string): boolean;
    static getUrlParameterByName(name: string, url: string): string;
    static check(property: any, type: any, name: string, callback?: (error: Error) => void): void;
    static createUrlConformIdFromInput(input: string, maxLength?: number): string;
    static unflattenJSON(data: any): any;
    static flattenJSON(data: any): any;
    static prettyPrintJson(object: any, maxLength?: number): string;
    static dasherize(str: string): string;
    static decapitalize(str: string): string;
    static capitalize(str: string): string;
    static spaceBeforeUppercase(str: string): string;
    static padString(str: string, maxLength: number, direction?: PadDirection, fillingCharacter?: string): string;
    static convertHexToRGB(colorAsHex: string): {
        r: number;
        g: number;
        b: number;
    };
    static isValidUrlName(url: string): boolean;
    static dataURLtoBlob(dataurl: string): Blob;
    static blobToDataURL(blob: Blob, callback: (dataUrl: string) => void): void;
    static imageUrlToBlob(url: string, callback: (blob: Blob) => void): void;
}
