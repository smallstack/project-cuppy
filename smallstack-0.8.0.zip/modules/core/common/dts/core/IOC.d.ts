export declare class IOC {
    private container;
    private onRegisterCallbacks;
    private _id;
    private static _instance;
    register(id: string, value: any): any;
    static register(id: string, value: any): any;
    get<T>(id: string): T;
    static get<T>(id: string): T;
    isRegistered(id: string): boolean;
    static isRegistered(id: string): boolean;
    static instance(): IOC;
    onRegister(id: string, callback: (injectable: any) => void): void;
    static onRegister(id: string, callback: (injectable: any) => void): void;
    getIOCID(): string;
}
