export declare class BootstrapHooks {
    private initLevelService;
    private dataBridge;
    private bootstrapHookSenderFns;
    private bootstrapHookReceiverFns;
    constructor();
    registerBootstrapHookSender(name: string, fn: (params: any) => any): void;
    registerBootstrapHookReceiver(name: string, params: any, fn: (data: any) => void): void;
}
