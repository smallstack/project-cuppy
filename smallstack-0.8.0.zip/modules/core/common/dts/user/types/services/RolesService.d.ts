import { GeneratedRolesService } from "../generated/services/GeneratedRolesService";
import { Role } from "../models/Role";
import { User } from "../models/User";
export declare class RolesService extends GeneratedRolesService<Role> {
    constructor();
    createRole(roleName: string, subRoleNames?: string[]): Role;
    userHasRole(userId: string, roleName: string): boolean;
    userHasRole(user: User, roleName: string): boolean;
    static userHasRole(userId: string, roleName: string): boolean;
    static userHasRole(user: User, roleName: string): boolean;
    getAllSubRoles(role: Role): Role[];
    isRole(roleName: string): boolean;
    getById(roleId: string): Role;
    getByName(roleName: string): Role;
    checkRole(userId: string, roleName: string): void;
    static checkRole(userId: string, roleName: string): void;
    private getAdministratorRole();
}
