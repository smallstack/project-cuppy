import "../../../media/types/services/MediaService";
import { GeneratedUserService } from "../generated/services/GeneratedUserService";
import { User } from "../models/User";
export declare class UserService extends GeneratedUserService<User> {
    private onCreateUserFns;
    private onCreateDemoUserFns;
    private avatarOrder;
    private mediaService;
    constructor();
    transformUser(user: any): User;
    transformUsers(users: any[]): User[];
    onCreateUser(callback: (user: User) => User): void;
    executeOnCreateUserFunctions(user: User): User;
    onCreateDemoUser(func: (user) => User): void;
    executeOnCreateDemoUserFunctions(user: User): User;
    getAvatarUrlForUser(user: User, mediaFormatName?: string): any;
    getDefaultAvatarUrl(): string;
    getAvatarUrlForUserId(userId: string, callback: Function): void;
    getFacebookAvatar(user: User): string;
    getGoogleAvatar(user: User): string;
    getTwitterAvatar(user: User): string;
    getLinkedInAvatar(user: User): string;
    getCurrentUser(): User;
}
