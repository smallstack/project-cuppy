import { GeneratedAddress } from "../generated/models/GeneratedAddress";
export declare class Address extends GeneratedAddress {
}
