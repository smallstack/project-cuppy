import { GeneratedRole } from "../generated/models/GeneratedRole";
export declare class Role extends GeneratedRole {
}
