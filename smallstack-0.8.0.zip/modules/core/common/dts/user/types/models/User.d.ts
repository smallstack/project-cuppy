import { GeneratedUser } from "../generated/models/GeneratedUser";
export declare class User extends GeneratedUser {
    getCurrentAccountDisplayObject(): any;
    isVerified(): boolean;
    getAvatarUrl(mediaFormat?: string): any;
    hasRole(role: string): boolean;
    getSocialLoginType(): string;
    getSocialLoginAccessToken(): any;
    getGender(): any;
    getSocialLoginId(): any;
    getEmail(): string;
    getDisplayName(): string;
    getTitle(): string;
}
