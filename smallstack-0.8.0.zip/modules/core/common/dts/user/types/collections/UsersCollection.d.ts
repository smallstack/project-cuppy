import { GeneratedUsersCollection } from "../generated/collections/GeneratedUsersCollection";
export declare class UsersCollection extends GeneratedUsersCollection {
    constructor();
    protected createCollection(): void;
    protected createSearchIndex(): void;
    protected getSchema(): any;
    protected getCollectionAllowRules(): any;
}
