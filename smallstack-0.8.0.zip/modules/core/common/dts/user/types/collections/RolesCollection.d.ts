import { GeneratedRolesCollection } from "../generated/collections/GeneratedRolesCollection";
export declare class RolesCollection extends GeneratedRolesCollection {
    constructor();
}
