import { Collection } from "../../../../common";
import { BaseCollection } from "../../../../common";
import { User } from "../../models/User";
export declare class GeneratedUsersCollection extends BaseCollection<User> implements Collection<User> {
    name: string;
    protected _easySearchIndex: any;
    static queries: {
        "getUsersByIds": {
            name: string;
            parameters: {
                ids: string;
            };
        };
        "getUserById": {
            name: string;
            parameters: {
                id: string;
            };
        };
        "getAllUsers": {
            name: string;
            parameters: {};
        };
        "getMyUser": {
            name: string;
            parameters: {};
        };
    };
    static expandables: {
        "roleIds": string;
    };
    constructor();
    protected createPublications(): void;
    protected createSearchIndex(): void;
    protected createCollection(): void;
    protected configureAllowDenyRules(): void;
    protected getCollectionAllowRules(): any;
    protected getCollectionDenyRules(): any;
    protected getSchema(): any;
    getForeignCollection(typeName: string): string;
    getForeignGetter(): string;
    static getForeignGetter(): string;
    getModelName(): string;
    getServiceName(): string;
    getQueries(): {
        [queryName: string]: any;
    };
    getCollectionName(): string;
    static getCollection(): Collection<User>;
}
