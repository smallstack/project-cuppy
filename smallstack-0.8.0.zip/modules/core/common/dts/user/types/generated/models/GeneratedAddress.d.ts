import { SmallstackModel, DataBridge } from "../../../../common";
export declare class GeneratedAddress implements SmallstackModel {
    protected dataBridge: DataBridge;
    id: string;
    street: string;
    streetNumber: string;
    zip: number;
    city: string;
    private _hasSubDocuments;
    private _isStored;
    constructor();
    static fromDocument<T>(doc: any): T;
    toDocument(identifierKey?: string): {};
    hasSubDocuments(): boolean;
    isStored(): boolean;
    static getModelName(): string;
    getModelName(): string;
    static getModelClass(): any;
    getModelClass(): any;
    static getSchema(): any;
}
