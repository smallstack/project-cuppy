import { QueryOptions, QueryObject, CollectionsService, Collection, DataBridge, SmallstackModel } from "../../../../common";
import { UserService } from "../../services/UserService";
export declare class GeneratedUserService<ModelClass extends SmallstackModel> {
    protected collectionsService: CollectionsService;
    protected dataBridge: DataBridge;
    constructor();
    static instance(): UserService;
    getCollection(): Collection<ModelClass>;
    getUsersByIds(parameters?: {
        ids: any;
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getUserById(parameters?: {
        id: any;
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getAllUsers(parameters?: {}, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getMyUser(parameters?: {}, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    updateProfileDetails(newValues: any, callback?: (error: Error, result: any) => void): void;
    save(model: ModelClass, callback?: (error: Error, savedId: string) => void): string;
    update(model: ModelClass, callback?: (error: Error, numberOfUpdatedDocuments: number) => void): number;
    delete(model: ModelClass, callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
}
