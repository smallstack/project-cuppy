import { Collection } from "../../../../common";
import { BaseCollection } from "../../../../common";
import { Role } from "../../models/Role";
export declare class GeneratedRolesCollection extends BaseCollection<Role> implements Collection<Role> {
    name: string;
    protected _easySearchIndex: any;
    static queries: {
        "getRoleByName": {
            name: string;
            parameters: {
                name: string;
            };
        };
        "getRoleById": {
            name: string;
            parameters: {
                id: string;
            };
        };
        "getRolesByIds": {
            name: string;
            parameters: {
                ids: string;
            };
        };
        "getAllRoles": {
            name: string;
            parameters: {};
        };
    };
    static expandables: {
        "subRoleIds": string;
    };
    constructor();
    protected createPublications(): void;
    protected createSearchIndex(): void;
    protected createCollection(): void;
    protected configureAllowDenyRules(): void;
    protected getCollectionAllowRules(): any;
    protected getCollectionDenyRules(): any;
    protected getSchema(): any;
    getForeignCollection(typeName: string): string;
    getForeignGetter(): string;
    static getForeignGetter(): string;
    getModelName(): string;
    getServiceName(): string;
    getQueries(): {
        [queryName: string]: any;
    };
    getCollectionName(): string;
    static getCollection(): Collection<Role>;
}
