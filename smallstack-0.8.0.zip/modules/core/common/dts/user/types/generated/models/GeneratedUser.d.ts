import { QueryObject, QueryOptions, SmallstackModel, DataBridge } from "../../../../common";
import { Role } from "../../models/Role";
export declare class GeneratedUser implements SmallstackModel {
    protected dataBridge: DataBridge;
    id: string;
    profile: any;
    emails: any[];
    createdAt: number;
    services: any;
    roleIds: string[];
    private _hasSubDocuments;
    private _isStored;
    constructor();
    static fromDocument<T>(doc: any): T;
    toDocument(identifierKey?: string): {};
    addRoleIds(ids: string[]): void;
    getRoles(options?: QueryOptions): QueryObject<Role>;
    hasSubDocuments(): boolean;
    isStored(): boolean;
    static getModelName(): string;
    getModelName(): string;
    static getModelClass(): any;
    getModelClass(): any;
    delete(callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
    update(callback?: (error: Error, numberOfSavedDocuments: number) => void): number;
    save(callback?: (error: Error, savedId: string) => void): string;
    static getSchema(): any;
}
