export declare enum BackofficeJobStatus {
    IDLE = 0,
    RUNNING = 1,
}
