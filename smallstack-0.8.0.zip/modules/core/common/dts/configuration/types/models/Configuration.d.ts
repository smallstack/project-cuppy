import { GeneratedConfiguration } from "../generated/models/GeneratedConfiguration";
export declare class Configuration extends GeneratedConfiguration {
}
