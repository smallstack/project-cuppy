import { SmallstackModel, DataBridge } from "../../../../common";
export declare class GeneratedConfiguration implements SmallstackModel {
    protected dataBridge: DataBridge;
    id: string;
    key: string;
    value: string;
    scope: string;
    private _hasSubDocuments;
    private _isStored;
    static enums: {
        "scope": {
            "SERVER": string;
            "EVERYWHERE": string;
        };
    };
    constructor();
    static fromDocument<T>(doc: any): T;
    toDocument(identifierKey?: string): {};
    hasSubDocuments(): boolean;
    isStored(): boolean;
    static getModelName(): string;
    getModelName(): string;
    static getModelClass(): any;
    getModelClass(): any;
    delete(callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
    update(callback?: (error: Error, numberOfSavedDocuments: number) => void): number;
    save(callback?: (error: Error, savedId: string) => void): string;
    static getSchema(): any;
}
