import { GeneratedConfigurationService } from "../generated/services/GeneratedConfigurationService";
import { Configuration } from "../models/Configuration";
export declare class ConfigurationService extends GeneratedConfigurationService<Configuration> {
    static scopes: {
        SERVER: string;
        EVERYWHERE: string;
    };
    private configuration;
    private envPrefix;
    private envServerPrefix;
    private functionCallbacks;
    private envIsRead;
    private onEnvReadCallbacks;
    constructor();
    initOnClient(done: (error: Error, result: any) => void): void;
    set(key: string, value: string, scope?: string): void;
    unset(key: string): void;
    get(key: string, defaultValue?: string): string;
    onSet(key: string, func: (value: string) => void): void;
    onEnvironmentRead(func: Function): void;
    contains(key: string): boolean;
    private convertKey(key);
    private processEnvConf();
    static instance(): ConfigurationService;
}
