import { GeneratedConfigurationCollection } from "../generated/collections/GeneratedConfigurationCollection";
export declare class ConfigurationCollection extends GeneratedConfigurationCollection {
    constructor();
}
