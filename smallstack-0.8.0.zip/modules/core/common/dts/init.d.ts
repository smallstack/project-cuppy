export declare function initSmallstackShared(initializeCollections?: boolean): void;
