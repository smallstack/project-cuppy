import { BackofficeJob } from "./BackofficeJob";
export declare class BackofficeJobRegistry {
    private registeredJobs;
    registerJob(job: BackofficeJob): void;
    executeJob(name: string, logger: (message: string) => void): void;
    getAllJobs(): any;
}
