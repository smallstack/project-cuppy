import { BackofficeJobStatus } from "@smallstack/core-common";
export interface BackofficeJob {
    name: string;
    description: string;
    status?: BackofficeJobStatus;
    execute(logger: (message: string) => void): void;
}
