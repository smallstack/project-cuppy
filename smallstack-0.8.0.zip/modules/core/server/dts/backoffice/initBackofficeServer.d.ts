export declare function initBackofficeServer(): void;
