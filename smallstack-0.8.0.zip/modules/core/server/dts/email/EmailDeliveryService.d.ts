import { TextReplacerContext } from "@smallstack/core-common";
import { Email } from "@smallstack/core-common";
import { EmailTemplate } from "@smallstack/core-common";
export declare class EmailDeliveryService {
    private configurationService;
    private localizationService;
    sendMail(email: Email, context?: TextReplacerContext): void;
    sendTemplate(template: EmailTemplate, to: string[], context?: TextReplacerContext): void;
}
