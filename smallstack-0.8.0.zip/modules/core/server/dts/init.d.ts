export declare function initServer(): void;
