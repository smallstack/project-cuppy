(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@smallstack/core-common'), require('underscore'), require('mailgun-js')) :
	typeof define === 'function' && define.amd ? define(['exports', '@smallstack/core-common', 'underscore', 'mailgun-js'], factory) :
	(factory((global['smallstack-core-server'] = global['smallstack-core-server'] || {}),global._smallstack_coreCommon,global.underscore,global.Mailgun));
}(this, (function (exports,_smallstack_coreCommon,_,Mailgun) { 'use strict';

var BackofficeJobRegistry = (function () {
    function BackofficeJobRegistry() {
        this.registeredJobs = {};
    }
    BackofficeJobRegistry.prototype.registerJob = function (job) {
        job.status = _smallstack_coreCommon.BackofficeJobStatus.IDLE;
        this.registeredJobs[job.name] = job;
    };
    BackofficeJobRegistry.prototype.executeJob = function (name, logger) {
        if (this.registeredJobs[name] === undefined)
            throw new Error("Could not find job with name '" + name + "'!");
        _smallstack_coreCommon.Logger.info("BackofficeJobRegistry", "Executing Job: " + name);
        try {
            this.registeredJobs[name].execute(logger);
        }
        catch (e) {
            _smallstack_coreCommon.Logger.error("BackofficeJobRegistry", "Error while executing job '" + name + "':", e);
            throw e;
        }
    };
    BackofficeJobRegistry.prototype.getAllJobs = function () {
        var jobsObj = [];
        _.each(this.registeredJobs, function (job) {
            jobsObj.push({
                name: job.name,
                description: job.description,
                status: job.status
            });
        });
        return jobsObj;
    };
    return BackofficeJobRegistry;
}());

function initBackofficeServer() {
    _smallstack_coreCommon.IOC.onRegister("rolesService", function (rolesService) {
        // create default roles
        rolesService.createRole("backoffice");
        rolesService.createRole("backoffice.roles");
        rolesService.createRole("backoffice.logs");
        rolesService.createRole("backoffice.queries");
        rolesService.createRole("backoffice.users");
    });
    _smallstack_coreCommon.IOC.register("backofficeJobRegistry", new BackofficeJobRegistry());
}

var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var EmailDeliveryService = (function () {
    function EmailDeliveryService() {
    }
    EmailDeliveryService.prototype.sendMail = function (email, context) {
        var _this = this;
        if (context === void 0) { context = {}; }
        var mailgunDomain = this.configurationService.get("mailgun.domain");
        var mailgunSecretApiKey = this.configurationService.get("mailgun.secretapikey");
        if (!mailgunDomain || !mailgunSecretApiKey)
            throw new Error("Please set mailgun.domain and mailgun.secretapikey to send mails!");
        var mailgun = new Mailgun({ apiKey: mailgunSecretApiKey, domain: mailgunDomain });
        // evaluate languages present in email object
        var availableLanguages = _.keys(email.contents);
        var defaultLanguageKey = this.localizationService.getFallbackLanguage();
        if (availableLanguages.indexOf(this.localizationService.getFallbackLanguage()) === -1) {
            _smallstack_coreCommon.Logger.debug("EmailDeliveryService", "default language '" + defaultLanguageKey + "' not present in email content object, using '" + availableLanguages[0] + "' instead!");
            defaultLanguageKey = availableLanguages[0];
        }
        // update status
        email.status = _smallstack_coreCommon.Email.enums.status.SENDING;
        email.update();
        _.each(availableLanguages, function (currentLanguageKey) {
            var isDefaultLanguage = defaultLanguageKey === currentLanguageKey;
            var data = {};
            // from
            data.from = email.from;
            // to
            data.to = [];
            // unpersonalized mails are always sent in the default language
            if (email.to !== undefined && isDefaultLanguage) {
                _.each(email.to, function (to) {
                    data.to.push(to);
                });
            }
            else if (email.toUserIds !== undefined) {
                data["recipient-variables"] = {};
                _.each(email.getToUsers().getModels(), function (user) {
                    var userLanguageKey = _this.localizationService.getUserLanguage(user);
                    if ((userLanguageKey === undefined && isDefaultLanguage) || (userLanguageKey !== undefined && userLanguageKey === currentLanguageKey)) {
                        var userMail = user.getEmail();
                        if (userMail !== undefined) {
                            data.to.push(userMail);
                            data["recipient-variables"][userMail] = {
                                "nickname": user.profile.displayName
                            };
                        }
                    }
                });
            }
            // check if there are any users for this language
            if (data.to.length === 0)
                _smallstack_coreCommon.Logger.debug("EmailDeliveryService", "Skipping mail for language " + currentLanguageKey + " since there aren't any recipients!", data);
            else {
                // subject
                data.subject = _smallstack_coreCommon.TextReplacer.replace(email.subjects[currentLanguageKey], context);
                // content
                if (email.htmlMail)
                    data.html = _smallstack_coreCommon.TextReplacer.replace(email.contents[currentLanguageKey], context);
                else
                    data.text = _smallstack_coreCommon.TextReplacer.replace(email.contents[currentLanguageKey], context);
                _smallstack_coreCommon.Logger.debug("EmailDeliveryService", "Sending mail for language " + currentLanguageKey + "!", data);
                mailgun.messages().send(data, function (error, body) {
                    if (error)
                        console.error(error);
                    else {
                        _smallstack_coreCommon.Logger.debug("EmailDeliveryService", "Sent mail for language " + currentLanguageKey + "!", body);
                        email.status = _smallstack_coreCommon.Email.enums.status.SENT;
                        email.sentAt = new Date();
                        email.update();
                    }
                });
            }
        });
    };
    EmailDeliveryService.prototype.sendTemplate = function (template, to, context) {
        if (context === void 0) { context = {}; }
        var email = new _smallstack_coreCommon.Email();
        email.from = template.from;
        email.to = to;
        email.createdAt = new Date();
        email.subjects = template.subjects;
        email.contents = template.contents;
        email.save();
        this.sendMail(email, context);
    };
    return EmailDeliveryService;
}());
__decorate([
    _smallstack_coreCommon.Autowired(),
    __metadata("design:type", _smallstack_coreCommon.ConfigurationService)
], EmailDeliveryService.prototype, "configurationService", void 0);
__decorate([
    _smallstack_coreCommon.Autowired(),
    __metadata("design:type", _smallstack_coreCommon.LocalizationService)
], EmailDeliveryService.prototype, "localizationService", void 0);

function initServer() {
    initBackofficeServer();
    _smallstack_coreCommon.IOC.register("emailDeliveryService", new EmailDeliveryService());
    _smallstack_coreCommon.IOC.register("backofficeJobRegistry", new BackofficeJobRegistry());
}

exports.initServer = initServer;
exports.BackofficeJobRegistry = BackofficeJobRegistry;
exports.initBackofficeServer = initBackofficeServer;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=server.umd.js.map
