export declare function initClient(): void;
