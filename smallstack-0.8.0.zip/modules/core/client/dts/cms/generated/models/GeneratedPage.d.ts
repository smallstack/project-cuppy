import { SmallstackModel, DataBridge } from "@smallstack/core-common";
export declare class GeneratedPage implements SmallstackModel {
    protected dataBridge: DataBridge;
    id: string;
    name: string;
    components: any;
    socketConnections: any[];
    private _hasSubDocuments;
    private _isStored;
    constructor();
    static fromDocument<T>(doc: any): T;
    toDocument(identifierKey?: string): {};
    /**
     * Returns true if the model can contain sub documents
     */
    hasSubDocuments(): boolean;
    /**
     * Returns true if model is stored in database
     */
    isStored(): boolean;
    static getModelName(): string;
    getModelName(): string;
    static getModelClass(): any;
    getModelClass(): any;
    delete(callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
    update(callback?: (error: Error, numberOfSavedDocuments: number) => void): number;
    save(callback?: (error: Error, savedId: string) => void): string;
    static getSchema(): any;
}
