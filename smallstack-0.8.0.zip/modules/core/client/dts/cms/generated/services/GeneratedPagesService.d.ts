import { QueryOptions, QueryObject, CollectionsService, Collection, DataBridge, SmallstackModel } from "@smallstack/core-common";
import { PagesService } from "../../services/PagesService";
export declare class GeneratedPagesService<ModelClass extends SmallstackModel> {
    protected collectionsService: CollectionsService;
    protected dataBridge: DataBridge;
    constructor();
    static instance(): PagesService;
    getCollection(): Collection<ModelClass>;
    getPageById(parameters?: {
        id: any;
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getAllPages(parameters?: {}, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    getPageByName(parameters?: {
        name: any;
    }, queryOptions?: QueryOptions): QueryObject<ModelClass>;
    save(model: ModelClass, callback?: (error: Error, savedId: string) => void): string;
    update(model: ModelClass, callback?: (error: Error, numberOfUpdatedDocuments: number) => void): number;
    delete(model: ModelClass, callback?: (error: Error, numberOfRemovedDocuments: number) => void): number;
}
