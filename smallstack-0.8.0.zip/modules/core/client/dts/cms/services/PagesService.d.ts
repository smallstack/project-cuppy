import { GeneratedPagesService } from "../generated/services/GeneratedPagesService";
import { Page } from "../models/Page";
export interface PageCallback {
    callback: (page: Page) => void;
    context: any;
}
export declare class PagesService extends GeneratedPagesService<Page> {
    private currentPage;
    private _backofficeMode;
    private _componentsRendered;
    private pageChangeCallbacks;
    private pageLoadedCallbacks;
    private eventService;
    private pageLoadingAnimationEnabled;
    constructor();
    getCurrentPage(): Page;
    setCurrentPage(page: Page): void;
    onPageChange(id: any, callback: (page: Page) => void, context?: any): void;
    onPageLoaded(id: any, callback: (page: Page) => void, context?: any): void;
    private allComponentsAreRendered();
    triggerPageChange(): void;
    clearPageChangeCallbacks(): void;
    clearPageChangeCallback(id: string): void;
    setBackofficeMode(backofficeMode: boolean): void;
    isBackofficeMode(): boolean;
    /** internal method to calculate the time when the pageLoaded event should get fired */
    _componentRendered(): void;
    setPageLoadingAnimationEnabled(pageLoadingAnimationEnabled: boolean): void;
    isPageLoadingAnimationEnabled(): boolean;
}
