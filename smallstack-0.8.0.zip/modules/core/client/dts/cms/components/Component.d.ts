import { ComponentConfiguration } from "./ComponentConfiguration";
import { ComponentSocket } from './ComponentSocket';
export declare enum ComponentType {
    ANGULAR1 = 0,
    ANGULAR2 = 1,
    REACT = 2,
    INVISIBLE = 3,
}
export declare abstract class Component<T> {
    componentName: string;
    description: string;
    tags: string[];
    label: string;
    sockets: ComponentSocket[];
    configuration: ComponentConfiguration[];
    setDescription(text: string): T;
    addTags(tags: string[]): T;
    setLabel(label: string): T;
    getLabel(): string;
    setComponentName(componentName: string): T;
    addSocket(socket: ComponentSocket): T;
    addConfiguration(configObject: ComponentConfiguration): T;
    abstract register(): void;
    abstract instantiate(componentInstanceId: string): void;
    abstract getType(): ComponentType;
}
