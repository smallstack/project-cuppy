import { Component, ComponentType } from "./Component";
export declare class ComponentsRegistry {
    private _components;
    addComponent(component: Component<any>): void;
    getAllComponentNames(): string[];
    getAllComponents(): Component<any>[];
    getComponentByName(name: string): Component<any>;
    isRegistered(componentName: string): boolean;
    getComponentsByType<T>(type: ComponentType): T[];
    static instance(): ComponentsRegistry;
}
