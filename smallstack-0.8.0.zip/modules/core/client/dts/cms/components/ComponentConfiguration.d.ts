export interface PossibleValues {
    value: any;
    label: string;
}
export declare class ComponentConfiguration {
    static types: {
        STRING: string;
        BOOLEAN: string;
        SELECT: string;
        TEXTAREA: string;
        NUMBER: string;
        OBJECT: string;
        I18N: string;
        LIST: string;
    };
    key: string;
    type: string;
    /**
     * should have the format : key -> label
     */
    possibleValues: PossibleValues[];
    /**
     * can be undefined
     */
    defaultValue: any;
    value: any;
    static createStringConfiguration(key: string, defaultValue?: string): ComponentConfiguration;
    static createSelectConfiguration(key: string, defaultValue: string, possibleValues: PossibleValues[]): ComponentConfiguration;
    static createTextareaConfiguration(key: string, defaultValue: string): ComponentConfiguration;
    static createNumberConfiguration(key: string, defaultValue: number): ComponentConfiguration;
    static createObjectConfiguration(key: string, defaultValue?: any): ComponentConfiguration;
    static createBooleanConfiguration(key: string, defaultValue?: boolean): ComponentConfiguration;
    static createI18nStringConfiguration(key: string, defaultTexts?: any): ComponentConfiguration;
    static convertObjectToPossibleValuesArray(obj: any): PossibleValues[];
}
