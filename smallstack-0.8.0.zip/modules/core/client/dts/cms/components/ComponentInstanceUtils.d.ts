import { Page } from "../models/Page";
import { ComponentInstance } from "./ComponentInstance";
export declare class ComponentInstanceUtils {
    static createInstance(name: string): ComponentInstance;
    static removeChildComponent(page: Page, componentId: string): Page;
    static getParent(page: Page, componentId: string): ComponentInstance;
    static findComponentById(page: Page, componentId: string): any;
    static findParent(componentInstance: ComponentInstance, componentId: string): ComponentInstance;
    static findInChildren(children: any[], componentId: string): any;
    static getAllComponentInstances(componentInstance: ComponentInstance, withChildren?: boolean): ComponentInstance[];
}
