export declare enum ComponentSocketDirection {
    IN = 0,
    OUT = 1,
}
export declare enum ComponentSocketType {
    NUMBER = 0,
    NUMBER_ARRAY = 1,
    STRING = 2,
    STRING_ARRAY = 3,
    BOOLEAN = 4,
    BOOLEAN_ARRAY = 5,
    OBJECT = 6,
    OBJECT_ARRAY = 7,
}
export declare class ComponentSocket {
    name: string;
    type: ComponentSocketType;
    direction: ComponentSocketDirection;
    values: any[];
    static create(name: string, type: ComponentSocketType, direction: ComponentSocketDirection, values?: any[]): ComponentSocket;
    static createInput(name: string, type: ComponentSocketType, values?: any[]): ComponentSocket;
    static createOutput(name: string, type: ComponentSocketType, values?: any[]): ComponentSocket;
    static componentSocketTypeToString(type: ComponentSocketType): string;
}
