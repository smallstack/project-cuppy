import { CollectionsService, DataBridge } from "@smallstack/core-common";
import { Component } from "./Component";
import { ComponentConfiguration } from "./ComponentConfiguration";
import { ComponentInstance } from "./ComponentInstance";
import { EventService } from "../events/EventService";
import { NotificationService } from "@smallstack/core-common";
import { Page } from "../models/Page";
import { PagesService } from "../services/PagesService";
export interface InitializationAware {
    afterInitialization(): any;
}
export interface SocketEventAware {
    onSocketEvent(socketName: string, socketData: any): any;
}
export interface PageChangeAware {
    onPageChange(page: Page): void;
}
export declare class BaseComponentController {
    protected notificationService: NotificationService;
    protected pagesService: PagesService;
    protected eventService: EventService;
    protected collectionsService: CollectionsService;
    protected dataBridge: DataBridge;
    protected componentInstanceId: string;
    protected dynamicData: any;
    setComponentInstanceId(componentInstanceId: string): void;
    getPage(): Page;
    getComponent(): Component<any>;
    getComponentInstance(): ComponentInstance;
    getChildren(): ComponentInstance[];
    getData(key: string): any;
    saveData(data: any): void;
    /**
     * Dynamic Data is stored on the component itself and not in the database. It overwrites potential database data sets!
     */
    protected saveDynamicData(data: any): void;
    sendOutput(socketName: string, socketData: any): void;
    getConfiguration(key: string): ComponentConfiguration;
    hasConfiguration(key: string): boolean;
    isBackofficeMode(): boolean;
}
