export interface ComponentInstance {
    id: string;
    name: string;
    children?: ComponentInstance[];
    data?: any;
}
