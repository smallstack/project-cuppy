export interface SocketConnection {
    sourceComponentInstanceId: string;
    sourceSocketName: string;
    targetComponentInstanceId: string;
    targetSocketName: string;
}
