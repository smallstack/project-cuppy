import { SocketConnection } from "./SocketConnection";
/**
 *
 * CMS Components can dispatch events to their sockets (over SocketConnections) or to the page (PageEvents).
 * Both events can be send via this service. The only restriction is, that no component knows the
 * target, neither if there's a receiver or many or none, totally decoupled hm hm hm.
 *
 */
export declare class EventService {
    private socketConnections;
    private socketConnectionCallbacks;
    private afterSocketRegistrationCallbacks;
    private pageEventCallbacks;
    addSocketConnection(socketConnection: SocketConnection): void;
    clearSocketConnections(componentId?: string): void;
    getSocketConnectionsBySource(sourceComponentInstanceId: string, sourceSocketName: string): SocketConnection[];
    getSocketConnectionsByTarget(targetComponentInstanceId: string, targetSocketName: string): SocketConnection[];
    dispatchSocketEvent(sourceComponentInstanceId: string, sourceSocketName: string, data?: any): void;
    sendSocketEvent(targetComponentInstanceId: string, targetSourceName: string, data?: any, waitForTargetComponent?: boolean): void;
    watchSocketEvent(sourceComponentInstanceId: string, sourceSocketName: string, cb: (data: any) => void): void;
    dispatchPageEvent(pageEventName: string, data?: any): void;
    registerSocketConnectionHandler(targetComponentInstanceId: string, targetSocketName: string, cb: (data: any) => void): void;
    removeSocketConnectionHandler(targetComponentInstanceId: string, targetSocketName?: string): void;
    registerPageEventHandler(pageEventName: string, cb: (data: any) => void, allowOnlyOneHandler?: boolean): void;
    private getSocketConnectionIdentifier(componentInstanceId, socketName);
    static instance(): EventService;
}
