import { ComponentInstance } from './../components/ComponentInstance';
import { ComponentSocketDirection } from './../components/ComponentSocket';
import { GeneratedPage } from "../generated/models/GeneratedPage";
import { SocketConnection } from "../events/SocketConnection";
/**
 * A page consists of a name and a component tree.
 *
 * *Name*
 * The *Name* is being used in the backoffice only to identify the page.
 * The regular user/customer will never see this *Name*.
 *
 * Component
 * Components are npm modules. They can be written in any Frontend Technology, as long as there is a renderer for it
 * registered in the smallstack. Components have to follow the ComponentInterface which exposes functionality to
 * register for configurable options etc. pp.
 *
 * In addition it can have the following attributes :
 * 	- name
 * 		the identifier to map the component to the source code implementation, e.g. : smallstack:text-editor:0.1.0
 * 	- children
 * 		an array of component identifiers
 *  - data
 * 		key:string -> value:any store for component specific data
 *
 *
 *
 * Component tree
 * The component tree consists of many related components. It always starts with one root component which then might
 * have several children etc. pp.
 */
export declare class Page extends GeneratedPage {
    private data;
    getAllComponentInstances(withChildren?: boolean): ComponentInstance[];
    getAllData(): {
        [identifier: string]: any;
    };
    getData(identifier: string): any;
    setData(identifier: string, data: any): void;
    getConnectionsForComponentId(componentId: string, direction?: ComponentSocketDirection): SocketConnection[];
}
