(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@smallstack/core-common'), require('underscore')) :
	typeof define === 'function' && define.amd ? define(['exports', '@smallstack/core-common', 'underscore'], factory) :
	(factory((global['smallstack-core-client'] = global['smallstack-core-client'] || {}),global['@smallstack/core-common'],global.underscore));
}(this, (function (exports,_smallstack_coreCommon,_) { 'use strict';

var ComponentsRegistry = (function () {
    function ComponentsRegistry() {
        this._components = [];
    }
    ComponentsRegistry.prototype.addComponent = function (component) {
        _smallstack_coreCommon.Logger.debug("ComponentsRegistry", "Registered component: " + component.componentName);
        this._components.push(component);
    };
    ComponentsRegistry.prototype.getAllComponentNames = function () {
        var names = [];
        _.each(this._components, function (component) {
            names.push(component.getLabel());
        });
        return names;
    };
    ComponentsRegistry.prototype.getAllComponents = function () {
        return this._components;
    };
    ComponentsRegistry.prototype.getComponentByName = function (name) {
        var component = _.find(this._components, function (component) { return component.componentName === name; });
        if (component)
            return component;
        throw new Error("ComponentsRegistry - Could not find component by name: " + name);
    };
    ComponentsRegistry.prototype.isRegistered = function (componentName) {
        return _.find(this._components, function (component) { return component.componentName === name; }) !== undefined;
    };
    ComponentsRegistry.prototype.getComponentsByType = function (type) {
        return _.reject(this._components, function (component) { return component.getType() !== type; });
    };
    ComponentsRegistry.instance = function () {
        return _smallstack_coreCommon.IOC.get("componentsRegistry");
    };
    return ComponentsRegistry;
}());

function initClient() {
    _smallstack_coreCommon.IOC.register("navigationService", new _smallstack_coreCommon.NavigationService());
    _smallstack_coreCommon.IOC.register("componentsRegistry", new ComponentsRegistry());
    _smallstack_coreCommon.Logger.printSmallstackLogo();
}

/**
 *
 * CMS Components can dispatch events to their sockets (over SocketConnections) or to the page (PageEvents).
 * Both events can be send via this service. The only restriction is, that no component knows the
 * target, neither if there's a receiver or many or none, totally decoupled hm hm hm.
 *
 */
var EventService = (function () {
    function EventService() {
        this.socketConnections = [];
        this.socketConnectionCallbacks = {};
        this.afterSocketRegistrationCallbacks = {};
        this.pageEventCallbacks = {};
    }
    EventService.prototype.addSocketConnection = function (socketConnection) {
        _smallstack_coreCommon.Logger.debug("EventService", "registering socket connection", socketConnection);
        this.socketConnections.push(socketConnection);
    };
    EventService.prototype.clearSocketConnections = function (componentId) {
        if (componentId === undefined) {
            _smallstack_coreCommon.Logger.debug("EventService", "clearing all socket connections");
            this.socketConnections = [];
        }
        else {
            _smallstack_coreCommon.Logger.debug("EventService", "clearing socket connections for componentId '" + componentId + "'");
            this.socketConnections = _.reject(this.socketConnections, function (socketConnection) {
                return socketConnection.sourceComponentInstanceId === componentId || socketConnection.targetComponentInstanceId === componentId;
            });
        }
    };
    EventService.prototype.getSocketConnectionsBySource = function (sourceComponentInstanceId, sourceSocketName) {
        return _.filter(this.socketConnections, function (event) { return event.sourceComponentInstanceId === sourceComponentInstanceId && event.sourceSocketName === sourceSocketName; });
    };
    EventService.prototype.getSocketConnectionsByTarget = function (targetComponentInstanceId, targetSocketName) {
        return _.filter(this.socketConnections, function (event) { return event.targetComponentInstanceId === targetComponentInstanceId && event.targetSocketName === targetSocketName; });
    };
    EventService.prototype.dispatchSocketEvent = function (sourceComponentInstanceId, sourceSocketName, data) {
        var _this = this;
        _.each(this.getSocketConnectionsBySource(sourceComponentInstanceId, sourceSocketName), function (event) {
            var fn = _this.socketConnectionCallbacks[_this.getSocketConnectionIdentifier(event.targetComponentInstanceId, event.targetSocketName)];
            if (!fn)
                _smallstack_coreCommon.Logger.error("EventService", "Could not find socket event callback for targetComponentInstanceId '" + event.targetComponentInstanceId + "' and targetSocketName '" + event.targetSocketName + "'!");
            else
                _this.sendSocketEvent(event.targetComponentInstanceId, event.targetSocketName, data);
        });
    };
    EventService.prototype.sendSocketEvent = function (targetComponentInstanceId, targetSourceName, data, waitForTargetComponent) {
        if (waitForTargetComponent === void 0) { waitForTargetComponent = false; }
        var socketIdentifier = this.getSocketConnectionIdentifier(targetComponentInstanceId, targetSourceName);
        var fn = this.socketConnectionCallbacks[socketIdentifier];
        if (fn)
            fn(data);
        else if (waitForTargetComponent) {
            if (!this.afterSocketRegistrationCallbacks[socketIdentifier])
                this.afterSocketRegistrationCallbacks[socketIdentifier] = [];
            this.afterSocketRegistrationCallbacks[socketIdentifier].push(data);
        }
        else
            _smallstack_coreCommon.Logger.warning("EventService", "No callback registered for socketIdentifier '" + socketIdentifier + "'!");
    };
    EventService.prototype.watchSocketEvent = function (sourceComponentInstanceId, sourceSocketName, cb) {
        var targetComponentInstanceId = chance.guid();
        var targetSocketName = "dynamicAbsorber";
        this.registerSocketConnectionHandler(targetComponentInstanceId, targetSocketName, cb);
        this.addSocketConnection({ sourceComponentInstanceId: sourceComponentInstanceId, sourceSocketName: sourceSocketName, targetComponentInstanceId: targetComponentInstanceId, targetSocketName: targetSocketName });
    };
    EventService.prototype.dispatchPageEvent = function (pageEventName, data) {
        if (this.pageEventCallbacks[pageEventName] !== undefined) {
            _.each(this.pageEventCallbacks[pageEventName], function (fn) {
                fn(data);
            });
        }
    };
    EventService.prototype.registerSocketConnectionHandler = function (targetComponentInstanceId, targetSocketName, cb) {
        _smallstack_coreCommon.Logger.debug("EventService", "Registering " + targetComponentInstanceId + "->" + targetSocketName);
        var socketIdentifier = this.getSocketConnectionIdentifier(targetComponentInstanceId, targetSocketName);
        this.socketConnectionCallbacks[socketIdentifier] = cb;
        // send stalled data
        _.each(this.afterSocketRegistrationCallbacks[socketIdentifier], function (data) {
            cb(data);
        });
        this.afterSocketRegistrationCallbacks[socketIdentifier] = [];
    };
    EventService.prototype.removeSocketConnectionHandler = function (targetComponentInstanceId, targetSocketName) {
        var _this = this;
        _smallstack_coreCommon.Logger.debug("EventService", "Removing socket handler for " + targetComponentInstanceId + "->" + (targetSocketName !== undefined ? targetSocketName : "[ALL]"));
        _.each(this.socketConnectionCallbacks, function (fn, socketIdentifier) {
            if (targetSocketName !== undefined && socketIdentifier === _this.getSocketConnectionIdentifier(targetComponentInstanceId, targetSocketName))
                delete _this.socketConnectionCallbacks[socketIdentifier];
            if (targetSocketName === undefined && socketIdentifier.indexOf(targetComponentInstanceId + "_") === 0)
                delete _this.socketConnectionCallbacks[socketIdentifier];
        });
    };
    EventService.prototype.registerPageEventHandler = function (pageEventName, cb, allowOnlyOneHandler) {
        if (allowOnlyOneHandler === void 0) { allowOnlyOneHandler = false; }
        if (this.pageEventCallbacks[pageEventName] === undefined || allowOnlyOneHandler)
            this.pageEventCallbacks[pageEventName] = [];
        this.pageEventCallbacks[pageEventName].push(cb);
    };
    EventService.prototype.getSocketConnectionIdentifier = function (componentInstanceId, socketName) {
        if (componentInstanceId === undefined)
            throw new Error("componentInstanceId is undefined while creating SocketConnectionIdentifier!");
        if (socketName === undefined)
            throw new Error("socketName is undefined while creating SocketConnectionIdentifier!");
        return componentInstanceId + "_" + socketName;
    };
    EventService.instance = function () {
        return _smallstack_coreCommon.IOC.get("eventService");
    };
    return EventService;
}());

/**
 * THIS FILE IS AUTO-GENERATED AND WILL BE REPLACED DURING CODE GENERATION
 */
var GeneratedPagesService = (function () {
    function GeneratedPagesService() {
        this.collectionsService = _smallstack_coreCommon.IOC.get("collectionsService");
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
    }
    GeneratedPagesService.instance = function () {
        return _smallstack_coreCommon.IOC.get("pagesService");
    };
    GeneratedPagesService.prototype.getCollection = function () {
        return this.collectionsService.getCollectionByName("pages");
    };
    GeneratedPagesService.prototype.getPageById = function (parameters, queryOptions) {
        return new _smallstack_coreCommon.QueryObject().create({ "_id": parameters.id }, "getPageById", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedPagesService.prototype.getAllPages = function (parameters, queryOptions) {
        return new _smallstack_coreCommon.QueryObject().create({}, "getAllPages", queryOptions, parameters, {}, this.getCollection());
    };
    GeneratedPagesService.prototype.getPageByName = function (parameters, queryOptions) {
        return new _smallstack_coreCommon.QueryObject().create({ "name": parameters.name }, "getPageByName", queryOptions, parameters, {}, this.getCollection());
    };
    // Model Operations
    GeneratedPagesService.prototype.save = function (model, callback) {
        return this.getCollection().insert(model, callback);
    };
    GeneratedPagesService.prototype.update = function (model, callback) {
        return this.getCollection().update(model.id, { $set: { "name": model["name"], "components": model["components"], "socketConnections": model["socketConnections"] } }, callback);
    };
    GeneratedPagesService.prototype.delete = function (model, callback) {
        return this.getCollection().remove(model.id, callback);
    };
    return GeneratedPagesService;
}());

var __extends = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var PagesService = (function (_super) {
    __extends(PagesService, _super);
    function PagesService() {
        var _this = _super.call(this) || this;
        _this._componentsRendered = 0;
        _this.pageChangeCallbacks = {};
        _this.pageLoadedCallbacks = {};
        _this.pageLoadingAnimationEnabled = true;
        if (_this.dataBridge.isClient())
            _this.eventService = EventService.instance();
        return _this;
    }
    PagesService.prototype.getCurrentPage = function () {
        return this.currentPage;
    };
    PagesService.prototype.setCurrentPage = function (page) {
        var _this = this;
        this.currentPage = page;
        this._componentsRendered = 0;
        // add socket events
        this.eventService.clearSocketConnections();
        if (page) {
            _.each(page.socketConnections, function (socketConnection) {
                _this.eventService.addSocketConnection(socketConnection);
            });
        }
        this.triggerPageChange();
    };
    // public onPageChange(id: string, callback: (page: Page) => void);
    // public onPageChange(callback: (page: Page) => void);
    PagesService.prototype.onPageChange = function (id, callback, context) {
        _smallstack_coreCommon.Logger.debug("PagesService", "Adding page change callback for id '" + id + "'!");
        if (!callback)
            throw new Error("no callback provided!");
        if (!id)
            id = chance.guid();
        this.pageChangeCallbacks[id] = { callback: callback, context: context };
        if (this.currentPage !== undefined) {
            if (context)
                callback.bind(context, this.currentPage)();
            else
                callback(this.currentPage);
        }
    };
    PagesService.prototype.onPageLoaded = function (id, callback, context) {
        _smallstack_coreCommon.Logger.debug("PagesService", "Adding page loaded callback for id '" + id + "'!");
        if (!callback)
            throw new Error("no callback provided!");
        if (!id)
            id = chance.guid();
        this.pageLoadedCallbacks[id] = { callback: callback, context: context };
        if (this.allComponentsAreRendered()) {
            if (context)
                callback.bind(context, this.currentPage)();
            else
                callback(this.currentPage);
        }
    };
    PagesService.prototype.allComponentsAreRendered = function () {
        if (!this.currentPage) {
            _smallstack_coreCommon.Logger.debug("PagesService", "Page not fully rendered yet, current page is undefined!");
            return false;
        }
        return true;
        // let componentsRenderedDelta: number = this.currentPage.getAllComponentInstances().length - this._componentsRendered;
        // if (componentsRenderedDelta === 0)
        // 	return true;
        // else
        // 	Logger.debug("PagesService", "Page not fully rendered yet, " + componentsRenderedDelta + " components not rendered!");
    };
    PagesService.prototype.triggerPageChange = function () {
        var _this = this;
        _.each(this.pageChangeCallbacks, function (cb) {
            try {
                if (cb.context)
                    cb.callback.bind(cb.context, _this.currentPage)();
                else
                    cb.callback(_this.currentPage);
            }
            catch (e) {
                console.error("Error in page change callback : ", e);
            }
        });
    };
    PagesService.prototype.clearPageChangeCallbacks = function () {
        _smallstack_coreCommon.Logger.debug("PagesService", "Clearing all page change callbacks!");
        this.pageChangeCallbacks = {};
    };
    PagesService.prototype.clearPageChangeCallback = function (id) {
        _smallstack_coreCommon.Logger.debug("PagesService", "Clearing page change callback for id '" + id + "'!");
        if (id !== undefined) {
            delete this.pageChangeCallbacks[id];
        }
    };
    PagesService.prototype.setBackofficeMode = function (backofficeMode) {
        this._backofficeMode = backofficeMode;
    };
    PagesService.prototype.isBackofficeMode = function () {
        return this._backofficeMode;
    };
    /** internal method to calculate the time when the pageLoaded event should get fired */
    PagesService.prototype._componentRendered = function () {
        var _this = this;
        this._componentsRendered++;
        if (this.allComponentsAreRendered()) {
            _.each(this.pageLoadedCallbacks, function (cb) {
                try {
                    if (cb.context)
                        cb.callback.bind(cb.context, _this.currentPage)();
                    else
                        cb.callback(_this.currentPage);
                }
                catch (e) {
                    console.error("Error in page loaded callback : ", e);
                }
            });
        }
    };
    PagesService.prototype.setPageLoadingAnimationEnabled = function (pageLoadingAnimationEnabled) {
        this.pageLoadingAnimationEnabled = pageLoadingAnimationEnabled;
    };
    PagesService.prototype.isPageLoadingAnimationEnabled = function () {
        return this.pageLoadingAnimationEnabled;
    };
    return PagesService;
}(GeneratedPagesService));

var ComponentInstanceUtils = (function () {
    function ComponentInstanceUtils() {
    }
    ComponentInstanceUtils.createInstance = function (name) {
        return {
            id: new Mongo.ObjectID().valueOf().toString(),
            name: name
        };
    };
    ComponentInstanceUtils.removeChildComponent = function (page, componentId) {
        if (componentId === undefined)
            return undefined;
        if (!page.components)
            return undefined;
        // root component?
        if (page.components.id === componentId)
            delete page.components;
        else {
            var parent = ComponentInstanceUtils.getParent(page, componentId);
            if (!parent)
                throw new Error("Could not find parent of child with ID '" + componentId + "'!");
            var found = false;
            for (var index = 0; index < parent.children.length; index++) {
                if (parent.children[index].id === componentId) {
                    parent.children.splice(index, 1);
                    found = true;
                }
            }
            if (!found)
                throw new Error("Could not find child component for removal!");
        }
        // connections
        page.socketConnections = _.reject(page.socketConnections, function (socketConnection) {
            return socketConnection.sourceComponentInstanceId === componentId || socketConnection.targetComponentInstanceId === componentId;
        });
        return page;
    };
    ComponentInstanceUtils.getParent = function (page, componentId) {
        if (componentId === undefined)
            return undefined;
        if (!page.components)
            return undefined;
        if (page.components.id === componentId)
            return page.components;
        return ComponentInstanceUtils.findParent(page.components, componentId);
    };
    ComponentInstanceUtils.findComponentById = function (page, componentId) {
        if (componentId === undefined)
            return undefined;
        if (!page.components)
            return undefined;
        if (page.components.id === componentId)
            return page.components;
        return ComponentInstanceUtils.findInChildren(page.components.children, componentId);
    };
    ComponentInstanceUtils.findParent = function (componentInstance, componentId) {
        if (componentInstance === undefined || componentInstance.children === undefined)
            return undefined;
        for (var index = 0; index < componentInstance.children.length; index++) {
            if (componentInstance.children[index].id === componentId)
                return componentInstance;
            var subParent = ComponentInstanceUtils.findParent(componentInstance.children[index], componentId);
            if (subParent)
                return subParent;
        }
        return undefined;
    };
    ComponentInstanceUtils.findInChildren = function (children, componentId) {
        if (children === undefined)
            return undefined;
        for (var index in children) {
            var child = children[index];
            if (child.id === componentId)
                return child;
            if (child.children) {
                var result = ComponentInstanceUtils.findInChildren(child.children, componentId);
                if (result !== undefined)
                    return result;
            }
        }
    };
    ComponentInstanceUtils.getAllComponentInstances = function (componentInstance, withChildren) {
        if (withChildren === void 0) { withChildren = false; }
        var instances = [];
        if (componentInstance === undefined)
            return instances;
        if (componentInstance.children)
            for (var index in componentInstance.children) {
                var child = componentInstance.children[index];
                instances = instances.concat(ComponentInstanceUtils.getAllComponentInstances(child));
            }
        if (!withChildren) {
            instances.push({
                id: componentInstance.id,
                name: componentInstance.name
            });
        }
        else
            instances.push(componentInstance);
        return instances;
    };
    return ComponentInstanceUtils;
}());

(function (ComponentSocketDirection) {
    ComponentSocketDirection[ComponentSocketDirection["IN"] = 0] = "IN";
    ComponentSocketDirection[ComponentSocketDirection["OUT"] = 1] = "OUT";
})(exports.ComponentSocketDirection || (exports.ComponentSocketDirection = {}));

(function (ComponentSocketType) {
    ComponentSocketType[ComponentSocketType["NUMBER"] = 0] = "NUMBER";
    ComponentSocketType[ComponentSocketType["NUMBER_ARRAY"] = 1] = "NUMBER_ARRAY";
    ComponentSocketType[ComponentSocketType["STRING"] = 2] = "STRING";
    ComponentSocketType[ComponentSocketType["STRING_ARRAY"] = 3] = "STRING_ARRAY";
    ComponentSocketType[ComponentSocketType["BOOLEAN"] = 4] = "BOOLEAN";
    ComponentSocketType[ComponentSocketType["BOOLEAN_ARRAY"] = 5] = "BOOLEAN_ARRAY";
    ComponentSocketType[ComponentSocketType["OBJECT"] = 6] = "OBJECT";
    ComponentSocketType[ComponentSocketType["OBJECT_ARRAY"] = 7] = "OBJECT_ARRAY";
})(exports.ComponentSocketType || (exports.ComponentSocketType = {}));
var ComponentSocket = (function () {
    function ComponentSocket() {
    }
    ComponentSocket.create = function (name, type, direction, values) {
        var socket = new ComponentSocket();
        socket.name = name;
        socket.direction = direction;
        socket.type = type;
        socket.values = values;
        return socket;
    };
    ComponentSocket.createInput = function (name, type, values) {
        return ComponentSocket.create(name, type, exports.ComponentSocketDirection.IN, values);
    };
    ComponentSocket.createOutput = function (name, type, values) {
        return ComponentSocket.create(name, type, exports.ComponentSocketDirection.OUT, values);
    };
    ComponentSocket.componentSocketTypeToString = function (type) {
        switch (type) {
            case exports.ComponentSocketType.BOOLEAN:
                return "boolean";
            case exports.ComponentSocketType.BOOLEAN_ARRAY:
                return "boolean[]";
            case exports.ComponentSocketType.NUMBER:
                return "number";
            case exports.ComponentSocketType.NUMBER_ARRAY:
                return "number[]";
            case exports.ComponentSocketType.OBJECT:
                return "object";
            case exports.ComponentSocketType.OBJECT_ARRAY:
                return "object[]";
            case exports.ComponentSocketType.STRING:
                return "string";
            case exports.ComponentSocketType.STRING_ARRAY:
                return "string[]";
        }
        throw new Error("UNKNOWN TYPE: " + type);
    };
    return ComponentSocket;
}());

/**
 * THIS FILE IS AUTO-GENERATED AND WILL BE REPLACED ON ANY RE-COMPILE
 */
var GeneratedPage = (function () {
    function GeneratedPage() {
        // internal properties
        this._hasSubDocuments = false;
        this._isStored = false;
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
    }
    GeneratedPage.fromDocument = function (doc) {
        var ModelConstructor = this.getModelClass();
        var model = new ModelConstructor();
        if (doc._id !== undefined) {
            model._isStored = true;
            model.id = doc._id;
        }
        model["name"] = doc["name"];
        model["components"] = doc["components"];
        model["socketConnections"] = doc["socketConnections"];
        return model;
    };
    GeneratedPage.prototype.toDocument = function (identifierKey) {
        if (identifierKey === void 0) { identifierKey = "_id"; }
        var doc = {};
        doc["name"] = this["name"];
        doc["components"] = this["components"];
        doc["socketConnections"] = this["socketConnections"];
        if (this.id)
            doc[identifierKey] = this.id;
        return doc;
    };
    /**
     * Returns true if the model can contain sub documents
     */
    GeneratedPage.prototype.hasSubDocuments = function () {
        return this._hasSubDocuments;
    };
    /**
     * Returns true if model is stored in database
     */
    GeneratedPage.prototype.isStored = function () {
        return this._isStored;
    };
    GeneratedPage.getModelName = function () {
        return "Page";
    };
    GeneratedPage.prototype.getModelName = function () {
        return "Page";
    };
    GeneratedPage.getModelClass = function () {
        return _smallstack_coreCommon.IOC.get("Page");
    };
    GeneratedPage.prototype.getModelClass = function () {
        return _smallstack_coreCommon.IOC.get("Page");
    };
    GeneratedPage.prototype.delete = function (callback) {
        if (callback === undefined && this.dataBridge.isClient()) {
            var that = this;
            callback = function (error, numberOfRemovedDocuments) {
                if (error)
                    _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error, "Could not delete Page with ID '" + that.id + "'!");
                else
                    _smallstack_coreCommon.NotificationService.instance().notification.success("Successfully removed Page with ID '" + that.id + "'!");
            };
        }
        return PagesService.instance().delete(this, callback);
    };
    GeneratedPage.prototype.update = function (callback) {
        var _this = this;
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, numberOfSavedDocuments) {
                if (error)
                    _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error, "Could not update Page with ID '" + _this.id + "'!");
                else
                    _smallstack_coreCommon.NotificationService.instance().notification.success("Successfully updated Page with ID '" + _this.id + "'!");
            };
        }
        return PagesService.instance().update(this, callback);
    };
    GeneratedPage.prototype.save = function (callback) {
        var _this = this;
        if (this.isStored())
            throw new Error("Model is already saved!");
        if (callback === undefined && this.dataBridge.isClient()) {
            callback = function (error, savedId) {
                if (error)
                    _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error, "Could not save Page!");
                else {
                    _this.id = savedId;
                    _this._isStored = true;
                    _smallstack_coreCommon.NotificationService.instance().notification.success("Successfully saved Page!");
                }
            };
        }
        if (this.dataBridge.isClient())
            PagesService.instance().save(this, callback);
        if (this.dataBridge.isServer()) {
            this.id = PagesService.instance().save(this, callback);
            this._isStored = true;
            return this.id;
        }
    };
    GeneratedPage.getSchema = function () {
        return {
            "_id": {
                "type": String,
                "optional": true
            },
            "name": {
                "type": String
            },
            "components": {
                "type": Object,
                "optional": true,
                "blackbox": true
            },
            "socketConnections": {
                "type": [Object],
                "optional": true,
                "blackbox": true
            },
        };
    };
    return GeneratedPage;
}());

var __extends$1 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
 * A page consists of a name and a component tree.
 *
 * *Name*
 * The *Name* is being used in the backoffice only to identify the page.
 * The regular user/customer will never see this *Name*.
 *
 * Component
 * Components are npm modules. They can be written in any Frontend Technology, as long as there is a renderer for it
 * registered in the smallstack. Components have to follow the ComponentInterface which exposes functionality to
 * register for configurable options etc. pp.
 *
 * In addition it can have the following attributes :
 * 	- name
 * 		the identifier to map the component to the source code implementation, e.g. : smallstack:text-editor:0.1.0
 * 	- children
 * 		an array of component identifiers
 *  - data
 * 		key:string -> value:any store for component specific data
 *
 *
 *
 * Component tree
 * The component tree consists of many related components. It always starts with one root component which then might
 * have several children etc. pp.
 */
var Page = (function (_super) {
    __extends$1(Page, _super);
    function Page() {
        var _this = _super.apply(this, arguments) || this;
        _this.data = {};
        return _this;
    }
    Page.prototype.getAllComponentInstances = function (withChildren) {
        if (withChildren === void 0) { withChildren = false; }
        return ComponentInstanceUtils.getAllComponentInstances(this.components, withChildren);
    };
    Page.prototype.getAllData = function () {
        return this.data;
    };
    Page.prototype.getData = function (identifier) {
        return this.data[identifier];
    };
    Page.prototype.setData = function (identifier, data) {
        this.data[identifier] = data;
    };
    Page.prototype.getConnectionsForComponentId = function (componentId, direction) {
        var matchingSocketConnections = [];
        _.each(this.socketConnections, function (socketConnection) {
            if (socketConnection.sourceComponentInstanceId === componentId && (direction === undefined || direction === exports.ComponentSocketDirection.OUT))
                matchingSocketConnections.push(socketConnection);
            if (socketConnection.targetComponentInstanceId === componentId && (direction === undefined || direction === exports.ComponentSocketDirection.IN))
                matchingSocketConnections.push(socketConnection);
        });
        return matchingSocketConnections;
    };
    return Page;
}(GeneratedPage));

(function (ComponentType) {
    ComponentType[ComponentType["ANGULAR1"] = 0] = "ANGULAR1";
    ComponentType[ComponentType["ANGULAR2"] = 1] = "ANGULAR2";
    ComponentType[ComponentType["REACT"] = 2] = "REACT";
    ComponentType[ComponentType["INVISIBLE"] = 3] = "INVISIBLE";
})(exports.ComponentType || (exports.ComponentType = {}));

var Component = (function () {
    function Component() {
        this.tags = [];
        this.sockets = [];
        this.configuration = [];
    }
    Component.prototype.setDescription = function (text) {
        this.description = text;
        return this;
    };
    Component.prototype.addTags = function (tags) {
        this.tags = this.tags.concat(tags);
        return this;
    };
    Component.prototype.setLabel = function (label) {
        this.label = label;
        return this;
    };
    Component.prototype.getLabel = function () {
        if (this.label === undefined)
            return this.componentName;
        return this.label;
    };
    Component.prototype.setComponentName = function (componentName) {
        this.componentName = componentName;
        return this;
    };
    Component.prototype.addSocket = function (socket) {
        this.sockets.push(socket);
        return this;
    };
    Component.prototype.addConfiguration = function (configObject) {
        this.configuration.push(configObject);
        return this;
    };
    return Component;
}());

var ComponentConfiguration = (function () {
    function ComponentConfiguration() {
        this.type = ComponentConfiguration.types.STRING;
        // public toData(): any {
        //     switch (this.type) {
        //     }
        // }
        // public static fromData(json: any): ComponentConfiguration {
        //     switch (json.type) {
        //         case ComponentConfiguration.types.STRING:
        //             var config: ComponentConfiguration = ComponentConfiguration.createStringConfiguration(json.key, json.defaultValue);
        //             config.value = json.value;
        //             return config;
        //     }
        // }
    }
    ComponentConfiguration.createStringConfiguration = function (key, defaultValue) {
        var configuration = new ComponentConfiguration();
        configuration.key = key;
        configuration.type = ComponentConfiguration.types.STRING;
        configuration.defaultValue = defaultValue;
        return configuration;
    };
    ComponentConfiguration.createSelectConfiguration = function (key, defaultValue, possibleValues) {
        var configuration = new ComponentConfiguration();
        configuration.key = key;
        configuration.type = ComponentConfiguration.types.SELECT;
        configuration.defaultValue = defaultValue;
        configuration.possibleValues = possibleValues;
        return configuration;
    };
    ComponentConfiguration.createTextareaConfiguration = function (key, defaultValue) {
        var configuration = new ComponentConfiguration();
        configuration.key = key;
        configuration.type = ComponentConfiguration.types.TEXTAREA;
        configuration.defaultValue = defaultValue;
        return configuration;
    };
    ComponentConfiguration.createNumberConfiguration = function (key, defaultValue) {
        var configuration = new ComponentConfiguration();
        configuration.key = key;
        configuration.type = ComponentConfiguration.types.NUMBER;
        configuration.defaultValue = defaultValue;
        return configuration;
    };
    ComponentConfiguration.createObjectConfiguration = function (key, defaultValue) {
        if (defaultValue === void 0) { defaultValue = {}; }
        var configuration = new ComponentConfiguration();
        configuration.key = key;
        configuration.type = ComponentConfiguration.types.OBJECT;
        configuration.defaultValue = defaultValue;
        return configuration;
    };
    ComponentConfiguration.createBooleanConfiguration = function (key, defaultValue) {
        if (defaultValue === void 0) { defaultValue = false; }
        var configuration = new ComponentConfiguration();
        configuration.key = key;
        configuration.type = ComponentConfiguration.types.BOOLEAN;
        configuration.defaultValue = defaultValue;
        return configuration;
    };
    ComponentConfiguration.createI18nStringConfiguration = function (key, defaultTexts) {
        if (defaultTexts === void 0) { defaultTexts = {}; }
        var configuration = new ComponentConfiguration();
        configuration.key = key;
        configuration.type = ComponentConfiguration.types.I18N;
        configuration.defaultValue = defaultTexts;
        return configuration;
    };
    ComponentConfiguration.convertObjectToPossibleValuesArray = function (obj) {
        var result = [];
        _.each(obj, function (value, key) {
            result.push({ label: value, value: key });
        });
        return result;
    };
    return ComponentConfiguration;
}());
ComponentConfiguration.types = {
    STRING: "string",
    BOOLEAN: "boolean",
    SELECT: "select",
    TEXTAREA: "textarea",
    NUMBER: "number",
    OBJECT: "object",
    I18N: "localizedtextarea",
    LIST: "list"
};

var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var BaseComponentController = (function () {
    function BaseComponentController() {
        this.componentInstanceId = undefined;
        this.dynamicData = {};
    }
    BaseComponentController.prototype.setComponentInstanceId = function (componentInstanceId) {
        var _this = this;
        this.componentInstanceId = componentInstanceId;
        if (typeof this["afterInitialization"] === 'function')
            this["afterInitialization"]();
        // register incoming socket events
        if (typeof this["onSocketEvent"] === 'function' && this.getComponent()) {
            _.each(this.getComponent().sockets, function (socket) {
                if (socket.direction === exports.ComponentSocketDirection.IN) {
                    EventService.instance().registerSocketConnectionHandler(_this.componentInstanceId, socket.name, function (data) {
                        _this["onSocketEvent"](socket.name, data);
                    });
                }
            });
        }
        if (typeof this["onPageChange"] === 'function') {
            this.pagesService.onPageChange(this.componentInstanceId, this["onPageChange"], this);
        }
        // if component belongs to a page, let pageService know
        if (this.getPage() !== undefined)
            this.pagesService._componentRendered();
    };
    BaseComponentController.prototype.getPage = function () {
        var _this = this;
        var page = this.pagesService.getCurrentPage();
        if (page !== undefined) {
            if (_.find(page.getAllComponentInstances(), function (componentInstance) { return componentInstance.id === _this.componentInstanceId; }) !== undefined)
                return page;
        }
        return undefined;
    };
    BaseComponentController.prototype.getComponent = function () {
        var instance = this.getComponentInstance();
        if (!instance)
            return undefined;
        return _smallstack_coreCommon.IOC.get("componentsRegistry").getComponentByName(instance.name);
    };
    BaseComponentController.prototype.getComponentInstance = function () {
        if (this.componentInstanceId === undefined || this.componentInstanceId === null)
            return undefined;
        var page = this.pagesService.getCurrentPage();
        if (!page)
            return undefined;
        var componentInstance = ComponentInstanceUtils.findComponentById(page, this.componentInstanceId);
        if (!componentInstance)
            _smallstack_coreCommon.Logger.debug("BaseComponentController", "Could not find component with ID '" + this.componentInstanceId + "' on page with ID '" + page.id + "'!");
        return componentInstance;
    };
    BaseComponentController.prototype.getChildren = function () {
        var componentInstance = this.getComponentInstance();
        if (componentInstance)
            return this.getComponentInstance().children;
        return [];
    };
    BaseComponentController.prototype.getData = function (key) {
        if (this.dynamicData && this.dynamicData[key])
            return this.dynamicData[key];
        var instance = this.getComponentInstance();
        if (instance !== undefined) {
            var data = instance.data;
            if (data !== undefined && data[key] !== undefined)
                return data[key];
        }
        if (this.hasConfiguration(key))
            return this.getConfiguration(key).defaultValue;
        return undefined;
    };
    BaseComponentController.prototype.saveData = function (data) {
        var _this = this;
        this.dataBridge.callMethod("cms-page-setComponentData", { currentPageId: this.pagesService.getCurrentPage().id, componentInstanceId: this.componentInstanceId, data: data }, function (error, success) {
            if (error)
                console.error("Could not save data for componentInstanceId : ", _this.componentInstanceId);
            else
                console.info("Successfully saved data for componentInstanceId : ", _this.componentInstanceId);
        });
    };
    /**
     * Dynamic Data is stored on the component itself and not in the database. It overwrites potential database data sets!
     */
    BaseComponentController.prototype.saveDynamicData = function (data) {
        this.dynamicData = data;
    };
    BaseComponentController.prototype.sendOutput = function (socketName, socketData) {
        _smallstack_coreCommon.Logger.debug("BaseComponentController", "Sending data:", { componentInstanceId: this.componentInstanceId, socketName: socketName, socketData: socketData });
        EventService.instance().dispatchSocketEvent(this.componentInstanceId, socketName, socketData);
    };
    BaseComponentController.prototype.getConfiguration = function (key) {
        return _.find(this.getComponent().configuration, function (conf) { return conf.key === key; });
    };
    BaseComponentController.prototype.hasConfiguration = function (key) {
        if (this.getComponent() !== undefined) {
            var searchResult = _.find(this.getComponent().configuration, function (conf) { return conf.key === key; });
            return searchResult !== undefined && searchResult !== null;
        }
        return false;
    };
    BaseComponentController.prototype.isBackofficeMode = function () {
        return this.pagesService.isBackofficeMode();
    };
    return BaseComponentController;
}());
__decorate([
    _smallstack_coreCommon.Autowired(),
    __metadata("design:type", _smallstack_coreCommon.NotificationService)
], BaseComponentController.prototype, "notificationService", void 0);
__decorate([
    _smallstack_coreCommon.Autowired(),
    __metadata("design:type", PagesService)
], BaseComponentController.prototype, "pagesService", void 0);
__decorate([
    _smallstack_coreCommon.Autowired(),
    __metadata("design:type", EventService)
], BaseComponentController.prototype, "eventService", void 0);
__decorate([
    _smallstack_coreCommon.Autowired(),
    __metadata("design:type", Object)
], BaseComponentController.prototype, "collectionsService", void 0);
__decorate([
    _smallstack_coreCommon.Autowired(),
    __metadata("design:type", Object)
], BaseComponentController.prototype, "dataBridge", void 0);

exports.initClient = initClient;
exports.EventService = EventService;
exports.PagesService = PagesService;
exports.Page = Page;
exports.Component = Component;
exports.ComponentConfiguration = ComponentConfiguration;
exports.ComponentSocket = ComponentSocket;
exports.BaseComponentController = BaseComponentController;
exports.ComponentsRegistry = ComponentsRegistry;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=client.umd.js.map
