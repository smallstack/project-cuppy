export * from "./src/initMeteorShared";
export * from "./src/MeteorBaseCollection";
export * from "./src/MeteorCollectionsService";
export * from "./src/MeteorDataBridge";
export * from "./src/MeteorCursorResolver";
import "./src/backoffice.i18n";
