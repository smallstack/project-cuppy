import { CursorResolver } from "@smallstack/core-common";
export declare class MeteorCursorResolver<ModelClass> implements CursorResolver<ModelClass> {
    resolve(cursor: any, callback?: (models: ModelClass[]) => void): ModelClass[];
}
