/// <reference types="meteor" />
import { Collection, CollectionsService, SmallstackModel, QueryOptions, Typesystem } from "@smallstack/core-common";
export declare abstract class MeteorBaseCollection<T extends SmallstackModel> implements Collection<T> {
    protected collectionsService: CollectionsService;
    protected typesystem: Typesystem;
    protected _collection: Mongo.Collection<T>;
    find(selector?: any, options?: any): any;
    findOne(selector?: any, options?: any): any;
    insert(document: T, callback?: (error: Error, savedId: string) => void): string;
    update(selector: any, updateOperation: any, callback?: (error: Error, updatedDocuments: number) => void): number;
    upsert(selector: any, updateOperation: any, callback?: (numbersAffectedOrInsertId: {
        numberAffected?: number;
        insertedId?: string;
    }) => void): {
        numberAffected?: number;
        insertedId?: string;
    };
    remove(selector: any, callback?: (error: Error, removedDocuments: number) => void): number;
    subscribe(publicationName: string, parameters: any, options: QueryOptions, callback?: () => void): void;
    subscribeForeignKeys(cursor: any, foreignKeys: any, callback?: any): void;
    getQueryCount(queryName: string, parameters: any, callback?: (count: number) => void): void;
    abstract getCollectionName(): string;
    abstract getForeignCollection(type: string): string;
    abstract getForeignGetter(): string;
    abstract getServiceName(): string;
    abstract getQueries(): {
        [queryName: string]: any;
    };
}
