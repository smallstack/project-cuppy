export declare function initMeteorShared(): void;
