/// <reference types="meteor" />
import { CollectionsService, PublisherMethodParameters, Collection } from "@smallstack/core-common";
export declare class MeteorCollectionsService implements CollectionsService {
    private typesystem;
    private publisherMethods;
    private collections;
    constructor();
    getCollectionByName(collectionName: string): Collection<any>;
    getAllCollections(): {
        [name: string]: Collection<any>;
    };
    addPublisherMethod(name: string, method: any): void;
    executePublisherMethod(publisherMethodName: string, params: PublisherMethodParameters): any;
    addPublisher(collectionName: string, name: string, mongoSelector?: any, mongoOptions?: any): void;
    subscribeForeignKeys(baseCollection: Collection<any>, cursor: Mongo.Cursor<any>, expands: string[], callback?: () => void): void;
    private getIdsFromExpandedCursor(expand, cursor);
    private getForeignSmallstackCollection(expand, baseCollection);
    registerCollection(collectionName: string, collection: Collection<any>): void;
    getAccessMethod(key: string): any;
    static instance(): CollectionsService;
    createCollection<ModelClass>(name: string, transformFn?: Function): any;
}
