(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@smallstack/core-common'), require('underscore')) :
	typeof define === 'function' && define.amd ? define(['exports', '@smallstack/core-common', 'underscore'], factory) :
	(factory((global['smallstack-meteor-common'] = global['smallstack-meteor-common'] || {}),global._smallstack_coreCommon,global._));
}(this, (function (exports,_smallstack_coreCommon,_) { 'use strict';

var MeteorCursorResolver = (function () {
    function MeteorCursorResolver() {
    }
    MeteorCursorResolver.prototype.resolve = function (cursor, callback) {
        var models = cursor.fetch();
        if (typeof callback === "function")
            callback(models);
        return cursor.fetch();
    };
    return MeteorCursorResolver;
}());

var MeteorDataBridge = (function () {
    function MeteorDataBridge() {
    }
    MeteorDataBridge.prototype.subscribe = function (publicationName, parameters, options, callbackFns) {
        Meteor.subscribe(publicationName, parameters, options, callbackFns);
    };
    MeteorDataBridge.prototype.getCurrentUserId = function () {
        return Meteor.userId();
    };
    MeteorDataBridge.prototype.userAuthenticated = function () {
        return Meteor.userId() !== null;
    };
    MeteorDataBridge.prototype.callMethod = function (methodName, parameters, callbackFns) {
        Meteor.call(methodName, parameters, callbackFns);
    };
    MeteorDataBridge.prototype.logout = function (callbackFn) {
        Meteor.logout(callbackFn);
    };
    MeteorDataBridge.prototype.getSessionVariable = function (key) {
        Session.get(key);
    };
    MeteorDataBridge.prototype.setSessionVariable = function (key, value) {
        Session.set(key, value);
    };
    MeteorDataBridge.prototype.isClient = function () {
        return Meteor.isClient;
    };
    MeteorDataBridge.prototype.isServer = function () {
        return Meteor.isServer;
    };
    MeteorDataBridge.prototype.instance = function () {
        return _smallstack_coreCommon.IOC.get("dataBridge");
    };
    MeteorDataBridge.prototype.addServerMethod = function (name, func) {
        _smallstack_coreCommon.Logger.debug("DataBridge", "Registering server method '" + name + "'!");
        var methods = {};
        methods[name] = func;
        Meteor.methods(methods);
    };
    MeteorDataBridge.prototype.reactiveContext = function (fn) {
        Tracker.autorun(function () { fn; });
    };
    return MeteorDataBridge;
}());

var MeteorCollectionsService = (function () {
    function MeteorCollectionsService() {
        var _this = this;
        this.publisherMethods = {};
        this.collections = {};
        _smallstack_coreCommon.IOC.onRegister("typesystem", function (typesystem) {
            _this.typesystem = typesystem;
        });
    }
    MeteorCollectionsService.prototype.getCollectionByName = function (collectionName) {
        if (this.collections[collectionName])
            return this.collections[collectionName];
        throw new Error("Collection '" + collectionName + "' does not exist!");
    };
    MeteorCollectionsService.prototype.getAllCollections = function () {
        return this.collections;
    };
    MeteorCollectionsService.prototype.addPublisherMethod = function (name, method) {
        if (Meteor.isServer)
            this.publisherMethods[name] = method;
    };
    MeteorCollectionsService.prototype.executePublisherMethod = function (publisherMethodName, params) {
        var publisherMethod = this.publisherMethods[publisherMethodName];
        if (!publisherMethod)
            throw new Error("Publication method '" + publisherMethodName + "' could not be found!");
        var result = publisherMethod(params);
        if (result.type === "boolean" && result.value === false)
            throw new Meteor.Error("403", "Access restricted by '" + publisherMethodName + "'!");
        return result;
    };
    MeteorCollectionsService.prototype.addPublisher = function (collectionName, name, mongoSelector, mongoOptions) {
        if (typeof name !== 'string' || name.length === 0)
            throw new Error("Tried to create publisher without name for collection '" + collectionName + "'!");
        if (Meteor.isServer) {
            var type = this.typesystem.getTypeByCollectionName(collectionName);
            var serviceQuery_1;
            if (type !== undefined) {
                serviceQuery_1 = type.getServiceQueryByName(name);
                if (serviceQuery_1 === undefined)
                    _smallstack_coreCommon.Logger.error("CollectionsService", "Could not find a service query for name : " + name);
                if (serviceQuery_1 !== undefined && serviceQuery_1.access === undefined)
                    _smallstack_coreCommon.Logger.debug("CollectionsService", "No access rules defined for publication " + collectionName + "->" + name);
            }
            else
                throw new Error("Could not find a smallstack type by collection name '" + collectionName + "'!");
            var self_1 = this;
            Meteor.publish(name, function (parameters, options) {
                var selector = _.clone(mongoSelector);
                try {
                    if (serviceQuery_1 !== undefined) {
                        if (serviceQuery_1.hasRole !== undefined) {
                            _smallstack_coreCommon.IOC.get("rolesService").checkRole(this.userId, serviceQuery_1.hasRole);
                        }
                        if (serviceQuery_1.access !== undefined) {
                            var accessParams_1 = {
                                context: { userId: this.userId },
                                parameters: parameters,
                                accessObject: serviceQuery_1.access
                            };
                            switch (typeof serviceQuery_1.access) {
                                case "string":
                                    var result = self_1.executePublisherMethod(serviceQuery_1.access, accessParams_1);
                                    if (result.type === "selector")
                                        selector = _.extend(selector, result.value);
                                    break;
                                case "object":
                                    _.each(serviceQuery_1.access, function (value, key) {
                                        var result = self_1.executePublisherMethod(key, accessParams_1);
                                        if (result.type === "selector")
                                            selector = _.extend(selector, result.value);
                                    });
                                default:
                                    throw new Error("Type of query.access: '" + typeof serviceQuery_1.access + "' is not allowed!");
                            }
                        }
                    }
                    var opts = {};
                    if (options && options.currentPage && options.entriesPerPage) {
                        opts.skip = (parseInt(options.currentPage) - 1) * parseInt(options.entriesPerPage);
                        opts.limit = parseInt(options.entriesPerPage);
                    }
                    else
                        opts.limit = options && options.limit ? options.limit : 50;
                    opts.skip = options && options.skip ? options.skip : 0;
                    if (mongoOptions && mongoOptions.sort !== undefined) {
                        opts.sort = mongoOptions.sort;
                    }
                    if (options && options.sort !== undefined) {
                        opts.sort = options.sort;
                    }
                    if (mongoOptions && mongoOptions.fields !== undefined) {
                        opts.fields = mongoOptions.fields;
                    }
                    var collection = self_1.getCollectionByName(collectionName);
                    if (collection === undefined)
                        throw new Meteor.Error("404", "Collection '" + collectionName + "' not found!");
                    var interpolatedSelector = _smallstack_coreCommon.QueryUtils.interpolate(selector, { userId: this.userId, parameters: parameters });
                    var cursor = collection.find(interpolatedSelector, opts);
                    _smallstack_coreCommon.Logger.debug("CollectionsService", "subscribing to '" + collectionName + "->" + name + "'");
                    _smallstack_coreCommon.Logger.debug("CollectionsService", "     >select       ", JSON.stringify(interpolatedSelector));
                    _smallstack_coreCommon.Logger.debug("CollectionsService", "     >options      ", JSON.stringify(mongoOptions));
                    _smallstack_coreCommon.Logger.debug("CollectionsService", "     >count        ", cursor.count());
                    _smallstack_coreCommon.Logger.debug("CollectionsService", "     >user options ", JSON.stringify(options));
                    _smallstack_coreCommon.Logger.debug("CollectionsService", "     >opts         ", JSON.stringify(opts));
                    return cursor;
                }
                catch (e) {
                    _smallstack_coreCommon.Logger.error("CollectionsService", e.message, e);
                    this.stop(e);
                }
            });
        }
    };
    MeteorCollectionsService.prototype.subscribeForeignKeys = function (baseCollection, cursor, expands, callback) {
        var _this = this;
        var collectionQueries = {};
        var solvedExpands = [];
        _smallstack_coreCommon.Logger.debug("CollectionsService", "expanding: ", expands);
        _.each(expands, function (expand) {
            if (expand !== undefined) {
                var subExpand;
                if (expand.indexOf(".") !== -1) {
                    var split = expand.split(".");
                    if (split.length > 2)
                        throw new Error("expanding deeper than 2 levels is not performant : " + expand);
                    expand = split[0];
                    subExpand = split[1];
                }
                if (!_.contains(solvedExpands, expand)) {
                    solvedExpands.push(expand);
                    var foreignCollection = _this.getForeignSmallstackCollection(expand, baseCollection);
                    if (collectionQueries[foreignCollection.getCollectionName()] === undefined) {
                        collectionQueries[foreignCollection.getCollectionName()] = { ids: [], subExpands: [], foreignGetterPublication: foreignCollection.getForeignGetter(), foreignServiceName: foreignCollection.getServiceName() };
                    }
                    collectionQueries[foreignCollection.getCollectionName()].ids = _.uniq(_.union(collectionQueries[foreignCollection.getCollectionName()].ids, _this.getIdsFromExpandedCursor(expand, cursor)));
                    if (subExpand !== undefined)
                        collectionQueries[foreignCollection.getCollectionName()].subExpands = _.uniq(_.union(collectionQueries[foreignCollection.getCollectionName()].subExpands, [subExpand]));
                }
            }
        });
        _smallstack_coreCommon.Logger.debug("CollectionsService", "collectionQueries: ", collectionQueries);
        var readyCount = _.keys(collectionQueries).length;
        _smallstack_coreCommon.Logger.debug("CollectionsService", "outstanding subscriptions : ", readyCount);
        _.each(_.keys(collectionQueries), function (collectionKey) {
            var service = _smallstack_coreCommon.IOC.get(collectionQueries[collectionKey].foreignServiceName);
            var foreignGetterPublication = collectionQueries[collectionKey].foreignGetterPublication;
            _smallstack_coreCommon.Logger.debug("CollectionsService", "Creating additional subscription to publication '" + collectionQueries[collectionKey].foreignServiceName + "->" + foreignGetterPublication + "' with ids : ", collectionQueries[collectionKey].ids);
            var foreignCollection = service.getCollection();
            if (foreignCollection.getQueries()[foreignGetterPublication] === undefined)
                throw new Error("Publication " + foreignCollection.getCollectionName() + "->" + foreignGetterPublication + " doesn't exist!");
            foreignCollection.subscribe(foreignGetterPublication, { ids: collectionQueries[collectionKey].ids }, {}, function () {
                if (collectionQueries[collectionKey].ids instanceof Array) {
                    var subDocumentsCursor = _this.getCollectionByName(collectionKey).find({ "_id": { "$in": collectionQueries[collectionKey].ids } });
                    if (collectionQueries[collectionKey].subExpands instanceof Array && collectionQueries[collectionKey].subExpands.length !== 0) {
                        _this.subscribeForeignKeys(_this.getCollectionByName(collectionKey), subDocumentsCursor, collectionQueries[collectionKey].subExpands);
                    }
                }
                else
                    console.error("collectionQueries[collectionKey].ids not instanceof Array!");
                readyCount--;
                _smallstack_coreCommon.Logger.debug("CollectionsService", "fetching objects : ", cursor.fetch());
                _smallstack_coreCommon.Logger.debug("CollectionsService", "outstanding subscriptions : ", readyCount);
                if (readyCount === 0 && typeof callback === 'function') {
                    callback();
                }
            });
        });
    };
    MeteorCollectionsService.prototype.getIdsFromExpandedCursor = function (expand, cursor) {
        var ids = [];
        cursor.forEach(function (entry) {
            if (entry[expand] !== undefined) {
                if (entry[expand] instanceof Array)
                    ids = ids.concat(entry[expand]);
                else
                    ids.push(entry[expand]);
            }
        });
        ids = _.uniq(ids);
        return ids;
    };
    MeteorCollectionsService.prototype.getForeignSmallstackCollection = function (expand, baseCollection) {
        var foreignCollectionName = baseCollection.getForeignCollection(expand);
        if (!foreignCollectionName)
            throw new Error("Could not find foreign collection name for foreign property '" + expand + "' of collection '" + baseCollection.getCollectionName() + "'!");
        var foreignCollection = this.getCollectionByName(foreignCollectionName);
        if (!foreignCollection)
            throw new Error("Could not find foreign collection for foreign collection name '" + foreignCollectionName + "'!");
        return foreignCollection;
    };
    MeteorCollectionsService.prototype.registerCollection = function (collectionName, collection) {
        this.collections[collectionName] = collection;
        _smallstack_coreCommon.Logger.debug("MeteorCollectionsService", "registered collection: " + collectionName);
    };
    MeteorCollectionsService.prototype.getAccessMethod = function (key) {
        return this.publisherMethods[key];
    };
    MeteorCollectionsService.instance = function () {
        return _smallstack_coreCommon.IOC.get("collectionsService");
    };
    MeteorCollectionsService.prototype.createCollection = function (name, transformFn) {
        return new Mongo.Collection(name, { transform: transformFn });
    };
    return MeteorCollectionsService;
}());

function initMeteorShared() {
    _smallstack_coreCommon.IOC.register("cursorResolver", new MeteorCursorResolver());
    _smallstack_coreCommon.IOC.register("dataBridge", new MeteorDataBridge());
    _smallstack_coreCommon.IOC.register("collectionsService", new MeteorCollectionsService());
}

var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var MeteorBaseCollection = (function () {
    function MeteorBaseCollection() {
    }
    MeteorBaseCollection.prototype.find = function (selector, options) {
        if (selector === void 0) { selector = {}; }
        if (options === void 0) { options = {}; }
        _smallstack_coreCommon.Logger.debug("MeteorBaseCollection", this.getCollectionName() + " -> Find Query : " + selector, { selector: selector, options: options });
        return this._collection.find(selector, options);
    };
    MeteorBaseCollection.prototype.findOne = function (selector, options) {
        return this._collection.findOne(selector, options);
    };
    MeteorBaseCollection.prototype.insert = function (document, callback) {
        return this._collection.insert(document.toDocument(), callback);
    };
    MeteorBaseCollection.prototype.update = function (selector, updateOperation, callback) {
        return this._collection.update(selector, updateOperation, callback);
    };
    MeteorBaseCollection.prototype.upsert = function (selector, updateOperation, callback) {
        return this._collection.upsert(selector, updateOperation, callback);
    };
    MeteorBaseCollection.prototype.remove = function (selector, callback) {
        return this._collection.remove(selector, callback);
    };
    MeteorBaseCollection.prototype.subscribe = function (publicationName, parameters, options, callback) {
        var _this = this;
        _smallstack_coreCommon.Logger.debug("MeteorBaseCollection", "Subscribing to " + publicationName);
        Meteor.subscribe(publicationName, parameters, options, {
            onStop: function (error) {
                if (error)
                    throw error;
                else
                    throw new Error("An unknown error occured while subscribing to : " + _this.getCollectionName() + "->" + publicationName);
            },
            onError: function (error) {
                if (error)
                    throw error;
                else
                    throw new Error("An unknown error occured while subscribing to : " + _this.getCollectionName() + "->" + publicationName);
            },
            onReady: function () {
                callback();
            }
        });
    };
    MeteorBaseCollection.prototype.subscribeForeignKeys = function (cursor, foreignKeys, callback) {
        this.collectionsService.subscribeForeignKeys(this, cursor, foreignKeys, callback);
    };
    MeteorBaseCollection.prototype.getQueryCount = function (queryName, parameters, callback) {
        Meteor.call("server-counts", queryName, parameters, function (error, count) {
            if (error)
                _smallstack_coreCommon.Logger.error("MeteorBaseCollection", "Could not get counts for query " + queryName, error);
            else
                callback(count);
        });
    };
    return MeteorBaseCollection;
}());
__decorate([
    _smallstack_coreCommon.Autowired()
], MeteorBaseCollection.prototype, "collectionsService", void 0);
__decorate([
    _smallstack_coreCommon.Autowired()
], MeteorBaseCollection.prototype, "typesystem", void 0);

_smallstack_coreCommon.IOC.onRegister("localizationService", function (localizationService) {
    _smallstack_coreCommon.LocalizationService.instance().addTranslation("de", {
        "backoffice": {
            "navigation": {
                "dashboard": "Übersicht",
                "jobs": "Aufgaben",
                "socialnetworks": "Soziale Netzwerke",
                "i18n": "Internationalisierung",
                "collections": "Datenbank",
                "addView": "Modul hinzufügen",
                "backup": "Backup & Restore",
                "configuration": "Konfiguration"
            }
        }
    });
});
_smallstack_coreCommon.IOC.onRegister("localizationService", function (localizationService) {
    _smallstack_coreCommon.LocalizationService.instance().addTranslation("en", {
        "backoffice": {
            "navigation": {
                "dashboard": "Dashboard",
                "jobs": "Jobs",
                "socialnetworks": "Social Networks",
                "i18n": "Internationalization",
                "collections": "Database",
                "addView": "Add Module",
                "backup": "Backup & Restore",
                "configuration": "Configuration"
            }
        }
    });
});

exports.initMeteorShared = initMeteorShared;
exports.MeteorBaseCollection = MeteorBaseCollection;
exports.MeteorCollectionsService = MeteorCollectionsService;
exports.MeteorDataBridge = MeteorDataBridge;
exports.MeteorCursorResolver = MeteorCursorResolver;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=common.umd.js.map
