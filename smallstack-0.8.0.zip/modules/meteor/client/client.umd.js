(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('underscore'), require('@smallstack/core-common'), require('@smallstack/core-client'), require('toastr'), require('@angular/core'), require('@angular/router'), require('chance'), require('@angular/forms'), require('@angular/platform-browser'), require('@angular/platform-browser-dynamic'), require('@angular/common'), require('ng2-bootstrap'), require('ng2-charts/ng2-charts'), require('ng2-file-upload'), require('angular2-wizard'), require('moment'), require('jquery')) :
	typeof define === 'function' && define.amd ? define(['exports', 'underscore', '@smallstack/core-common', '@smallstack/core-client', 'toastr', '@angular/core', '@angular/router', 'chance', '@angular/forms', '@angular/platform-browser', '@angular/platform-browser-dynamic', '@angular/common', 'ng2-bootstrap', 'ng2-charts/ng2-charts', 'ng2-file-upload', 'angular2-wizard', 'moment', 'jquery'], factory) :
	(factory((global['smallstack-meteor-client'] = global['smallstack-meteor-client'] || {}),global.underscore,global['@smallstack/core-common'],global._smallstack_coreClient,global.toastr,global.ng.core,global.ng.router,global.chance,global.ng.forms,global.ng.platformBrowser,global.ng.platformBrowserDynamic,global.ng.common,global.ng2Bootstrap,global.ng2Charts_ng2Charts,global.ng2FileUpload,global.angular2Wizard,global.moment,global.jquery));
}(this, (function (exports,_,_smallstack_coreCommon,_smallstack_coreClient,toastr,_angular_core,_angular_router,Chance,_angular_forms,_angular_platformBrowser,_angular_platformBrowserDynamic,_angular_common,ng2Bootstrap,ng2Charts_ng2Charts,ng2FileUpload,angular2Wizard,moment,$$1) { 'use strict';

moment = 'default' in moment ? moment['default'] : moment;
$$1 = 'default' in $$1 ? $$1['default'] : $$1;

var ToastrNotifier = (function () {
    function ToastrNotifier() {
        toastr.options.progressBar = true;
        toastr.options.extendedTimeOut = 20000;
        toastr.options.timeOut = 5000;
    }
    ToastrNotifier.prototype.getOptions = function () {
        return {};
    };
    ToastrNotifier.prototype.log = function (title, message, level) {
        switch (level) {
            case "error":
                toastr.error(title, message, this.getOptions());
                break;
            case "success":
                toastr.success(title, message, this.getOptions());
                break;
            case "warn":
                toastr.warning(title, message, this.getOptions());
                break;
            case "debug":
                toastr.info(title, message, this.getOptions());
                break;
            case "info":
                toastr.info(title, message, this.getOptions());
                break;
            default:
                _smallstack_coreCommon.Logger.error("ToastrNotifier", "\"$level\" is not a known notifier level!");
                toastr.error(title, message, this.getOptions());
        }
    };
    ToastrNotifier.prototype.info = function (title, message) {
        this.log(title, message, "info");
    };
    ToastrNotifier.prototype.success = function (title, message) {
        this.log(title, message, "success");
    };
    ToastrNotifier.prototype.debug = function (title, message) {
        this.log(title, message, "debug");
    };
    ToastrNotifier.prototype.warn = function (title, message) {
        this.log(title, message, "warn");
    };
    ToastrNotifier.prototype.error = function (title, message) {
        this.log(title, message, "error");
    };
    ToastrNotifier.prototype.confirmation = function (title, message, callback) {
        $("body").append("\n            <div class=\"fullscreen-notification-container\">\n                <div class=\"fullscreen-notification-header\">" + title + "</div>\n                <div class=\"fullscreen-notification-body\">" + message + "</div>\n            </div>\n        ");
    };
    return ToastrNotifier;
}());

var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PageNotFoundComponent = (function () {
    function PageNotFoundComponent() {
    }
    return PageNotFoundComponent;
}());
PageNotFoundComponent = __decorate([
    _angular_core.Component({
        template: '<h2>Page not found!</h2>'
    }),
    __metadata("design:paramtypes", [])
], PageNotFoundComponent);

// import all components
function initMeteorClient$$1() {
    _smallstack_coreCommon.IOC.register("navigationService", new _smallstack_coreCommon.NavigationService());
    _smallstack_coreCommon.IOC.register("angular2Router", new Angular2Router());
    _smallstack_coreCommon.IOC.register("componentsRegistry", new _smallstack_coreClient.ComponentsRegistry());
    // notifications
    _smallstack_coreCommon.IOC.onRegister("notificationService", function (notificationService) {
        var toastrNotifier = new ToastrNotifier();
        notificationService.setPopupNotifier(toastrNotifier);
        notificationService.setNotificationNotifier(toastrNotifier);
    });
    _smallstack_coreCommon.Logger.printSmallstackLogo();
}
function getAngular2Declarations$$1() {
    // get all declarations
    var angular2Components = _smallstack_coreCommon.IOC.get("componentsRegistry").getComponentsByType(_smallstack_coreClient.ComponentType.ANGULAR2);
    var declarations = [];
    _.each(angular2Components, function (c) {
        _smallstack_coreCommon.Logger.debug("ComponentsModule", "adding component => ", c);
        declarations.push(c.component);
    });
    return declarations.concat([
        exports.TranslatePipe,
        exports.CapitalizePipe,
        exports.I18nPipe,
        PageNotFoundComponent
    ]);
}

var __decorate$1 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
exports.TranslatePipe = (function () {
    function TranslatePipe() {
    }
    TranslatePipe.prototype.transform = function (i18nKey) {
        return this.localizationService.getTranslation(i18nKey, { showMissingKey: true });
    };
    return TranslatePipe;
}());
__decorate$1([
    _smallstack_coreCommon.Autowired(),
    __metadata$1("design:type", _smallstack_coreCommon.LocalizationService)
], exports.TranslatePipe.prototype, "localizationService", void 0);
exports.TranslatePipe = __decorate$1([
    _angular_core.Pipe({ name: "translate" }),
    __metadata$1("design:paramtypes", [])
], exports.TranslatePipe);

var __decorate$2 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
exports.I18nPipe = (function () {
    function I18nPipe() {
        this.localizationService = _smallstack_coreCommon.IOC.get("localizationService");
    }
    I18nPipe.prototype.transform = function (i18nObject) {
        var currentLanguage = this.localizationService.getCurrentLanguage();
        if (currentLanguage in i18nObject)
            return i18nObject[currentLanguage];
        return i18nObject[this.localizationService.getFallbackLanguage()];
    };
    return I18nPipe;
}());
exports.I18nPipe = __decorate$2([
    _angular_core.Pipe({ name: 'i18n' }),
    __metadata$2("design:paramtypes", [])
], exports.I18nPipe);

var __decorate$3 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
exports.CapitalizePipe = (function () {
    function CapitalizePipe() {
    }
    CapitalizePipe.prototype.transform = function (val) {
        return _smallstack_coreCommon.Utils.capitalize(val);
    };
    return CapitalizePipe;
}());
exports.CapitalizePipe = __decorate$3([
    _angular_core.Pipe({ name: 'capitalize' }),
    __metadata$3("design:paramtypes", [])
], exports.CapitalizePipe);

var __decorate$4 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$4 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
exports.UserAuthenticatedGuard = (function () {
    function UserAuthenticatedGuard(router) {
        this.router = router;
    }
    UserAuthenticatedGuard.prototype.canActivate = function (route, state) {
        if (!_smallstack_coreCommon.IOC.get("dataBridge").userAuthenticated()) {
            var loginRoute = route.data["loginRoute"];
            if (loginRoute === undefined)
                loginRoute = "/login";
            this.router.navigate([loginRoute]);
            return false;
        }
        return true;
    };
    return UserAuthenticatedGuard;
}());
exports.UserAuthenticatedGuard = __decorate$4([
    _angular_core.Injectable(),
    __metadata$4("design:paramtypes", [_angular_router.Router])
], exports.UserAuthenticatedGuard);

var Angular2Router = (function () {
    function Angular2Router() {
        this.routes = [];
        this.navigationService = _smallstack_coreCommon.IOC.get("navigationService");
        this.navigationService.onNavigationEntryAdd(this.addAngularRoute, this);
    }
    Angular2Router.prototype.getRouterModule = function () {
        if (this.routes.length === 0) {
            _smallstack_coreCommon.Logger.warning("Angular2Router", "No routes defined, this might lead to further errors!");
            return _angular_router.RouterModule.forRoot([]);
        }
        else {
            _smallstack_coreCommon.Logger.debug("Angular2Router", "Routes: ", this.routes);
            return _angular_router.RouterModule.forRoot(this.routes);
        }
    };
    Angular2Router.prototype.addAngularRoute = function (navigationEntry) {
        _smallstack_coreCommon.Logger.debug("Angular2Router", "creating angular2 route entry for " + navigationEntry.route);
        if (navigationEntry.route === undefined)
            throw new Error("Angular2 routes need a route defined!");
        if (navigationEntry.route.charAt(0) === "/")
            navigationEntry.route = navigationEntry.route.substr(1);
        var route = {};
        route.path = navigationEntry.route;
        route.data = {
            label: navigationEntry.getLabel()
        };
        route.component = navigationEntry.getComponent();
        // if (navigationEntry.pageId !== undefined)
        //     route.component = new PageComponent();
        if (navigationEntry.doesRequireAuthentication()) {
            if (navigationEntry.loginRoute)
                route.data["loginRoute"] = navigationEntry.loginRoute;
            route.canActivate = [exports.UserAuthenticatedGuard];
        }
        // state["meta"] = _.extend(navigationEntry.getMetaTags(), { baseUrl: Meteor.absoluteUrl("") });
        // route.resolve = {
        //     "currentUser": () => {
        //         if (navigationEntry.doesRequireAuthentication()) {
        //             return Meteor.userId() !== null;
        //         }
        //     }
        //     // ,
        //     // "userHasRole": () => {
        //     //     if (navigationEntry.getRequiredRole() !== undefined) {
        //     //         var deferred: angular.IDeferred<Boolean> = $q.defer();
        //     //         UserService.instance().getMyUser({}).subscribe((cursor) => {
        //     //             let currentUser: User = cursor.fetch()[0];
        //     //             if (currentUser && this.rolesService.userHasRole(currentUser, navigationEntry.getRequiredRole()))
        //     //                 deferred.resolve(true);
        //     //             else {
        //     //                 Session.set("error", new Meteor.Error("403", "You don't have the necessary rights to access this page!", "Role required : " + navigationEntry.getRequiredRole()));
        //     //                 deferred.reject(new Error("ROLE_REQUIRED"));
        //     //             }
        //     //         });
        //     //         return deferred.promise;
        //     //     }
        //     // }
        // }
        var childOfRoute = navigationEntry.getChildOfRoute();
        if (childOfRoute !== undefined) {
            var parentRoute = this.getRouteByRoute(childOfRoute);
            if (parentRoute) {
                if (!parentRoute.children) {
                    parentRoute.children = [];
                    if (parentRoute.redirectTo) {
                        parentRoute.children.push({
                            path: '',
                            redirectTo: parentRoute.redirectTo,
                            pathMatch: "full"
                        });
                        parentRoute.redirectTo = undefined;
                    }
                }
                parentRoute.children.push(route);
            }
            else
                throw new Error("Could not find parent route '" + childOfRoute + "'!");
        }
        else
            this.routes.push(route);
        if (navigationEntry.redirectTo !== undefined) {
            if (route.children === undefined)
                route.redirectTo = navigationEntry.redirectTo;
            else {
                route.children.push({
                    path: '',
                    redirectTo: navigationEntry.redirectTo,
                    pathMatch: "full"
                });
            }
        }
    };
    Angular2Router.prototype.getRouteByRoute = function (routePath, routes) {
        if (routes === void 0) { routes = this.routes; }
        var found = undefined;
        for (var r = 0; r < routes.length; r++) {
            if (routes[r].path === routePath) {
                found = routes[r];
                break;
            }
            if (routes[r].children instanceof Array && routes[r].children.length > 0) {
                found = this.getRouteByRoute(routePath, routes[r].children);
                if (found)
                    break;
            }
        }
        return found;
    };
    return Angular2Router;
}());

var __extends = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Angular2Component = (function (_super) {
    __extends(Angular2Component, _super);
    function Angular2Component(componentName, component) {
        var _this = _super.call(this) || this;
        _this.initializeAngularComponent = true;
        _this.component = component;
        _this.setComponentName(componentName);
        return _this;
    }
    Angular2Component.new = function (componentName, component) {
        return new Angular2Component(componentName, component);
    };
    Angular2Component.prototype.setTemplate = function (template) {
        this.template = template;
        return this;
    };
    Angular2Component.prototype.setStyles = function (styles) {
        this.styles = styles;
        return this;
    };
    Angular2Component.prototype.setInitializeAngularComponent = function (initializeAngularComponent) {
        this.initializeAngularComponent = initializeAngularComponent;
        return this;
    };
    Angular2Component.prototype.getType = function () {
        return _smallstack_coreClient.ComponentType.ANGULAR2;
    };
    Angular2Component.prototype.instantiate = function () {
    };
    Angular2Component.prototype.register = function () {
        var _this = this;
        _smallstack_coreCommon.IOC.onRegister("componentsRegistry", function (registry) {
            if (registry.isRegistered(_this.componentName))
                throw new Error("Component with name '" + _this.componentName + "' already exists!");
            if (!_this.component || !_this.component["prototype"])
                _smallstack_coreCommon.Logger.error("Angular2Component", "No component given, or non-function given as component!", _this);
            else {
                _this.component.prototype["getComponentName"] = function () { return _this.componentName; };
                if (_this.initializeAngularComponent) {
                    var ConstructFn = _angular_core.Component;
                    var inputs_1 = [];
                    var outputs_1 = [];
                    _.each(_this.sockets, function (socket) {
                        if (socket.direction === _smallstack_coreClient.ComponentSocketDirection.IN) {
                            inputs_1.push("sockets_input_" + socket.name + ":" + socket.name);
                        }
                        if (socket.direction === _smallstack_coreClient.ComponentSocketDirection.OUT) {
                            var internalSocketName = "sockets_output_" + socket.name;
                            outputs_1.push(internalSocketName + ":" + socket.name);
                            _this.component.prototype[internalSocketName] = new _angular_core.EventEmitter();
                            _smallstack_coreCommon.Logger.debug("Angular2Component", "Created Angular2 socket '" + internalSocketName + "'!");
                        }
                    });
                    var componentData = {
                        selector: _this.componentName,
                        inputs: inputs_1,
                        outputs: outputs_1
                    };
                    if (_this.template)
                        componentData.template = _this.template;
                    else
                        ConstructFn = _angular_core.Directive;
                    if (_this.styles)
                        componentData.styles = _this.styles;
                    _this.component.annotations = [new ConstructFn(componentData)];
                }
            }
            _smallstack_coreCommon.IOC.get("componentsRegistry").addComponent(_this);
        });
    };
    return Angular2Component;
}(_smallstack_coreClient.Component));

var __extends$1 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate$5 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$5 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var Angular2BaseComponentController = (function (_super) {
    __extends$1(Angular2BaseComponentController, _super);
    function Angular2BaseComponentController() {
        var _this = _super.call(this) || this;
        _this.routeCallbacks = [];
        _this.subscriptions = [];
        _smallstack_coreCommon.IOC.onRegister("angular2Injector", function (injector) {
            _this.router = injector.get(_angular_router.Router);
            var completeRoute = injector.get(_angular_router.ActivatedRoute);
            _this.subscriptions.push(_this.router.events
                .filter(function (event) { return event instanceof _angular_router.NavigationEnd; })
                .subscribe(function (event) {
                var currentRoute = completeRoute.root;
                while (currentRoute.children[0] !== undefined) {
                    currentRoute = currentRoute.children[0];
                }
                _this.route = currentRoute;
                _.each(_this.routeCallbacks, function (routeCB) { routeCB(_this.route); });
            }));
        });
        return _this;
    }
    Angular2BaseComponentController.prototype.onCurrentRoute = function (callback) {
        if (this.route)
            callback(this.route);
        else
            this.routeCallbacks.push(callback);
    };
    Angular2BaseComponentController.prototype.ngOnInit = function () {
        var _this = this;
        if (this.data)
            this.saveDynamicData(this.data);
        _smallstack_coreCommon.IOC.onRegister("ngZone", function () {
            if (_this.componentId)
                _this.setComponentInstanceId(_this.componentId);
            else
                _this.setComponentInstanceId(new Chance().guid());
        });
    };
    Angular2BaseComponentController.prototype.ngOnDestroy = function () {
        this.eventService.clearSocketConnections(this.componentInstanceId);
        this.eventService.removeSocketConnectionHandler(this.componentInstanceId);
        if (typeof this["onPageChange"] === 'function') {
            this.pagesService.clearPageChangeCallback(this.componentInstanceId);
        }
        _.each(this.subscriptions, function (sub) {
            sub.unsubscribe();
        });
    };
    Angular2BaseComponentController.prototype.getRouteParameter = function (parameterName, callback) {
        var _this = this;
        this.onCurrentRoute(function () {
            _this.subscriptions.push(_this.route.params.subscribe(function (params) {
                callback(params[parameterName]);
            }));
        });
    };
    Angular2BaseComponentController.prototype.onSocketEvent = function (socketName, socketData) {
        this[socketName] = socketData;
    };
    Angular2BaseComponentController.prototype.ngOnChanges = function (changes) {
        var _this = this;
        if (typeof this["onSocketEvent"] !== "function")
            _smallstack_coreCommon.Logger.error("Angular2BaseComponent", "Angular2 change detected but Component (" + this.getComponentName() + ") does not implement SocketEventAware!");
        else {
            _.each(changes, function (change, key) {
                _this["onSocketEvent"](key.replace("sockets_input_", ""), change.currentValue);
            });
        }
    };
    /**
     * Synchronizes data from the components data storage to the current controller if data is available.
     * Use {localKey} if the property on the controller should have a different name than the data key!
     */
    Angular2BaseComponentController.prototype.syncDataIfAvailable = function (dataKey, localKey) {
        var data = this.getData(dataKey);
        if (data !== undefined) {
            if (localKey)
                this[localKey] = data;
            else
                this[dataKey] = data;
        }
    };
    /**
     * Synchronizes data from the components data storage to the current controller.
     * Use {@param localKey} if the property on the controller should have a different name than the data key!
     */
    Angular2BaseComponentController.prototype.syncData = function (dataKey, localKey) {
        var data = this.getData(dataKey);
        if (localKey)
            this[localKey] = data;
        else
            this[dataKey] = data;
    };
    Angular2BaseComponentController.prototype.getComponent = function () {
        return _smallstack_coreCommon.IOC.get("componentsRegistry").getComponentByName(this.getComponentName());
    };
    Angular2BaseComponentController.prototype.getComponentName = function () {
        throw new Error("Please register components via Angular2Component.new(...).register() or overload the getComponentName method yourself!");
    };
    Angular2BaseComponentController.prototype.sendOutput = function (socketName, socketData) {
        var internalSocketName = "sockets_output_" + socketName;
        if (!this[internalSocketName] || typeof this[internalSocketName].emit !== "function")
            _smallstack_coreCommon.Logger.error("Angular2BaseComponent", "this[\"" + internalSocketName + "\"] is not an angular2 event emitter!");
        else
            this[internalSocketName].emit(socketData);
        _super.prototype.sendOutput.call(this, internalSocketName, socketData);
    };
    return Angular2BaseComponentController;
}(_smallstack_coreClient.BaseComponentController));
__decorate$5([
    _angular_core.Input(),
    __metadata$5("design:type", Object)
], Angular2BaseComponentController.prototype, "data", void 0);
__decorate$5([
    _angular_core.Input(),
    __metadata$5("design:type", String)
], Angular2BaseComponentController.prototype, "componentId", void 0);
__decorate$5([
    _smallstack_coreCommon.Autowired("angular2Injector"),
    __metadata$5("design:type", _angular_core.Injector)
], Angular2BaseComponentController.prototype, "injector", void 0);
__decorate$5([
    _smallstack_coreCommon.Autowired(),
    __metadata$5("design:type", _angular_core.NgZone)
], Angular2BaseComponentController.prototype, "ngZone", void 0);
__decorate$5([
    _smallstack_coreCommon.Autowired(),
    __metadata$5("design:type", Object)
], Angular2BaseComponentController.prototype, "dataBridge", void 0);

var Angular2ErrorHandler = (function () {
    function Angular2ErrorHandler() {
    }
    Angular2ErrorHandler.prototype.handleError = function (error$$1) {
        _smallstack_coreCommon.Logger.error("UNCAUGHT ERROR", error$$1);
        _smallstack_coreCommon.NotificationService.instance().popup.error("Uncaught Error", "An unexpected error occured, please reload the page!" + error$$1);
        return true;
    };
    return Angular2ErrorHandler;
}());

var __decorate$6 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$6 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
function Angular2RootModule$$1(bootstrapComponent, additionalComponents) {
    // NG2 Bootstrap Alpha 6 hack
    window.__theme = 'bs4';
    var angular2Components = _smallstack_coreCommon.IOC.get("componentsRegistry").getComponentsByType(_smallstack_coreClient.ComponentType.ANGULAR2);
    var declarations = [];
    _.each(angular2Components, function (c) {
        _smallstack_coreCommon.Logger.debug("ComponentsModule", "adding : " + c.componentName, c);
        declarations.push(c.component);
    });
    declarations = [
        exports.TranslatePipe,
        exports.CapitalizePipe,
        exports.I18nPipe,
        PageNotFoundComponent
    ].concat(declarations).concat(additionalComponents);
    var angular2Router = _smallstack_coreCommon.IOC.get("angular2Router");
    var BaseAppModule = (function () {
        function BaseAppModule() {
        }
        return BaseAppModule;
    }());
    BaseAppModule = __decorate$6([
        _angular_core.NgModule({
            imports: [
                _angular_platformBrowser.BrowserModule,
                _angular_common.CommonModule,
                _angular_router.RouterModule,
                _angular_forms.ReactiveFormsModule,
                _angular_forms.FormsModule,
                ng2Bootstrap.Ng2BootstrapModule,
                ng2FileUpload.FileUploadModule,
                ng2Bootstrap.DatepickerModule.forRoot(),
                ng2Bootstrap.DropdownModule.forRoot(),
                ng2Bootstrap.TabsModule.forRoot(),
                ng2Bootstrap.ModalModule.forRoot(),
                ng2Charts_ng2Charts.ChartsModule,
                angular2Wizard.FormWizardModule,
                angular2Router.getRouterModule(),
                _angular_router.RouterModule.forRoot([{ path: '**', component: PageNotFoundComponent }])
            ],
            declarations: [
                bootstrapComponent, PageNotFoundComponent
            ].concat(declarations),
            entryComponents: [
                bootstrapComponent
            ],
            bootstrap: [
                bootstrapComponent
            ],
            providers: [
                exports.UserAuthenticatedGuard, { provide: _angular_core.ErrorHandler, useClass: Angular2ErrorHandler }
            ]
        }),
        __metadata$6("design:paramtypes", [])
    ], BaseAppModule);
    return BaseAppModule;
}
function bootstrapAngular$$1(rootComponent, additionalComponents, callback) {
    _smallstack_coreCommon.IOC.register("angular2Router", new Angular2Router());
    _angular_platformBrowserDynamic.platformBrowserDynamic().bootstrapModule(Angular2RootModule$$1(rootComponent, additionalComponents)).then(function (appRef) {
        _smallstack_coreCommon.IOC.register("angular2Injector", appRef.injector);
        _smallstack_coreCommon.IOC.register("ngZone", appRef.injector.get(_angular_core.NgZone));
        callback();
    });
}

var __decorate$7 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$7 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
* Allows the aside to be toggled via click.
*/
exports.AsideToggleDirective = (function () {
    function AsideToggleDirective() {
    }
    AsideToggleDirective.prototype.toggleOpen = function ($event) {
        $event.preventDefault();
        document.querySelector('body').classList.toggle('aside-menu-hidden');
    };
    return AsideToggleDirective;
}());
__decorate$7([
    _angular_core.HostListener('click', ['$event']),
    __metadata$7("design:type", Function),
    __metadata$7("design:paramtypes", [Object]),
    __metadata$7("design:returntype", void 0)
], exports.AsideToggleDirective.prototype, "toggleOpen", null);
exports.AsideToggleDirective = __decorate$7([
    _angular_core.Directive({
        selector: '.aside-menu-toggler',
    }),
    __metadata$7("design:paramtypes", [])
], exports.AsideToggleDirective);

var __decorate$8 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$8 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
// import 'rxjs/add/operator/filter';
exports.BreadcrumbsComponent = (function () {
    function BreadcrumbsComponent(router, route) {
        this.router = router;
        this.route = route;
    }
    BreadcrumbsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.router.events.filter(function (event) { return event instanceof _angular_router.NavigationEnd; }).subscribe(function (event) {
            _this.breadcrumbs = [];
            var currentRoute = _this.route.root, url = '';
            do {
                var childrenRoutes = currentRoute.children;
                currentRoute = null;
                childrenRoutes.forEach(function (route) {
                    if (route.outlet === 'primary') {
                        var routeSnapshot = route.snapshot;
                        url += '/' + routeSnapshot.url.map(function (segment) { return segment.path; }).join('/');
                        _this.breadcrumbs.push({
                            label: route.snapshot.data["label"],
                            url: url
                        });
                        currentRoute = route;
                    }
                });
            } while (currentRoute);
        });
    };
    return BreadcrumbsComponent;
}());
exports.BreadcrumbsComponent = __decorate$8([
    _angular_core.Component({
        selector: 'breadcrumbs',
        template: "\n    <template ngFor let-breadcrumb [ngForOf]=\"breadcrumbs\" let-last = last>\n        <li class=\"breadcrumb-item\" *ngIf=\"breadcrumb.label && breadcrumb.url\" [ngClass]=\"{active: last}\">\n            <a *ngIf=\"!last\" [routerLink]=\"breadcrumb.url\">{{breadcrumb.label | translate}}</a>\n            <span *ngIf=\"last\" [routerLink]=\"breadcrumb.url\">{{breadcrumb.label | translate}}</span>\n        </li>\n    </template>"
    }),
    __metadata$8("design:paramtypes", [_angular_router.Router, _angular_router.ActivatedRoute])
], exports.BreadcrumbsComponent);
Angular2Component.new("breadcrumbs", exports.BreadcrumbsComponent)
    .setInitializeAngularComponent(false)
    .register();

var __decorate$9 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$9 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
exports.NavDropdownDirective = (function () {
    function NavDropdownDirective() {
        this._open = false;
    }
    /**
    * Checks if the dropdown menu is open or not.
    */
    NavDropdownDirective.prototype.isOpen = function () { return this._open; };
    /**
    * Opens the dropdown menu.
    */
    NavDropdownDirective.prototype.open = function () {
        this._open = true;
    };
    /**
    * Closes the dropdown menu .
    */
    NavDropdownDirective.prototype.close = function () {
        this._open = false;
    };
    /**
    * Toggles the dropdown menu.
    */
    NavDropdownDirective.prototype.toggle = function () {
        if (this.isOpen()) {
            this.close();
        }
        else {
            this.open();
        }
    };
    return NavDropdownDirective;
}());
exports.NavDropdownDirective = __decorate$9([
    _angular_core.Directive({
        selector: '.nav-dropdown',
        host: {
            '[class.open]': '_open',
        }
    }),
    __metadata$9("design:paramtypes", [])
], exports.NavDropdownDirective);
/**
* Allows the dropdown to be toggled via click.
*/
exports.NavDropdownToggleDirective = (function () {
    function NavDropdownToggleDirective(dropdown) {
        this.dropdown = dropdown;
    }
    NavDropdownToggleDirective.prototype.toggleOpen = function ($event) {
        $event.preventDefault();
        this.dropdown.toggle();
    };
    return NavDropdownToggleDirective;
}());
__decorate$9([
    _angular_core.HostListener('click', ['$event']),
    __metadata$9("design:type", Function),
    __metadata$9("design:paramtypes", [Object]),
    __metadata$9("design:returntype", void 0)
], exports.NavDropdownToggleDirective.prototype, "toggleOpen", null);
exports.NavDropdownToggleDirective = __decorate$9([
    _angular_core.Directive({
        selector: '.nav-dropdown-toggle',
    }),
    __metadata$9("design:paramtypes", [exports.NavDropdownDirective])
], exports.NavDropdownToggleDirective);
var NAV_DROPDOWN_DIRECTIVES = [exports.NavDropdownDirective, exports.NavDropdownToggleDirective];
// export const NGB_DROPDOWN_DIRECTIVES = [NgbDropdownToggle, NgbDropdown];

var __decorate$10 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$10 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
* Allows the sidebar to be toggled via click.
*/
exports.SidebarToggleDirective = (function () {
    function SidebarToggleDirective() {
    }
    SidebarToggleDirective.prototype.toggleOpen = function ($event) {
        $event.preventDefault();
        document.querySelector('body').classList.toggle('sidebar-hidden');
    };
    return SidebarToggleDirective;
}());
__decorate$10([
    _angular_core.HostListener('click', ['$event']),
    __metadata$10("design:type", Function),
    __metadata$10("design:paramtypes", [Object]),
    __metadata$10("design:returntype", void 0)
], exports.SidebarToggleDirective.prototype, "toggleOpen", null);
exports.SidebarToggleDirective = __decorate$10([
    _angular_core.Directive({
        selector: '.sidebar-toggler',
    }),
    __metadata$10("design:paramtypes", [])
], exports.SidebarToggleDirective);
exports.MobileSidebarToggleDirective = (function () {
    function MobileSidebarToggleDirective() {
    }
    //Check if element has class
    MobileSidebarToggleDirective.prototype.hasClass = function (target, elementClassName) {
        return new RegExp('(\\s|^)' + elementClassName + '(\\s|$)').test(target.className);
    };
    MobileSidebarToggleDirective.prototype.toggleOpen = function ($event) {
        $event.preventDefault();
        document.querySelector('body').classList.toggle('sidebar-mobile-show');
    };
    return MobileSidebarToggleDirective;
}());
__decorate$10([
    _angular_core.HostListener('click', ['$event']),
    __metadata$10("design:type", Function),
    __metadata$10("design:paramtypes", [Object]),
    __metadata$10("design:returntype", void 0)
], exports.MobileSidebarToggleDirective.prototype, "toggleOpen", null);
exports.MobileSidebarToggleDirective = __decorate$10([
    _angular_core.Directive({
        selector: '.mobile-sidebar-toggler',
    }),
    __metadata$10("design:paramtypes", [])
], exports.MobileSidebarToggleDirective);
/**
* Allows the off-canvas sidebar to be closed via click.
*/
exports.SidebarOffCanvasCloseDirective = (function () {
    function SidebarOffCanvasCloseDirective() {
    }
    //Check if element has class
    SidebarOffCanvasCloseDirective.prototype.hasClass = function (target, elementClassName) {
        return new RegExp('(\\s|^)' + elementClassName + '(\\s|$)').test(target.className);
    };
    //Toggle element class
    SidebarOffCanvasCloseDirective.prototype.toggleClass = function (elem, elementClassName) {
        var newClass = ' ' + elem.className.replace(/[\t\r\n]/g, ' ') + ' ';
        if (this.hasClass(elem, elementClassName)) {
            while (newClass.indexOf(' ' + elementClassName + ' ') >= 0) {
                newClass = newClass.replace(' ' + elementClassName + ' ', ' ');
            }
            elem.className = newClass.replace(/^\s+|\s+$/g, '');
        }
        else {
            elem.className += ' ' + elementClassName;
        }
    };
    SidebarOffCanvasCloseDirective.prototype.toggleOpen = function ($event) {
        $event.preventDefault();
        if (this.hasClass(document.querySelector('body'), 'sidebar-off-canvas')) {
            this.toggleClass(document.querySelector('body'), 'sidebar-opened');
        }
    };
    return SidebarOffCanvasCloseDirective;
}());
__decorate$10([
    _angular_core.HostListener('click', ['$event']),
    __metadata$10("design:type", Function),
    __metadata$10("design:paramtypes", [Object]),
    __metadata$10("design:returntype", void 0)
], exports.SidebarOffCanvasCloseDirective.prototype, "toggleOpen", null);
exports.SidebarOffCanvasCloseDirective = __decorate$10([
    _angular_core.Directive({
        selector: '.sidebar-close',
    }),
    __metadata$10("design:paramtypes", [])
], exports.SidebarOffCanvasCloseDirective);
var SIDEBAR_TOGGLE_DIRECTIVES = [exports.SidebarToggleDirective, exports.SidebarOffCanvasCloseDirective, exports.MobileSidebarToggleDirective];

var __decorate$11 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$11 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
* Smart body resize
*/
exports.SmartResizeDirective = (function () {
    function SmartResizeDirective() {
        var _this = this;
        this.body = document.body;
        this.html = document.documentElement;
        if (this.hasClass(document.querySelector('body'), 'fixed-nav')) {
        }
        else {
            setTimeout(function () {
                _this.height = Math.max(_this.body.scrollHeight, _this.body.offsetHeight, _this.html.clientHeight, _this.html.scrollHeight, _this.html.offsetHeight);
                document.getElementsByTagName('body')[0].style.minHeight = _this.height + "px";
            }, 100);
        }
    }
    //Check if element has class
    SmartResizeDirective.prototype.hasClass = function (target, elementClassName) {
        return new RegExp('(\\s|^)' + elementClassName + '(\\s|$)').test(target.className);
    };
    SmartResizeDirective.prototype.onResize = function (event) {
        if (this.hasClass(document.querySelector('body'), 'fixed-nav')) {
        }
        else {
            this.height = Math.max(this.body.scrollHeight, this.body.offsetHeight, this.html.clientHeight, this.html.scrollHeight, this.html.offsetHeight);
            document.getElementsByTagName('body')[0].style.minHeight = this.height + "px";
        }
    };
    return SmartResizeDirective;
}());
__decorate$11([
    _angular_core.HostListener('window:resize', ['$event']),
    __metadata$11("design:type", Function),
    __metadata$11("design:paramtypes", [Object]),
    __metadata$11("design:returntype", void 0)
], exports.SmartResizeDirective.prototype, "onResize", null);
exports.SmartResizeDirective = __decorate$11([
    _angular_core.Directive({
        selector: 'main',
    }),
    __metadata$11("design:paramtypes", [])
], exports.SmartResizeDirective);

var template = "<div class=\"backoffice-flex\"><header class=\"app-header navbar\"><button class=\"navbar-toggler mobile-sidebar-toggler hidden-lg-up\" type=\"button\">&#9776;</button> <a class=\"navbar-brand\" [routerLink]=\"['/manage']\"></a><ul class=\"nav navbar-nav hidden-md-down\"><li class=\"nav-item\"><a class=\"nav-link navbar-toggler sidebar-toggler\" href=\"#\">&#9776;</a></li></ul></header><div class=\"app-body\"><div class=\"sidebar\"><div class=\"sidebar-header\" *ngIf=\"currentUser\"><img src=\"{{currentUser.getAvatarUrl()}}\" class=\"img-avatar\" alt=\"Avatar\"><div><strong>{{currentUser.getDisplayName()}}</strong></div><div class=\"text-muted\"><small>{{currentUser.getTitle()}}</small></div><div class=\"text-muted\"><a (click)=\"logout()\">Logout</a></div></div><nav class=\"sidebar-nav\"><ul class=\"nav\"><li class=\"nav-title\">Main Navigation</li><template ngFor let-entry [ngForOf]=\"navigationEntries\"><li class=\"nav-item\" routerLinkActive=\"open\" [ngClass]=\"{'nav-dropdown': entry.hasSubEntries()}\"><a class=\"nav-link\" [routerLink]=\"[entry.getRoute()]\" [ngClass]=\"{'nav-dropdown-toggle': entry.hasSubEntries()}\"><i class=\"{{entry.getIcon()}}\"></i> <span *ngIf=\"entry.getI18nLabel()\">{{entry.getI18nLabel() | translate}}</span> <span *ngIf=\"entry.getLabel()\">{{entry.getLabel()}}</span></a><ul class=\"nav-dropdown-items\" *ngIf=\"entry.hasSubEntries()\"><template ngFor let-subEntry [ngForOf]=\"getSubEntries(entry)\"><li class=\"nav-item\"><a class=\"nav-link\" routerLinkActive=\"active\" [routerLink]=\"[entry.getRoute(), subEntry.getRoute()]\"><i class=\"{{subEntry.getIcon()}}\"></i> <span *ngIf=\"subEntry.getI18nLabel()\">{{subEntry.getI18nLabel() | translate}}</span> <span *ngIf=\"subEntry.getLabel()\">{{subEntry.getLabel()}}</span></a></li></template></ul></li></template><li class=\"divider\"></li></ul></nav></div><main class=\"main\"><ol class=\"breadcrumb\"><breadcrumbs></breadcrumbs></ol><div class=\"container-fluid\"><router-outlet></router-outlet></div></main></div></div>";

var style = "@charset \"UTF-8\";\n/**\n * GenesisUI - Bootstrap 4 Admin Template\n * @version v1.6.1\n * @link https://genesisui.com\n * Copyright (c) 2017 creativeLabs Łukasz Holeczek\n * @license Commercial\n */\n/*! normalize.css v5.0.0 | MIT License | github.com/necolas/normalize.css */\nhtml {\n  font-family: sans-serif;\n  line-height: 1.15;\n  -ms-text-size-adjust: 100%;\n  -webkit-text-size-adjust: 100%; }\n\nbody {\n  margin: 0; }\n\narticle,\naside,\nfooter,\nheader,\nnav,\nsection {\n  display: block; }\n\nh1 {\n  font-size: 2em;\n  margin: 0.67em 0; }\n\nfigcaption,\nfigure,\nmain {\n  display: block; }\n\nfigure {\n  margin: 1em 40px; }\n\nhr {\n  box-sizing: content-box;\n  height: 0;\n  overflow: visible; }\n\npre {\n  font-family: monospace, monospace;\n  font-size: 1em; }\n\na {\n  background-color: transparent;\n  -webkit-text-decoration-skip: objects; }\n\na:active,\na:hover {\n  outline-width: 0; }\n\nabbr[title] {\n  border-bottom: none;\n  text-decoration: underline;\n  text-decoration: underline dotted; }\n\nb,\nstrong {\n  font-weight: inherit; }\n\nb,\nstrong {\n  font-weight: bolder; }\n\ncode,\nkbd,\nsamp {\n  font-family: monospace, monospace;\n  font-size: 1em; }\n\ndfn {\n  font-style: italic; }\n\nmark {\n  background-color: #ff0;\n  color: #000; }\n\nsmall {\n  font-size: 80%; }\n\nsub,\nsup {\n  font-size: 75%;\n  line-height: 0;\n  position: relative;\n  vertical-align: baseline; }\n\nsub {\n  bottom: -0.25em; }\n\nsup {\n  top: -0.5em; }\n\naudio,\nvideo {\n  display: inline-block; }\n\naudio:not([controls]) {\n  display: none;\n  height: 0; }\n\nimg {\n  border-style: none; }\n\nsvg:not(:root) {\n  overflow: hidden; }\n\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n  font-family: sans-serif;\n  font-size: 100%;\n  line-height: 1.15;\n  margin: 0; }\n\nbutton,\ninput {\n  overflow: visible; }\n\nbutton,\nselect {\n  text-transform: none; }\n\nbutton,\nhtml [type=\"button\"],\n[type=\"reset\"],\n[type=\"submit\"] {\n  -webkit-appearance: button; }\n\nbutton::-moz-focus-inner,\n[type=\"button\"]::-moz-focus-inner,\n[type=\"reset\"]::-moz-focus-inner,\n[type=\"submit\"]::-moz-focus-inner {\n  border-style: none;\n  padding: 0; }\n\nbutton:-moz-focusring,\n[type=\"button\"]:-moz-focusring,\n[type=\"reset\"]:-moz-focusring,\n[type=\"submit\"]:-moz-focusring {\n  outline: 1px dotted ButtonText; }\n\nfieldset {\n  border: 1px solid #c0c0c0;\n  margin: 0 2px;\n  padding: 0.35em 0.625em 0.75em; }\n\nlegend {\n  box-sizing: border-box;\n  color: inherit;\n  display: table;\n  max-width: 100%;\n  padding: 0;\n  white-space: normal; }\n\nprogress {\n  display: inline-block;\n  vertical-align: baseline; }\n\ntextarea {\n  overflow: auto; }\n\n[type=\"checkbox\"],\n[type=\"radio\"] {\n  box-sizing: border-box;\n  padding: 0; }\n\n[type=\"number\"]::-webkit-inner-spin-button,\n[type=\"number\"]::-webkit-outer-spin-button {\n  height: auto; }\n\n[type=\"search\"] {\n  -webkit-appearance: textfield;\n  outline-offset: -2px; }\n\n[type=\"search\"]::-webkit-search-cancel-button,\n[type=\"search\"]::-webkit-search-decoration {\n  -webkit-appearance: none; }\n\n::-webkit-file-upload-button {\n  -webkit-appearance: button;\n  font: inherit; }\n\ndetails,\nmenu {\n  display: block; }\n\nsummary {\n  display: list-item; }\n\ncanvas {\n  display: inline-block; }\n\ntemplate {\n  display: none; }\n\n[hidden] {\n  display: none; }\n\n@media print {\n  *,\n  *::before,\n  *::after,\n  p::first-letter,\n  div::first-letter,\n  blockquote::first-letter,\n  li::first-letter,\n  p::first-line,\n  div::first-line,\n  blockquote::first-line,\n  li::first-line {\n    text-shadow: none !important;\n    box-shadow: none !important; }\n  a,\n  a:visited {\n    text-decoration: underline; }\n  abbr[title]::after {\n    content: \" (\" attr(title) \")\"; }\n  pre {\n    white-space: pre-wrap !important; }\n  pre,\n  blockquote {\n    border: 1px solid #999;\n    page-break-inside: avoid; }\n  thead {\n    display: table-header-group; }\n  tr,\n  img {\n    page-break-inside: avoid; }\n  p,\n  h2,\n  h3 {\n    orphans: 3;\n    widows: 3; }\n  h2,\n  h3 {\n    page-break-after: avoid; }\n  .navbar {\n    display: none; }\n  .badge {\n    border: 1px solid #000; }\n  .table {\n    border-collapse: collapse !important; }\n    .table td,\n    .table th {\n      background-color: #fff !important; }\n  .table-bordered th,\n  .table-bordered td {\n    border: 1px solid #ddd !important; } }\n\nhtml {\n  box-sizing: border-box; }\n\n*,\n*::before,\n*::after {\n  box-sizing: inherit; }\n\n@-ms-viewport {\n  width: device-width; }\n\nhtml {\n  -ms-overflow-style: scrollbar;\n  -webkit-tap-highlight-color: transparent; }\n\nbody {\n  font-family: -apple-system, system-ui, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif;\n  font-size: 0.875rem;\n  font-weight: normal;\n  line-height: 1.5;\n  color: #2a2c36;\n  background-color: #e4e5e6; }\n\n[tabindex=\"-1\"]:focus {\n  outline: none !important; }\n\nh1, h2, h3, h4, h5, h6 {\n  margin-top: 0;\n  margin-bottom: .5rem; }\n\np {\n  margin-top: 0;\n  margin-bottom: 1rem; }\n\nabbr[title],\nabbr[data-original-title] {\n  cursor: help; }\n\naddress {\n  margin-bottom: 1rem;\n  font-style: normal;\n  line-height: inherit; }\n\nol,\nul,\ndl {\n  margin-top: 0;\n  margin-bottom: 1rem; }\n\nol ol,\nul ul,\nol ul,\nul ol {\n  margin-bottom: 0; }\n\ndt {\n  font-weight: bold; }\n\ndd {\n  margin-bottom: .5rem;\n  margin-left: 0; }\n\nblockquote {\n  margin: 0 0 1rem; }\n\na {\n  color: #20a8d8;\n  text-decoration: none; }\n  a:focus, a:hover {\n    color: #167495;\n    text-decoration: underline; }\n\na:not([href]):not([tabindex]) {\n  color: inherit;\n  text-decoration: none; }\n  a:not([href]):not([tabindex]):focus, a:not([href]):not([tabindex]):hover {\n    color: inherit;\n    text-decoration: none; }\n  a:not([href]):not([tabindex]):focus {\n    outline: 0; }\n\npre {\n  margin-top: 0;\n  margin-bottom: 1rem;\n  overflow: auto; }\n\nfigure {\n  margin: 0 0 1rem; }\n\nimg {\n  vertical-align: middle; }\n\n[role=\"button\"] {\n  cursor: pointer; }\n\na,\narea,\nbutton,\n[role=\"button\"],\ninput,\nlabel,\nselect,\nsummary,\ntextarea {\n  touch-action: manipulation; }\n\ntable {\n  border-collapse: collapse;\n  background-color: transparent; }\n\ncaption {\n  padding-top: 0.75rem;\n  padding-bottom: 0.75rem;\n  color: #818a91;\n  text-align: left;\n  caption-side: bottom; }\n\nth {\n  text-align: left; }\n\nlabel {\n  display: inline-block;\n  margin-bottom: .5rem; }\n\nbutton:focus {\n  outline: 1px dotted;\n  outline: 5px auto -webkit-focus-ring-color; }\n\ninput,\nbutton,\nselect,\ntextarea {\n  line-height: inherit; }\n\ninput[type=\"radio\"]:disabled,\ninput[type=\"checkbox\"]:disabled {\n  cursor: not-allowed; }\n\ninput[type=\"date\"],\ninput[type=\"time\"],\ninput[type=\"datetime-local\"],\ninput[type=\"month\"] {\n  -webkit-appearance: listbox; }\n\ntextarea {\n  resize: vertical; }\n\nfieldset {\n  min-width: 0;\n  padding: 0;\n  margin: 0;\n  border: 0; }\n\nlegend {\n  display: block;\n  width: 100%;\n  padding: 0;\n  margin-bottom: .5rem;\n  font-size: 1.5rem;\n  line-height: inherit; }\n\ninput[type=\"search\"] {\n  -webkit-appearance: none; }\n\noutput {\n  display: inline-block; }\n\n[hidden] {\n  display: none !important; }\n\nh1, h2, h3, h4, h5, h6,\n.h1, .h2, .h3, .h4, .h5, .h6 {\n  margin-bottom: 0.5rem;\n  font-family: inherit;\n  font-weight: 500;\n  line-height: 1.1;\n  color: inherit; }\n\nh1, .h1 {\n  font-size: 2.5rem; }\n\nh2, .h2 {\n  font-size: 2rem; }\n\nh3, .h3 {\n  font-size: 1.75rem; }\n\nh4, .h4 {\n  font-size: 1.5rem; }\n\nh5, .h5 {\n  font-size: 1.25rem; }\n\nh6, .h6 {\n  font-size: 1rem; }\n\n.lead {\n  font-size: 1.25rem;\n  font-weight: 300; }\n\n.display-1 {\n  font-size: 6rem;\n  font-weight: 300;\n  line-height: 1.1; }\n\n.display-2 {\n  font-size: 5.5rem;\n  font-weight: 300;\n  line-height: 1.1; }\n\n.display-3 {\n  font-size: 4.5rem;\n  font-weight: 300;\n  line-height: 1.1; }\n\n.display-4 {\n  font-size: 3.5rem;\n  font-weight: 300;\n  line-height: 1.1; }\n\nhr {\n  margin-top: 1rem;\n  margin-bottom: 1rem;\n  border: 0;\n  border-top: 1px solid rgba(0, 0, 0, 0.1); }\n\nsmall,\n.small {\n  font-size: 80%;\n  font-weight: normal; }\n\nmark,\n.mark {\n  padding: 0.2em;\n  background-color: #fcf8e3; }\n\n.list-unstyled {\n  padding-left: 0;\n  list-style: none; }\n\n.list-inline {\n  padding-left: 0;\n  list-style: none; }\n\n.list-inline-item {\n  display: inline-block; }\n  .list-inline-item:not(:last-child) {\n    margin-right: 5px; }\n\n.initialism {\n  font-size: 90%;\n  text-transform: uppercase; }\n\n.blockquote {\n  padding: 0.5rem 1rem;\n  margin-bottom: 1rem;\n  font-size: 1.09375rem;\n  border-left: 0.25rem solid #d1d4d7; }\n\n.blockquote-footer {\n  display: block;\n  font-size: 80%;\n  color: #818a91; }\n  .blockquote-footer::before {\n    content: \"\\2014 \\00A0\"; }\n\n.blockquote-reverse {\n  padding-right: 1rem;\n  padding-left: 0;\n  text-align: right;\n  border-right: 0.25rem solid #d1d4d7;\n  border-left: 0; }\n\n.blockquote-reverse .blockquote-footer::before {\n  content: \"\"; }\n\n.blockquote-reverse .blockquote-footer::after {\n  content: \"\\00A0 \\2014\"; }\n\n.img-fluid {\n  max-width: 100%;\n  height: auto; }\n\n.img-thumbnail {\n  padding: 0.25rem;\n  background-color: #e4e5e6;\n  border: 1px solid #ddd;\n  transition: all 0.2s ease-in-out;\n  max-width: 100%;\n  height: auto; }\n\n.figure {\n  display: inline-block; }\n\n.figure-img {\n  margin-bottom: 0.5rem;\n  line-height: 1; }\n\n.figure-caption {\n  font-size: 90%;\n  color: #818a91; }\n\ncode,\nkbd,\npre,\nsamp {\n  font-family: Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace; }\n\ncode {\n  padding: 0.2rem 0.4rem;\n  font-size: 90%;\n  color: #bd4147;\n  background-color: #f8f9fa; }\n  a > code {\n    padding: 0;\n    color: inherit;\n    background-color: inherit; }\n\nkbd {\n  padding: 0.2rem 0.4rem;\n  font-size: 90%;\n  color: #fff;\n  background-color: #2a2c36; }\n  kbd kbd {\n    padding: 0;\n    font-size: 100%;\n    font-weight: bold; }\n\npre {\n  display: block;\n  margin-top: 0;\n  margin-bottom: 1rem;\n  font-size: 90%;\n  color: #2a2c36; }\n  pre code {\n    padding: 0;\n    font-size: inherit;\n    color: inherit;\n    background-color: transparent;\n    border-radius: 0; }\n\n.pre-scrollable {\n  max-height: 340px;\n  overflow-y: scroll; }\n\n.container {\n  position: relative;\n  margin-left: auto;\n  margin-right: auto;\n  padding-right: 15px;\n  padding-left: 15px; }\n  @media (min-width: 576px) {\n    .container {\n      padding-right: 15px;\n      padding-left: 15px; } }\n  @media (min-width: 768px) {\n    .container {\n      padding-right: 15px;\n      padding-left: 15px; } }\n  @media (min-width: 992px) {\n    .container {\n      padding-right: 15px;\n      padding-left: 15px; } }\n  @media (min-width: 1200px) {\n    .container {\n      padding-right: 15px;\n      padding-left: 15px; } }\n  @media (min-width: 576px) {\n    .container {\n      width: 540px;\n      max-width: 100%; } }\n  @media (min-width: 768px) {\n    .container {\n      width: 720px;\n      max-width: 100%; } }\n  @media (min-width: 992px) {\n    .container {\n      width: 960px;\n      max-width: 100%; } }\n  @media (min-width: 1200px) {\n    .container {\n      width: 1140px;\n      max-width: 100%; } }\n\n.container-fluid {\n  position: relative;\n  margin-left: auto;\n  margin-right: auto;\n  padding-right: 15px;\n  padding-left: 15px; }\n  @media (min-width: 576px) {\n    .container-fluid {\n      padding-right: 15px;\n      padding-left: 15px; } }\n  @media (min-width: 768px) {\n    .container-fluid {\n      padding-right: 15px;\n      padding-left: 15px; } }\n  @media (min-width: 992px) {\n    .container-fluid {\n      padding-right: 15px;\n      padding-left: 15px; } }\n  @media (min-width: 1200px) {\n    .container-fluid {\n      padding-right: 15px;\n      padding-left: 15px; } }\n\n.row {\n  display: flex;\n  flex-wrap: wrap;\n  margin-right: -15px;\n  margin-left: -15px; }\n  @media (min-width: 576px) {\n    .row {\n      margin-right: -15px;\n      margin-left: -15px; } }\n  @media (min-width: 768px) {\n    .row {\n      margin-right: -15px;\n      margin-left: -15px; } }\n  @media (min-width: 992px) {\n    .row {\n      margin-right: -15px;\n      margin-left: -15px; } }\n  @media (min-width: 1200px) {\n    .row {\n      margin-right: -15px;\n      margin-left: -15px; } }\n\n.no-gutters {\n  margin-right: 0;\n  margin-left: 0; }\n  .no-gutters > .col,\n  .no-gutters > [class*=\"col-\"] {\n    padding-right: 0;\n    padding-left: 0; }\n\n.col-1, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-10, .col-11, .col-12, .col, .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm, .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12, .col-md, .col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg, .col-xl-1, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl {\n  position: relative;\n  width: 100%;\n  min-height: 1px;\n  padding-right: 15px;\n  padding-left: 15px; }\n  @media (min-width: 576px) {\n    .col-1, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-10, .col-11, .col-12, .col, .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm, .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12, .col-md, .col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg, .col-xl-1, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl {\n      padding-right: 15px;\n      padding-left: 15px; } }\n  @media (min-width: 768px) {\n    .col-1, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-10, .col-11, .col-12, .col, .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm, .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12, .col-md, .col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg, .col-xl-1, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl {\n      padding-right: 15px;\n      padding-left: 15px; } }\n  @media (min-width: 992px) {\n    .col-1, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-10, .col-11, .col-12, .col, .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm, .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12, .col-md, .col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg, .col-xl-1, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl {\n      padding-right: 15px;\n      padding-left: 15px; } }\n  @media (min-width: 1200px) {\n    .col-1, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-10, .col-11, .col-12, .col, .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm, .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12, .col-md, .col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg, .col-xl-1, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl {\n      padding-right: 15px;\n      padding-left: 15px; } }\n\n.col {\n  flex-basis: 0;\n  flex-grow: 1;\n  max-width: 100%; }\n\n.col-auto {\n  flex: 0 0 auto;\n  width: auto; }\n\n.col-1 {\n  flex: 0 0 8.33333%;\n  max-width: 8.33333%; }\n\n.col-2 {\n  flex: 0 0 16.66667%;\n  max-width: 16.66667%; }\n\n.col-3 {\n  flex: 0 0 25%;\n  max-width: 25%; }\n\n.col-4 {\n  flex: 0 0 33.33333%;\n  max-width: 33.33333%; }\n\n.col-5 {\n  flex: 0 0 41.66667%;\n  max-width: 41.66667%; }\n\n.col-6 {\n  flex: 0 0 50%;\n  max-width: 50%; }\n\n.col-7 {\n  flex: 0 0 58.33333%;\n  max-width: 58.33333%; }\n\n.col-8 {\n  flex: 0 0 66.66667%;\n  max-width: 66.66667%; }\n\n.col-9 {\n  flex: 0 0 75%;\n  max-width: 75%; }\n\n.col-10 {\n  flex: 0 0 83.33333%;\n  max-width: 83.33333%; }\n\n.col-11 {\n  flex: 0 0 91.66667%;\n  max-width: 91.66667%; }\n\n.col-12 {\n  flex: 0 0 100%;\n  max-width: 100%; }\n\n.pull-0 {\n  right: auto; }\n\n.pull-1 {\n  right: 8.33333%; }\n\n.pull-2 {\n  right: 16.66667%; }\n\n.pull-3 {\n  right: 25%; }\n\n.pull-4 {\n  right: 33.33333%; }\n\n.pull-5 {\n  right: 41.66667%; }\n\n.pull-6 {\n  right: 50%; }\n\n.pull-7 {\n  right: 58.33333%; }\n\n.pull-8 {\n  right: 66.66667%; }\n\n.pull-9 {\n  right: 75%; }\n\n.pull-10 {\n  right: 83.33333%; }\n\n.pull-11 {\n  right: 91.66667%; }\n\n.pull-12 {\n  right: 100%; }\n\n.push-0 {\n  left: auto; }\n\n.push-1 {\n  left: 8.33333%; }\n\n.push-2 {\n  left: 16.66667%; }\n\n.push-3 {\n  left: 25%; }\n\n.push-4 {\n  left: 33.33333%; }\n\n.push-5 {\n  left: 41.66667%; }\n\n.push-6 {\n  left: 50%; }\n\n.push-7 {\n  left: 58.33333%; }\n\n.push-8 {\n  left: 66.66667%; }\n\n.push-9 {\n  left: 75%; }\n\n.push-10 {\n  left: 83.33333%; }\n\n.push-11 {\n  left: 91.66667%; }\n\n.push-12 {\n  left: 100%; }\n\n.offset-1 {\n  margin-left: 8.33333%; }\n\n.offset-2 {\n  margin-left: 16.66667%; }\n\n.offset-3 {\n  margin-left: 25%; }\n\n.offset-4 {\n  margin-left: 33.33333%; }\n\n.offset-5 {\n  margin-left: 41.66667%; }\n\n.offset-6 {\n  margin-left: 50%; }\n\n.offset-7 {\n  margin-left: 58.33333%; }\n\n.offset-8 {\n  margin-left: 66.66667%; }\n\n.offset-9 {\n  margin-left: 75%; }\n\n.offset-10 {\n  margin-left: 83.33333%; }\n\n.offset-11 {\n  margin-left: 91.66667%; }\n\n@media (min-width: 576px) {\n  .col-sm {\n    flex-basis: 0;\n    flex-grow: 1;\n    max-width: 100%; }\n  .col-sm-auto {\n    flex: 0 0 auto;\n    width: auto; }\n  .col-sm-1 {\n    flex: 0 0 8.33333%;\n    max-width: 8.33333%; }\n  .col-sm-2 {\n    flex: 0 0 16.66667%;\n    max-width: 16.66667%; }\n  .col-sm-3 {\n    flex: 0 0 25%;\n    max-width: 25%; }\n  .col-sm-4 {\n    flex: 0 0 33.33333%;\n    max-width: 33.33333%; }\n  .col-sm-5 {\n    flex: 0 0 41.66667%;\n    max-width: 41.66667%; }\n  .col-sm-6 {\n    flex: 0 0 50%;\n    max-width: 50%; }\n  .col-sm-7 {\n    flex: 0 0 58.33333%;\n    max-width: 58.33333%; }\n  .col-sm-8 {\n    flex: 0 0 66.66667%;\n    max-width: 66.66667%; }\n  .col-sm-9 {\n    flex: 0 0 75%;\n    max-width: 75%; }\n  .col-sm-10 {\n    flex: 0 0 83.33333%;\n    max-width: 83.33333%; }\n  .col-sm-11 {\n    flex: 0 0 91.66667%;\n    max-width: 91.66667%; }\n  .col-sm-12 {\n    flex: 0 0 100%;\n    max-width: 100%; }\n  .pull-sm-0 {\n    right: auto; }\n  .pull-sm-1 {\n    right: 8.33333%; }\n  .pull-sm-2 {\n    right: 16.66667%; }\n  .pull-sm-3 {\n    right: 25%; }\n  .pull-sm-4 {\n    right: 33.33333%; }\n  .pull-sm-5 {\n    right: 41.66667%; }\n  .pull-sm-6 {\n    right: 50%; }\n  .pull-sm-7 {\n    right: 58.33333%; }\n  .pull-sm-8 {\n    right: 66.66667%; }\n  .pull-sm-9 {\n    right: 75%; }\n  .pull-sm-10 {\n    right: 83.33333%; }\n  .pull-sm-11 {\n    right: 91.66667%; }\n  .pull-sm-12 {\n    right: 100%; }\n  .push-sm-0 {\n    left: auto; }\n  .push-sm-1 {\n    left: 8.33333%; }\n  .push-sm-2 {\n    left: 16.66667%; }\n  .push-sm-3 {\n    left: 25%; }\n  .push-sm-4 {\n    left: 33.33333%; }\n  .push-sm-5 {\n    left: 41.66667%; }\n  .push-sm-6 {\n    left: 50%; }\n  .push-sm-7 {\n    left: 58.33333%; }\n  .push-sm-8 {\n    left: 66.66667%; }\n  .push-sm-9 {\n    left: 75%; }\n  .push-sm-10 {\n    left: 83.33333%; }\n  .push-sm-11 {\n    left: 91.66667%; }\n  .push-sm-12 {\n    left: 100%; }\n  .offset-sm-0 {\n    margin-left: 0%; }\n  .offset-sm-1 {\n    margin-left: 8.33333%; }\n  .offset-sm-2 {\n    margin-left: 16.66667%; }\n  .offset-sm-3 {\n    margin-left: 25%; }\n  .offset-sm-4 {\n    margin-left: 33.33333%; }\n  .offset-sm-5 {\n    margin-left: 41.66667%; }\n  .offset-sm-6 {\n    margin-left: 50%; }\n  .offset-sm-7 {\n    margin-left: 58.33333%; }\n  .offset-sm-8 {\n    margin-left: 66.66667%; }\n  .offset-sm-9 {\n    margin-left: 75%; }\n  .offset-sm-10 {\n    margin-left: 83.33333%; }\n  .offset-sm-11 {\n    margin-left: 91.66667%; } }\n\n@media (min-width: 768px) {\n  .col-md {\n    flex-basis: 0;\n    flex-grow: 1;\n    max-width: 100%; }\n  .col-md-auto {\n    flex: 0 0 auto;\n    width: auto; }\n  .col-md-1 {\n    flex: 0 0 8.33333%;\n    max-width: 8.33333%; }\n  .col-md-2 {\n    flex: 0 0 16.66667%;\n    max-width: 16.66667%; }\n  .col-md-3 {\n    flex: 0 0 25%;\n    max-width: 25%; }\n  .col-md-4 {\n    flex: 0 0 33.33333%;\n    max-width: 33.33333%; }\n  .col-md-5 {\n    flex: 0 0 41.66667%;\n    max-width: 41.66667%; }\n  .col-md-6 {\n    flex: 0 0 50%;\n    max-width: 50%; }\n  .col-md-7 {\n    flex: 0 0 58.33333%;\n    max-width: 58.33333%; }\n  .col-md-8 {\n    flex: 0 0 66.66667%;\n    max-width: 66.66667%; }\n  .col-md-9 {\n    flex: 0 0 75%;\n    max-width: 75%; }\n  .col-md-10 {\n    flex: 0 0 83.33333%;\n    max-width: 83.33333%; }\n  .col-md-11 {\n    flex: 0 0 91.66667%;\n    max-width: 91.66667%; }\n  .col-md-12 {\n    flex: 0 0 100%;\n    max-width: 100%; }\n  .pull-md-0 {\n    right: auto; }\n  .pull-md-1 {\n    right: 8.33333%; }\n  .pull-md-2 {\n    right: 16.66667%; }\n  .pull-md-3 {\n    right: 25%; }\n  .pull-md-4 {\n    right: 33.33333%; }\n  .pull-md-5 {\n    right: 41.66667%; }\n  .pull-md-6 {\n    right: 50%; }\n  .pull-md-7 {\n    right: 58.33333%; }\n  .pull-md-8 {\n    right: 66.66667%; }\n  .pull-md-9 {\n    right: 75%; }\n  .pull-md-10 {\n    right: 83.33333%; }\n  .pull-md-11 {\n    right: 91.66667%; }\n  .pull-md-12 {\n    right: 100%; }\n  .push-md-0 {\n    left: auto; }\n  .push-md-1 {\n    left: 8.33333%; }\n  .push-md-2 {\n    left: 16.66667%; }\n  .push-md-3 {\n    left: 25%; }\n  .push-md-4 {\n    left: 33.33333%; }\n  .push-md-5 {\n    left: 41.66667%; }\n  .push-md-6 {\n    left: 50%; }\n  .push-md-7 {\n    left: 58.33333%; }\n  .push-md-8 {\n    left: 66.66667%; }\n  .push-md-9 {\n    left: 75%; }\n  .push-md-10 {\n    left: 83.33333%; }\n  .push-md-11 {\n    left: 91.66667%; }\n  .push-md-12 {\n    left: 100%; }\n  .offset-md-0 {\n    margin-left: 0%; }\n  .offset-md-1 {\n    margin-left: 8.33333%; }\n  .offset-md-2 {\n    margin-left: 16.66667%; }\n  .offset-md-3 {\n    margin-left: 25%; }\n  .offset-md-4 {\n    margin-left: 33.33333%; }\n  .offset-md-5 {\n    margin-left: 41.66667%; }\n  .offset-md-6 {\n    margin-left: 50%; }\n  .offset-md-7 {\n    margin-left: 58.33333%; }\n  .offset-md-8 {\n    margin-left: 66.66667%; }\n  .offset-md-9 {\n    margin-left: 75%; }\n  .offset-md-10 {\n    margin-left: 83.33333%; }\n  .offset-md-11 {\n    margin-left: 91.66667%; } }\n\n@media (min-width: 992px) {\n  .col-lg {\n    flex-basis: 0;\n    flex-grow: 1;\n    max-width: 100%; }\n  .col-lg-auto {\n    flex: 0 0 auto;\n    width: auto; }\n  .col-lg-1 {\n    flex: 0 0 8.33333%;\n    max-width: 8.33333%; }\n  .col-lg-2 {\n    flex: 0 0 16.66667%;\n    max-width: 16.66667%; }\n  .col-lg-3 {\n    flex: 0 0 25%;\n    max-width: 25%; }\n  .col-lg-4 {\n    flex: 0 0 33.33333%;\n    max-width: 33.33333%; }\n  .col-lg-5 {\n    flex: 0 0 41.66667%;\n    max-width: 41.66667%; }\n  .col-lg-6 {\n    flex: 0 0 50%;\n    max-width: 50%; }\n  .col-lg-7 {\n    flex: 0 0 58.33333%;\n    max-width: 58.33333%; }\n  .col-lg-8 {\n    flex: 0 0 66.66667%;\n    max-width: 66.66667%; }\n  .col-lg-9 {\n    flex: 0 0 75%;\n    max-width: 75%; }\n  .col-lg-10 {\n    flex: 0 0 83.33333%;\n    max-width: 83.33333%; }\n  .col-lg-11 {\n    flex: 0 0 91.66667%;\n    max-width: 91.66667%; }\n  .col-lg-12 {\n    flex: 0 0 100%;\n    max-width: 100%; }\n  .pull-lg-0 {\n    right: auto; }\n  .pull-lg-1 {\n    right: 8.33333%; }\n  .pull-lg-2 {\n    right: 16.66667%; }\n  .pull-lg-3 {\n    right: 25%; }\n  .pull-lg-4 {\n    right: 33.33333%; }\n  .pull-lg-5 {\n    right: 41.66667%; }\n  .pull-lg-6 {\n    right: 50%; }\n  .pull-lg-7 {\n    right: 58.33333%; }\n  .pull-lg-8 {\n    right: 66.66667%; }\n  .pull-lg-9 {\n    right: 75%; }\n  .pull-lg-10 {\n    right: 83.33333%; }\n  .pull-lg-11 {\n    right: 91.66667%; }\n  .pull-lg-12 {\n    right: 100%; }\n  .push-lg-0 {\n    left: auto; }\n  .push-lg-1 {\n    left: 8.33333%; }\n  .push-lg-2 {\n    left: 16.66667%; }\n  .push-lg-3 {\n    left: 25%; }\n  .push-lg-4 {\n    left: 33.33333%; }\n  .push-lg-5 {\n    left: 41.66667%; }\n  .push-lg-6 {\n    left: 50%; }\n  .push-lg-7 {\n    left: 58.33333%; }\n  .push-lg-8 {\n    left: 66.66667%; }\n  .push-lg-9 {\n    left: 75%; }\n  .push-lg-10 {\n    left: 83.33333%; }\n  .push-lg-11 {\n    left: 91.66667%; }\n  .push-lg-12 {\n    left: 100%; }\n  .offset-lg-0 {\n    margin-left: 0%; }\n  .offset-lg-1 {\n    margin-left: 8.33333%; }\n  .offset-lg-2 {\n    margin-left: 16.66667%; }\n  .offset-lg-3 {\n    margin-left: 25%; }\n  .offset-lg-4 {\n    margin-left: 33.33333%; }\n  .offset-lg-5 {\n    margin-left: 41.66667%; }\n  .offset-lg-6 {\n    margin-left: 50%; }\n  .offset-lg-7 {\n    margin-left: 58.33333%; }\n  .offset-lg-8 {\n    margin-left: 66.66667%; }\n  .offset-lg-9 {\n    margin-left: 75%; }\n  .offset-lg-10 {\n    margin-left: 83.33333%; }\n  .offset-lg-11 {\n    margin-left: 91.66667%; } }\n\n@media (min-width: 1200px) {\n  .col-xl {\n    flex-basis: 0;\n    flex-grow: 1;\n    max-width: 100%; }\n  .col-xl-auto {\n    flex: 0 0 auto;\n    width: auto; }\n  .col-xl-1 {\n    flex: 0 0 8.33333%;\n    max-width: 8.33333%; }\n  .col-xl-2 {\n    flex: 0 0 16.66667%;\n    max-width: 16.66667%; }\n  .col-xl-3 {\n    flex: 0 0 25%;\n    max-width: 25%; }\n  .col-xl-4 {\n    flex: 0 0 33.33333%;\n    max-width: 33.33333%; }\n  .col-xl-5 {\n    flex: 0 0 41.66667%;\n    max-width: 41.66667%; }\n  .col-xl-6 {\n    flex: 0 0 50%;\n    max-width: 50%; }\n  .col-xl-7 {\n    flex: 0 0 58.33333%;\n    max-width: 58.33333%; }\n  .col-xl-8 {\n    flex: 0 0 66.66667%;\n    max-width: 66.66667%; }\n  .col-xl-9 {\n    flex: 0 0 75%;\n    max-width: 75%; }\n  .col-xl-10 {\n    flex: 0 0 83.33333%;\n    max-width: 83.33333%; }\n  .col-xl-11 {\n    flex: 0 0 91.66667%;\n    max-width: 91.66667%; }\n  .col-xl-12 {\n    flex: 0 0 100%;\n    max-width: 100%; }\n  .pull-xl-0 {\n    right: auto; }\n  .pull-xl-1 {\n    right: 8.33333%; }\n  .pull-xl-2 {\n    right: 16.66667%; }\n  .pull-xl-3 {\n    right: 25%; }\n  .pull-xl-4 {\n    right: 33.33333%; }\n  .pull-xl-5 {\n    right: 41.66667%; }\n  .pull-xl-6 {\n    right: 50%; }\n  .pull-xl-7 {\n    right: 58.33333%; }\n  .pull-xl-8 {\n    right: 66.66667%; }\n  .pull-xl-9 {\n    right: 75%; }\n  .pull-xl-10 {\n    right: 83.33333%; }\n  .pull-xl-11 {\n    right: 91.66667%; }\n  .pull-xl-12 {\n    right: 100%; }\n  .push-xl-0 {\n    left: auto; }\n  .push-xl-1 {\n    left: 8.33333%; }\n  .push-xl-2 {\n    left: 16.66667%; }\n  .push-xl-3 {\n    left: 25%; }\n  .push-xl-4 {\n    left: 33.33333%; }\n  .push-xl-5 {\n    left: 41.66667%; }\n  .push-xl-6 {\n    left: 50%; }\n  .push-xl-7 {\n    left: 58.33333%; }\n  .push-xl-8 {\n    left: 66.66667%; }\n  .push-xl-9 {\n    left: 75%; }\n  .push-xl-10 {\n    left: 83.33333%; }\n  .push-xl-11 {\n    left: 91.66667%; }\n  .push-xl-12 {\n    left: 100%; }\n  .offset-xl-0 {\n    margin-left: 0%; }\n  .offset-xl-1 {\n    margin-left: 8.33333%; }\n  .offset-xl-2 {\n    margin-left: 16.66667%; }\n  .offset-xl-3 {\n    margin-left: 25%; }\n  .offset-xl-4 {\n    margin-left: 33.33333%; }\n  .offset-xl-5 {\n    margin-left: 41.66667%; }\n  .offset-xl-6 {\n    margin-left: 50%; }\n  .offset-xl-7 {\n    margin-left: 58.33333%; }\n  .offset-xl-8 {\n    margin-left: 66.66667%; }\n  .offset-xl-9 {\n    margin-left: 75%; }\n  .offset-xl-10 {\n    margin-left: 83.33333%; }\n  .offset-xl-11 {\n    margin-left: 91.66667%; } }\n\n.table {\n  width: 100%;\n  max-width: 100%;\n  margin-bottom: 1rem; }\n  .table th,\n  .table td {\n    padding: 0.75rem;\n    vertical-align: top;\n    border-top: 1px solid #d1d4d7; }\n  .table thead th {\n    vertical-align: bottom;\n    border-bottom: 2px solid #d1d4d7; }\n  .table tbody + tbody {\n    border-top: 2px solid #d1d4d7; }\n  .table .table {\n    background-color: #e4e5e6; }\n\n.table-sm th,\n.table-sm td {\n  padding: 0.3rem; }\n\n.table-bordered {\n  border: 1px solid #d1d4d7; }\n  .table-bordered th,\n  .table-bordered td {\n    border: 1px solid #d1d4d7; }\n  .table-bordered thead th,\n  .table-bordered thead td {\n    border-bottom-width: 2px; }\n\n.table-striped tbody tr:nth-of-type(odd) {\n  background-color: rgba(0, 0, 0, 0.05); }\n\n.table-hover tbody tr:hover {\n  background-color: rgba(0, 0, 0, 0.075); }\n\n.table-active,\n.table-active > th,\n.table-active > td {\n  background-color: rgba(0, 0, 0, 0.075); }\n\n.table-hover .table-active:hover {\n  background-color: rgba(0, 0, 0, 0.075); }\n  .table-hover .table-active:hover > td,\n  .table-hover .table-active:hover > th {\n    background-color: rgba(0, 0, 0, 0.075); }\n\n.table-success,\n.table-success > th,\n.table-success > td {\n  background-color: #dff0d8; }\n\n.table-hover .table-success:hover {\n  background-color: #d0e9c6; }\n  .table-hover .table-success:hover > td,\n  .table-hover .table-success:hover > th {\n    background-color: #d0e9c6; }\n\n.table-info,\n.table-info > th,\n.table-info > td {\n  background-color: #d9edf7; }\n\n.table-hover .table-info:hover {\n  background-color: #c4e3f3; }\n  .table-hover .table-info:hover > td,\n  .table-hover .table-info:hover > th {\n    background-color: #c4e3f3; }\n\n.table-warning,\n.table-warning > th,\n.table-warning > td {\n  background-color: #fcf8e3; }\n\n.table-hover .table-warning:hover {\n  background-color: #faf2cc; }\n  .table-hover .table-warning:hover > td,\n  .table-hover .table-warning:hover > th {\n    background-color: #faf2cc; }\n\n.table-danger,\n.table-danger > th,\n.table-danger > td {\n  background-color: #f2dede; }\n\n.table-hover .table-danger:hover {\n  background-color: #ebcccc; }\n  .table-hover .table-danger:hover > td,\n  .table-hover .table-danger:hover > th {\n    background-color: #ebcccc; }\n\n.thead-inverse th {\n  color: #e4e5e6;\n  background-color: #2a2c36; }\n\n.thead-default th {\n  color: #55595c;\n  background-color: #d1d4d7; }\n\n.table-inverse {\n  color: #e4e5e6;\n  background-color: #2a2c36; }\n  .table-inverse th,\n  .table-inverse td,\n  .table-inverse thead th {\n    border-color: #e4e5e6; }\n  .table-inverse.table-bordered {\n    border: 0; }\n\n.table-responsive {\n  display: block;\n  width: 100%;\n  overflow-x: auto;\n  -ms-overflow-style: -ms-autohiding-scrollbar; }\n  .table-responsive.table-bordered {\n    border: 0; }\n\n.table-outline {\n  border: 1px solid #d1d4d7; }\n  .table-outline td {\n    vertical-align: middle; }\n\n.table-align-middle td {\n  vertical-align: middle; }\n\n.table-clear td {\n  border: 0; }\n\n.form-control, .daterangepicker .input-mini, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control.direction-up {\n  display: block;\n  width: 100%;\n  padding: 0.5rem 0.75rem;\n  font-size: 0.875rem;\n  line-height: 1.25;\n  color: #55595c;\n  background-color: #fff;\n  background-image: none;\n  background-clip: padding-box;\n  border: 1px solid rgba(0, 0, 0, 0.15);\n  border-radius: 0;\n  transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s; }\n  .form-control::-ms-expand, .daterangepicker .input-mini::-ms-expand, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control::-ms-expand, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control.direction-up::-ms-expand {\n    background-color: transparent;\n    border: 0; }\n  .form-control:focus, .daterangepicker .input-mini:focus, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control:focus {\n    color: #55595c;\n    background-color: #fff;\n    border-color: #8ad4ee;\n    outline: none; }\n  .form-control::placeholder, .daterangepicker .input-mini::placeholder, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control::placeholder, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control.direction-up::placeholder {\n    color: #818a91;\n    opacity: 1; }\n  .form-control:disabled, .daterangepicker .input-mini:disabled, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control:disabled, .form-control[readonly], .daterangepicker [readonly].input-mini, .input-group > .ui-select-bootstrap > input[readonly].ui-select-search.form-control {\n    background-color: #d1d4d7;\n    opacity: 1; }\n  .form-control:disabled, .daterangepicker .input-mini:disabled, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control:disabled {\n    cursor: not-allowed; }\n\nselect.form-control:not([size]):not([multiple]), .daterangepicker select.input-mini:not([size]):not([multiple]) {\n  height: calc(2.09375rem + 2px); }\n\nselect.form-control:focus::-ms-value, .daterangepicker select.input-mini:focus::-ms-value {\n  color: #55595c;\n  background-color: #fff; }\n\n.form-control-file,\n.form-control-range {\n  display: block; }\n\n.col-form-label {\n  padding-top: calc(0.5rem - 1px * 2);\n  padding-bottom: calc(0.5rem - 1px * 2);\n  margin-bottom: 0; }\n\n.col-form-label-lg {\n  padding-top: calc(0.75rem - 1px * 2);\n  padding-bottom: calc(0.75rem - 1px * 2);\n  font-size: 1.25rem; }\n\n.col-form-label-sm {\n  padding-top: calc(0.25rem - 1px * 2);\n  padding-bottom: calc(0.25rem - 1px * 2);\n  font-size: 0.875rem; }\n\n.col-form-legend {\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n  margin-bottom: 0;\n  font-size: 0.875rem; }\n\n.form-control-static {\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n  margin-bottom: 0;\n  line-height: 1.25;\n  border: solid transparent;\n  border-width: 1px 0; }\n  .form-control-static.form-control-sm, .input-group-sm > .form-control-static.form-control, .daterangepicker .input-group-sm > .form-control-static.input-mini, .input-group > .ui-select-bootstrap.input-group-sm > input.form-control-static.ui-select-search.form-control,\n  .input-group-sm > .form-control-static.input-group-addon,\n  .input-group-sm > .input-group-btn > .form-control-static.btn, .fc\n  .input-group-sm > .input-group-btn > button.form-control-static, .form-control-static.form-control-lg, .input-group-lg > .form-control-static.form-control, .daterangepicker .input-group-lg > .form-control-static.input-mini, .input-group > .ui-select-bootstrap.input-group-lg > input.form-control-static.ui-select-search.form-control,\n  .input-group-lg > .form-control-static.input-group-addon,\n  .input-group-lg > .input-group-btn > .form-control-static.btn, .fc\n  .input-group-lg > .input-group-btn > button.form-control-static {\n    padding-right: 0;\n    padding-left: 0; }\n\n.form-control-sm, .input-group-sm > .form-control, .daterangepicker .input-group-sm > .input-mini, .input-group > .ui-select-bootstrap.input-group-sm > input.ui-select-search.form-control,\n.input-group-sm > .input-group-addon,\n.input-group-sm > .input-group-btn > .btn, .fc\n.input-group-sm > .input-group-btn > button {\n  padding: 0.25rem 0.5rem;\n  font-size: 0.875rem; }\n\nselect.form-control-sm:not([size]):not([multiple]), .input-group-sm > select.form-control:not([size]):not([multiple]), .daterangepicker .input-group-sm > select.input-mini:not([size]):not([multiple]),\n.input-group-sm > select.input-group-addon:not([size]):not([multiple]),\n.input-group-sm > .input-group-btn > select.btn:not([size]):not([multiple]) {\n  height: 1.8125rem; }\n\n.form-control-lg, .input-group-lg > .form-control, .daterangepicker .input-group-lg > .input-mini, .input-group > .ui-select-bootstrap.input-group-lg > input.ui-select-search.form-control,\n.input-group-lg > .input-group-addon,\n.input-group-lg > .input-group-btn > .btn, .fc\n.input-group-lg > .input-group-btn > button {\n  padding: 0.75rem 1.5rem;\n  font-size: 1.25rem; }\n\nselect.form-control-lg:not([size]):not([multiple]), .input-group-lg > select.form-control:not([size]):not([multiple]), .daterangepicker .input-group-lg > select.input-mini:not([size]):not([multiple]),\n.input-group-lg > select.input-group-addon:not([size]):not([multiple]),\n.input-group-lg > .input-group-btn > select.btn:not([size]):not([multiple]) {\n  height: 3.16667rem; }\n\n.form-group {\n  margin-bottom: 1rem; }\n\n.form-text {\n  display: block;\n  margin-top: 0.25rem; }\n\n.form-check {\n  position: relative;\n  display: block;\n  margin-bottom: 0.5rem; }\n  .form-check.disabled .form-check-label {\n    color: #818a91;\n    cursor: not-allowed; }\n\n.form-check-label {\n  padding-left: 1.25rem;\n  margin-bottom: 0;\n  cursor: pointer; }\n\n.form-check-input {\n  position: absolute;\n  margin-top: 0.25rem;\n  margin-left: -1.25rem; }\n  .form-check-input:only-child {\n    position: static; }\n\n.form-check-inline {\n  display: inline-block; }\n  .form-check-inline .form-check-label {\n    vertical-align: middle; }\n  .form-check-inline + .form-check-inline {\n    margin-left: 0.75rem; }\n\n.form-control-feedback {\n  margin-top: 0.25rem; }\n\n.form-control-success,\n.form-control-warning,\n.form-control-danger {\n  padding-right: 2.25rem;\n  background-repeat: no-repeat;\n  background-position: center right 0.52344rem;\n  background-size: 1.04688rem 1.04688rem; }\n\n.has-success .form-control-feedback,\n.has-success .form-control-label,\n.has-success .col-form-label,\n.has-success .form-check-label,\n.has-success .custom-control {\n  color: #4dbd74; }\n\n.has-success .form-control, .has-success .daterangepicker .input-mini, .daterangepicker .has-success .input-mini, .has-success .input-group > .ui-select-bootstrap > input.ui-select-search.form-control {\n  border-color: #4dbd74; }\n\n.has-success .input-group-addon {\n  color: #4dbd74;\n  border-color: #4dbd74;\n  background-color: #e2f4e8; }\n\n.has-success .form-control-success {\n  background-image: url(\"data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%234dbd74' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3E%3C/svg%3E\"); }\n\n.has-warning .form-control-feedback,\n.has-warning .form-control-label,\n.has-warning .col-form-label,\n.has-warning .form-check-label,\n.has-warning .custom-control {\n  color: #f8cb00; }\n\n.has-warning .form-control, .has-warning .daterangepicker .input-mini, .daterangepicker .has-warning .input-mini, .has-warning .input-group > .ui-select-bootstrap > input.ui-select-search.form-control {\n  border-color: #f8cb00; }\n\n.has-warning .input-group-addon {\n  color: #f8cb00;\n  border-color: #f8cb00;\n  background-color: #fff4c5; }\n\n.has-warning .form-control-warning {\n  background-image: url(\"data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23f8cb00' d='M4.4 5.324h-.8v-2.46h.8zm0 1.42h-.8V5.89h.8zM3.76.63L.04 7.075c-.115.2.016.425.26.426h7.397c.242 0 .372-.226.258-.426C6.726 4.924 5.47 2.79 4.253.63c-.113-.174-.39-.174-.494 0z'/%3E%3C/svg%3E\"); }\n\n.has-danger .form-control-feedback,\n.has-danger .form-control-label,\n.has-danger .col-form-label,\n.has-danger .form-check-label,\n.has-danger .custom-control {\n  color: #f86c6b; }\n\n.has-danger .form-control, .has-danger .daterangepicker .input-mini, .daterangepicker .has-danger .input-mini, .has-danger .input-group > .ui-select-bootstrap > input.ui-select-search.form-control {\n  border-color: #f86c6b; }\n\n.has-danger .input-group-addon {\n  color: #f86c6b;\n  border-color: #f86c6b;\n  background-color: white; }\n\n.has-danger .form-control-danger {\n  background-image: url(\"data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23f86c6b' viewBox='-2 -2 7 7'%3E%3Cpath stroke='%23d9534f' d='M0 0l3 3m0-3L0 3'/%3E%3Ccircle r='.5'/%3E%3Ccircle cx='3' r='.5'/%3E%3Ccircle cy='3' r='.5'/%3E%3Ccircle cx='3' cy='3' r='.5'/%3E%3C/svg%3E\"); }\n\n.form-inline {\n  display: flex;\n  flex-flow: row wrap;\n  align-items: center; }\n  .form-inline .form-check {\n    width: 100%; }\n  @media (min-width: 576px) {\n    .form-inline label {\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      margin-bottom: 0; }\n    .form-inline .form-group {\n      display: flex;\n      flex: 0 0 auto;\n      flex-flow: row wrap;\n      align-items: center;\n      margin-bottom: 0; }\n    .form-inline .form-control, .form-inline .daterangepicker .input-mini, .daterangepicker .form-inline .input-mini, .form-inline .input-group > .ui-select-bootstrap > input.ui-select-search.form-control {\n      display: inline-block;\n      width: auto;\n      vertical-align: middle; }\n    .form-inline .form-control-static {\n      display: inline-block; }\n    .form-inline .input-group {\n      width: auto; }\n    .form-inline .form-control-label {\n      margin-bottom: 0;\n      vertical-align: middle; }\n    .form-inline .form-check {\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      width: auto;\n      margin-top: 0;\n      margin-bottom: 0; }\n    .form-inline .form-check-label {\n      padding-left: 0; }\n    .form-inline .form-check-input {\n      position: relative;\n      margin-top: 0;\n      margin-right: 0.25rem;\n      margin-left: 0; }\n    .form-inline .custom-control {\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      padding-left: 0; }\n    .form-inline .custom-control-indicator {\n      position: static;\n      display: inline-block;\n      margin-right: 0.25rem;\n      vertical-align: text-bottom; }\n    .form-inline .has-feedback .form-control-feedback {\n      top: 0; } }\n\n.btn, .fc button {\n  display: inline-block;\n  font-weight: normal;\n  line-height: 1.25;\n  text-align: center;\n  white-space: nowrap;\n  vertical-align: middle;\n  user-select: none;\n  border: 1px solid transparent;\n  padding: 0.5rem 1rem;\n  font-size: 0.875rem;\n  transition: all 0.2s ease-in-out; }\n  .btn:focus, .fc button:focus, .btn:hover, .fc button:hover {\n    text-decoration: none; }\n  .btn:focus, .fc button:focus, .btn.focus, .fc button.focus {\n    outline: 0;\n    box-shadow: 0 0 0 2px rgba(32, 168, 216, 0.25); }\n  .btn.disabled, .fc button.disabled, .btn:disabled, .fc button:disabled {\n    cursor: not-allowed;\n    opacity: .65; }\n  .btn:active, .fc button:active, .btn.active, .fc button.active {\n    background-image: none; }\n\na.btn.disabled,\nfieldset[disabled] a.btn {\n  pointer-events: none; }\n\n.btn-primary, .fc-today-button {\n  color: #fff;\n  background-color: #20a8d8;\n  border-color: #20a8d8; }\n  .btn-primary:hover, .fc-today-button:hover {\n    color: #fff;\n    background-color: #1985ac;\n    border-color: #187fa3; }\n  .btn-primary:focus, .fc-today-button:focus, .btn-primary.focus, .focus.fc-today-button {\n    box-shadow: 0 0 0 2px rgba(32, 168, 216, 0.5); }\n  .btn-primary.disabled, .disabled.fc-today-button, .btn-primary:disabled, .fc-today-button:disabled {\n    background-color: #20a8d8;\n    border-color: #20a8d8; }\n  .btn-primary:active, .fc-today-button:active, .btn-primary.active, .active.fc-today-button,\n  .show > .btn-primary.dropdown-toggle,\n  .show > .dropdown-toggle.fc-today-button {\n    color: #fff;\n    background-color: #1985ac;\n    background-image: none;\n    border-color: #187fa3; }\n\n.btn-secondary, .fc button {\n  color: #2a2c36;\n  background-color: #fff;\n  border-color: #ccc; }\n  .btn-secondary:hover, .fc button:hover {\n    color: #2a2c36;\n    background-color: #e6e6e6;\n    border-color: #adadad; }\n  .btn-secondary:focus, .fc button:focus, .btn-secondary.focus, .fc button.focus {\n    box-shadow: 0 0 0 2px rgba(204, 204, 204, 0.5); }\n  .btn-secondary.disabled, .fc button.disabled, .btn-secondary:disabled, .fc button:disabled {\n    background-color: #fff;\n    border-color: #ccc; }\n  .btn-secondary:active, .fc button:active, .btn-secondary.active, .fc button.active,\n  .show > .btn-secondary.dropdown-toggle, .fc\n  .show > button.dropdown-toggle {\n    color: #2a2c36;\n    background-color: #e6e6e6;\n    background-image: none;\n    border-color: #adadad; }\n\n.btn-info {\n  color: #fff;\n  background-color: #63c2de;\n  border-color: #63c2de; }\n  .btn-info:hover {\n    color: #fff;\n    background-color: #39b2d5;\n    border-color: #30aed3; }\n  .btn-info:focus, .btn-info.focus {\n    box-shadow: 0 0 0 2px rgba(99, 194, 222, 0.5); }\n  .btn-info.disabled, .btn-info:disabled {\n    background-color: #63c2de;\n    border-color: #63c2de; }\n  .btn-info:active, .btn-info.active,\n  .show > .btn-info.dropdown-toggle {\n    color: #fff;\n    background-color: #39b2d5;\n    background-image: none;\n    border-color: #30aed3; }\n\n.btn-success {\n  color: #fff;\n  background-color: #4dbd74;\n  border-color: #4dbd74; }\n  .btn-success:hover {\n    color: #fff;\n    background-color: #3a9d5d;\n    border-color: #379558; }\n  .btn-success:focus, .btn-success.focus {\n    box-shadow: 0 0 0 2px rgba(77, 189, 116, 0.5); }\n  .btn-success.disabled, .btn-success:disabled {\n    background-color: #4dbd74;\n    border-color: #4dbd74; }\n  .btn-success:active, .btn-success.active,\n  .show > .btn-success.dropdown-toggle {\n    color: #fff;\n    background-color: #3a9d5d;\n    background-image: none;\n    border-color: #379558; }\n\n.btn-warning {\n  color: #fff;\n  background-color: #f8cb00;\n  border-color: #f8cb00; }\n  .btn-warning:hover {\n    color: #fff;\n    background-color: #c5a100;\n    border-color: #bb9900; }\n  .btn-warning:focus, .btn-warning.focus {\n    box-shadow: 0 0 0 2px rgba(248, 203, 0, 0.5); }\n  .btn-warning.disabled, .btn-warning:disabled {\n    background-color: #f8cb00;\n    border-color: #f8cb00; }\n  .btn-warning:active, .btn-warning.active,\n  .show > .btn-warning.dropdown-toggle {\n    color: #fff;\n    background-color: #c5a100;\n    background-image: none;\n    border-color: #bb9900; }\n\n.btn-danger {\n  color: #fff;\n  background-color: #f86c6b;\n  border-color: #f86c6b; }\n  .btn-danger:hover {\n    color: #fff;\n    background-color: #f63c3a;\n    border-color: #f53231; }\n  .btn-danger:focus, .btn-danger.focus {\n    box-shadow: 0 0 0 2px rgba(248, 108, 107, 0.5); }\n  .btn-danger.disabled, .btn-danger:disabled {\n    background-color: #f86c6b;\n    border-color: #f86c6b; }\n  .btn-danger:active, .btn-danger.active,\n  .show > .btn-danger.dropdown-toggle {\n    color: #fff;\n    background-color: #f63c3a;\n    background-image: none;\n    border-color: #f53231; }\n\n.btn-outline-primary {\n  color: #20a8d8;\n  background-image: none;\n  background-color: transparent;\n  border-color: #20a8d8; }\n  .btn-outline-primary:hover {\n    color: #fff;\n    background-color: #20a8d8;\n    border-color: #20a8d8; }\n  .btn-outline-primary:focus, .btn-outline-primary.focus {\n    box-shadow: 0 0 0 2px rgba(32, 168, 216, 0.5); }\n  .btn-outline-primary.disabled, .btn-outline-primary:disabled {\n    color: #20a8d8;\n    background-color: transparent; }\n  .btn-outline-primary:active, .btn-outline-primary.active,\n  .show > .btn-outline-primary.dropdown-toggle {\n    color: #fff;\n    background-color: #20a8d8;\n    border-color: #20a8d8; }\n\n.btn-outline-secondary {\n  color: #ccc;\n  background-image: none;\n  background-color: transparent;\n  border-color: #ccc; }\n  .btn-outline-secondary:hover {\n    color: #fff;\n    background-color: #ccc;\n    border-color: #ccc; }\n  .btn-outline-secondary:focus, .btn-outline-secondary.focus {\n    box-shadow: 0 0 0 2px rgba(204, 204, 204, 0.5); }\n  .btn-outline-secondary.disabled, .btn-outline-secondary:disabled {\n    color: #ccc;\n    background-color: transparent; }\n  .btn-outline-secondary:active, .btn-outline-secondary.active,\n  .show > .btn-outline-secondary.dropdown-toggle {\n    color: #fff;\n    background-color: #ccc;\n    border-color: #ccc; }\n\n.btn-outline-info {\n  color: #63c2de;\n  background-image: none;\n  background-color: transparent;\n  border-color: #63c2de; }\n  .btn-outline-info:hover {\n    color: #fff;\n    background-color: #63c2de;\n    border-color: #63c2de; }\n  .btn-outline-info:focus, .btn-outline-info.focus {\n    box-shadow: 0 0 0 2px rgba(99, 194, 222, 0.5); }\n  .btn-outline-info.disabled, .btn-outline-info:disabled {\n    color: #63c2de;\n    background-color: transparent; }\n  .btn-outline-info:active, .btn-outline-info.active,\n  .show > .btn-outline-info.dropdown-toggle {\n    color: #fff;\n    background-color: #63c2de;\n    border-color: #63c2de; }\n\n.btn-outline-success {\n  color: #4dbd74;\n  background-image: none;\n  background-color: transparent;\n  border-color: #4dbd74; }\n  .btn-outline-success:hover {\n    color: #fff;\n    background-color: #4dbd74;\n    border-color: #4dbd74; }\n  .btn-outline-success:focus, .btn-outline-success.focus {\n    box-shadow: 0 0 0 2px rgba(77, 189, 116, 0.5); }\n  .btn-outline-success.disabled, .btn-outline-success:disabled {\n    color: #4dbd74;\n    background-color: transparent; }\n  .btn-outline-success:active, .btn-outline-success.active,\n  .show > .btn-outline-success.dropdown-toggle {\n    color: #fff;\n    background-color: #4dbd74;\n    border-color: #4dbd74; }\n\n.btn-outline-warning {\n  color: #f8cb00;\n  background-image: none;\n  background-color: transparent;\n  border-color: #f8cb00; }\n  .btn-outline-warning:hover {\n    color: #fff;\n    background-color: #f8cb00;\n    border-color: #f8cb00; }\n  .btn-outline-warning:focus, .btn-outline-warning.focus {\n    box-shadow: 0 0 0 2px rgba(248, 203, 0, 0.5); }\n  .btn-outline-warning.disabled, .btn-outline-warning:disabled {\n    color: #f8cb00;\n    background-color: transparent; }\n  .btn-outline-warning:active, .btn-outline-warning.active,\n  .show > .btn-outline-warning.dropdown-toggle {\n    color: #fff;\n    background-color: #f8cb00;\n    border-color: #f8cb00; }\n\n.btn-outline-danger {\n  color: #f86c6b;\n  background-image: none;\n  background-color: transparent;\n  border-color: #f86c6b; }\n  .btn-outline-danger:hover {\n    color: #fff;\n    background-color: #f86c6b;\n    border-color: #f86c6b; }\n  .btn-outline-danger:focus, .btn-outline-danger.focus {\n    box-shadow: 0 0 0 2px rgba(248, 108, 107, 0.5); }\n  .btn-outline-danger.disabled, .btn-outline-danger:disabled {\n    color: #f86c6b;\n    background-color: transparent; }\n  .btn-outline-danger:active, .btn-outline-danger.active,\n  .show > .btn-outline-danger.dropdown-toggle {\n    color: #fff;\n    background-color: #f86c6b;\n    border-color: #f86c6b; }\n\n.btn-link {\n  font-weight: normal;\n  color: #20a8d8;\n  border-radius: 0; }\n  .btn-link, .btn-link:active, .btn-link.active, .btn-link:disabled {\n    background-color: transparent; }\n  .btn-link, .btn-link:focus, .btn-link:active {\n    border-color: transparent; }\n  .btn-link:hover {\n    border-color: transparent; }\n  .btn-link:focus, .btn-link:hover {\n    color: #167495;\n    text-decoration: underline;\n    background-color: transparent; }\n  .btn-link:disabled {\n    color: #818a91; }\n    .btn-link:disabled:focus, .btn-link:disabled:hover {\n      text-decoration: none; }\n\n.btn-lg, .btn-group-lg > .btn, .fc .btn-group-lg > button {\n  padding: 0.75rem 1.5rem;\n  font-size: 1.25rem; }\n\n.btn-sm, .btn-group-sm > .btn, .fc .btn-group-sm > button {\n  padding: 0.25rem 0.5rem;\n  font-size: 0.875rem; }\n\n.btn-block {\n  display: block;\n  width: 100%; }\n\n.btn-block + .btn-block {\n  margin-top: 0.5rem; }\n\ninput[type=\"submit\"].btn-block,\ninput[type=\"reset\"].btn-block,\ninput[type=\"button\"].btn-block {\n  width: 100%; }\n\n.btn .badge, .fc button .badge {\n  position: absolute;\n  top: 2px;\n  right: 6px;\n  font-size: 9px; }\n\n.fade {\n  opacity: 0;\n  transition: opacity 0.15s linear; }\n  .fade.show {\n    opacity: 1; }\n\n.collapse {\n  display: none; }\n  .collapse.show {\n    display: block; }\n\ntr.collapse.show {\n  display: table-row; }\n\ntbody.collapse.show {\n  display: table-row-group; }\n\n.collapsing {\n  position: relative;\n  height: 0;\n  overflow: hidden;\n  transition: height 0.35s ease; }\n\n.dropup,\n.dropdown {\n  position: relative; }\n\n.dropdown-toggle::after {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 0.3em;\n  vertical-align: middle;\n  content: \"\";\n  border-top: 0.3em solid;\n  border-right: 0.3em solid transparent;\n  border-left: 0.3em solid transparent; }\n\n.dropdown-toggle:focus {\n  outline: 0; }\n\n.dropup .dropdown-toggle::after {\n  border-top: 0;\n  border-bottom: 0.3em solid; }\n\n.dropdown-menu {\n  position: absolute;\n  top: 100%;\n  left: 0;\n  z-index: 1000;\n  display: none;\n  float: left;\n  min-width: 10rem;\n  padding: 0 0;\n  margin: 0.125rem 0 0;\n  font-size: 0.875rem;\n  color: #2a2c36;\n  text-align: left;\n  list-style: none;\n  background-color: #fff;\n  background-clip: padding-box;\n  border: 1px solid #d1d4d7; }\n\n.dropdown-divider {\n  height: 1px;\n  margin: 0.5rem 0;\n  overflow: hidden;\n  background-color: #f8f9fa; }\n\n.dropdown-item {\n  display: block;\n  width: 100%;\n  padding: 3px 1.5rem;\n  clear: both;\n  font-weight: normal;\n  color: #2a2c36;\n  text-align: inherit;\n  white-space: nowrap;\n  background: none;\n  border: 0; }\n  .dropdown-item:focus, .dropdown-item:hover {\n    color: #1f2028;\n    text-decoration: none;\n    background-color: #f8f9fa; }\n  .dropdown-item.active, .dropdown-item:active {\n    color: #fff;\n    text-decoration: none;\n    background-color: #20a8d8; }\n  .dropdown-item.disabled, .dropdown-item:disabled {\n    color: #818a91;\n    cursor: not-allowed;\n    background-color: transparent; }\n\n.show > .dropdown-menu {\n  display: block; }\n\n.show > a {\n  outline: 0; }\n\n.dropdown-menu-right {\n  right: 0;\n  left: auto; }\n\n.dropdown-menu-left {\n  right: auto;\n  left: 0; }\n\n.dropdown-header {\n  display: block;\n  padding: 0 1.5rem;\n  margin-bottom: 0;\n  font-size: 0.875rem;\n  color: #818a91;\n  white-space: nowrap; }\n\n.dropdown-backdrop {\n  position: fixed;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  z-index: 990; }\n\n.dropup .dropdown-menu {\n  top: auto;\n  bottom: 100%;\n  margin-bottom: 0.125rem; }\n\n.dropdown-item {\n  position: relative;\n  padding: 10px 20px;\n  border-bottom: 1px solid #d1d4d7; }\n  .dropdown-item:last-child {\n    border-bottom: 0; }\n  .dropdown-item i {\n    display: inline-block;\n    width: 20px;\n    margin-right: 10px;\n    margin-left: -10px;\n    color: #d1d4d7;\n    text-align: center; }\n  .dropdown-item .badge {\n    position: absolute;\n    right: 10px;\n    margin-top: 2px; }\n\n.dropdown-header {\n  padding: 8px 20px;\n  background: #f8f9fa;\n  border-bottom: 1px solid #d1d4d7; }\n  .dropdown-header .btn, .dropdown-header .fc button, .fc .dropdown-header button {\n    margin-top: -7px;\n    color: #818a91; }\n    .dropdown-header .btn:hover, .dropdown-header .fc button:hover, .fc .dropdown-header button:hover {\n      color: #2a2c36; }\n    .dropdown-header .btn.pull-right, .dropdown-header .fc button.pull-right, .fc .dropdown-header button.pull-right {\n      margin-right: -20px; }\n\n.dropdown-menu-lg {\n  width: 250px; }\n\n.btn-group, .fc-button-group,\n.btn-group-vertical {\n  position: relative;\n  display: inline-flex;\n  vertical-align: middle; }\n  .btn-group > .btn, .fc-button-group > .btn, .fc .btn-group > button, .fc .fc-button-group > button,\n  .btn-group-vertical > .btn, .fc\n  .btn-group-vertical > button {\n    position: relative;\n    flex: 0 1 auto; }\n    .btn-group > .btn:hover, .fc-button-group > .btn:hover, .fc .btn-group > button:hover, .fc .fc-button-group > button:hover,\n    .btn-group-vertical > .btn:hover, .fc\n    .btn-group-vertical > button:hover {\n      z-index: 2; }\n    .btn-group > .btn:focus, .fc-button-group > .btn:focus, .fc .btn-group > button:focus, .fc .fc-button-group > button:focus, .btn-group > .btn:active, .fc-button-group > .btn:active, .fc .btn-group > button:active, .fc .fc-button-group > button:active, .btn-group > .btn.active, .fc-button-group > .btn.active, .fc .btn-group > button.active, .fc .fc-button-group > button.active,\n    .btn-group-vertical > .btn:focus, .fc\n    .btn-group-vertical > button:focus,\n    .btn-group-vertical > .btn:active, .fc\n    .btn-group-vertical > button:active,\n    .btn-group-vertical > .btn.active, .fc\n    .btn-group-vertical > button.active {\n      z-index: 2; }\n  .btn-group .btn + .btn, .fc-button-group .btn + .btn, .btn-group .fc button + .btn, .fc .btn-group button + .btn, .fc-button-group .fc button + .btn, .fc .fc-button-group button + .btn, .btn-group .fc .btn + button, .fc .btn-group .btn + button, .fc-button-group .fc .btn + button, .fc .fc-button-group .btn + button, .btn-group .fc button + button, .fc .btn-group button + button, .fc-button-group .fc button + button, .fc .fc-button-group button + button,\n  .btn-group .btn + .btn-group, .fc-button-group .btn + .btn-group,\n  .btn-group .fc button + .btn-group, .fc\n  .btn-group button + .btn-group, .fc-button-group .fc button + .btn-group, .fc .fc-button-group button + .btn-group,\n  .btn-group .btn + .fc-button-group, .fc-button-group .btn + .fc-button-group,\n  .btn-group .fc button + .fc-button-group, .fc\n  .btn-group button + .fc-button-group, .fc-button-group .fc button + .fc-button-group, .fc .fc-button-group button + .fc-button-group,\n  .btn-group .btn-group + .btn, .fc-button-group .btn-group + .btn,\n  .btn-group .fc-button-group + .btn, .fc-button-group .fc-button-group + .btn,\n  .btn-group .fc .btn-group + button, .fc\n  .btn-group .btn-group + button, .fc-button-group .fc .btn-group + button, .fc .fc-button-group .btn-group + button,\n  .btn-group .fc .fc-button-group + button, .fc\n  .btn-group .fc-button-group + button, .fc-button-group .fc .fc-button-group + button, .fc .fc-button-group .fc-button-group + button,\n  .btn-group .btn-group + .btn-group, .fc-button-group .btn-group + .btn-group,\n  .btn-group .fc-button-group + .btn-group, .fc-button-group .fc-button-group + .btn-group,\n  .btn-group .btn-group + .fc-button-group, .fc-button-group .btn-group + .fc-button-group,\n  .btn-group .fc-button-group + .fc-button-group, .fc-button-group .fc-button-group + .fc-button-group,\n  .btn-group-vertical .btn + .btn,\n  .btn-group-vertical .fc button + .btn, .fc\n  .btn-group-vertical button + .btn,\n  .btn-group-vertical .fc .btn + button, .fc\n  .btn-group-vertical .btn + button,\n  .btn-group-vertical .fc button + button, .fc\n  .btn-group-vertical button + button,\n  .btn-group-vertical .btn + .btn-group,\n  .btn-group-vertical .fc button + .btn-group, .fc\n  .btn-group-vertical button + .btn-group,\n  .btn-group-vertical .btn + .fc-button-group,\n  .btn-group-vertical .fc button + .fc-button-group, .fc\n  .btn-group-vertical button + .fc-button-group,\n  .btn-group-vertical .btn-group + .btn,\n  .btn-group-vertical .fc-button-group + .btn,\n  .btn-group-vertical .fc .btn-group + button, .fc\n  .btn-group-vertical .btn-group + button,\n  .btn-group-vertical .fc .fc-button-group + button, .fc\n  .btn-group-vertical .fc-button-group + button,\n  .btn-group-vertical .btn-group + .btn-group,\n  .btn-group-vertical .fc-button-group + .btn-group,\n  .btn-group-vertical .btn-group + .fc-button-group,\n  .btn-group-vertical .fc-button-group + .fc-button-group {\n    margin-left: -1px; }\n\n.btn-toolbar {\n  display: flex;\n  justify-content: flex-start; }\n  .btn-toolbar .input-group {\n    width: auto; }\n\n.btn-group > .btn:not(:first-child):not(:last-child):not(.dropdown-toggle), .fc-button-group > .btn:not(:first-child):not(:last-child):not(.dropdown-toggle), .fc .btn-group > button:not(:first-child):not(:last-child):not(.dropdown-toggle), .fc .fc-button-group > button:not(:first-child):not(:last-child):not(.dropdown-toggle) {\n  border-radius: 0; }\n\n.btn-group > .btn:first-child, .fc-button-group > .btn:first-child, .fc .btn-group > button:first-child, .fc .fc-button-group > button:first-child {\n  margin-left: 0; }\n\n.btn-group > .btn-group, .fc-button-group > .btn-group, .btn-group > .fc-button-group, .fc-button-group > .fc-button-group {\n  float: left; }\n\n.btn-group > .btn-group:not(:first-child):not(:last-child) > .btn, .fc-button-group > .btn-group:not(:first-child):not(:last-child) > .btn, .btn-group > .fc-button-group:not(:first-child):not(:last-child) > .btn, .fc-button-group > .fc-button-group:not(:first-child):not(:last-child) > .btn, .fc .btn-group > .btn-group:not(:first-child):not(:last-child) > button, .fc .fc-button-group > .btn-group:not(:first-child):not(:last-child) > button, .fc .btn-group > .fc-button-group:not(:first-child):not(:last-child) > button, .fc .fc-button-group > .fc-button-group:not(:first-child):not(:last-child) > button {\n  border-radius: 0; }\n\n.btn-group .dropdown-toggle:active, .fc-button-group .dropdown-toggle:active,\n.btn-group.open .dropdown-toggle, .open.fc-button-group .dropdown-toggle {\n  outline: 0; }\n\n.btn + .dropdown-toggle-split, .fc button + .dropdown-toggle-split {\n  padding-right: 0.75rem;\n  padding-left: 0.75rem; }\n  .btn + .dropdown-toggle-split::after, .fc button + .dropdown-toggle-split::after {\n    margin-left: 0; }\n\n.btn-sm + .dropdown-toggle-split, .btn-group-sm > .btn + .dropdown-toggle-split, .fc .btn-group-sm > button + .dropdown-toggle-split {\n  padding-right: 0.375rem;\n  padding-left: 0.375rem; }\n\n.btn-lg + .dropdown-toggle-split, .btn-group-lg > .btn + .dropdown-toggle-split, .fc .btn-group-lg > button + .dropdown-toggle-split {\n  padding-right: 1.125rem;\n  padding-left: 1.125rem; }\n\n.btn-group-vertical {\n  display: inline-flex;\n  flex-direction: column;\n  align-items: flex-start;\n  justify-content: center; }\n  .btn-group-vertical .btn, .btn-group-vertical .fc button, .fc .btn-group-vertical button,\n  .btn-group-vertical .btn-group,\n  .btn-group-vertical .fc-button-group {\n    width: 100%; }\n  .btn-group-vertical > .btn + .btn, .fc .btn-group-vertical > button + .btn, .fc .btn-group-vertical > .btn + button, .fc .btn-group-vertical > button + button,\n  .btn-group-vertical > .btn + .btn-group, .fc\n  .btn-group-vertical > button + .btn-group,\n  .btn-group-vertical > .btn + .fc-button-group, .fc\n  .btn-group-vertical > button + .fc-button-group,\n  .btn-group-vertical > .btn-group + .btn,\n  .btn-group-vertical > .fc-button-group + .btn, .fc\n  .btn-group-vertical > .btn-group + button, .fc\n  .btn-group-vertical > .fc-button-group + button,\n  .btn-group-vertical > .btn-group + .btn-group,\n  .btn-group-vertical > .fc-button-group + .btn-group,\n  .btn-group-vertical > .btn-group + .fc-button-group,\n  .btn-group-vertical > .fc-button-group + .fc-button-group {\n    margin-top: -1px;\n    margin-left: 0; }\n\n.btn-group-vertical > .btn:not(:first-child):not(:last-child), .fc .btn-group-vertical > button:not(:first-child):not(:last-child) {\n  border-radius: 0; }\n\n.btn-group-vertical > .btn-group:not(:first-child):not(:last-child) > .btn, .btn-group-vertical > .fc-button-group:not(:first-child):not(:last-child) > .btn, .fc .btn-group-vertical > .btn-group:not(:first-child):not(:last-child) > button, .fc .btn-group-vertical > .fc-button-group:not(:first-child):not(:last-child) > button {\n  border-radius: 0; }\n\n[data-toggle=\"buttons\"] > .btn input[type=\"radio\"], .fc [data-toggle=\"buttons\"] > button input[type=\"radio\"],\n[data-toggle=\"buttons\"] > .btn input[type=\"checkbox\"], .fc\n[data-toggle=\"buttons\"] > button input[type=\"checkbox\"],\n[data-toggle=\"buttons\"] > .btn-group > .btn input[type=\"radio\"],\n[data-toggle=\"buttons\"] > .fc-button-group > .btn input[type=\"radio\"], .fc\n[data-toggle=\"buttons\"] > .btn-group > button input[type=\"radio\"], .fc\n[data-toggle=\"buttons\"] > .fc-button-group > button input[type=\"radio\"],\n[data-toggle=\"buttons\"] > .btn-group > .btn input[type=\"checkbox\"],\n[data-toggle=\"buttons\"] > .fc-button-group > .btn input[type=\"checkbox\"], .fc\n[data-toggle=\"buttons\"] > .btn-group > button input[type=\"checkbox\"], .fc\n[data-toggle=\"buttons\"] > .fc-button-group > button input[type=\"checkbox\"] {\n  position: absolute;\n  clip: rect(0, 0, 0, 0);\n  pointer-events: none; }\n\n.input-group {\n  position: relative;\n  display: flex;\n  width: 100%; }\n  .input-group .form-control, .input-group .daterangepicker .input-mini, .daterangepicker .input-group .input-mini, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control.direction-up {\n    position: relative;\n    z-index: 2;\n    flex: 1 1 auto;\n    width: 1%;\n    margin-bottom: 0; }\n    .input-group .form-control:focus, .input-group .daterangepicker .input-mini:focus, .daterangepicker .input-group .input-mini:focus, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control:focus, .input-group .form-control:active, .input-group .daterangepicker .input-mini:active, .daterangepicker .input-group .input-mini:active, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control:active, .input-group .form-control:hover, .input-group .daterangepicker .input-mini:hover, .daterangepicker .input-group .input-mini:hover, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control:hover {\n      z-index: 3; }\n\n.input-group-addon,\n.input-group-btn,\n.input-group .form-control,\n.input-group .daterangepicker .input-mini, .daterangepicker\n.input-group .input-mini, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control.direction-up {\n  display: flex;\n  flex-direction: column;\n  justify-content: center; }\n\n.input-group-addon,\n.input-group-btn {\n  white-space: nowrap;\n  vertical-align: middle; }\n\n.input-group-addon {\n  padding: 0.5rem 0.75rem;\n  margin-bottom: 0;\n  font-size: 0.875rem;\n  font-weight: normal;\n  line-height: 1.25;\n  color: #55595c;\n  text-align: center;\n  background-color: #d1d4d7;\n  border: 1px solid rgba(0, 0, 0, 0.15); }\n  .input-group-addon.form-control-sm, .daterangepicker .input-group-sm > .input-group-addon.input-mini, .input-group > .ui-select-bootstrap.input-group-sm > input.input-group-addon.ui-select-search.form-control,\n  .input-group-sm > .input-group-addon,\n  .input-group-sm > .input-group-btn > .input-group-addon.btn, .fc\n  .input-group-sm > .input-group-btn > button.input-group-addon {\n    padding: 0.25rem 0.5rem;\n    font-size: 0.875rem; }\n  .input-group-addon.form-control-lg, .daterangepicker .input-group-lg > .input-group-addon.input-mini, .input-group > .ui-select-bootstrap.input-group-lg > input.input-group-addon.ui-select-search.form-control,\n  .input-group-lg > .input-group-addon,\n  .input-group-lg > .input-group-btn > .input-group-addon.btn, .fc\n  .input-group-lg > .input-group-btn > button.input-group-addon {\n    padding: 0.75rem 1.5rem;\n    font-size: 1.25rem; }\n  .input-group-addon input[type=\"radio\"],\n  .input-group-addon input[type=\"checkbox\"] {\n    margin-top: 0; }\n\n.input-group-addon:not(:last-child) {\n  border-right: 0; }\n\n.form-control + .input-group-addon:not(:first-child), .daterangepicker .input-mini + .input-group-addon:not(:first-child), .input-group > .ui-select-bootstrap > input.ui-select-search.form-control + .input-group-addon:not(:first-child) {\n  border-left: 0; }\n\n.input-group-btn {\n  position: relative;\n  font-size: 0;\n  white-space: nowrap; }\n  .input-group-btn > .btn, .fc .input-group-btn > button {\n    position: relative;\n    flex: 1; }\n    .input-group-btn > .btn + .btn, .fc .input-group-btn > button + .btn, .fc .input-group-btn > .btn + button, .fc .input-group-btn > button + button {\n      margin-left: -1px; }\n    .input-group-btn > .btn:focus, .fc .input-group-btn > button:focus, .input-group-btn > .btn:active, .fc .input-group-btn > button:active, .input-group-btn > .btn:hover, .fc .input-group-btn > button:hover {\n      z-index: 3; }\n  .input-group-btn:not(:last-child) > .btn, .fc .input-group-btn:not(:last-child) > button,\n  .input-group-btn:not(:last-child) > .btn-group,\n  .input-group-btn:not(:last-child) > .fc-button-group {\n    margin-right: -1px; }\n  .input-group-btn:not(:first-child) > .btn, .fc .input-group-btn:not(:first-child) > button,\n  .input-group-btn:not(:first-child) > .btn-group,\n  .input-group-btn:not(:first-child) > .fc-button-group {\n    z-index: 2;\n    margin-left: -1px; }\n    .input-group-btn:not(:first-child) > .btn:focus, .fc .input-group-btn:not(:first-child) > button:focus, .input-group-btn:not(:first-child) > .btn:active, .fc .input-group-btn:not(:first-child) > button:active, .input-group-btn:not(:first-child) > .btn:hover, .fc .input-group-btn:not(:first-child) > button:hover,\n    .input-group-btn:not(:first-child) > .btn-group:focus,\n    .input-group-btn:not(:first-child) > .fc-button-group:focus,\n    .input-group-btn:not(:first-child) > .btn-group:active,\n    .input-group-btn:not(:first-child) > .fc-button-group:active,\n    .input-group-btn:not(:first-child) > .btn-group:hover,\n    .input-group-btn:not(:first-child) > .fc-button-group:hover {\n      z-index: 3; }\n\n.input-group-addon,\n.input-group-btn {\n  min-width: 40px;\n  white-space: nowrap;\n  vertical-align: middle; }\n\n.nav {\n  display: flex;\n  padding-left: 0;\n  margin-bottom: 0;\n  list-style: none; }\n\n.nav-link {\n  display: block;\n  padding: 0.5em 1em; }\n  .nav-link:focus, .nav-link:hover {\n    text-decoration: none; }\n  .nav-link.disabled {\n    color: #818a91;\n    cursor: not-allowed; }\n\n.nav-tabs {\n  border-bottom: 1px solid #ddd; }\n  .nav-tabs .nav-item {\n    margin-bottom: -1px; }\n  .nav-tabs .nav-link {\n    border: 1px solid transparent; }\n    .nav-tabs .nav-link:focus, .nav-tabs .nav-link:hover {\n      border-color: #d1d4d7 #d1d4d7 #ddd; }\n    .nav-tabs .nav-link.disabled {\n      color: #818a91;\n      background-color: transparent;\n      border-color: transparent; }\n  .nav-tabs .nav-link.active,\n  .nav-tabs .nav-item.show .nav-link {\n    color: #55595c;\n    background-color: #e4e5e6;\n    border-color: #ddd #ddd #e4e5e6; }\n  .nav-tabs .dropdown-menu {\n    margin-top: -1px; }\n\n.nav-pills .nav-link.active,\n.nav-pills .nav-item.show .nav-link {\n  color: #fff;\n  cursor: default;\n  background-color: #20a8d8; }\n\n.nav-fill .nav-item {\n  flex: 1 1 auto;\n  text-align: center; }\n\n.nav-justified .nav-item {\n  flex: 1 1 100%;\n  text-align: center; }\n\n.tab-content > .tab-pane {\n  display: none; }\n\n.tab-content > .active {\n  display: block; }\n\n.nav-tabs .nav-link {\n  color: #55595c; }\n  .nav-tabs .nav-link.active {\n    color: #2a2c36;\n    background: #fff;\n    border-color: #d1d4d7;\n    border-bottom-color: #fff; }\n    .nav-tabs .nav-link.active:focus {\n      background: #fff;\n      border-color: #d1d4d7;\n      border-bottom-color: #fff; }\n\n.tab-content {\n  margin-top: -1px;\n  background: #fff;\n  border: 1px solid #d1d4d7; }\n  .tab-content .tab-pane {\n    padding: 1rem 1rem; }\n\n.card-block .tab-content {\n  margin-top: 0;\n  border: 0; }\n\n.navbar {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  padding: 0.5rem 1rem; }\n\n.navbar-brand {\n  display: inline-block;\n  padding-top: .25rem;\n  padding-bottom: .25rem;\n  margin-right: 1rem;\n  font-size: 1.25rem;\n  line-height: inherit;\n  white-space: nowrap; }\n  .navbar-brand:focus, .navbar-brand:hover {\n    text-decoration: none; }\n\n.navbar-nav {\n  display: flex;\n  flex-direction: column;\n  padding-left: 0;\n  margin-bottom: 0;\n  list-style: none; }\n  .navbar-nav .nav-link {\n    padding-right: 0;\n    padding-left: 0; }\n\n.navbar-text {\n  display: inline-block;\n  padding-top: .425rem;\n  padding-bottom: .425rem; }\n\n.navbar-toggler {\n  align-self: flex-start;\n  padding: 0.25rem 0.75rem;\n  font-size: 1.25rem;\n  line-height: 1;\n  background: transparent;\n  border: 1px solid transparent; }\n  .navbar-toggler:focus, .navbar-toggler:hover {\n    text-decoration: none; }\n\n.navbar-toggler-icon {\n  display: inline-block;\n  width: 1.5em;\n  height: 1.5em;\n  vertical-align: middle;\n  content: \"\";\n  background: no-repeat center center;\n  background-size: 100% 100%; }\n\n.navbar-toggler-left {\n  position: absolute;\n  left: 1rem; }\n\n.navbar-toggler-right {\n  position: absolute;\n  right: 1rem; }\n\n@media (max-width: 575px) {\n  .navbar-toggleable .navbar-nav .dropdown-menu {\n    position: static;\n    float: none; }\n  .navbar-toggleable > .container {\n    padding-right: 0;\n    padding-left: 0; } }\n\n@media (min-width: 576px) {\n  .navbar-toggleable {\n    flex-direction: row;\n    flex-wrap: nowrap;\n    align-items: center; }\n    .navbar-toggleable .navbar-nav {\n      flex-direction: row; }\n      .navbar-toggleable .navbar-nav .nav-link {\n        padding-right: .5rem;\n        padding-left: .5rem; }\n    .navbar-toggleable > .container {\n      display: flex;\n      flex-wrap: nowrap;\n      align-items: center; }\n    .navbar-toggleable .navbar-collapse {\n      display: flex !important;\n      width: 100%; }\n    .navbar-toggleable .navbar-toggler {\n      display: none; } }\n\n@media (max-width: 767px) {\n  .navbar-toggleable-sm .navbar-nav .dropdown-menu {\n    position: static;\n    float: none; }\n  .navbar-toggleable-sm > .container {\n    padding-right: 0;\n    padding-left: 0; } }\n\n@media (min-width: 768px) {\n  .navbar-toggleable-sm {\n    flex-direction: row;\n    flex-wrap: nowrap;\n    align-items: center; }\n    .navbar-toggleable-sm .navbar-nav {\n      flex-direction: row; }\n      .navbar-toggleable-sm .navbar-nav .nav-link {\n        padding-right: .5rem;\n        padding-left: .5rem; }\n    .navbar-toggleable-sm > .container {\n      display: flex;\n      flex-wrap: nowrap;\n      align-items: center; }\n    .navbar-toggleable-sm .navbar-collapse {\n      display: flex !important;\n      width: 100%; }\n    .navbar-toggleable-sm .navbar-toggler {\n      display: none; } }\n\n@media (max-width: 991px) {\n  .navbar-toggleable-md .navbar-nav .dropdown-menu {\n    position: static;\n    float: none; }\n  .navbar-toggleable-md > .container {\n    padding-right: 0;\n    padding-left: 0; } }\n\n@media (min-width: 992px) {\n  .navbar-toggleable-md {\n    flex-direction: row;\n    flex-wrap: nowrap;\n    align-items: center; }\n    .navbar-toggleable-md .navbar-nav {\n      flex-direction: row; }\n      .navbar-toggleable-md .navbar-nav .nav-link {\n        padding-right: .5rem;\n        padding-left: .5rem; }\n    .navbar-toggleable-md > .container {\n      display: flex;\n      flex-wrap: nowrap;\n      align-items: center; }\n    .navbar-toggleable-md .navbar-collapse {\n      display: flex !important;\n      width: 100%; }\n    .navbar-toggleable-md .navbar-toggler {\n      display: none; } }\n\n@media (max-width: 1199px) {\n  .navbar-toggleable-lg .navbar-nav .dropdown-menu {\n    position: static;\n    float: none; }\n  .navbar-toggleable-lg > .container {\n    padding-right: 0;\n    padding-left: 0; } }\n\n@media (min-width: 1200px) {\n  .navbar-toggleable-lg {\n    flex-direction: row;\n    flex-wrap: nowrap;\n    align-items: center; }\n    .navbar-toggleable-lg .navbar-nav {\n      flex-direction: row; }\n      .navbar-toggleable-lg .navbar-nav .nav-link {\n        padding-right: .5rem;\n        padding-left: .5rem; }\n    .navbar-toggleable-lg > .container {\n      display: flex;\n      flex-wrap: nowrap;\n      align-items: center; }\n    .navbar-toggleable-lg .navbar-collapse {\n      display: flex !important;\n      width: 100%; }\n    .navbar-toggleable-lg .navbar-toggler {\n      display: none; } }\n\n.navbar-toggleable-xl {\n  flex-direction: row;\n  flex-wrap: nowrap;\n  align-items: center; }\n  .navbar-toggleable-xl .navbar-nav .dropdown-menu {\n    position: static;\n    float: none; }\n  .navbar-toggleable-xl > .container {\n    padding-right: 0;\n    padding-left: 0; }\n  .navbar-toggleable-xl .navbar-nav {\n    flex-direction: row; }\n    .navbar-toggleable-xl .navbar-nav .nav-link {\n      padding-right: .5rem;\n      padding-left: .5rem; }\n  .navbar-toggleable-xl > .container {\n    display: flex;\n    flex-wrap: nowrap;\n    align-items: center; }\n  .navbar-toggleable-xl .navbar-collapse {\n    display: flex !important;\n    width: 100%; }\n  .navbar-toggleable-xl .navbar-toggler {\n    display: none; }\n\n.navbar-light .navbar-brand,\n.navbar-light .navbar-toggler {\n  color: rgba(0, 0, 0, 0.9); }\n  .navbar-light .navbar-brand:focus, .navbar-light .navbar-brand:hover,\n  .navbar-light .navbar-toggler:focus,\n  .navbar-light .navbar-toggler:hover {\n    color: rgba(0, 0, 0, 0.9); }\n\n.navbar-light .navbar-nav .nav-link {\n  color: rgba(0, 0, 0, 0.5); }\n  .navbar-light .navbar-nav .nav-link:focus, .navbar-light .navbar-nav .nav-link:hover {\n    color: rgba(0, 0, 0, 0.7); }\n  .navbar-light .navbar-nav .nav-link.disabled {\n    color: rgba(0, 0, 0, 0.3); }\n\n.navbar-light .navbar-nav .open > .nav-link,\n.navbar-light .navbar-nav .active > .nav-link,\n.navbar-light .navbar-nav .nav-link.open,\n.navbar-light .navbar-nav .nav-link.active {\n  color: rgba(0, 0, 0, 0.9); }\n\n.navbar-light .navbar-toggler {\n  border-color: rgba(0, 0, 0, 0.1); }\n\n.navbar-light .navbar-toggler-icon {\n  background-image: url(\"data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(0, 0, 0, 0.5)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 8h24M4 16h24M4 24h24'/%3E%3C/svg%3E\"); }\n\n.navbar-light .navbar-text {\n  color: rgba(0, 0, 0, 0.5); }\n\n.navbar-inverse .navbar-brand,\n.navbar-inverse .navbar-toggler {\n  color: white; }\n  .navbar-inverse .navbar-brand:focus, .navbar-inverse .navbar-brand:hover,\n  .navbar-inverse .navbar-toggler:focus,\n  .navbar-inverse .navbar-toggler:hover {\n    color: white; }\n\n.navbar-inverse .navbar-nav .nav-link {\n  color: rgba(255, 255, 255, 0.5); }\n  .navbar-inverse .navbar-nav .nav-link:focus, .navbar-inverse .navbar-nav .nav-link:hover {\n    color: rgba(255, 255, 255, 0.75); }\n  .navbar-inverse .navbar-nav .nav-link.disabled {\n    color: rgba(255, 255, 255, 0.25); }\n\n.navbar-inverse .navbar-nav .open > .nav-link,\n.navbar-inverse .navbar-nav .active > .nav-link,\n.navbar-inverse .navbar-nav .nav-link.open,\n.navbar-inverse .navbar-nav .nav-link.active {\n  color: white; }\n\n.navbar-inverse .navbar-toggler {\n  border-color: rgba(255, 255, 255, 0.1); }\n\n.navbar-inverse .navbar-toggler-icon {\n  background-image: url(\"data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(255, 255, 255, 0.5)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 8h24M4 16h24M4 24h24'/%3E%3C/svg%3E\"); }\n\n.navbar-inverse .navbar-text {\n  color: rgba(255, 255, 255, 0.5); }\n\nheader.navbar {\n  position: relative;\n  height: 55px;\n  padding: 0;\n  background-color: #fff;\n  border-bottom: 1px solid #d1d4d7;\n  flex-direction: row; }\n  header.navbar .navbar-brand {\n    display: inline-block;\n    width: 200px;\n    height: 55px;\n    margin-right: 0;\n    padding: 0.5rem 1rem;\n    background-color: #141519;\n    background-image: url(\"../img/logo.png\");\n    background-repeat: no-repeat;\n    background-position: center center;\n    background-size: 70px auto;\n    border-bottom: 1px solid #141519; }\n  header.navbar .navbar-nav {\n    flex-direction: row;\n    align-items: center; }\n  header.navbar .nav-item {\n    position: relative;\n    min-width: 50px;\n    margin: 0 !important;\n    text-align: center; }\n    header.navbar .nav-item .nav-link {\n      padding-top: 0;\n      padding-bottom: 0; }\n      header.navbar .nav-item .nav-link .badge {\n        position: absolute;\n        top: 50%;\n        left: 50%;\n        margin-top: -16px;\n        margin-left: 0px; }\n      header.navbar .nav-item .nav-link > .img-avatar {\n        height: 35px;\n        margin: 0 10px; }\n  header.navbar .dropdown-menu {\n    padding-bottom: 0;\n    line-height: 1.5; }\n  header.navbar .dropdown-item {\n    min-width: 180px; }\n\n.navbar-brand {\n  color: rgba(0, 0, 0, 0.8); }\n  .navbar-brand:focus, .navbar-brand:hover {\n    color: rgba(0, 0, 0, 0.8); }\n\n.navbar-nav .nav-link {\n  color: rgba(0, 0, 0, 0.3); }\n  .navbar-nav .nav-link:focus, .navbar-nav .nav-link:hover {\n    color: rgba(0, 0, 0, 0.6); }\n\n.navbar-nav .open > .nav-link, .navbar-nav .open > .nav-link:focus, .navbar-nav .open > .nav-link:hover,\n.navbar-nav .active > .nav-link,\n.navbar-nav .active > .nav-link:focus,\n.navbar-nav .active > .nav-link:hover,\n.navbar-nav .nav-link.open,\n.navbar-nav .nav-link.open:focus,\n.navbar-nav .nav-link.open:hover,\n.navbar-nav .nav-link.active,\n.navbar-nav .nav-link.active:focus,\n.navbar-nav .nav-link.active:hover {\n  color: rgba(0, 0, 0, 0.8); }\n\n.navbar-divider {\n  background-color: rgba(0, 0, 0, 0.075); }\n\n.card {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  background-color: #fff;\n  border: 1px solid #d1d4d7; }\n\n.card-block {\n  flex: 1 1 auto;\n  padding: 1.25rem; }\n\n.card-title {\n  margin-bottom: 0.75rem; }\n\n.card-subtitle {\n  margin-top: -0.375rem;\n  margin-bottom: 0; }\n\n.card-text:last-child {\n  margin-bottom: 0; }\n\n.card-link:hover {\n  text-decoration: none; }\n\n.card-link + .card-link {\n  margin-left: 1.25rem; }\n\n.card-header {\n  padding: 0.75rem 1.25rem;\n  margin-bottom: 0;\n  background-color: #f8f9fa;\n  border-bottom: 1px solid #d1d4d7; }\n\n.card-footer {\n  padding: 0.75rem 1.25rem;\n  background-color: #f8f9fa;\n  border-top: 1px solid #d1d4d7; }\n\n.card-header-tabs {\n  margin-right: -0.625rem;\n  margin-bottom: -0.75rem;\n  margin-left: -0.625rem;\n  border-bottom: 0; }\n\n.card-header-pills {\n  margin-right: -0.625rem;\n  margin-left: -0.625rem; }\n\n.card-primary {\n  background-color: #20a8d8;\n  border-color: #20a8d8; }\n  .card-primary .card-header,\n  .card-primary .card-footer {\n    background-color: transparent; }\n\n.card-success {\n  background-color: #4dbd74;\n  border-color: #4dbd74; }\n  .card-success .card-header,\n  .card-success .card-footer {\n    background-color: transparent; }\n\n.card-info {\n  background-color: #63c2de;\n  border-color: #63c2de; }\n  .card-info .card-header,\n  .card-info .card-footer {\n    background-color: transparent; }\n\n.card-warning {\n  background-color: #f8cb00;\n  border-color: #f8cb00; }\n  .card-warning .card-header,\n  .card-warning .card-footer {\n    background-color: transparent; }\n\n.card-danger {\n  background-color: #f86c6b;\n  border-color: #f86c6b; }\n  .card-danger .card-header,\n  .card-danger .card-footer {\n    background-color: transparent; }\n\n.card-outline-primary {\n  background-color: transparent;\n  border-color: #20a8d8; }\n\n.card-outline-secondary {\n  background-color: transparent;\n  border-color: #ccc; }\n\n.card-outline-info {\n  background-color: transparent;\n  border-color: #63c2de; }\n\n.card-outline-success {\n  background-color: transparent;\n  border-color: #4dbd74; }\n\n.card-outline-warning {\n  background-color: transparent;\n  border-color: #f8cb00; }\n\n.card-outline-danger {\n  background-color: transparent;\n  border-color: #f86c6b; }\n\n.card-inverse {\n  color: rgba(255, 255, 255, 0.65); }\n  .card-inverse .card-header,\n  .card-inverse .card-footer {\n    background-color: transparent;\n    border-color: rgba(255, 255, 255, 0.2); }\n  .card-inverse .card-header,\n  .card-inverse .card-footer,\n  .card-inverse .card-title,\n  .card-inverse .card-blockquote {\n    color: #fff; }\n  .card-inverse .card-link,\n  .card-inverse .card-text,\n  .card-inverse .card-subtitle,\n  .card-inverse .card-blockquote .blockquote-footer {\n    color: rgba(255, 255, 255, 0.65); }\n  .card-inverse .card-link:focus, .card-inverse .card-link:hover {\n    color: #fff; }\n\n.card-blockquote {\n  padding: 0;\n  margin-bottom: 0;\n  border-left: 0; }\n\n.card-img-overlay {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  padding: 1.25rem; }\n\n@media (min-width: 576px) {\n  .card-deck {\n    display: flex;\n    flex-flow: row wrap; }\n    .card-deck .card {\n      display: flex;\n      flex: 1 0 0;\n      flex-direction: column; }\n      .card-deck .card:not(:first-child) {\n        margin-left: 15px; }\n      .card-deck .card:not(:last-child) {\n        margin-right: 15px; } }\n\n@media (min-width: 576px) {\n  .card-group {\n    display: flex;\n    flex-flow: row wrap; }\n    .card-group .card {\n      flex: 1 0 0; }\n      .card-group .card + .card {\n        margin-left: 0;\n        border-left: 0; } }\n\n@media (min-width: 576px) {\n  .card-columns {\n    column-count: 3;\n    column-gap: 1.25rem; }\n    .card-columns .card {\n      display: inline-block;\n      width: 100%;\n      margin-bottom: 0.75rem; } }\n\n.card {\n  margin-bottom: 1.5rem; }\n\n.card-header i.icon-bg {\n  display: inline-block;\n  padding: 0.75rem 1.25rem !important;\n  margin-top: -0.75rem;\n  margin-right: 1.25rem;\n  margin-bottom: -0.75rem;\n  margin-left: -1.25rem;\n  line-height: inherit;\n  color: #2a2c36;\n  vertical-align: bottom;\n  background: transparent;\n  border-right: 1px solid #d1d4d7; }\n\n.card-header ul.nav.nav-tabs {\n  margin-top: -0.75rem;\n  margin-bottom: -0.75rem;\n  border-bottom: 0; }\n  .card-header ul.nav.nav-tabs li.nav-item {\n    border-top: 0; }\n    .card-header ul.nav.nav-tabs li.nav-item a.nav-link {\n      padding: 0.75rem 0.625rem;\n      color: #818a91;\n      border-top: 0; }\n      .card-header ul.nav.nav-tabs li.nav-item a.nav-link.active {\n        color: #2a2c36;\n        background: #fff; }\n\n.card-header.card-header-inverse {\n  color: #fff; }\n\n.card-header.card-header-primary {\n  margin: -1px -1px 0;\n  background: #20a8d8;\n  border-bottom: 1px solid #20a8d8; }\n\n.card-header.card-header-secondary {\n  margin: -1px -1px 0;\n  background: #d1d4d7;\n  border-bottom: 1px solid #d1d4d7; }\n\n.card-header.card-header-success {\n  margin: -1px -1px 0;\n  background: #4dbd74;\n  border-bottom: 1px solid #4dbd74; }\n\n.card-header.card-header-info {\n  margin: -1px -1px 0;\n  background: #63c2de;\n  border-bottom: 1px solid #63c2de; }\n\n.card-header.card-header-warning {\n  margin: -1px -1px 0;\n  background: #f8cb00;\n  border-bottom: 1px solid #f8cb00; }\n\n.card-header.card-header-danger {\n  margin: -1px -1px 0;\n  background: #f86c6b;\n  border-bottom: 1px solid #f86c6b; }\n\n.card-header .btn, .card-header .fc button, .fc .card-header button {\n  margin-top: -0.5rem; }\n\n.card-header .btn-sm, .card-header .btn-group-sm > .btn, .card-header .fc .btn-group-sm > button, .fc .card-header .btn-group-sm > button {\n  margin-top: -0.25rem; }\n\n.card-header .btn-lg, .card-header .btn-group-lg > .btn, .card-header .fc .btn-group-lg > button, .fc .card-header .btn-group-lg > button {\n  margin-top: -0.75rem; }\n\n.card-footer ul {\n  display: table;\n  width: 100%;\n  padding: 0;\n  margin: 0;\n  table-layout: fixed; }\n  .card-footer ul li {\n    display: table-cell;\n    padding: 0 1.25rem;\n    text-align: center; }\n    .card-footer ul li progress {\n      margin-top: 0.75rem;\n      margin-bottom: 0; }\n\n.card-primary {\n  background-color: #20a8d8; }\n  .card-primary .card-header {\n    border-color: #1d97c2; }\n  .card-primary .card-header, .card-primary .card-footer {\n    background-color: #1d97c2; }\n\n.card-secondary {\n  background-color: #d1d4d7; }\n  .card-secondary .card-header {\n    border-color: #c3c7cb; }\n  .card-secondary .card-header, .card-secondary .card-footer {\n    background-color: #c3c7cb; }\n\n.card-success {\n  background-color: #4dbd74; }\n  .card-success .card-header {\n    border-color: #41af67; }\n  .card-success .card-header, .card-success .card-footer {\n    background-color: #41af67; }\n\n.card-info {\n  background-color: #63c2de; }\n  .card-info .card-header {\n    border-color: #4ebada; }\n  .card-info .card-header, .card-info .card-footer {\n    background-color: #4ebada; }\n\n.card-warning {\n  background-color: #f8cb00; }\n  .card-warning .card-header {\n    border-color: #dfb600; }\n  .card-warning .card-header, .card-warning .card-footer {\n    background-color: #dfb600; }\n\n.card-danger {\n  background-color: #f86c6b; }\n  .card-danger .card-header {\n    border-color: #f75453; }\n  .card-danger .card-header, .card-danger .card-footer {\n    background-color: #f75453; }\n\n.card-inverse {\n  color: #fff; }\n  .card-inverse .text-muted {\n    color: rgba(255, 255, 255, 0.6) !important; }\n\n[class*=\"card-outline-\"] .card-block {\n  background: #fff !important; }\n\n[class*=\"card-outline-\"].card-outline-top {\n  border-top-width: 2px;\n  border-right-color: #d1d4d7;\n  border-bottom-color: #d1d4d7;\n  border-left-color: #d1d4d7; }\n\n.card-accent-primary {\n  border-top-width: 2px;\n  border-top-color: #20a8d8; }\n\n.card-accent-secondary {\n  border-top-width: 2px;\n  border-top-color: #ccc; }\n\n.card-accent-info {\n  border-top-width: 2px;\n  border-top-color: #63c2de; }\n\n.card-accent-success {\n  border-top-width: 2px;\n  border-top-color: #4dbd74; }\n\n.card-accent-warning {\n  border-top-width: 2px;\n  border-top-color: #f8cb00; }\n\n.card-accent-danger {\n  border-top-width: 2px;\n  border-top-color: #f86c6b; }\n\n.card-header > i {\n  margin-right: 0.5rem; }\n\n.card-header .card-actions {\n  position: absolute;\n  top: 0;\n  right: 0; }\n  .card-header .card-actions a, .card-header .card-actions button {\n    display: block;\n    float: left;\n    width: 50px;\n    padding: 0.75rem 0;\n    margin: 0 !important;\n    color: #2a2c36;\n    text-align: center;\n    background: transparent;\n    border: 0;\n    border-left: 1px solid #d1d4d7;\n    box-shadow: 0; }\n    .card-header .card-actions a:hover, .card-header .card-actions button:hover {\n      text-decoration: none; }\n    .card-header .card-actions a [class^=\"icon-\"], .card-header .card-actions a [class*=\" icon-\"], .card-header .card-actions button [class^=\"icon-\"], .card-header .card-actions button [class*=\" icon-\"] {\n      display: inline-block;\n      vertical-align: middle; }\n    .card-header .card-actions a i, .card-header .card-actions button i {\n      display: inline-block;\n      transition: .4s; }\n    .card-header .card-actions a i.r180, .card-header .card-actions button i.r180 {\n      -webkit-transform: rotate(180deg);\n      transform: rotate(180deg); }\n  .card-header .card-actions .input-group {\n    width: 230px;\n    margin: 6px; }\n    .card-header .card-actions .input-group .input-group-addon {\n      background: #fff; }\n    .card-header .card-actions .input-group input {\n      border-left: 0; }\n\n.card-full {\n  margin-top: -1rem;\n  margin-right: -15px;\n  margin-left: -15px;\n  border: 0;\n  border-bottom: 1px solid #d1d4d7; }\n\n@media (min-width: 576px) {\n  .card-columns.cols-2 {\n    -moz-column-count: 2;\n    -webkit-column-count: 2;\n    column-count: 2; } }\n\n.card.drag, .card .drag {\n  cursor: move; }\n\n.card-placeholder {\n  background: rgba(0, 0, 0, 0.025);\n  border: 1px dashed #818a91; }\n\n.breadcrumb {\n  padding: 0.75rem 1rem;\n  margin-bottom: 1rem;\n  list-style: none;\n  background-color: #fff; }\n  .breadcrumb::after {\n    display: block;\n    content: \"\";\n    clear: both; }\n\n.breadcrumb-item {\n  float: left; }\n  .breadcrumb-item + .breadcrumb-item::before {\n    display: inline-block;\n    padding-right: 0.5rem;\n    padding-left: 0.5rem;\n    color: #818a91;\n    content: \"/\"; }\n  .breadcrumb-item + .breadcrumb-item:hover::before {\n    text-decoration: underline; }\n  .breadcrumb-item + .breadcrumb-item:hover::before {\n    text-decoration: none; }\n  .breadcrumb-item.active {\n    color: #818a91; }\n\n.breadcrumb {\n  position: relative;\n  margin-bottom: 1.5rem;\n  border-bottom: 1px solid #d1d4d7; }\n\n.pagination {\n  display: flex;\n  padding-left: 0;\n  list-style: none; }\n\n.page-item:first-child .page-link, .pagination-datatables li:first-child .page-link, .pagination li:first-child .page-link, .page-item:first-child .pagination-datatables li a, .pagination-datatables li .page-item:first-child a, .pagination-datatables li:first-child a, .page-item:first-child .pagination li a, .pagination li .page-item:first-child a, .pagination li:first-child a {\n  margin-left: 0; }\n\n.page-item.active .page-link, .pagination-datatables li.active .page-link, .pagination li.active .page-link, .page-item.active .pagination-datatables li a, .pagination-datatables li .page-item.active a, .pagination-datatables li.active a, .page-item.active .pagination li a, .pagination li .page-item.active a, .pagination li.active a {\n  z-index: 2;\n  color: #fff;\n  background-color: #20a8d8;\n  border-color: #20a8d8; }\n\n.page-item.disabled .page-link, .pagination-datatables li.disabled .page-link, .pagination li.disabled .page-link, .page-item.disabled .pagination-datatables li a, .pagination-datatables li .page-item.disabled a, .pagination-datatables li.disabled a, .page-item.disabled .pagination li a, .pagination li .page-item.disabled a, .pagination li.disabled a {\n  color: #818a91;\n  pointer-events: none;\n  cursor: not-allowed;\n  background-color: #fff;\n  border-color: #ddd; }\n\n.page-link, .pagination-datatables li a, .pagination li a {\n  position: relative;\n  display: block;\n  padding: 0.5rem 0.75rem;\n  margin-left: -1px;\n  line-height: 1.25;\n  color: #20a8d8;\n  background-color: #fff;\n  border: 1px solid #ddd; }\n  .page-link:focus, .pagination-datatables li a:focus, .pagination li a:focus, .page-link:hover, .pagination-datatables li a:hover, .pagination li a:hover {\n    color: #167495;\n    text-decoration: none;\n    background-color: #d1d4d7;\n    border-color: #ddd; }\n\n.pagination-lg .page-link, .pagination-lg .pagination-datatables li a, .pagination-datatables li .pagination-lg a, .pagination-lg .pagination li a, .pagination li .pagination-lg a {\n  padding: 0.75rem 1.5rem;\n  font-size: 1.25rem; }\n\n.pagination-sm .page-link, .pagination-sm .pagination-datatables li a, .pagination-datatables li .pagination-sm a, .pagination-sm .pagination li a, .pagination li .pagination-sm a {\n  padding: 0.25rem 0.5rem;\n  font-size: 0.875rem; }\n\n.badge {\n  display: inline-block;\n  padding: 0.25em 0.4em;\n  font-size: 75%;\n  font-weight: bold;\n  line-height: 1;\n  color: #fff;\n  text-align: center;\n  white-space: nowrap;\n  vertical-align: baseline; }\n  .badge:empty {\n    display: none; }\n\n.btn .badge, .fc button .badge {\n  position: relative;\n  top: -1px; }\n\na.badge:focus, a.badge:hover {\n  color: #fff;\n  text-decoration: none;\n  cursor: pointer; }\n\n.badge-pill {\n  padding-right: 0.6em;\n  padding-left: 0.6em; }\n\n.badge-default {\n  background-color: #818a91; }\n  .badge-default[href]:focus, .badge-default[href]:hover {\n    background-color: #687077; }\n\n.badge-primary {\n  background-color: #20a8d8; }\n  .badge-primary[href]:focus, .badge-primary[href]:hover {\n    background-color: #1985ac; }\n\n.badge-success {\n  background-color: #4dbd74; }\n  .badge-success[href]:focus, .badge-success[href]:hover {\n    background-color: #3a9d5d; }\n\n.badge-info {\n  background-color: #63c2de; }\n  .badge-info[href]:focus, .badge-info[href]:hover {\n    background-color: #39b2d5; }\n\n.badge-warning {\n  background-color: #f8cb00; }\n  .badge-warning[href]:focus, .badge-warning[href]:hover {\n    background-color: #c5a100; }\n\n.badge-danger {\n  background-color: #f86c6b; }\n  .badge-danger[href]:focus, .badge-danger[href]:hover {\n    background-color: #f63c3a; }\n\n.badge-pill {\n  border-radius: 10rem; }\n\n.alert {\n  padding: 0.75rem 1.25rem;\n  margin-bottom: 1rem;\n  border: 1px solid transparent; }\n\n.alert-heading {\n  color: inherit; }\n\n.alert-link {\n  font-weight: bold; }\n\n.alert-dismissible .close {\n  position: relative;\n  top: -0.75rem;\n  right: -1.25rem;\n  padding: 0.75rem 1.25rem;\n  color: inherit; }\n\n.alert-success {\n  background-color: #dff0d8;\n  border-color: #d0e9c6;\n  color: #3c763d; }\n  .alert-success hr {\n    border-top-color: #c1e2b3; }\n  .alert-success .alert-link {\n    color: #2b542c; }\n\n.alert-info {\n  background-color: #d9edf7;\n  border-color: #bcdff1;\n  color: #31708f; }\n  .alert-info hr {\n    border-top-color: #a6d5ec; }\n  .alert-info .alert-link {\n    color: #245269; }\n\n.alert-warning {\n  background-color: #fcf8e3;\n  border-color: #faf2cc;\n  color: #8a6d3b; }\n  .alert-warning hr {\n    border-top-color: #f7ecb5; }\n  .alert-warning .alert-link {\n    color: #66512c; }\n\n.alert-danger {\n  background-color: #f2dede;\n  border-color: #ebcccc;\n  color: #a94442; }\n  .alert-danger hr {\n    border-top-color: #e4b9b9; }\n  .alert-danger .alert-link {\n    color: #843534; }\n\n@keyframes progress-bar-stripes {\n  from {\n    background-position: 1rem 0; }\n  to {\n    background-position: 0 0; } }\n\n.progress {\n  display: flex;\n  overflow: hidden;\n  font-size: 0.75rem;\n  line-height: 1rem;\n  text-align: center;\n  background-color: #d1d4d7; }\n\n.progress-bar {\n  height: 1rem;\n  color: #fff;\n  background-color: #20a8d8; }\n\n.progress-bar-striped {\n  background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);\n  background-size: 1rem 1rem; }\n\n.progress-bar-animated {\n  animation: progress-bar-stripes 1s linear infinite; }\n\n.progress-xs {\n  height: 4px; }\n\n.progress-sm {\n  height: 8px; }\n\n.progress-white {\n  background-color: rgba(255, 255, 255, 0.2) !important; }\n  .progress-white .progress-bar {\n    background-color: #fff; }\n\n.list-group {\n  display: flex;\n  flex-direction: column;\n  padding-left: 0;\n  margin-bottom: 0; }\n\n.list-group-item-action {\n  width: 100%;\n  color: #55595c;\n  text-align: inherit; }\n  .list-group-item-action .list-group-item-heading {\n    color: #2a2c36; }\n  .list-group-item-action:focus, .list-group-item-action:hover {\n    color: #55595c;\n    text-decoration: none;\n    background-color: #f8f9fa; }\n  .list-group-item-action:active {\n    color: #2a2c36;\n    background-color: #d1d4d7; }\n\n.list-group-item {\n  position: relative;\n  display: flex;\n  flex-flow: row wrap;\n  align-items: center;\n  padding: 0.75rem 1.25rem;\n  margin-bottom: -1px;\n  background-color: #fff;\n  border: 1px solid rgba(0, 0, 0, 0.125); }\n  .list-group-item:last-child {\n    margin-bottom: 0; }\n  .list-group-item:focus, .list-group-item:hover {\n    text-decoration: none; }\n  .list-group-item.disabled, .list-group-item:disabled {\n    color: #818a91;\n    cursor: not-allowed;\n    background-color: #fff; }\n    .list-group-item.disabled .list-group-item-heading, .list-group-item:disabled .list-group-item-heading {\n      color: inherit; }\n    .list-group-item.disabled .list-group-item-text, .list-group-item:disabled .list-group-item-text {\n      color: #818a91; }\n  .list-group-item.active {\n    z-index: 2;\n    color: #fff;\n    background-color: #20a8d8;\n    border-color: #20a8d8; }\n    .list-group-item.active .list-group-item-heading,\n    .list-group-item.active .list-group-item-heading > small,\n    .list-group-item.active .list-group-item-heading > .small {\n      color: inherit; }\n    .list-group-item.active .list-group-item-text {\n      color: #f9fdfe; }\n\n.list-group-flush .list-group-item {\n  border-right: 0;\n  border-left: 0;\n  border-radius: 0; }\n\n.list-group-flush:first-child .list-group-item:first-child {\n  border-top: 0; }\n\n.list-group-flush:last-child .list-group-item:last-child {\n  border-bottom: 0; }\n\n.list-group-item-success {\n  color: #3c763d;\n  background-color: #dff0d8; }\n\na.list-group-item-success,\nbutton.list-group-item-success {\n  color: #3c763d; }\n  a.list-group-item-success .list-group-item-heading,\n  button.list-group-item-success .list-group-item-heading {\n    color: inherit; }\n  a.list-group-item-success:focus, a.list-group-item-success:hover,\n  button.list-group-item-success:focus,\n  button.list-group-item-success:hover {\n    color: #3c763d;\n    background-color: #d0e9c6; }\n  a.list-group-item-success.active,\n  button.list-group-item-success.active {\n    color: #fff;\n    background-color: #3c763d;\n    border-color: #3c763d; }\n\n.list-group-item-info {\n  color: #31708f;\n  background-color: #d9edf7; }\n\na.list-group-item-info,\nbutton.list-group-item-info {\n  color: #31708f; }\n  a.list-group-item-info .list-group-item-heading,\n  button.list-group-item-info .list-group-item-heading {\n    color: inherit; }\n  a.list-group-item-info:focus, a.list-group-item-info:hover,\n  button.list-group-item-info:focus,\n  button.list-group-item-info:hover {\n    color: #31708f;\n    background-color: #c4e3f3; }\n  a.list-group-item-info.active,\n  button.list-group-item-info.active {\n    color: #fff;\n    background-color: #31708f;\n    border-color: #31708f; }\n\n.list-group-item-warning {\n  color: #8a6d3b;\n  background-color: #fcf8e3; }\n\na.list-group-item-warning,\nbutton.list-group-item-warning {\n  color: #8a6d3b; }\n  a.list-group-item-warning .list-group-item-heading,\n  button.list-group-item-warning .list-group-item-heading {\n    color: inherit; }\n  a.list-group-item-warning:focus, a.list-group-item-warning:hover,\n  button.list-group-item-warning:focus,\n  button.list-group-item-warning:hover {\n    color: #8a6d3b;\n    background-color: #faf2cc; }\n  a.list-group-item-warning.active,\n  button.list-group-item-warning.active {\n    color: #fff;\n    background-color: #8a6d3b;\n    border-color: #8a6d3b; }\n\n.list-group-item-danger {\n  color: #a94442;\n  background-color: #f2dede; }\n\na.list-group-item-danger,\nbutton.list-group-item-danger {\n  color: #a94442; }\n  a.list-group-item-danger .list-group-item-heading,\n  button.list-group-item-danger .list-group-item-heading {\n    color: inherit; }\n  a.list-group-item-danger:focus, a.list-group-item-danger:hover,\n  button.list-group-item-danger:focus,\n  button.list-group-item-danger:hover {\n    color: #a94442;\n    background-color: #ebcccc; }\n  a.list-group-item-danger.active,\n  button.list-group-item-danger.active {\n    color: #fff;\n    background-color: #a94442;\n    border-color: #a94442; }\n\n.embed-responsive {\n  position: relative;\n  display: block;\n  width: 100%;\n  padding: 0;\n  overflow: hidden; }\n  .embed-responsive::before {\n    display: block;\n    content: \"\"; }\n  .embed-responsive .embed-responsive-item,\n  .embed-responsive iframe,\n  .embed-responsive embed,\n  .embed-responsive object,\n  .embed-responsive video {\n    position: absolute;\n    top: 0;\n    bottom: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    border: 0; }\n\n.embed-responsive-21by9::before {\n  padding-top: 42.85714%; }\n\n.embed-responsive-16by9::before {\n  padding-top: 56.25%; }\n\n.embed-responsive-4by3::before {\n  padding-top: 75%; }\n\n.embed-responsive-1by1::before {\n  padding-top: 100%; }\n\n.close {\n  float: right;\n  font-size: 1.3125rem;\n  font-weight: bold;\n  line-height: 1;\n  color: #000;\n  text-shadow: 0 1px 0 #fff;\n  opacity: .5; }\n  .close:focus, .close:hover {\n    color: #000;\n    text-decoration: none;\n    cursor: pointer;\n    opacity: .75; }\n\nbutton.close {\n  padding: 0;\n  cursor: pointer;\n  background: transparent;\n  border: 0;\n  -webkit-appearance: none; }\n\n.modal-open {\n  overflow: hidden; }\n\n.modal {\n  position: fixed;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  z-index: 1050;\n  display: none;\n  overflow: hidden;\n  outline: 0; }\n  .modal.fade .modal-dialog {\n    transition: transform 0.3s ease-out;\n    transform: translate(0, -25%); }\n  .modal.show .modal-dialog {\n    transform: translate(0, 0); }\n\n.modal-open .modal {\n  overflow-x: hidden;\n  overflow-y: auto; }\n\n.modal-dialog {\n  position: relative;\n  width: auto;\n  margin: 10px; }\n\n.modal-content {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  background-color: #fff;\n  background-clip: padding-box;\n  border: 1px solid rgba(0, 0, 0, 0.2);\n  outline: 0; }\n\n.modal-backdrop {\n  position: fixed;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  z-index: 1040;\n  background-color: #000; }\n  .modal-backdrop.fade {\n    opacity: 0; }\n  .modal-backdrop.show {\n    opacity: 0.5; }\n\n.modal-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 15px;\n  border-bottom: 1px solid #d1d4d7; }\n\n.modal-title {\n  margin-bottom: 0;\n  line-height: 1.5; }\n\n.modal-body {\n  position: relative;\n  flex: 1 1 auto;\n  padding: 15px; }\n\n.modal-footer {\n  display: flex;\n  align-items: center;\n  justify-content: flex-end;\n  padding: 15px;\n  border-top: 1px solid #d1d4d7; }\n  .modal-footer > :not(:first-child) {\n    margin-left: .25rem; }\n  .modal-footer > :not(:last-child) {\n    margin-right: .25rem; }\n\n.modal-scrollbar-measure {\n  position: absolute;\n  top: -9999px;\n  width: 50px;\n  height: 50px;\n  overflow: scroll; }\n\n@media (min-width: 576px) {\n  .modal-dialog {\n    max-width: 500px;\n    margin: 30px auto; }\n  .modal-sm {\n    max-width: 300px; } }\n\n@media (min-width: 992px) {\n  .modal-lg {\n    max-width: 800px; } }\n\n.modal-primary .modal-content {\n  border-color: #20a8d8; }\n\n.modal-primary .modal-header {\n  color: #fff;\n  background-color: #20a8d8; }\n\n.modal-secondary .modal-content {\n  border-color: #d1d4d7; }\n\n.modal-secondary .modal-header {\n  color: #fff;\n  background-color: #d1d4d7; }\n\n.modal-success .modal-content {\n  border-color: #4dbd74; }\n\n.modal-success .modal-header {\n  color: #fff;\n  background-color: #4dbd74; }\n\n.modal-info .modal-content {\n  border-color: #63c2de; }\n\n.modal-info .modal-header {\n  color: #fff;\n  background-color: #63c2de; }\n\n.modal-warning .modal-content {\n  border-color: #f8cb00; }\n\n.modal-warning .modal-header {\n  color: #fff;\n  background-color: #f8cb00; }\n\n.modal-danger .modal-content {\n  border-color: #f86c6b; }\n\n.modal-danger .modal-header {\n  color: #fff;\n  background-color: #f86c6b; }\n\n.tooltip {\n  position: absolute;\n  z-index: 1070;\n  display: block;\n  font-family: -apple-system, system-ui, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif;\n  font-style: normal;\n  font-weight: normal;\n  letter-spacing: normal;\n  line-break: auto;\n  line-height: 1.5;\n  text-align: left;\n  text-align: start;\n  text-decoration: none;\n  text-shadow: none;\n  text-transform: none;\n  white-space: normal;\n  word-break: normal;\n  word-spacing: normal;\n  font-size: 0.875rem;\n  word-wrap: break-word;\n  opacity: 0; }\n  .tooltip.show {\n    opacity: 0.9; }\n  .tooltip.tooltip-top, .tooltip.bs-tether-element-attached-bottom {\n    padding: 5px 0;\n    margin-top: -3px; }\n    .tooltip.tooltip-top .tooltip-inner::before, .tooltip.bs-tether-element-attached-bottom .tooltip-inner::before {\n      bottom: 0;\n      left: 50%;\n      margin-left: -5px;\n      content: \"\";\n      border-width: 5px 5px 0;\n      border-top-color: #000; }\n  .tooltip.tooltip-right, .tooltip.bs-tether-element-attached-left {\n    padding: 0 5px;\n    margin-left: 3px; }\n    .tooltip.tooltip-right .tooltip-inner::before, .tooltip.bs-tether-element-attached-left .tooltip-inner::before {\n      top: 50%;\n      left: 0;\n      margin-top: -5px;\n      content: \"\";\n      border-width: 5px 5px 5px 0;\n      border-right-color: #000; }\n  .tooltip.tooltip-bottom, .tooltip.bs-tether-element-attached-top {\n    padding: 5px 0;\n    margin-top: 3px; }\n    .tooltip.tooltip-bottom .tooltip-inner::before, .tooltip.bs-tether-element-attached-top .tooltip-inner::before {\n      top: 0;\n      left: 50%;\n      margin-left: -5px;\n      content: \"\";\n      border-width: 0 5px 5px;\n      border-bottom-color: #000; }\n  .tooltip.tooltip-left, .tooltip.bs-tether-element-attached-right {\n    padding: 0 5px;\n    margin-left: -3px; }\n    .tooltip.tooltip-left .tooltip-inner::before, .tooltip.bs-tether-element-attached-right .tooltip-inner::before {\n      top: 50%;\n      right: 0;\n      margin-top: -5px;\n      content: \"\";\n      border-width: 5px 0 5px 5px;\n      border-left-color: #000; }\n\n.tooltip-inner {\n  max-width: 200px;\n  padding: 3px 8px;\n  color: #fff;\n  text-align: center;\n  background-color: #000; }\n  .tooltip-inner::before {\n    position: absolute;\n    width: 0;\n    height: 0;\n    border-color: transparent;\n    border-style: solid; }\n\n.popover {\n  position: absolute;\n  top: 0;\n  left: 0;\n  z-index: 1060;\n  display: block;\n  max-width: 276px;\n  padding: 1px;\n  font-family: -apple-system, system-ui, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif;\n  font-style: normal;\n  font-weight: normal;\n  letter-spacing: normal;\n  line-break: auto;\n  line-height: 1.5;\n  text-align: left;\n  text-align: start;\n  text-decoration: none;\n  text-shadow: none;\n  text-transform: none;\n  white-space: normal;\n  word-break: normal;\n  word-spacing: normal;\n  font-size: 0.875rem;\n  word-wrap: break-word;\n  background-color: #fff;\n  background-clip: padding-box;\n  border: 1px solid rgba(0, 0, 0, 0.2); }\n  .popover.popover-top, .popover.bs-tether-element-attached-bottom {\n    margin-top: -10px; }\n    .popover.popover-top::before, .popover.popover-top::after, .popover.bs-tether-element-attached-bottom::before, .popover.bs-tether-element-attached-bottom::after {\n      left: 50%;\n      border-bottom-width: 0; }\n    .popover.popover-top::before, .popover.bs-tether-element-attached-bottom::before {\n      bottom: -11px;\n      margin-left: -11px;\n      border-top-color: rgba(0, 0, 0, 0.25); }\n    .popover.popover-top::after, .popover.bs-tether-element-attached-bottom::after {\n      bottom: -10px;\n      margin-left: -10px;\n      border-top-color: #fff; }\n  .popover.popover-right, .popover.bs-tether-element-attached-left {\n    margin-left: 10px; }\n    .popover.popover-right::before, .popover.popover-right::after, .popover.bs-tether-element-attached-left::before, .popover.bs-tether-element-attached-left::after {\n      top: 50%;\n      border-left-width: 0; }\n    .popover.popover-right::before, .popover.bs-tether-element-attached-left::before {\n      left: -11px;\n      margin-top: -11px;\n      border-right-color: rgba(0, 0, 0, 0.25); }\n    .popover.popover-right::after, .popover.bs-tether-element-attached-left::after {\n      left: -10px;\n      margin-top: -10px;\n      border-right-color: #fff; }\n  .popover.popover-bottom, .popover.bs-tether-element-attached-top {\n    margin-top: 10px; }\n    .popover.popover-bottom::before, .popover.popover-bottom::after, .popover.bs-tether-element-attached-top::before, .popover.bs-tether-element-attached-top::after {\n      left: 50%;\n      border-top-width: 0; }\n    .popover.popover-bottom::before, .popover.bs-tether-element-attached-top::before {\n      top: -11px;\n      margin-left: -11px;\n      border-bottom-color: rgba(0, 0, 0, 0.25); }\n    .popover.popover-bottom::after, .popover.bs-tether-element-attached-top::after {\n      top: -10px;\n      margin-left: -10px;\n      border-bottom-color: #f7f7f7; }\n    .popover.popover-bottom .popover-title::before, .popover.bs-tether-element-attached-top .popover-title::before {\n      position: absolute;\n      top: 0;\n      left: 50%;\n      display: block;\n      width: 20px;\n      margin-left: -10px;\n      content: \"\";\n      border-bottom: 1px solid #f7f7f7; }\n  .popover.popover-left, .popover.bs-tether-element-attached-right {\n    margin-left: -10px; }\n    .popover.popover-left::before, .popover.popover-left::after, .popover.bs-tether-element-attached-right::before, .popover.bs-tether-element-attached-right::after {\n      top: 50%;\n      border-right-width: 0; }\n    .popover.popover-left::before, .popover.bs-tether-element-attached-right::before {\n      right: -11px;\n      margin-top: -11px;\n      border-left-color: rgba(0, 0, 0, 0.25); }\n    .popover.popover-left::after, .popover.bs-tether-element-attached-right::after {\n      right: -10px;\n      margin-top: -10px;\n      border-left-color: #fff; }\n\n.popover-title {\n  padding: 8px 14px;\n  margin-bottom: 0;\n  font-size: 0.875rem;\n  background-color: #f7f7f7;\n  border-bottom: 1px solid #ebebeb; }\n  .popover-title:empty {\n    display: none; }\n\n.popover-content {\n  padding: 9px 14px; }\n\n.popover::before,\n.popover::after {\n  position: absolute;\n  display: block;\n  width: 0;\n  height: 0;\n  border-color: transparent;\n  border-style: solid; }\n\n.popover::before {\n  content: \"\";\n  border-width: 11px; }\n\n.popover::after {\n  content: \"\";\n  border-width: 10px; }\n\n.carousel {\n  position: relative; }\n\n.carousel-inner {\n  position: relative;\n  width: 100%;\n  overflow: hidden; }\n\n.carousel-item {\n  position: relative;\n  display: none;\n  width: 100%; }\n  @media (-webkit-transform-3d) {\n    .carousel-item {\n      transition: transform 0.6s ease-in-out;\n      backface-visibility: hidden;\n      perspective: 1000px; } }\n  @supports (transform: translate3d(0, 0, 0)) {\n    .carousel-item {\n      transition: transform 0.6s ease-in-out;\n      backface-visibility: hidden;\n      perspective: 1000px; } }\n\n.carousel-item.active,\n.carousel-item-next,\n.carousel-item-prev {\n  display: flex; }\n\n.carousel-item-next,\n.carousel-item-prev {\n  position: absolute;\n  top: 0; }\n\n@media (-webkit-transform-3d) {\n  .carousel-item-next.carousel-item-left,\n  .carousel-item-prev.carousel-item-right {\n    transform: translate3d(0, 0, 0); }\n  .carousel-item-next,\n  .active.carousel-item-right {\n    transform: translate3d(100%, 0, 0); }\n  .carousel-item-prev,\n  .active.carousel-item-left {\n    transform: translate3d(-100%, 0, 0); } }\n\n@supports (transform: translate3d(0, 0, 0)) {\n  .carousel-item-next.carousel-item-left,\n  .carousel-item-prev.carousel-item-right {\n    transform: translate3d(0, 0, 0); }\n  .carousel-item-next,\n  .active.carousel-item-right {\n    transform: translate3d(100%, 0, 0); }\n  .carousel-item-prev,\n  .active.carousel-item-left {\n    transform: translate3d(-100%, 0, 0); } }\n\n.carousel-control-prev,\n.carousel-control-next {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 15%;\n  color: #fff;\n  text-align: center;\n  opacity: 0.5; }\n  .carousel-control-prev:focus, .carousel-control-prev:hover,\n  .carousel-control-next:focus,\n  .carousel-control-next:hover {\n    color: #fff;\n    text-decoration: none;\n    outline: 0;\n    opacity: .9; }\n\n.carousel-control-prev {\n  left: 0; }\n\n.carousel-control-next {\n  right: 0; }\n\n.carousel-control-prev-icon,\n.carousel-control-next-icon {\n  display: inline-block;\n  width: 20px;\n  height: 20px;\n  background: transparent no-repeat center center;\n  background-size: 100% 100%; }\n\n.carousel-control-prev-icon {\n  background-image: url(\"data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M4 0l-4 4 4 4 1.5-1.5-2.5-2.5 2.5-2.5-1.5-1.5z'/%3E%3C/svg%3E\"); }\n\n.carousel-control-next-icon {\n  background-image: url(\"data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M1.5 0l-1.5 1.5 2.5 2.5-2.5 2.5 1.5 1.5 4-4-4-4z'/%3E%3C/svg%3E\"); }\n\n.carousel-indicators {\n  position: absolute;\n  right: 0;\n  bottom: 10px;\n  left: 0;\n  z-index: 15;\n  display: flex;\n  justify-content: center;\n  padding-left: 0;\n  margin-right: 15%;\n  margin-left: 15%;\n  list-style: none; }\n  .carousel-indicators li {\n    position: relative;\n    flex: 1 0 auto;\n    max-width: 30px;\n    height: 3px;\n    margin-right: 3px;\n    margin-left: 3px;\n    text-indent: -999px;\n    cursor: pointer;\n    background-color: rgba(255, 255, 255, 0.5); }\n    .carousel-indicators li::before {\n      position: absolute;\n      top: -10px;\n      left: 0;\n      display: inline-block;\n      width: 100%;\n      height: 10px;\n      content: \"\"; }\n    .carousel-indicators li::after {\n      position: absolute;\n      bottom: -10px;\n      left: 0;\n      display: inline-block;\n      width: 100%;\n      height: 10px;\n      content: \"\"; }\n  .carousel-indicators .active {\n    background-color: #fff; }\n\n.carousel-caption {\n  position: absolute;\n  right: 15%;\n  bottom: 20px;\n  left: 15%;\n  z-index: 10;\n  padding-top: 20px;\n  padding-bottom: 20px;\n  color: #fff;\n  text-align: center; }\n\n.align-baseline {\n  vertical-align: baseline !important; }\n\n.align-top {\n  vertical-align: top !important; }\n\n.align-middle {\n  vertical-align: middle !important; }\n\n.align-bottom {\n  vertical-align: bottom !important; }\n\n.align-text-bottom {\n  vertical-align: text-bottom !important; }\n\n.align-text-top {\n  vertical-align: text-top !important; }\n\n.bg-faded {\n  background-color: #dcdddf; }\n\n.bg-primary {\n  color: #fff !important;\n  background-color: #20a8d8 !important; }\n\na.bg-primary:focus, a.bg-primary:hover {\n  background-color: #1985ac; }\n\n.bg-success {\n  color: #fff !important;\n  background-color: #4dbd74 !important; }\n\na.bg-success:focus, a.bg-success:hover {\n  background-color: #3a9d5d; }\n\n.bg-info {\n  color: #fff !important;\n  background-color: #63c2de !important; }\n\na.bg-info:focus, a.bg-info:hover {\n  background-color: #39b2d5; }\n\n.bg-warning {\n  color: #fff !important;\n  background-color: #f8cb00 !important; }\n\na.bg-warning:focus, a.bg-warning:hover {\n  background-color: #c5a100; }\n\n.bg-danger {\n  color: #fff !important;\n  background-color: #f86c6b !important; }\n\na.bg-danger:focus, a.bg-danger:hover {\n  background-color: #f63c3a; }\n\n.bg-inverse {\n  color: #fff !important;\n  background-color: #2a2c36 !important; }\n\na.bg-inverse:focus, a.bg-inverse:hover {\n  background-color: #141519; }\n\n.border-0 {\n  border: 0 !important; }\n\n.border-top-0 {\n  border-top: 0 !important; }\n\n.border-right-0 {\n  border-right: 0 !important; }\n\n.border-bottom-0 {\n  border-bottom: 0 !important; }\n\n.border-left-0 {\n  border-left: 0 !important; }\n\n.rounded-circle {\n  border-radius: 50%; }\n\n.rounded-0 {\n  border-radius: 0; }\n\n.clearfix::after {\n  display: block;\n  content: \"\";\n  clear: both; }\n\n.d-none {\n  display: none !important; }\n\n.d-inline {\n  display: inline !important; }\n\n.d-inline-block {\n  display: inline-block !important; }\n\n.d-block {\n  display: block !important; }\n\n.d-table {\n  display: table !important; }\n\n.d-table-cell {\n  display: table-cell !important; }\n\n.d-flex {\n  display: flex !important; }\n\n.d-inline-flex {\n  display: inline-flex !important; }\n\n@media (min-width: 576px) {\n  .d-sm-none {\n    display: none !important; }\n  .d-sm-inline {\n    display: inline !important; }\n  .d-sm-inline-block {\n    display: inline-block !important; }\n  .d-sm-block {\n    display: block !important; }\n  .d-sm-table {\n    display: table !important; }\n  .d-sm-table-cell {\n    display: table-cell !important; }\n  .d-sm-flex {\n    display: flex !important; }\n  .d-sm-inline-flex {\n    display: inline-flex !important; } }\n\n@media (min-width: 768px) {\n  .d-md-none {\n    display: none !important; }\n  .d-md-inline {\n    display: inline !important; }\n  .d-md-inline-block {\n    display: inline-block !important; }\n  .d-md-block {\n    display: block !important; }\n  .d-md-table {\n    display: table !important; }\n  .d-md-table-cell {\n    display: table-cell !important; }\n  .d-md-flex {\n    display: flex !important; }\n  .d-md-inline-flex {\n    display: inline-flex !important; } }\n\n@media (min-width: 992px) {\n  .d-lg-none {\n    display: none !important; }\n  .d-lg-inline {\n    display: inline !important; }\n  .d-lg-inline-block {\n    display: inline-block !important; }\n  .d-lg-block {\n    display: block !important; }\n  .d-lg-table {\n    display: table !important; }\n  .d-lg-table-cell {\n    display: table-cell !important; }\n  .d-lg-flex {\n    display: flex !important; }\n  .d-lg-inline-flex {\n    display: inline-flex !important; } }\n\n@media (min-width: 1200px) {\n  .d-xl-none {\n    display: none !important; }\n  .d-xl-inline {\n    display: inline !important; }\n  .d-xl-inline-block {\n    display: inline-block !important; }\n  .d-xl-block {\n    display: block !important; }\n  .d-xl-table {\n    display: table !important; }\n  .d-xl-table-cell {\n    display: table-cell !important; }\n  .d-xl-flex {\n    display: flex !important; }\n  .d-xl-inline-flex {\n    display: inline-flex !important; } }\n\n.flex-first {\n  order: -1; }\n\n.flex-last {\n  order: 1; }\n\n.flex-unordered {\n  order: 0; }\n\n.flex-row {\n  flex-direction: row !important; }\n\n.flex-column {\n  flex-direction: column !important; }\n\n.flex-row-reverse {\n  flex-direction: row-reverse !important; }\n\n.flex-column-reverse {\n  flex-direction: column-reverse !important; }\n\n.flex-wrap {\n  flex-wrap: wrap !important; }\n\n.flex-nowrap {\n  flex-wrap: nowrap !important; }\n\n.flex-wrap-reverse {\n  flex-wrap: wrap-reverse !important; }\n\n.justify-content-start {\n  justify-content: flex-start !important; }\n\n.justify-content-end {\n  justify-content: flex-end !important; }\n\n.justify-content-center {\n  justify-content: center !important; }\n\n.justify-content-between {\n  justify-content: space-between !important; }\n\n.justify-content-around {\n  justify-content: space-around !important; }\n\n.align-items-start {\n  align-items: flex-start !important; }\n\n.align-items-end {\n  align-items: flex-end !important; }\n\n.align-items-center {\n  align-items: center !important; }\n\n.align-items-baseline {\n  align-items: baseline !important; }\n\n.align-items-stretch {\n  align-items: stretch !important; }\n\n.align-content-start {\n  align-content: flex-start !important; }\n\n.align-content-end {\n  align-content: flex-end !important; }\n\n.align-content-center {\n  align-content: center !important; }\n\n.align-content-between {\n  align-content: space-between !important; }\n\n.align-content-around {\n  align-content: space-around !important; }\n\n.align-content-stretch {\n  align-content: stretch !important; }\n\n.align-self-auto {\n  align-self: auto !important; }\n\n.align-self-start {\n  align-self: flex-start !important; }\n\n.align-self-end {\n  align-self: flex-end !important; }\n\n.align-self-center {\n  align-self: center !important; }\n\n.align-self-baseline {\n  align-self: baseline !important; }\n\n.align-self-stretch {\n  align-self: stretch !important; }\n\n@media (min-width: 576px) {\n  .flex-sm-first {\n    order: -1; }\n  .flex-sm-last {\n    order: 1; }\n  .flex-sm-unordered {\n    order: 0; }\n  .flex-sm-row {\n    flex-direction: row !important; }\n  .flex-sm-column {\n    flex-direction: column !important; }\n  .flex-sm-row-reverse {\n    flex-direction: row-reverse !important; }\n  .flex-sm-column-reverse {\n    flex-direction: column-reverse !important; }\n  .flex-sm-wrap {\n    flex-wrap: wrap !important; }\n  .flex-sm-nowrap {\n    flex-wrap: nowrap !important; }\n  .flex-sm-wrap-reverse {\n    flex-wrap: wrap-reverse !important; }\n  .justify-content-sm-start {\n    justify-content: flex-start !important; }\n  .justify-content-sm-end {\n    justify-content: flex-end !important; }\n  .justify-content-sm-center {\n    justify-content: center !important; }\n  .justify-content-sm-between {\n    justify-content: space-between !important; }\n  .justify-content-sm-around {\n    justify-content: space-around !important; }\n  .align-items-sm-start {\n    align-items: flex-start !important; }\n  .align-items-sm-end {\n    align-items: flex-end !important; }\n  .align-items-sm-center {\n    align-items: center !important; }\n  .align-items-sm-baseline {\n    align-items: baseline !important; }\n  .align-items-sm-stretch {\n    align-items: stretch !important; }\n  .align-content-sm-start {\n    align-content: flex-start !important; }\n  .align-content-sm-end {\n    align-content: flex-end !important; }\n  .align-content-sm-center {\n    align-content: center !important; }\n  .align-content-sm-between {\n    align-content: space-between !important; }\n  .align-content-sm-around {\n    align-content: space-around !important; }\n  .align-content-sm-stretch {\n    align-content: stretch !important; }\n  .align-self-sm-auto {\n    align-self: auto !important; }\n  .align-self-sm-start {\n    align-self: flex-start !important; }\n  .align-self-sm-end {\n    align-self: flex-end !important; }\n  .align-self-sm-center {\n    align-self: center !important; }\n  .align-self-sm-baseline {\n    align-self: baseline !important; }\n  .align-self-sm-stretch {\n    align-self: stretch !important; } }\n\n@media (min-width: 768px) {\n  .flex-md-first {\n    order: -1; }\n  .flex-md-last {\n    order: 1; }\n  .flex-md-unordered {\n    order: 0; }\n  .flex-md-row {\n    flex-direction: row !important; }\n  .flex-md-column {\n    flex-direction: column !important; }\n  .flex-md-row-reverse {\n    flex-direction: row-reverse !important; }\n  .flex-md-column-reverse {\n    flex-direction: column-reverse !important; }\n  .flex-md-wrap {\n    flex-wrap: wrap !important; }\n  .flex-md-nowrap {\n    flex-wrap: nowrap !important; }\n  .flex-md-wrap-reverse {\n    flex-wrap: wrap-reverse !important; }\n  .justify-content-md-start {\n    justify-content: flex-start !important; }\n  .justify-content-md-end {\n    justify-content: flex-end !important; }\n  .justify-content-md-center {\n    justify-content: center !important; }\n  .justify-content-md-between {\n    justify-content: space-between !important; }\n  .justify-content-md-around {\n    justify-content: space-around !important; }\n  .align-items-md-start {\n    align-items: flex-start !important; }\n  .align-items-md-end {\n    align-items: flex-end !important; }\n  .align-items-md-center {\n    align-items: center !important; }\n  .align-items-md-baseline {\n    align-items: baseline !important; }\n  .align-items-md-stretch {\n    align-items: stretch !important; }\n  .align-content-md-start {\n    align-content: flex-start !important; }\n  .align-content-md-end {\n    align-content: flex-end !important; }\n  .align-content-md-center {\n    align-content: center !important; }\n  .align-content-md-between {\n    align-content: space-between !important; }\n  .align-content-md-around {\n    align-content: space-around !important; }\n  .align-content-md-stretch {\n    align-content: stretch !important; }\n  .align-self-md-auto {\n    align-self: auto !important; }\n  .align-self-md-start {\n    align-self: flex-start !important; }\n  .align-self-md-end {\n    align-self: flex-end !important; }\n  .align-self-md-center {\n    align-self: center !important; }\n  .align-self-md-baseline {\n    align-self: baseline !important; }\n  .align-self-md-stretch {\n    align-self: stretch !important; } }\n\n@media (min-width: 992px) {\n  .flex-lg-first {\n    order: -1; }\n  .flex-lg-last {\n    order: 1; }\n  .flex-lg-unordered {\n    order: 0; }\n  .flex-lg-row {\n    flex-direction: row !important; }\n  .flex-lg-column {\n    flex-direction: column !important; }\n  .flex-lg-row-reverse {\n    flex-direction: row-reverse !important; }\n  .flex-lg-column-reverse {\n    flex-direction: column-reverse !important; }\n  .flex-lg-wrap {\n    flex-wrap: wrap !important; }\n  .flex-lg-nowrap {\n    flex-wrap: nowrap !important; }\n  .flex-lg-wrap-reverse {\n    flex-wrap: wrap-reverse !important; }\n  .justify-content-lg-start {\n    justify-content: flex-start !important; }\n  .justify-content-lg-end {\n    justify-content: flex-end !important; }\n  .justify-content-lg-center {\n    justify-content: center !important; }\n  .justify-content-lg-between {\n    justify-content: space-between !important; }\n  .justify-content-lg-around {\n    justify-content: space-around !important; }\n  .align-items-lg-start {\n    align-items: flex-start !important; }\n  .align-items-lg-end {\n    align-items: flex-end !important; }\n  .align-items-lg-center {\n    align-items: center !important; }\n  .align-items-lg-baseline {\n    align-items: baseline !important; }\n  .align-items-lg-stretch {\n    align-items: stretch !important; }\n  .align-content-lg-start {\n    align-content: flex-start !important; }\n  .align-content-lg-end {\n    align-content: flex-end !important; }\n  .align-content-lg-center {\n    align-content: center !important; }\n  .align-content-lg-between {\n    align-content: space-between !important; }\n  .align-content-lg-around {\n    align-content: space-around !important; }\n  .align-content-lg-stretch {\n    align-content: stretch !important; }\n  .align-self-lg-auto {\n    align-self: auto !important; }\n  .align-self-lg-start {\n    align-self: flex-start !important; }\n  .align-self-lg-end {\n    align-self: flex-end !important; }\n  .align-self-lg-center {\n    align-self: center !important; }\n  .align-self-lg-baseline {\n    align-self: baseline !important; }\n  .align-self-lg-stretch {\n    align-self: stretch !important; } }\n\n@media (min-width: 1200px) {\n  .flex-xl-first {\n    order: -1; }\n  .flex-xl-last {\n    order: 1; }\n  .flex-xl-unordered {\n    order: 0; }\n  .flex-xl-row {\n    flex-direction: row !important; }\n  .flex-xl-column {\n    flex-direction: column !important; }\n  .flex-xl-row-reverse {\n    flex-direction: row-reverse !important; }\n  .flex-xl-column-reverse {\n    flex-direction: column-reverse !important; }\n  .flex-xl-wrap {\n    flex-wrap: wrap !important; }\n  .flex-xl-nowrap {\n    flex-wrap: nowrap !important; }\n  .flex-xl-wrap-reverse {\n    flex-wrap: wrap-reverse !important; }\n  .justify-content-xl-start {\n    justify-content: flex-start !important; }\n  .justify-content-xl-end {\n    justify-content: flex-end !important; }\n  .justify-content-xl-center {\n    justify-content: center !important; }\n  .justify-content-xl-between {\n    justify-content: space-between !important; }\n  .justify-content-xl-around {\n    justify-content: space-around !important; }\n  .align-items-xl-start {\n    align-items: flex-start !important; }\n  .align-items-xl-end {\n    align-items: flex-end !important; }\n  .align-items-xl-center {\n    align-items: center !important; }\n  .align-items-xl-baseline {\n    align-items: baseline !important; }\n  .align-items-xl-stretch {\n    align-items: stretch !important; }\n  .align-content-xl-start {\n    align-content: flex-start !important; }\n  .align-content-xl-end {\n    align-content: flex-end !important; }\n  .align-content-xl-center {\n    align-content: center !important; }\n  .align-content-xl-between {\n    align-content: space-between !important; }\n  .align-content-xl-around {\n    align-content: space-around !important; }\n  .align-content-xl-stretch {\n    align-content: stretch !important; }\n  .align-self-xl-auto {\n    align-self: auto !important; }\n  .align-self-xl-start {\n    align-self: flex-start !important; }\n  .align-self-xl-end {\n    align-self: flex-end !important; }\n  .align-self-xl-center {\n    align-self: center !important; }\n  .align-self-xl-baseline {\n    align-self: baseline !important; }\n  .align-self-xl-stretch {\n    align-self: stretch !important; } }\n\n.float-left {\n  float: left !important; }\n\n.float-right {\n  float: right !important; }\n\n.float-none {\n  float: none !important; }\n\n@media (min-width: 576px) {\n  .float-sm-left {\n    float: left !important; }\n  .float-sm-right {\n    float: right !important; }\n  .float-sm-none {\n    float: none !important; } }\n\n@media (min-width: 768px) {\n  .float-md-left {\n    float: left !important; }\n  .float-md-right {\n    float: right !important; }\n  .float-md-none {\n    float: none !important; } }\n\n@media (min-width: 992px) {\n  .float-lg-left {\n    float: left !important; }\n  .float-lg-right {\n    float: right !important; }\n  .float-lg-none {\n    float: none !important; } }\n\n@media (min-width: 1200px) {\n  .float-xl-left {\n    float: left !important; }\n  .float-xl-right {\n    float: right !important; }\n  .float-xl-none {\n    float: none !important; } }\n\n.fixed-top {\n  position: fixed;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 1030; }\n\n.fixed-bottom {\n  position: fixed;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  z-index: 1030; }\n\n.sticky-top {\n  position: sticky;\n  top: 0;\n  z-index: 1030; }\n\n.sr-only {\n  position: absolute;\n  width: 1px;\n  height: 1px;\n  padding: 0;\n  margin: -1px;\n  overflow: hidden;\n  clip: rect(0, 0, 0, 0);\n  border: 0; }\n\n.sr-only-focusable:active, .sr-only-focusable:focus {\n  position: static;\n  width: auto;\n  height: auto;\n  margin: 0;\n  overflow: visible;\n  clip: auto; }\n\n.w-25 {\n  width: 25% !important; }\n\n.w-50 {\n  width: 50% !important; }\n\n.w-75 {\n  width: 75% !important; }\n\n.w-100 {\n  width: 100% !important; }\n\n.h-25 {\n  height: 25% !important; }\n\n.h-50 {\n  height: 50% !important; }\n\n.h-75 {\n  height: 75% !important; }\n\n.h-100 {\n  height: 100% !important; }\n\n.mw-100 {\n  max-width: 100% !important; }\n\n.mh-100 {\n  max-height: 100% !important; }\n\n.m-q {\n  margin: 0.25rem 0.25rem !important; }\n\n.mt-q {\n  margin-top: 0.25rem !important; }\n\n.mr-q {\n  margin-right: 0.25rem !important; }\n\n.mb-q {\n  margin-bottom: 0.25rem !important; }\n\n.ml-q {\n  margin-left: 0.25rem !important; }\n\n.mx-q {\n  margin-right: 0.25rem !important;\n  margin-left: 0.25rem !important; }\n\n.my-q {\n  margin-top: 0.25rem !important;\n  margin-bottom: 0.25rem !important; }\n\n.m-h {\n  margin: 0.5rem 0.5rem !important; }\n\n.mt-h {\n  margin-top: 0.5rem !important; }\n\n.mr-h {\n  margin-right: 0.5rem !important; }\n\n.mb-h {\n  margin-bottom: 0.5rem !important; }\n\n.ml-h {\n  margin-left: 0.5rem !important; }\n\n.mx-h {\n  margin-right: 0.5rem !important;\n  margin-left: 0.5rem !important; }\n\n.my-h {\n  margin-top: 0.5rem !important;\n  margin-bottom: 0.5rem !important; }\n\n.m-0 {\n  margin: 0 0 !important; }\n\n.mt-0 {\n  margin-top: 0 !important; }\n\n.mr-0 {\n  margin-right: 0 !important; }\n\n.mb-0 {\n  margin-bottom: 0 !important; }\n\n.ml-0 {\n  margin-left: 0 !important; }\n\n.mx-0 {\n  margin-right: 0 !important;\n  margin-left: 0 !important; }\n\n.my-0 {\n  margin-top: 0 !important;\n  margin-bottom: 0 !important; }\n\n.m-1 {\n  margin: 1rem 1rem !important; }\n\n.mt-1 {\n  margin-top: 1rem !important; }\n\n.mr-1 {\n  margin-right: 1rem !important; }\n\n.mb-1 {\n  margin-bottom: 1rem !important; }\n\n.ml-1 {\n  margin-left: 1rem !important; }\n\n.mx-1 {\n  margin-right: 1rem !important;\n  margin-left: 1rem !important; }\n\n.my-1 {\n  margin-top: 1rem !important;\n  margin-bottom: 1rem !important; }\n\n.m-2 {\n  margin: 1.5rem 1.5rem !important; }\n\n.mt-2 {\n  margin-top: 1.5rem !important; }\n\n.mr-2 {\n  margin-right: 1.5rem !important; }\n\n.mb-2 {\n  margin-bottom: 1.5rem !important; }\n\n.ml-2 {\n  margin-left: 1.5rem !important; }\n\n.mx-2 {\n  margin-right: 1.5rem !important;\n  margin-left: 1.5rem !important; }\n\n.my-2 {\n  margin-top: 1.5rem !important;\n  margin-bottom: 1.5rem !important; }\n\n.m-3 {\n  margin: 3rem 3rem !important; }\n\n.mt-3 {\n  margin-top: 3rem !important; }\n\n.mr-3 {\n  margin-right: 3rem !important; }\n\n.mb-3 {\n  margin-bottom: 3rem !important; }\n\n.ml-3 {\n  margin-left: 3rem !important; }\n\n.mx-3 {\n  margin-right: 3rem !important;\n  margin-left: 3rem !important; }\n\n.my-3 {\n  margin-top: 3rem !important;\n  margin-bottom: 3rem !important; }\n\n.p-q {\n  padding: 0.25rem 0.25rem !important; }\n\n.pt-q {\n  padding-top: 0.25rem !important; }\n\n.pr-q {\n  padding-right: 0.25rem !important; }\n\n.pb-q {\n  padding-bottom: 0.25rem !important; }\n\n.pl-q {\n  padding-left: 0.25rem !important; }\n\n.px-q {\n  padding-right: 0.25rem !important;\n  padding-left: 0.25rem !important; }\n\n.py-q {\n  padding-top: 0.25rem !important;\n  padding-bottom: 0.25rem !important; }\n\n.p-h {\n  padding: 0.5rem 0.5rem !important; }\n\n.pt-h {\n  padding-top: 0.5rem !important; }\n\n.pr-h {\n  padding-right: 0.5rem !important; }\n\n.pb-h {\n  padding-bottom: 0.5rem !important; }\n\n.pl-h {\n  padding-left: 0.5rem !important; }\n\n.px-h {\n  padding-right: 0.5rem !important;\n  padding-left: 0.5rem !important; }\n\n.py-h {\n  padding-top: 0.5rem !important;\n  padding-bottom: 0.5rem !important; }\n\n.p-0 {\n  padding: 0 0 !important; }\n\n.pt-0 {\n  padding-top: 0 !important; }\n\n.pr-0 {\n  padding-right: 0 !important; }\n\n.pb-0 {\n  padding-bottom: 0 !important; }\n\n.pl-0 {\n  padding-left: 0 !important; }\n\n.px-0 {\n  padding-right: 0 !important;\n  padding-left: 0 !important; }\n\n.py-0 {\n  padding-top: 0 !important;\n  padding-bottom: 0 !important; }\n\n.p-1 {\n  padding: 1rem 1rem !important; }\n\n.pt-1 {\n  padding-top: 1rem !important; }\n\n.pr-1 {\n  padding-right: 1rem !important; }\n\n.pb-1 {\n  padding-bottom: 1rem !important; }\n\n.pl-1 {\n  padding-left: 1rem !important; }\n\n.px-1 {\n  padding-right: 1rem !important;\n  padding-left: 1rem !important; }\n\n.py-1 {\n  padding-top: 1rem !important;\n  padding-bottom: 1rem !important; }\n\n.p-2 {\n  padding: 1.5rem 1.5rem !important; }\n\n.pt-2 {\n  padding-top: 1.5rem !important; }\n\n.pr-2 {\n  padding-right: 1.5rem !important; }\n\n.pb-2 {\n  padding-bottom: 1.5rem !important; }\n\n.pl-2 {\n  padding-left: 1.5rem !important; }\n\n.px-2 {\n  padding-right: 1.5rem !important;\n  padding-left: 1.5rem !important; }\n\n.py-2 {\n  padding-top: 1.5rem !important;\n  padding-bottom: 1.5rem !important; }\n\n.p-3 {\n  padding: 3rem 3rem !important; }\n\n.pt-3 {\n  padding-top: 3rem !important; }\n\n.pr-3 {\n  padding-right: 3rem !important; }\n\n.pb-3 {\n  padding-bottom: 3rem !important; }\n\n.pl-3 {\n  padding-left: 3rem !important; }\n\n.px-3 {\n  padding-right: 3rem !important;\n  padding-left: 3rem !important; }\n\n.py-3 {\n  padding-top: 3rem !important;\n  padding-bottom: 3rem !important; }\n\n.m-auto {\n  margin: auto !important; }\n\n.mt-auto {\n  margin-top: auto !important; }\n\n.mr-auto {\n  margin-right: auto !important; }\n\n.mb-auto {\n  margin-bottom: auto !important; }\n\n.ml-auto {\n  margin-left: auto !important; }\n\n.mx-auto {\n  margin-right: auto !important;\n  margin-left: auto !important; }\n\n.my-auto {\n  margin-top: auto !important;\n  margin-bottom: auto !important; }\n\n@media (min-width: 576px) {\n  .m-sm-q {\n    margin: 0.25rem 0.25rem !important; }\n  .mt-sm-q {\n    margin-top: 0.25rem !important; }\n  .mr-sm-q {\n    margin-right: 0.25rem !important; }\n  .mb-sm-q {\n    margin-bottom: 0.25rem !important; }\n  .ml-sm-q {\n    margin-left: 0.25rem !important; }\n  .mx-sm-q {\n    margin-right: 0.25rem !important;\n    margin-left: 0.25rem !important; }\n  .my-sm-q {\n    margin-top: 0.25rem !important;\n    margin-bottom: 0.25rem !important; }\n  .m-sm-h {\n    margin: 0.5rem 0.5rem !important; }\n  .mt-sm-h {\n    margin-top: 0.5rem !important; }\n  .mr-sm-h {\n    margin-right: 0.5rem !important; }\n  .mb-sm-h {\n    margin-bottom: 0.5rem !important; }\n  .ml-sm-h {\n    margin-left: 0.5rem !important; }\n  .mx-sm-h {\n    margin-right: 0.5rem !important;\n    margin-left: 0.5rem !important; }\n  .my-sm-h {\n    margin-top: 0.5rem !important;\n    margin-bottom: 0.5rem !important; }\n  .m-sm-0 {\n    margin: 0 0 !important; }\n  .mt-sm-0 {\n    margin-top: 0 !important; }\n  .mr-sm-0 {\n    margin-right: 0 !important; }\n  .mb-sm-0 {\n    margin-bottom: 0 !important; }\n  .ml-sm-0 {\n    margin-left: 0 !important; }\n  .mx-sm-0 {\n    margin-right: 0 !important;\n    margin-left: 0 !important; }\n  .my-sm-0 {\n    margin-top: 0 !important;\n    margin-bottom: 0 !important; }\n  .m-sm-1 {\n    margin: 1rem 1rem !important; }\n  .mt-sm-1 {\n    margin-top: 1rem !important; }\n  .mr-sm-1 {\n    margin-right: 1rem !important; }\n  .mb-sm-1 {\n    margin-bottom: 1rem !important; }\n  .ml-sm-1 {\n    margin-left: 1rem !important; }\n  .mx-sm-1 {\n    margin-right: 1rem !important;\n    margin-left: 1rem !important; }\n  .my-sm-1 {\n    margin-top: 1rem !important;\n    margin-bottom: 1rem !important; }\n  .m-sm-2 {\n    margin: 1.5rem 1.5rem !important; }\n  .mt-sm-2 {\n    margin-top: 1.5rem !important; }\n  .mr-sm-2 {\n    margin-right: 1.5rem !important; }\n  .mb-sm-2 {\n    margin-bottom: 1.5rem !important; }\n  .ml-sm-2 {\n    margin-left: 1.5rem !important; }\n  .mx-sm-2 {\n    margin-right: 1.5rem !important;\n    margin-left: 1.5rem !important; }\n  .my-sm-2 {\n    margin-top: 1.5rem !important;\n    margin-bottom: 1.5rem !important; }\n  .m-sm-3 {\n    margin: 3rem 3rem !important; }\n  .mt-sm-3 {\n    margin-top: 3rem !important; }\n  .mr-sm-3 {\n    margin-right: 3rem !important; }\n  .mb-sm-3 {\n    margin-bottom: 3rem !important; }\n  .ml-sm-3 {\n    margin-left: 3rem !important; }\n  .mx-sm-3 {\n    margin-right: 3rem !important;\n    margin-left: 3rem !important; }\n  .my-sm-3 {\n    margin-top: 3rem !important;\n    margin-bottom: 3rem !important; }\n  .p-sm-q {\n    padding: 0.25rem 0.25rem !important; }\n  .pt-sm-q {\n    padding-top: 0.25rem !important; }\n  .pr-sm-q {\n    padding-right: 0.25rem !important; }\n  .pb-sm-q {\n    padding-bottom: 0.25rem !important; }\n  .pl-sm-q {\n    padding-left: 0.25rem !important; }\n  .px-sm-q {\n    padding-right: 0.25rem !important;\n    padding-left: 0.25rem !important; }\n  .py-sm-q {\n    padding-top: 0.25rem !important;\n    padding-bottom: 0.25rem !important; }\n  .p-sm-h {\n    padding: 0.5rem 0.5rem !important; }\n  .pt-sm-h {\n    padding-top: 0.5rem !important; }\n  .pr-sm-h {\n    padding-right: 0.5rem !important; }\n  .pb-sm-h {\n    padding-bottom: 0.5rem !important; }\n  .pl-sm-h {\n    padding-left: 0.5rem !important; }\n  .px-sm-h {\n    padding-right: 0.5rem !important;\n    padding-left: 0.5rem !important; }\n  .py-sm-h {\n    padding-top: 0.5rem !important;\n    padding-bottom: 0.5rem !important; }\n  .p-sm-0 {\n    padding: 0 0 !important; }\n  .pt-sm-0 {\n    padding-top: 0 !important; }\n  .pr-sm-0 {\n    padding-right: 0 !important; }\n  .pb-sm-0 {\n    padding-bottom: 0 !important; }\n  .pl-sm-0 {\n    padding-left: 0 !important; }\n  .px-sm-0 {\n    padding-right: 0 !important;\n    padding-left: 0 !important; }\n  .py-sm-0 {\n    padding-top: 0 !important;\n    padding-bottom: 0 !important; }\n  .p-sm-1 {\n    padding: 1rem 1rem !important; }\n  .pt-sm-1 {\n    padding-top: 1rem !important; }\n  .pr-sm-1 {\n    padding-right: 1rem !important; }\n  .pb-sm-1 {\n    padding-bottom: 1rem !important; }\n  .pl-sm-1 {\n    padding-left: 1rem !important; }\n  .px-sm-1 {\n    padding-right: 1rem !important;\n    padding-left: 1rem !important; }\n  .py-sm-1 {\n    padding-top: 1rem !important;\n    padding-bottom: 1rem !important; }\n  .p-sm-2 {\n    padding: 1.5rem 1.5rem !important; }\n  .pt-sm-2 {\n    padding-top: 1.5rem !important; }\n  .pr-sm-2 {\n    padding-right: 1.5rem !important; }\n  .pb-sm-2 {\n    padding-bottom: 1.5rem !important; }\n  .pl-sm-2 {\n    padding-left: 1.5rem !important; }\n  .px-sm-2 {\n    padding-right: 1.5rem !important;\n    padding-left: 1.5rem !important; }\n  .py-sm-2 {\n    padding-top: 1.5rem !important;\n    padding-bottom: 1.5rem !important; }\n  .p-sm-3 {\n    padding: 3rem 3rem !important; }\n  .pt-sm-3 {\n    padding-top: 3rem !important; }\n  .pr-sm-3 {\n    padding-right: 3rem !important; }\n  .pb-sm-3 {\n    padding-bottom: 3rem !important; }\n  .pl-sm-3 {\n    padding-left: 3rem !important; }\n  .px-sm-3 {\n    padding-right: 3rem !important;\n    padding-left: 3rem !important; }\n  .py-sm-3 {\n    padding-top: 3rem !important;\n    padding-bottom: 3rem !important; }\n  .m-sm-auto {\n    margin: auto !important; }\n  .mt-sm-auto {\n    margin-top: auto !important; }\n  .mr-sm-auto {\n    margin-right: auto !important; }\n  .mb-sm-auto {\n    margin-bottom: auto !important; }\n  .ml-sm-auto {\n    margin-left: auto !important; }\n  .mx-sm-auto {\n    margin-right: auto !important;\n    margin-left: auto !important; }\n  .my-sm-auto {\n    margin-top: auto !important;\n    margin-bottom: auto !important; } }\n\n@media (min-width: 768px) {\n  .m-md-q {\n    margin: 0.25rem 0.25rem !important; }\n  .mt-md-q {\n    margin-top: 0.25rem !important; }\n  .mr-md-q {\n    margin-right: 0.25rem !important; }\n  .mb-md-q {\n    margin-bottom: 0.25rem !important; }\n  .ml-md-q {\n    margin-left: 0.25rem !important; }\n  .mx-md-q {\n    margin-right: 0.25rem !important;\n    margin-left: 0.25rem !important; }\n  .my-md-q {\n    margin-top: 0.25rem !important;\n    margin-bottom: 0.25rem !important; }\n  .m-md-h {\n    margin: 0.5rem 0.5rem !important; }\n  .mt-md-h {\n    margin-top: 0.5rem !important; }\n  .mr-md-h {\n    margin-right: 0.5rem !important; }\n  .mb-md-h {\n    margin-bottom: 0.5rem !important; }\n  .ml-md-h {\n    margin-left: 0.5rem !important; }\n  .mx-md-h {\n    margin-right: 0.5rem !important;\n    margin-left: 0.5rem !important; }\n  .my-md-h {\n    margin-top: 0.5rem !important;\n    margin-bottom: 0.5rem !important; }\n  .m-md-0 {\n    margin: 0 0 !important; }\n  .mt-md-0 {\n    margin-top: 0 !important; }\n  .mr-md-0 {\n    margin-right: 0 !important; }\n  .mb-md-0 {\n    margin-bottom: 0 !important; }\n  .ml-md-0 {\n    margin-left: 0 !important; }\n  .mx-md-0 {\n    margin-right: 0 !important;\n    margin-left: 0 !important; }\n  .my-md-0 {\n    margin-top: 0 !important;\n    margin-bottom: 0 !important; }\n  .m-md-1 {\n    margin: 1rem 1rem !important; }\n  .mt-md-1 {\n    margin-top: 1rem !important; }\n  .mr-md-1 {\n    margin-right: 1rem !important; }\n  .mb-md-1 {\n    margin-bottom: 1rem !important; }\n  .ml-md-1 {\n    margin-left: 1rem !important; }\n  .mx-md-1 {\n    margin-right: 1rem !important;\n    margin-left: 1rem !important; }\n  .my-md-1 {\n    margin-top: 1rem !important;\n    margin-bottom: 1rem !important; }\n  .m-md-2 {\n    margin: 1.5rem 1.5rem !important; }\n  .mt-md-2 {\n    margin-top: 1.5rem !important; }\n  .mr-md-2 {\n    margin-right: 1.5rem !important; }\n  .mb-md-2 {\n    margin-bottom: 1.5rem !important; }\n  .ml-md-2 {\n    margin-left: 1.5rem !important; }\n  .mx-md-2 {\n    margin-right: 1.5rem !important;\n    margin-left: 1.5rem !important; }\n  .my-md-2 {\n    margin-top: 1.5rem !important;\n    margin-bottom: 1.5rem !important; }\n  .m-md-3 {\n    margin: 3rem 3rem !important; }\n  .mt-md-3 {\n    margin-top: 3rem !important; }\n  .mr-md-3 {\n    margin-right: 3rem !important; }\n  .mb-md-3 {\n    margin-bottom: 3rem !important; }\n  .ml-md-3 {\n    margin-left: 3rem !important; }\n  .mx-md-3 {\n    margin-right: 3rem !important;\n    margin-left: 3rem !important; }\n  .my-md-3 {\n    margin-top: 3rem !important;\n    margin-bottom: 3rem !important; }\n  .p-md-q {\n    padding: 0.25rem 0.25rem !important; }\n  .pt-md-q {\n    padding-top: 0.25rem !important; }\n  .pr-md-q {\n    padding-right: 0.25rem !important; }\n  .pb-md-q {\n    padding-bottom: 0.25rem !important; }\n  .pl-md-q {\n    padding-left: 0.25rem !important; }\n  .px-md-q {\n    padding-right: 0.25rem !important;\n    padding-left: 0.25rem !important; }\n  .py-md-q {\n    padding-top: 0.25rem !important;\n    padding-bottom: 0.25rem !important; }\n  .p-md-h {\n    padding: 0.5rem 0.5rem !important; }\n  .pt-md-h {\n    padding-top: 0.5rem !important; }\n  .pr-md-h {\n    padding-right: 0.5rem !important; }\n  .pb-md-h {\n    padding-bottom: 0.5rem !important; }\n  .pl-md-h {\n    padding-left: 0.5rem !important; }\n  .px-md-h {\n    padding-right: 0.5rem !important;\n    padding-left: 0.5rem !important; }\n  .py-md-h {\n    padding-top: 0.5rem !important;\n    padding-bottom: 0.5rem !important; }\n  .p-md-0 {\n    padding: 0 0 !important; }\n  .pt-md-0 {\n    padding-top: 0 !important; }\n  .pr-md-0 {\n    padding-right: 0 !important; }\n  .pb-md-0 {\n    padding-bottom: 0 !important; }\n  .pl-md-0 {\n    padding-left: 0 !important; }\n  .px-md-0 {\n    padding-right: 0 !important;\n    padding-left: 0 !important; }\n  .py-md-0 {\n    padding-top: 0 !important;\n    padding-bottom: 0 !important; }\n  .p-md-1 {\n    padding: 1rem 1rem !important; }\n  .pt-md-1 {\n    padding-top: 1rem !important; }\n  .pr-md-1 {\n    padding-right: 1rem !important; }\n  .pb-md-1 {\n    padding-bottom: 1rem !important; }\n  .pl-md-1 {\n    padding-left: 1rem !important; }\n  .px-md-1 {\n    padding-right: 1rem !important;\n    padding-left: 1rem !important; }\n  .py-md-1 {\n    padding-top: 1rem !important;\n    padding-bottom: 1rem !important; }\n  .p-md-2 {\n    padding: 1.5rem 1.5rem !important; }\n  .pt-md-2 {\n    padding-top: 1.5rem !important; }\n  .pr-md-2 {\n    padding-right: 1.5rem !important; }\n  .pb-md-2 {\n    padding-bottom: 1.5rem !important; }\n  .pl-md-2 {\n    padding-left: 1.5rem !important; }\n  .px-md-2 {\n    padding-right: 1.5rem !important;\n    padding-left: 1.5rem !important; }\n  .py-md-2 {\n    padding-top: 1.5rem !important;\n    padding-bottom: 1.5rem !important; }\n  .p-md-3 {\n    padding: 3rem 3rem !important; }\n  .pt-md-3 {\n    padding-top: 3rem !important; }\n  .pr-md-3 {\n    padding-right: 3rem !important; }\n  .pb-md-3 {\n    padding-bottom: 3rem !important; }\n  .pl-md-3 {\n    padding-left: 3rem !important; }\n  .px-md-3 {\n    padding-right: 3rem !important;\n    padding-left: 3rem !important; }\n  .py-md-3 {\n    padding-top: 3rem !important;\n    padding-bottom: 3rem !important; }\n  .m-md-auto {\n    margin: auto !important; }\n  .mt-md-auto {\n    margin-top: auto !important; }\n  .mr-md-auto {\n    margin-right: auto !important; }\n  .mb-md-auto {\n    margin-bottom: auto !important; }\n  .ml-md-auto {\n    margin-left: auto !important; }\n  .mx-md-auto {\n    margin-right: auto !important;\n    margin-left: auto !important; }\n  .my-md-auto {\n    margin-top: auto !important;\n    margin-bottom: auto !important; } }\n\n@media (min-width: 992px) {\n  .m-lg-q {\n    margin: 0.25rem 0.25rem !important; }\n  .mt-lg-q {\n    margin-top: 0.25rem !important; }\n  .mr-lg-q {\n    margin-right: 0.25rem !important; }\n  .mb-lg-q {\n    margin-bottom: 0.25rem !important; }\n  .ml-lg-q {\n    margin-left: 0.25rem !important; }\n  .mx-lg-q {\n    margin-right: 0.25rem !important;\n    margin-left: 0.25rem !important; }\n  .my-lg-q {\n    margin-top: 0.25rem !important;\n    margin-bottom: 0.25rem !important; }\n  .m-lg-h {\n    margin: 0.5rem 0.5rem !important; }\n  .mt-lg-h {\n    margin-top: 0.5rem !important; }\n  .mr-lg-h {\n    margin-right: 0.5rem !important; }\n  .mb-lg-h {\n    margin-bottom: 0.5rem !important; }\n  .ml-lg-h {\n    margin-left: 0.5rem !important; }\n  .mx-lg-h {\n    margin-right: 0.5rem !important;\n    margin-left: 0.5rem !important; }\n  .my-lg-h {\n    margin-top: 0.5rem !important;\n    margin-bottom: 0.5rem !important; }\n  .m-lg-0 {\n    margin: 0 0 !important; }\n  .mt-lg-0 {\n    margin-top: 0 !important; }\n  .mr-lg-0 {\n    margin-right: 0 !important; }\n  .mb-lg-0 {\n    margin-bottom: 0 !important; }\n  .ml-lg-0 {\n    margin-left: 0 !important; }\n  .mx-lg-0 {\n    margin-right: 0 !important;\n    margin-left: 0 !important; }\n  .my-lg-0 {\n    margin-top: 0 !important;\n    margin-bottom: 0 !important; }\n  .m-lg-1 {\n    margin: 1rem 1rem !important; }\n  .mt-lg-1 {\n    margin-top: 1rem !important; }\n  .mr-lg-1 {\n    margin-right: 1rem !important; }\n  .mb-lg-1 {\n    margin-bottom: 1rem !important; }\n  .ml-lg-1 {\n    margin-left: 1rem !important; }\n  .mx-lg-1 {\n    margin-right: 1rem !important;\n    margin-left: 1rem !important; }\n  .my-lg-1 {\n    margin-top: 1rem !important;\n    margin-bottom: 1rem !important; }\n  .m-lg-2 {\n    margin: 1.5rem 1.5rem !important; }\n  .mt-lg-2 {\n    margin-top: 1.5rem !important; }\n  .mr-lg-2 {\n    margin-right: 1.5rem !important; }\n  .mb-lg-2 {\n    margin-bottom: 1.5rem !important; }\n  .ml-lg-2 {\n    margin-left: 1.5rem !important; }\n  .mx-lg-2 {\n    margin-right: 1.5rem !important;\n    margin-left: 1.5rem !important; }\n  .my-lg-2 {\n    margin-top: 1.5rem !important;\n    margin-bottom: 1.5rem !important; }\n  .m-lg-3 {\n    margin: 3rem 3rem !important; }\n  .mt-lg-3 {\n    margin-top: 3rem !important; }\n  .mr-lg-3 {\n    margin-right: 3rem !important; }\n  .mb-lg-3 {\n    margin-bottom: 3rem !important; }\n  .ml-lg-3 {\n    margin-left: 3rem !important; }\n  .mx-lg-3 {\n    margin-right: 3rem !important;\n    margin-left: 3rem !important; }\n  .my-lg-3 {\n    margin-top: 3rem !important;\n    margin-bottom: 3rem !important; }\n  .p-lg-q {\n    padding: 0.25rem 0.25rem !important; }\n  .pt-lg-q {\n    padding-top: 0.25rem !important; }\n  .pr-lg-q {\n    padding-right: 0.25rem !important; }\n  .pb-lg-q {\n    padding-bottom: 0.25rem !important; }\n  .pl-lg-q {\n    padding-left: 0.25rem !important; }\n  .px-lg-q {\n    padding-right: 0.25rem !important;\n    padding-left: 0.25rem !important; }\n  .py-lg-q {\n    padding-top: 0.25rem !important;\n    padding-bottom: 0.25rem !important; }\n  .p-lg-h {\n    padding: 0.5rem 0.5rem !important; }\n  .pt-lg-h {\n    padding-top: 0.5rem !important; }\n  .pr-lg-h {\n    padding-right: 0.5rem !important; }\n  .pb-lg-h {\n    padding-bottom: 0.5rem !important; }\n  .pl-lg-h {\n    padding-left: 0.5rem !important; }\n  .px-lg-h {\n    padding-right: 0.5rem !important;\n    padding-left: 0.5rem !important; }\n  .py-lg-h {\n    padding-top: 0.5rem !important;\n    padding-bottom: 0.5rem !important; }\n  .p-lg-0 {\n    padding: 0 0 !important; }\n  .pt-lg-0 {\n    padding-top: 0 !important; }\n  .pr-lg-0 {\n    padding-right: 0 !important; }\n  .pb-lg-0 {\n    padding-bottom: 0 !important; }\n  .pl-lg-0 {\n    padding-left: 0 !important; }\n  .px-lg-0 {\n    padding-right: 0 !important;\n    padding-left: 0 !important; }\n  .py-lg-0 {\n    padding-top: 0 !important;\n    padding-bottom: 0 !important; }\n  .p-lg-1 {\n    padding: 1rem 1rem !important; }\n  .pt-lg-1 {\n    padding-top: 1rem !important; }\n  .pr-lg-1 {\n    padding-right: 1rem !important; }\n  .pb-lg-1 {\n    padding-bottom: 1rem !important; }\n  .pl-lg-1 {\n    padding-left: 1rem !important; }\n  .px-lg-1 {\n    padding-right: 1rem !important;\n    padding-left: 1rem !important; }\n  .py-lg-1 {\n    padding-top: 1rem !important;\n    padding-bottom: 1rem !important; }\n  .p-lg-2 {\n    padding: 1.5rem 1.5rem !important; }\n  .pt-lg-2 {\n    padding-top: 1.5rem !important; }\n  .pr-lg-2 {\n    padding-right: 1.5rem !important; }\n  .pb-lg-2 {\n    padding-bottom: 1.5rem !important; }\n  .pl-lg-2 {\n    padding-left: 1.5rem !important; }\n  .px-lg-2 {\n    padding-right: 1.5rem !important;\n    padding-left: 1.5rem !important; }\n  .py-lg-2 {\n    padding-top: 1.5rem !important;\n    padding-bottom: 1.5rem !important; }\n  .p-lg-3 {\n    padding: 3rem 3rem !important; }\n  .pt-lg-3 {\n    padding-top: 3rem !important; }\n  .pr-lg-3 {\n    padding-right: 3rem !important; }\n  .pb-lg-3 {\n    padding-bottom: 3rem !important; }\n  .pl-lg-3 {\n    padding-left: 3rem !important; }\n  .px-lg-3 {\n    padding-right: 3rem !important;\n    padding-left: 3rem !important; }\n  .py-lg-3 {\n    padding-top: 3rem !important;\n    padding-bottom: 3rem !important; }\n  .m-lg-auto {\n    margin: auto !important; }\n  .mt-lg-auto {\n    margin-top: auto !important; }\n  .mr-lg-auto {\n    margin-right: auto !important; }\n  .mb-lg-auto {\n    margin-bottom: auto !important; }\n  .ml-lg-auto {\n    margin-left: auto !important; }\n  .mx-lg-auto {\n    margin-right: auto !important;\n    margin-left: auto !important; }\n  .my-lg-auto {\n    margin-top: auto !important;\n    margin-bottom: auto !important; } }\n\n@media (min-width: 1200px) {\n  .m-xl-q {\n    margin: 0.25rem 0.25rem !important; }\n  .mt-xl-q {\n    margin-top: 0.25rem !important; }\n  .mr-xl-q {\n    margin-right: 0.25rem !important; }\n  .mb-xl-q {\n    margin-bottom: 0.25rem !important; }\n  .ml-xl-q {\n    margin-left: 0.25rem !important; }\n  .mx-xl-q {\n    margin-right: 0.25rem !important;\n    margin-left: 0.25rem !important; }\n  .my-xl-q {\n    margin-top: 0.25rem !important;\n    margin-bottom: 0.25rem !important; }\n  .m-xl-h {\n    margin: 0.5rem 0.5rem !important; }\n  .mt-xl-h {\n    margin-top: 0.5rem !important; }\n  .mr-xl-h {\n    margin-right: 0.5rem !important; }\n  .mb-xl-h {\n    margin-bottom: 0.5rem !important; }\n  .ml-xl-h {\n    margin-left: 0.5rem !important; }\n  .mx-xl-h {\n    margin-right: 0.5rem !important;\n    margin-left: 0.5rem !important; }\n  .my-xl-h {\n    margin-top: 0.5rem !important;\n    margin-bottom: 0.5rem !important; }\n  .m-xl-0 {\n    margin: 0 0 !important; }\n  .mt-xl-0 {\n    margin-top: 0 !important; }\n  .mr-xl-0 {\n    margin-right: 0 !important; }\n  .mb-xl-0 {\n    margin-bottom: 0 !important; }\n  .ml-xl-0 {\n    margin-left: 0 !important; }\n  .mx-xl-0 {\n    margin-right: 0 !important;\n    margin-left: 0 !important; }\n  .my-xl-0 {\n    margin-top: 0 !important;\n    margin-bottom: 0 !important; }\n  .m-xl-1 {\n    margin: 1rem 1rem !important; }\n  .mt-xl-1 {\n    margin-top: 1rem !important; }\n  .mr-xl-1 {\n    margin-right: 1rem !important; }\n  .mb-xl-1 {\n    margin-bottom: 1rem !important; }\n  .ml-xl-1 {\n    margin-left: 1rem !important; }\n  .mx-xl-1 {\n    margin-right: 1rem !important;\n    margin-left: 1rem !important; }\n  .my-xl-1 {\n    margin-top: 1rem !important;\n    margin-bottom: 1rem !important; }\n  .m-xl-2 {\n    margin: 1.5rem 1.5rem !important; }\n  .mt-xl-2 {\n    margin-top: 1.5rem !important; }\n  .mr-xl-2 {\n    margin-right: 1.5rem !important; }\n  .mb-xl-2 {\n    margin-bottom: 1.5rem !important; }\n  .ml-xl-2 {\n    margin-left: 1.5rem !important; }\n  .mx-xl-2 {\n    margin-right: 1.5rem !important;\n    margin-left: 1.5rem !important; }\n  .my-xl-2 {\n    margin-top: 1.5rem !important;\n    margin-bottom: 1.5rem !important; }\n  .m-xl-3 {\n    margin: 3rem 3rem !important; }\n  .mt-xl-3 {\n    margin-top: 3rem !important; }\n  .mr-xl-3 {\n    margin-right: 3rem !important; }\n  .mb-xl-3 {\n    margin-bottom: 3rem !important; }\n  .ml-xl-3 {\n    margin-left: 3rem !important; }\n  .mx-xl-3 {\n    margin-right: 3rem !important;\n    margin-left: 3rem !important; }\n  .my-xl-3 {\n    margin-top: 3rem !important;\n    margin-bottom: 3rem !important; }\n  .p-xl-q {\n    padding: 0.25rem 0.25rem !important; }\n  .pt-xl-q {\n    padding-top: 0.25rem !important; }\n  .pr-xl-q {\n    padding-right: 0.25rem !important; }\n  .pb-xl-q {\n    padding-bottom: 0.25rem !important; }\n  .pl-xl-q {\n    padding-left: 0.25rem !important; }\n  .px-xl-q {\n    padding-right: 0.25rem !important;\n    padding-left: 0.25rem !important; }\n  .py-xl-q {\n    padding-top: 0.25rem !important;\n    padding-bottom: 0.25rem !important; }\n  .p-xl-h {\n    padding: 0.5rem 0.5rem !important; }\n  .pt-xl-h {\n    padding-top: 0.5rem !important; }\n  .pr-xl-h {\n    padding-right: 0.5rem !important; }\n  .pb-xl-h {\n    padding-bottom: 0.5rem !important; }\n  .pl-xl-h {\n    padding-left: 0.5rem !important; }\n  .px-xl-h {\n    padding-right: 0.5rem !important;\n    padding-left: 0.5rem !important; }\n  .py-xl-h {\n    padding-top: 0.5rem !important;\n    padding-bottom: 0.5rem !important; }\n  .p-xl-0 {\n    padding: 0 0 !important; }\n  .pt-xl-0 {\n    padding-top: 0 !important; }\n  .pr-xl-0 {\n    padding-right: 0 !important; }\n  .pb-xl-0 {\n    padding-bottom: 0 !important; }\n  .pl-xl-0 {\n    padding-left: 0 !important; }\n  .px-xl-0 {\n    padding-right: 0 !important;\n    padding-left: 0 !important; }\n  .py-xl-0 {\n    padding-top: 0 !important;\n    padding-bottom: 0 !important; }\n  .p-xl-1 {\n    padding: 1rem 1rem !important; }\n  .pt-xl-1 {\n    padding-top: 1rem !important; }\n  .pr-xl-1 {\n    padding-right: 1rem !important; }\n  .pb-xl-1 {\n    padding-bottom: 1rem !important; }\n  .pl-xl-1 {\n    padding-left: 1rem !important; }\n  .px-xl-1 {\n    padding-right: 1rem !important;\n    padding-left: 1rem !important; }\n  .py-xl-1 {\n    padding-top: 1rem !important;\n    padding-bottom: 1rem !important; }\n  .p-xl-2 {\n    padding: 1.5rem 1.5rem !important; }\n  .pt-xl-2 {\n    padding-top: 1.5rem !important; }\n  .pr-xl-2 {\n    padding-right: 1.5rem !important; }\n  .pb-xl-2 {\n    padding-bottom: 1.5rem !important; }\n  .pl-xl-2 {\n    padding-left: 1.5rem !important; }\n  .px-xl-2 {\n    padding-right: 1.5rem !important;\n    padding-left: 1.5rem !important; }\n  .py-xl-2 {\n    padding-top: 1.5rem !important;\n    padding-bottom: 1.5rem !important; }\n  .p-xl-3 {\n    padding: 3rem 3rem !important; }\n  .pt-xl-3 {\n    padding-top: 3rem !important; }\n  .pr-xl-3 {\n    padding-right: 3rem !important; }\n  .pb-xl-3 {\n    padding-bottom: 3rem !important; }\n  .pl-xl-3 {\n    padding-left: 3rem !important; }\n  .px-xl-3 {\n    padding-right: 3rem !important;\n    padding-left: 3rem !important; }\n  .py-xl-3 {\n    padding-top: 3rem !important;\n    padding-bottom: 3rem !important; }\n  .m-xl-auto {\n    margin: auto !important; }\n  .mt-xl-auto {\n    margin-top: auto !important; }\n  .mr-xl-auto {\n    margin-right: auto !important; }\n  .mb-xl-auto {\n    margin-bottom: auto !important; }\n  .ml-xl-auto {\n    margin-left: auto !important; }\n  .mx-xl-auto {\n    margin-right: auto !important;\n    margin-left: auto !important; }\n  .my-xl-auto {\n    margin-top: auto !important;\n    margin-bottom: auto !important; } }\n\n.text-justify {\n  text-align: justify !important; }\n\n.text-nowrap {\n  white-space: nowrap !important; }\n\n.text-truncate {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap; }\n\n.text-left {\n  text-align: left !important; }\n\n.text-right {\n  text-align: right !important; }\n\n.text-center {\n  text-align: center !important; }\n\n@media (min-width: 576px) {\n  .text-sm-left {\n    text-align: left !important; }\n  .text-sm-right {\n    text-align: right !important; }\n  .text-sm-center {\n    text-align: center !important; } }\n\n@media (min-width: 768px) {\n  .text-md-left {\n    text-align: left !important; }\n  .text-md-right {\n    text-align: right !important; }\n  .text-md-center {\n    text-align: center !important; } }\n\n@media (min-width: 992px) {\n  .text-lg-left {\n    text-align: left !important; }\n  .text-lg-right {\n    text-align: right !important; }\n  .text-lg-center {\n    text-align: center !important; } }\n\n@media (min-width: 1200px) {\n  .text-xl-left {\n    text-align: left !important; }\n  .text-xl-right {\n    text-align: right !important; }\n  .text-xl-center {\n    text-align: center !important; } }\n\n.text-lowercase {\n  text-transform: lowercase !important; }\n\n.text-uppercase {\n  text-transform: uppercase !important; }\n\n.text-capitalize {\n  text-transform: capitalize !important; }\n\n.font-weight-normal {\n  font-weight: normal; }\n\n.font-weight-bold {\n  font-weight: bold; }\n\n.font-italic {\n  font-style: italic; }\n\n.text-white {\n  color: #fff !important; }\n\n.text-muted {\n  color: #818a91 !important; }\n\na.text-muted:focus, a.text-muted:hover {\n  color: #687077 !important; }\n\n.text-primary {\n  color: #20a8d8 !important; }\n\na.text-primary:focus, a.text-primary:hover {\n  color: #1985ac !important; }\n\n.text-success {\n  color: #4dbd74 !important; }\n\na.text-success:focus, a.text-success:hover {\n  color: #3a9d5d !important; }\n\n.text-info {\n  color: #63c2de !important; }\n\na.text-info:focus, a.text-info:hover {\n  color: #39b2d5 !important; }\n\n.text-warning {\n  color: #f8cb00 !important; }\n\na.text-warning:focus, a.text-warning:hover {\n  color: #c5a100 !important; }\n\n.text-danger {\n  color: #f86c6b !important; }\n\na.text-danger:focus, a.text-danger:hover {\n  color: #f63c3a !important; }\n\n.text-gray-dark {\n  color: #2a2c36 !important; }\n\na.text-gray-dark:focus, a.text-gray-dark:hover {\n  color: #141519 !important; }\n\n.text-hide {\n  font: 0/0 a;\n  color: transparent;\n  text-shadow: none;\n  background-color: transparent;\n  border: 0; }\n\n.invisible {\n  visibility: hidden !important; }\n\n.hidden-xs-up {\n  display: none !important; }\n\n@media (max-width: 575px) {\n  .hidden-xs-down {\n    display: none !important; } }\n\n@media (min-width: 576px) {\n  .hidden-sm-up {\n    display: none !important; } }\n\n@media (max-width: 767px) {\n  .hidden-sm-down {\n    display: none !important; } }\n\n@media (min-width: 768px) {\n  .hidden-md-up {\n    display: none !important; } }\n\n@media (max-width: 991px) {\n  .hidden-md-down {\n    display: none !important; } }\n\n@media (min-width: 992px) {\n  .hidden-lg-up {\n    display: none !important; } }\n\n@media (max-width: 1199px) {\n  .hidden-lg-down {\n    display: none !important; } }\n\n@media (min-width: 1200px) {\n  .hidden-xl-up {\n    display: none !important; } }\n\n.hidden-xl-down {\n  display: none !important; }\n\n.visible-print-block {\n  display: none !important; }\n  @media print {\n    .visible-print-block {\n      display: block !important; } }\n\n.visible-print-inline {\n  display: none !important; }\n  @media print {\n    .visible-print-inline {\n      display: inline !important; } }\n\n.visible-print-inline-block {\n  display: none !important; }\n  @media print {\n    .visible-print-inline-block {\n      display: inline-block !important; } }\n\n@media print {\n  .hidden-print {\n    display: none !important; } }\n\n.cal-month-view .cal-header {\n  text-align: center;\n  font-weight: bolder; }\n\n.cal-month-view .cal-cell-row:hover {\n  background-color: #f8f9fa; }\n\n.cal-month-view .cal-header .cal-cell {\n  padding: 5px 0;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  display: block;\n  white-space: nowrap; }\n\n.cal-month-view .cal-cell-row .cal-cell:hover,\n.cal-month-view .cal-cell.cal-has-events.cal-open {\n  background-color: #f8f9fa; }\n\n.cal-month-view .cal-days {\n  border: 1px solid #d1d4d7;\n  border-bottom: 0; }\n\n.cal-month-view .cal-cell-top {\n  min-height: 62px; }\n\n.cal-month-view .cal-cell-row {\n  display: flex; }\n\n.cal-month-view .cal-cell {\n  float: left;\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  align-items: stretch; }\n\n.cal-month-view .cal-day-cell {\n  min-height: 100px; }\n\n.cal-month-view .cal-day-cell:not(:last-child) {\n  border-right: 1px solid #d1d4d7; }\n\n.cal-month-view .cal-days .cal-cell-row {\n  border-bottom: 1px solid #d1d4d7; }\n\n.cal-month-view .cal-day-badge {\n  margin-top: 18px;\n  margin-left: 10px;\n  background-color: #f86c6b;\n  display: inline-block;\n  min-width: 10px;\n  padding: 3px 7px;\n  font-size: 12px;\n  font-weight: 700;\n  line-height: 1;\n  color: white;\n  text-align: center;\n  white-space: nowrap;\n  vertical-align: middle;\n  border-radius: 10px; }\n\n.cal-month-view .cal-day-number {\n  font-size: 1.2em;\n  font-weight: 400;\n  opacity: 0.5;\n  margin-top: 15px;\n  margin-right: 15px;\n  float: right;\n  margin-bottom: 10px; }\n\n.cal-month-view .cal-events {\n  flex: 1;\n  align-items: flex-end;\n  margin: 3px;\n  line-height: 10px;\n  display: flex;\n  flex-wrap: wrap; }\n\n.cal-month-view .cal-event {\n  width: 10px;\n  height: 10px;\n  border-radius: 50%;\n  display: inline-block;\n  margin: 2px; }\n\n.cal-month-view .cal-day-cell.cal-in-month.cal-has-events {\n  cursor: pointer; }\n\n.cal-month-view .cal-day-cell.cal-out-month .cal-day-number {\n  opacity: 0.1;\n  cursor: default; }\n\n.cal-month-view .cal-day-cell.cal-weekend .cal-day-number {\n  color: darkred; }\n\n.cal-month-view .cal-day-cell.cal-today {\n  background-color: e8fde7; }\n\n.cal-month-view .cal-day-cell.cal-today .cal-day-number {\n  font-size: 1.9em; }\n\n.cal-month-view .cal-open-day-events {\n  padding: 15px;\n  color: white;\n  background-color: #55595c; }\n\n.cal-month-view .cal-open-day-events .cal-event {\n  position: relative;\n  top: 2px; }\n\n.cal-month-view .cal-event-title {\n  color: white; }\n\n.cal-month-view .cal-out-month .cal-day-badge,\n.cal-month-view .cal-out-month .cal-event {\n  opacity: 0.3; }\n\n.cal-week-view .cal-day-headers {\n  display: flex;\n  margin-bottom: 3px;\n  border: 1px solid #d1d4d7;\n  margin-left: 2px;\n  margin-right: 2px; }\n\n.cal-week-view .cal-day-headers .cal-header {\n  flex: 1;\n  text-align: center;\n  padding: 5px; }\n\n.cal-week-view .cal-day-headers .cal-header:not(:last-child) {\n  border-right: 1px solid #d1d4d7; }\n\n.cal-week-view .cal-day-headers .cal-header:hover {\n  background-color: #f8f9fa; }\n\n.cal-week-view .cal-day-headers span {\n  font-weight: 400;\n  opacity: 0.5; }\n\n.cal-week-view .cal-event-container {\n  display: inline-block; }\n\n.cal-week-view .cal-event {\n  padding: 0 10px;\n  font-size: 12px;\n  margin-left: 2px;\n  margin-right: 2px;\n  height: 30px;\n  line-height: 30px; }\n\n.cal-week-view .cal-event.cal-starts-within-week {\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px; }\n\n.cal-week-view .cal-event.cal-ends-within-week {\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px; }\n\n.cal-week-view .cal-header.cal-today {\n  background-color: #aadfbd; }\n\n.cal-week-view .cal-header.cal-weekend span {\n  color: #f86c6b; }\n\n.cal-week-view .cal-event,\n.cal-week-view .cal-header {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap; }\n\n.cal-day-view .cal-hour-rows {\n  width: 100%;\n  border: solid 1px #d1d4d7;\n  overflow-x: scroll;\n  position: relative; }\n\n.cal-day-view .cal-hour:nth-child(odd) {\n  background-color: #f8f9fa; }\n\n.cal-day-view .cal-hour-segment {\n  height: 30px; }\n\n.cal-day-view .cal-hour:not(:last-child) .cal-hour-segment,\n.cal-day-view .cal-hour:last-child :not(:last-child) .cal-hour-segment {\n  border-bottom: thin dashed #d1d4d7; }\n\n.cal-day-view .cal-time {\n  font-weight: bold;\n  padding-top: 5px;\n  width: 70px;\n  text-align: center; }\n\n.cal-day-view .cal-hour-segment:hover {\n  background-color: #d1d4d7; }\n\n.cal-day-view .cal-event {\n  position: absolute;\n  border: solid 1px;\n  padding: 5px;\n  font-size: 12px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap; }\n\n.cal-day-view .cal-event.cal-starts-within-day {\n  border-top-left-radius: 5px;\n  border-top-right-radius: 5px; }\n\n.cal-day-view .cal-event.cal-ends-within-day {\n  border-bottom-left-radius: 5px;\n  border-bottom-right-radius: 5px; }\n\n.cal-day-view .cal-all-day-event {\n  padding: 8px;\n  border: solid 1px; }\n\n.chart-legend,\n.bar-legend,\n.line-legend,\n.pie-legend,\n.radar-legend,\n.polararea-legend,\n.doughnut-legend {\n  list-style-type: none;\n  margin-top: 5px;\n  text-align: center;\n  -webkit-padding-start: 0;\n  -moz-padding-start: 0;\n  padding-left: 0; }\n\n.chart-legend li,\n.bar-legend li,\n.line-legend li,\n.pie-legend li,\n.radar-legend li,\n.polararea-legend li,\n.doughnut-legend li {\n  display: inline-block;\n  white-space: nowrap;\n  position: relative;\n  margin-bottom: 4px;\n  padding: 2px 8px 2px 28px;\n  font-size: smaller;\n  cursor: default; }\n\n.chart-legend li span,\n.bar-legend li span,\n.line-legend li span,\n.pie-legend li span,\n.radar-legend li span,\n.polararea-legend li span,\n.doughnut-legend li span {\n  display: block;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px; }\n\n/*!\n* angular-datatables - v0.5.0\n* https://github.com/l-lin/angular-datatables\n* License: MIT\n*/\ndiv.dataTables_length label {\n  font-weight: normal;\n  float: left;\n  text-align: left; }\n\ndiv.dataTables_length select {\n  width: 75px; }\n\ndiv.dataTables_filter label {\n  font-weight: normal;\n  float: right; }\n\ndiv.dataTables_filter input {\n  width: 16em; }\n\ndiv.dataTables_info {\n  padding-top: 8px; }\n\ndiv.dataTables_paginate {\n  float: right;\n  margin: 0; }\n\ndiv.dataTables_paginate ul.pagination {\n  margin: 2px; }\n\ntable.table {\n  clear: both;\n  max-width: none !important; }\n\ntable.table thead .sorting,\ntable.table thead .sorting_asc,\ntable.table thead .sorting_desc,\ntable.table thead .sorting_asc_disabled,\ntable.table thead .sorting_desc_disabled {\n  cursor: pointer;\n  background: none; }\n\ntable.table thead .sorting:before {\n  content: ' ';\n  position: relative;\n  left: -5px; }\n\ntable.table thead .sorting_desc:before {\n  content: \"\\2193\";\n  padding-right: 5px; }\n\ntable.table thead .sorting_asc:before {\n  content: \"\\2191\";\n  padding-right: 5px; }\n\n.dataTables_scrollBody table.table thead .sorting:before,\n.dataTables_scrollBody table.table thead .sorting_desc:before,\n.dataTables_scrollBody table.table thead .sorting_asc:before {\n  content: '';\n  padding-right: 0; }\n\ntable.dataTable th:active {\n  outline: none; }\n\n.dataTables_wrapper .row {\n  margin-top: 20px; }\n\n/* Scrolling */\ndiv.dataTables_scrollHead table {\n  margin-bottom: 0 !important;\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0; }\n\ndiv.dataTables_scrollHead table thead tr:last-child th:first-child, div.dataTables_scrollHead table thead tr:last-child td:first-child {\n  border-bottom-left-radius: 0 !important;\n  border-bottom-right-radius: 0 !important; }\n\ndiv.dataTables_scrollBody table {\n  border-top: none;\n  margin-bottom: 0 !important; }\n\ndiv.dataTables_scrollBody tbody tr:first-child th, div.dataTables_scrollBody tbody tr:first-child td {\n  border-top: none; }\n\ndiv.dataTables_scrollFoot table {\n  border-top: none; }\n\n/*\n* TableTools styles\n*/\n/*\n.table tbody tr.active td, .table tbody tr.active th {\nbackground-color: #08C;\ncolor: white;\n}\n.table tbody tr.active:hover td, .table tbody tr.active:hover th {\nbackground-color: #0075b0 !important;\n}\n.table-striped tbody tr.active:nth-child(odd) td, .table-striped tbody tr.active:nth-child(odd) th {\nbackground-color: #017ebc;\n}\n*/\ntable.DTTT_selectable tbody tr {\n  cursor: pointer; }\n\ndiv.DTTT .btn, div.DTTT .fc button, .fc div.DTTT button {\n  color: #333 !important; }\n\ndiv.DTTT .btn:hover, div.DTTT .fc button:hover, .fc div.DTTT button:hover {\n  text-decoration: none !important; }\n\nul.DTTT_dropdown.dropdown-menu {\n  z-index: 2003; }\n\nul.DTTT_dropdown.dropdown-menu a {\n  color: #333 !important; }\n\nul.DTTT_dropdown.dropdown-menu li {\n  position: relative; }\n\nul.DTTT_dropdown.dropdown-menu li:hover a {\n  background-color: #0088cc;\n  color: white !important; }\n\ndiv.DTTT_collection_background {\n  z-index: 2002; }\n\n/* TableTools information display */\ndiv.DTTT_print_info.modal {\n  height: 150px;\n  margin-top: -75px;\n  text-align: center; }\n\ndiv.DTTT_print_info h6 {\n  font-weight: normal;\n  font-size: 28px;\n  line-height: 28px;\n  margin: 1em; }\n\ndiv.DTTT_print_info p {\n  font-size: 14px;\n  line-height: 20px; }\n\n/*\n* FixedColumns styles\n*/\ndiv.DTFC_LeftHeadWrapper table, div.DTFC_LeftFootWrapper table, div.DTFC_RightHeadWrapper table, div.DTFC_RightFootWrapper table, table.DTFC_Cloned tr.even {\n  background-color: white; }\n\ndiv.DTFC_RightHeadWrapper table, div.DTFC_LeftHeadWrapper table {\n  margin-bottom: 0 !important;\n  border-top-right-radius: 0 !important;\n  border-bottom-left-radius: 0 !important;\n  border-bottom-right-radius: 0 !important; }\n\ndiv.DTFC_RightHeadWrapper table thead tr:last-child th:first-child, div.DTFC_RightHeadWrapper table thead tr:last-child td:first-child, div.DTFC_LeftHeadWrapper table thead tr:last-child th:first-child, div.DTFC_LeftHeadWrapper table thead tr:last-child td:first-child {\n  border-bottom-left-radius: 0 !important;\n  border-bottom-right-radius: 0 !important; }\n\ndiv.DTFC_RightBodyWrapper table, div.DTFC_LeftBodyWrapper table {\n  border-top: none;\n  margin-bottom: 0 !important; }\n\ndiv.DTFC_RightBodyWrapper tbody tr:first-child th, div.DTFC_RightBodyWrapper tbody tr:first-child td, div.DTFC_LeftBodyWrapper tbody tr:first-child th, div.DTFC_LeftBodyWrapper tbody tr:first-child td {\n  border-top: none; }\n\ndiv.DTFC_RightFootWrapper table, div.DTFC_LeftFootWrapper table {\n  border-top: none; }\n\n/*\n* ColVis\n*/\nul.ColVis_collection {\n  width: auto !important; }\n\n/*\n* Server side processing\n*/\n.dataTables_wrapper {\n  position: relative; }\n\n.dataTables_wrapper .dataTables_processing {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  width: 100%;\n  height: 40px;\n  margin-left: -50%;\n  margin-top: -25px;\n  padding-top: 20px;\n  text-align: center;\n  font-size: 1.2em;\n  background-color: white;\n  background: -webkit-gradient(linear, left top, right top, color-stop(0%, rgba(255, 255, 255, 0)), color-stop(25%, rgba(255, 255, 255, 0.9)), color-stop(75%, rgba(255, 255, 255, 0.9)), color-stop(100%, rgba(255, 255, 255, 0)));\n  /* Chrome,Safari4+ */\n  background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.9) 25%, rgba(255, 255, 255, 0.9) 75%, rgba(255, 255, 255, 0) 100%);\n  /* Chrome10+,Safari5.1+ */\n  background: -moz-linear-gradient(left, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.9) 25%, rgba(255, 255, 255, 0.9) 75%, rgba(255, 255, 255, 0) 100%);\n  /* FF3.6+ */\n  background: -ms-linear-gradient(left, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.9) 25%, rgba(255, 255, 255, 0.9) 75%, rgba(255, 255, 255, 0) 100%);\n  /* IE10+ */\n  background: -o-linear-gradient(left, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.9) 25%, rgba(255, 255, 255, 0.9) 75%, rgba(255, 255, 255, 0) 100%);\n  /* Opera 11.10+ */\n  background: linear-gradient(to right, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.9) 25%, rgba(255, 255, 255, 0.9) 75%, rgba(255, 255, 255, 0) 100%);\n  /* W3C */ }\n\n.dataTables_wrapper .dataTables_processing {\n  color: #333333; }\n\n/**\n* A stylesheet for use with Bootstrap 3.x\n* @author: Dan Grossman http://www.dangrossman.info/\n* @copyright: Copyright (c) 2012-2015 Dan Grossman. All rights reserved.\n* @license: Licensed under the MIT license. See http://www.opensource.org/licenses/mit-license.php\n* @website: https://www.improvely.com/\n*/\n/* Container Appearance */\n.daterangepicker {\n  position: absolute;\n  background: #fff;\n  top: 100px;\n  left: 20px;\n  padding: 4px;\n  margin-top: 1px;\n  width: 278px; }\n\n.daterangepicker.opensleft:before {\n  position: absolute;\n  top: -7px;\n  right: 9px;\n  display: inline-block;\n  border-right: 7px solid transparent;\n  border-bottom: 7px solid #d1d4d7;\n  border-left: 7px solid transparent;\n  border-bottom-color: #d1d4d7;\n  content: ''; }\n\n.daterangepicker.opensleft:after {\n  position: absolute;\n  top: -6px;\n  right: 10px;\n  display: inline-block;\n  border-right: 6px solid transparent;\n  border-bottom: 6px solid #fff;\n  border-left: 6px solid transparent;\n  content: ''; }\n\n.daterangepicker.openscenter:before {\n  position: absolute;\n  top: -7px;\n  left: 0;\n  right: 0;\n  width: 0;\n  margin-left: auto;\n  margin-right: auto;\n  display: inline-block;\n  border-right: 7px solid transparent;\n  border-bottom: 7px solid #d1d4d7;\n  border-left: 7px solid transparent;\n  border-bottom-color: #d1d4d7;\n  content: ''; }\n\n.daterangepicker.openscenter:after {\n  position: absolute;\n  top: -6px;\n  left: 0;\n  right: 0;\n  width: 0;\n  margin-left: auto;\n  margin-right: auto;\n  display: inline-block;\n  border-right: 6px solid transparent;\n  border-bottom: 6px solid #fff;\n  border-left: 6px solid transparent;\n  content: ''; }\n\n.daterangepicker.opensright:before {\n  position: absolute;\n  top: -7px;\n  left: 9px;\n  display: inline-block;\n  border-right: 7px solid transparent;\n  border-bottom: 7px solid #d1d4d7;\n  border-left: 7px solid transparent;\n  border-bottom-color: #d1d4d7;\n  content: ''; }\n\n.daterangepicker.opensright:after {\n  position: absolute;\n  top: -6px;\n  left: 10px;\n  display: inline-block;\n  border-right: 6px solid transparent;\n  border-bottom: 6px solid #fff;\n  border-left: 6px solid transparent;\n  content: ''; }\n\n.daterangepicker.dropup {\n  margin-top: -5px; }\n\n.daterangepicker.dropup:before {\n  top: initial;\n  bottom: -7px;\n  border-bottom: initial;\n  border-top: 7px solid #d1d4d7; }\n\n.daterangepicker.dropup:after {\n  top: initial;\n  bottom: -6px;\n  border-bottom: initial;\n  border-top: 6px solid #fff; }\n\n.daterangepicker.dropdown-menu {\n  max-width: none;\n  z-index: 3000; }\n\n.daterangepicker.single .ranges, .daterangepicker.single .calendar {\n  float: none; }\n\n.daterangepicker .calendar {\n  display: none;\n  max-width: 270px;\n  margin: 4px; }\n\n.daterangepicker.show-calendar .calendar {\n  display: block; }\n\n.daterangepicker .calendar.single .calendar-table {\n  border: none; }\n\n/* Calendars */\n.daterangepicker .calendar th, .daterangepicker .calendar td {\n  white-space: nowrap;\n  text-align: center;\n  min-width: 32px;\n  line-height: 30px; }\n\n.daterangepicker .calendar-table {\n  border: 1px solid #ddd;\n  padding: 4px;\n  background: #fff; }\n\n.daterangepicker table {\n  width: 100%;\n  margin: 0; }\n\n.daterangepicker table thead {\n  background: #f8f9fa; }\n\n.daterangepicker td, .daterangepicker th {\n  text-align: center;\n  width: 20px;\n  height: 20px;\n  white-space: nowrap;\n  cursor: pointer; }\n\n.daterangepicker td.off, .daterangepicker td.off.in-range, .daterangepicker td.off.start-date, .daterangepicker td.off.end-date {\n  color: #d1d4d7;\n  background: #fff; }\n\n.daterangepicker td.disabled, .daterangepicker option.disabled {\n  color: #d1d4d7;\n  cursor: not-allowed;\n  text-decoration: line-through; }\n\n.daterangepicker td.available:hover, .daterangepicker th.available:hover {\n  background: #f8f9fa; }\n\n.daterangepicker td.in-range {\n  background: #ccecf8;\n  border-radius: 0; }\n\n.daterangepicker td.active, .daterangepicker td.active:hover {\n  background-color: #20a8d8;\n  border-color: #20a8d8;\n  color: #fff; }\n\n.daterangepicker td.week, .daterangepicker th.week {\n  font-size: 80%;\n  color: #ccc; }\n\n.daterangepicker select.monthselect, .daterangepicker select.yearselect {\n  font-size: 12px;\n  padding: 1px;\n  height: auto;\n  margin: 0;\n  cursor: default; }\n\n.daterangepicker select.monthselect {\n  margin-right: 2%;\n  width: 56%; }\n\n.daterangepicker select.yearselect {\n  width: 40%; }\n\n.daterangepicker select.hourselect, .daterangepicker select.minuteselect, .daterangepicker select.secondselect, .daterangepicker select.ampmselect {\n  width: 50px;\n  margin-bottom: 0; }\n\n.daterangepicker th.month {\n  width: auto; }\n\n/* Text Input Above Each Calendar */\n.daterangepicker .input-mini {\n  margin-bottom: 5px;\n  padding-left: 28px; }\n\n.daterangepicker .input-mini.active {\n  border: 1px solid #20a8d8; }\n\n.daterangepicker .daterangepicker_input i {\n  position: absolute;\n  left: 8px;\n  top: 10px;\n  color: #d1d4d7; }\n\n.daterangepicker .daterangepicker_input {\n  position: relative; }\n\n/* Time Picker */\n.daterangepicker .calendar-time {\n  text-align: center;\n  margin: 5px auto;\n  line-height: 30px;\n  position: relative;\n  padding-left: 28px; }\n\n.daterangepicker .calendar-time select.disabled {\n  color: #ccc;\n  cursor: not-allowed; }\n\n/* Predefined Ranges */\n.daterangepicker .ranges {\n  font-size: 11px;\n  float: none;\n  margin: 4px;\n  text-align: left; }\n\n.daterangepicker .ranges ul {\n  list-style: none;\n  margin: 0 auto;\n  padding: 0;\n  width: 100%; }\n\n.daterangepicker .ranges li {\n  font-size: 13px;\n  background: #f8f9fa;\n  border: 1px solid #d1d4d7;\n  padding: 7px 10px;\n  margin-bottom: 5px;\n  cursor: pointer; }\n\n.daterangepicker .ranges li.active, .daterangepicker .ranges li:hover {\n  background: #20a8d8;\n  border-color: #20a8d8;\n  color: #fff; }\n\n/*  Larger Screen Styling */\n@media (min-width: 564px) {\n  .daterangepicker {\n    width: auto; }\n  .daterangepicker .ranges ul {\n    width: 160px; }\n  .daterangepicker.single .ranges ul {\n    width: 100%; }\n  .daterangepicker .calendar.left .calendar-table {\n    border-right: none;\n    border-top-right-radius: 0;\n    border-bottom-right-radius: 0; }\n  .daterangepicker .calendar.right .calendar-table {\n    border-left: none;\n    border-top-left-radius: 0;\n    border-bottom-left-radius: 0; }\n  .daterangepicker .calendar.left {\n    clear: left;\n    margin-right: 0; }\n  .daterangepicker.single .calendar.left {\n    clear: none; }\n  .daterangepicker.single .ranges,\n  .daterangepicker.single .calendar {\n    float: left; }\n  .daterangepicker .calendar.right {\n    margin-left: 0; }\n  .daterangepicker .left .daterangepicker_input {\n    padding-right: 12px; }\n  .daterangepicker .calendar.left .calendar-table {\n    padding-right: 12px; }\n  .daterangepicker .ranges,\n  .daterangepicker .calendar {\n    float: left; } }\n\n@media (min-width: 730px) {\n  .daterangepicker .ranges {\n    width: auto;\n    float: left; }\n  .daterangepicker .calendar.left {\n    clear: none; } }\n\n.gu-mirror {\n  position: fixed !important;\n  margin: 0 !important;\n  z-index: 9999 !important;\n  opacity: 0.8;\n  -ms-filter: \"progid:DXImageTransform.Microsoft.Alpha(Opacity=80)\";\n  filter: alpha(opacity=80); }\n\n.gu-hide {\n  display: none !important; }\n\n.gu-unselectable {\n  -webkit-user-select: none !important;\n  -moz-user-select: none !important;\n  -ms-user-select: none !important;\n  user-select: none !important; }\n\n.gu-transit {\n  opacity: 0.2;\n  -ms-filter: \"progid:DXImageTransform.Microsoft.Alpha(Opacity=20)\";\n  filter: alpha(opacity=20); }\n\n/*!\n * FullCalendar v2.4.0 Stylesheet\n * Docs & License: http://fullcalendar.io/\n * (c) 2015 Adam Shaw\n */\n.fc {\n  direction: ltr;\n  text-align: left; }\n\n.fc-rtl {\n  text-align: right; }\n\nbody .fc {\n  /* extra precedence to overcome jqui */\n  font-size: 1em; }\n\n/* Colors\n--------------------------------------------------------------------------------------------------*/\n.fc-unthemed th,\n.fc-unthemed td,\n.fc-unthemed thead,\n.fc-unthemed tbody,\n.fc-unthemed .fc-divider,\n.fc-unthemed .fc-row,\n.fc-unthemed .fc-popover {\n  border-color: #d1d4d7; }\n\n.fc-unthemed .fc-popover {\n  background-color: #fff; }\n\n.fc-unthemed .fc-divider,\n.fc-unthemed .fc-popover .fc-header {\n  background: #eee; }\n\n.fc-unthemed .fc-popover .fc-header .fc-close {\n  color: #666; }\n\n.fc-unthemed .fc-today {\n  background: #fcf8e3; }\n\n.fc-highlight {\n  /* when user is selecting cells */\n  background: #bce8f1;\n  opacity: .3;\n  filter: alpha(opacity=30);\n  /* for IE */ }\n\n.fc-bgevent {\n  /* default look for background events */\n  background: #8fdf82;\n  opacity: .3;\n  filter: alpha(opacity=30);\n  /* for IE */ }\n\n.fc-nonbusiness {\n  /* default look for non-business-hours areas */\n  /* will inherit .fc-bgevent's styles */\n  background: #d7d7d7; }\n\n/* Icons (inline elements with styled text that mock arrow icons)\n--------------------------------------------------------------------------------------------------*/\n.fc-icon {\n  font-family: \"FontAwesome\"; }\n\n/*\nAcceptable font-family overrides for individual icons:\n\t\"Arial\", sans-serif\n\t\"Times New Roman\", serif\n\nNOTE: use percentage font sizes or else old IE chokes\n*/\n.fc-icon:after {\n  position: relative; }\n\n.fc-icon-left-single-arrow:after {\n  content: \"\\f104\";\n  font-weight: bold; }\n\n.fc-icon-right-single-arrow:after {\n  content: \"\\f105\";\n  font-weight: bold; }\n\n.fc-icon-left-double-arrow:after {\n  content: \"\\f100\"; }\n\n.fc-icon-right-double-arrow:after {\n  content: \"\\f101\"; }\n\n.fc-icon-left-triangle:after {\n  content: \"\\25C4\";\n  font-size: 125%;\n  top: 3%;\n  left: -2%; }\n\n.fc-icon-right-triangle:after {\n  content: \"\\25BA\";\n  font-size: 125%;\n  top: 3%;\n  left: 2%; }\n\n.fc-icon-down-triangle:after {\n  content: \"\\25BC\";\n  font-size: 125%;\n  top: 2%; }\n\n.fc-icon-x:after {\n  content: \"\\000D7\";\n  font-size: 200%;\n  top: 6%; }\n\n/* Buttons (styled <button> tags, normalized to work cross-browser)\n--------------------------------------------------------------------------------------------------*/\n/* Firefox has an annoying inner border */\n.fc button::-moz-focus-inner {\n  margin: 0;\n  padding: 0; }\n\n.fc-state-default {\n  /* non-theme */\n  border: 1px solid; }\n\n.fc-state-default.fc-corner-left {\n  /* non-theme */ }\n\n.fc-state-default.fc-corner-right {\n  /* non-theme */ }\n\n/* icons in buttons */\n.fc button .fc-icon {\n  /* non-theme */\n  position: relative;\n  top: -0.05em;\n  /* seems to be a good adjustment across browsers */\n  margin: 0 .2em;\n  vertical-align: middle; }\n\n/*\n  button states\n  borrowed from twitter bootstrap (http://twitter.github.com/bootstrap/)\n*/\n.fc-state-hover,\n.fc-state-down,\n.fc-state-active,\n.fc-state-disabled {\n  color: #333333;\n  background-color: #e6e6e6; }\n\n.fc-state-hover {\n  color: #333333;\n  text-decoration: none;\n  background-position: 0 -15px;\n  -webkit-transition: background-position 0.1s linear;\n  -moz-transition: background-position 0.1s linear;\n  -o-transition: background-position 0.1s linear;\n  transition: background-position 0.1s linear; }\n\n.fc-state-down,\n.fc-state-active {\n  background-color: #cccccc;\n  background-image: none;\n  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.15), 0 1px 2px rgba(0, 0, 0, 0.05); }\n\n.fc-state-disabled {\n  cursor: default;\n  background-image: none;\n  opacity: 0.65;\n  filter: alpha(opacity=65);\n  box-shadow: none; }\n\n/* Buttons Groups\n--------------------------------------------------------------------------------------------------*/\n/*\nevery button that is not first in a button group should scootch over one pixel and cover the\nprevious button's border...\n*/\n.fc .fc-button-group > * {\n  /* extra precedence b/c buttons have margin set to zero */\n  float: left;\n  margin: 0 0 0 -1px; }\n\n.fc .fc-button-group > :first-child {\n  /* same */\n  margin-left: 0; }\n\n/* Popover\n--------------------------------------------------------------------------------------------------*/\n.fc-popover {\n  position: absolute;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15); }\n\n.fc-popover .fc-header {\n  /* TODO: be more consistent with fc-head/fc-body */\n  padding: 2px 4px; }\n\n.fc-popover .fc-header .fc-title {\n  margin: 0 2px; }\n\n.fc-popover .fc-header .fc-close {\n  cursor: pointer; }\n\n.fc-ltr .fc-popover .fc-header .fc-title,\n.fc-rtl .fc-popover .fc-header .fc-close {\n  float: left; }\n\n.fc-rtl .fc-popover .fc-header .fc-title,\n.fc-ltr .fc-popover .fc-header .fc-close {\n  float: right; }\n\n/* unthemed */\n.fc-unthemed .fc-popover {\n  border-width: 1px;\n  border-style: solid; }\n\n.fc-unthemed .fc-popover .fc-header .fc-close {\n  font-size: .9em;\n  margin-top: 2px; }\n\n/* jqui themed */\n.fc-popover > .ui-widget-header + .ui-widget-content {\n  border-top: 0;\n  /* where they meet, let the header have the border */ }\n\n/* Misc Reusable Components\n--------------------------------------------------------------------------------------------------*/\n.fc-divider {\n  border-style: solid;\n  border-width: 1px; }\n\nhr.fc-divider {\n  height: 0;\n  margin: 0;\n  padding: 0 0 2px;\n  /* height is unreliable across browsers, so use padding */\n  border-width: 1px 0; }\n\n.fc-clear {\n  clear: both; }\n\n.fc-bg,\n.fc-bgevent-skeleton,\n.fc-highlight-skeleton,\n.fc-helper-skeleton {\n  /* these element should always cling to top-left/right corners */\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0; }\n\n.fc-bg {\n  bottom: 0;\n  /* strech bg to bottom edge */ }\n\n.fc-bg table {\n  height: 100%;\n  /* strech bg to bottom edge */ }\n\n/* Tables\n--------------------------------------------------------------------------------------------------*/\n.fc table {\n  width: 100%;\n  table-layout: fixed;\n  border-collapse: collapse;\n  border-spacing: 0;\n  font-size: 1em;\n  /* normalize cross-browser */ }\n\n.fc th {\n  text-align: center; }\n\n.fc th,\n.fc td {\n  border-style: solid;\n  border-width: 1px;\n  padding: 0;\n  vertical-align: top; }\n\n.fc td.fc-today {\n  border-style: double;\n  /* overcome neighboring borders */ }\n\n/* Fake Table Rows\n--------------------------------------------------------------------------------------------------*/\n.fc .fc-row {\n  /* extra precedence to overcome themes w/ .ui-widget-content forcing a 1px border */\n  /* no visible border by default. but make available if need be (scrollbar width compensation) */\n  border-style: solid;\n  border-width: 0; }\n\n.fc-row table {\n  /* don't put left/right border on anything within a fake row.\n\t   the outer tbody will worry about this */\n  border-left: 0 hidden transparent;\n  border-right: 0 hidden transparent;\n  /* no bottom borders on rows */\n  border-bottom: 0 hidden transparent; }\n\n.fc-row:first-child table {\n  border-top: 0 hidden transparent;\n  /* no top border on first row */ }\n\n/* Day Row (used within the header and the DayGrid)\n--------------------------------------------------------------------------------------------------*/\n.fc-row {\n  position: relative; }\n\n.fc-row .fc-bg {\n  z-index: 1; }\n\n/* highlighting cells & background event skeleton */\n.fc-row .fc-bgevent-skeleton,\n.fc-row .fc-highlight-skeleton {\n  bottom: 0;\n  /* stretch skeleton to bottom of row */ }\n\n.fc-row .fc-bgevent-skeleton table,\n.fc-row .fc-highlight-skeleton table {\n  height: 100%;\n  /* stretch skeleton to bottom of row */ }\n\n.fc-row .fc-highlight-skeleton td,\n.fc-row .fc-bgevent-skeleton td {\n  border-color: transparent; }\n\n.fc-row .fc-bgevent-skeleton {\n  z-index: 2; }\n\n.fc-row .fc-highlight-skeleton {\n  z-index: 3; }\n\n/*\nrow content (which contains day/week numbers and events) as well as \"helper\" (which contains\ntemporary rendered events).\n*/\n.fc-row .fc-content-skeleton {\n  position: relative;\n  z-index: 4;\n  padding-bottom: 2px;\n  /* matches the space above the events */ }\n\n.fc-row .fc-helper-skeleton {\n  z-index: 5; }\n\n.fc-row .fc-content-skeleton td,\n.fc-row .fc-helper-skeleton td {\n  /* see-through to the background below */\n  background: none;\n  /* in case <td>s are globally styled */\n  border-color: transparent;\n  /* don't put a border between events and/or the day number */\n  border-bottom: 0; }\n\n.fc-row .fc-content-skeleton tbody td,\n.fc-row .fc-helper-skeleton tbody td {\n  /* don't put a border between event cells */\n  border-top: 0; }\n\n/* Scrolling Container\n--------------------------------------------------------------------------------------------------*/\n.fc-scroller {\n  /* this class goes on elements for guaranteed vertical scrollbars */\n  overflow-y: scroll;\n  overflow-x: hidden; }\n\n.fc-scroller > * {\n  /* we expect an immediate inner element */\n  position: relative;\n  /* re-scope all positions */\n  width: 100%;\n  /* hack to force re-sizing this inner element when scrollbars appear/disappear */\n  overflow: hidden;\n  /* don't let negative margins or absolute positioning create further scroll */ }\n\n/* Global Event Styles\n--------------------------------------------------------------------------------------------------*/\n.fc-event {\n  position: relative;\n  /* for resize handle and other inner positioning */\n  display: block;\n  /* make the <a> tag block */\n  font-size: .85em;\n  line-height: 1.3;\n  border: 1px solid #20a8d8;\n  /* default BORDER color */\n  background-color: #20a8d8;\n  /* default BACKGROUND color */\n  font-weight: normal;\n  /* undo jqui's ui-widget-header bold */ }\n\n/* overpower some of bootstrap's and jqui's styles on <a> tags */\n.fc-event,\n.fc-event:hover,\n.ui-widget .fc-event {\n  color: #fff;\n  /* default TEXT color */\n  text-decoration: none;\n  /* if <a> has an href */ }\n\n.fc-event[href],\n.fc-event.fc-draggable {\n  cursor: pointer;\n  /* give events with links and draggable events a hand mouse pointer */ }\n\n.fc-not-allowed,\n.fc-not-allowed .fc-event {\n  /* to override an event's custom cursor */\n  cursor: not-allowed; }\n\n.fc-event .fc-bg {\n  /* the generic .fc-bg already does position */\n  z-index: 1;\n  background: #fff;\n  opacity: .25;\n  filter: alpha(opacity=25);\n  /* for IE */ }\n\n.fc-event .fc-content {\n  position: relative;\n  z-index: 2; }\n\n.fc-event .fc-resizer {\n  position: absolute;\n  z-index: 3; }\n\n/* Horizontal Events\n--------------------------------------------------------------------------------------------------*/\n/* events that are continuing to/from another week. kill rounded corners and butt up against edge */\n.fc-ltr .fc-h-event.fc-not-start,\n.fc-rtl .fc-h-event.fc-not-end {\n  margin-left: 0;\n  border-left-width: 0;\n  padding-left: 1px;\n  /* replace the border with padding */\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0; }\n\n.fc-ltr .fc-h-event.fc-not-end,\n.fc-rtl .fc-h-event.fc-not-start {\n  margin-right: 0;\n  border-right-width: 0;\n  padding-right: 1px;\n  /* replace the border with padding */\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0; }\n\n/* resizer */\n.fc-h-event .fc-resizer {\n  /* positioned it to overcome the event's borders */\n  top: -1px;\n  bottom: -1px;\n  left: -1px;\n  right: -1px;\n  width: 5px; }\n\n/* left resizer  */\n.fc-ltr .fc-h-event .fc-start-resizer,\n.fc-ltr .fc-h-event .fc-start-resizer:before,\n.fc-ltr .fc-h-event .fc-start-resizer:after,\n.fc-rtl .fc-h-event .fc-end-resizer,\n.fc-rtl .fc-h-event .fc-end-resizer:before,\n.fc-rtl .fc-h-event .fc-end-resizer:after {\n  right: auto;\n  /* ignore the right and only use the left */\n  cursor: w-resize; }\n\n/* right resizer */\n.fc-ltr .fc-h-event .fc-end-resizer,\n.fc-ltr .fc-h-event .fc-end-resizer:before,\n.fc-ltr .fc-h-event .fc-end-resizer:after,\n.fc-rtl .fc-h-event .fc-start-resizer,\n.fc-rtl .fc-h-event .fc-start-resizer:before,\n.fc-rtl .fc-h-event .fc-start-resizer:after {\n  left: auto;\n  /* ignore the left and only use the right */\n  cursor: e-resize; }\n\n/* DayGrid events\n----------------------------------------------------------------------------------------------------\nWe use the full \"fc-day-grid-event\" class instead of using descendants because the event won't\nbe a descendant of the grid when it is being dragged.\n*/\n.fc-day-grid-event {\n  margin: 1px 2px 0;\n  /* spacing between events and edges */\n  padding: 0 1px; }\n\n.fc-day-grid-event .fc-content {\n  /* force events to be one-line tall */\n  white-space: nowrap;\n  overflow: hidden; }\n\n.fc-day-grid-event .fc-time {\n  font-weight: bold; }\n\n.fc-day-grid-event .fc-resizer {\n  /* enlarge the default hit area */\n  left: -3px;\n  right: -3px;\n  width: 7px; }\n\n/* Event Limiting\n--------------------------------------------------------------------------------------------------*/\n/* \"more\" link that represents hidden events */\na.fc-more {\n  margin: 1px 3px;\n  font-size: .85em;\n  cursor: pointer;\n  text-decoration: none; }\n\na.fc-more:hover {\n  text-decoration: underline; }\n\n.fc-limited {\n  /* rows and cells that are hidden because of a \"more\" link */\n  display: none; }\n\n/* popover that appears when \"more\" link is clicked */\n.fc-day-grid .fc-row {\n  z-index: 1;\n  /* make the \"more\" popover one higher than this */ }\n\n.fc-more-popover {\n  z-index: 2;\n  width: 220px; }\n\n.fc-more-popover .fc-event-container {\n  padding: 10px; }\n\n/* Toolbar\n--------------------------------------------------------------------------------------------------*/\n.fc-toolbar {\n  text-align: center;\n  margin-bottom: 1em; }\n\n.fc-toolbar .fc-left {\n  float: left; }\n\n.fc-toolbar .fc-right {\n  float: right; }\n\n.fc-toolbar .fc-center {\n  display: inline-block; }\n\n/* the things within each left/right/center section */\n.fc .fc-toolbar > * > * {\n  /* extra precedence to override button border margins */\n  float: left;\n  margin-left: .75em; }\n\n/* the first thing within each left/center/right section */\n.fc .fc-toolbar > * > :first-child {\n  /* extra precedence to override button border margins */\n  margin-left: 0; }\n\n/* title text */\n.fc-toolbar h2 {\n  margin: 0; }\n\n/* button layering (for border precedence) */\n.fc-toolbar button {\n  position: relative; }\n\n.fc-toolbar .fc-state-hover,\n.fc-toolbar .ui-state-hover {\n  z-index: 2; }\n\n.fc-toolbar .fc-state-down {\n  z-index: 3; }\n\n.fc-toolbar .fc-state-active,\n.fc-toolbar .ui-state-active {\n  z-index: 4; }\n\n.fc-toolbar button:focus {\n  z-index: 5; }\n\n/* View Structure\n--------------------------------------------------------------------------------------------------*/\n/* undo twitter bootstrap's box-sizing rules. normalizes positioning techniques */\n/* don't do this for the toolbar because we'll want bootstrap to style those buttons as some pt */\n.fc-view-container *,\n.fc-view-container *:before,\n.fc-view-container *:after {\n  -webkit-box-sizing: content-box;\n  -moz-box-sizing: content-box;\n  box-sizing: content-box; }\n\n.fc-view,\n.fc-view > table {\n  /* so dragged elements can be above the view's main element */\n  position: relative;\n  z-index: 1; }\n\n/* BasicView\n--------------------------------------------------------------------------------------------------*/\n/* day row structure */\n.fc-basicWeek-view .fc-content-skeleton,\n.fc-basicDay-view .fc-content-skeleton {\n  /* we are sure there are no day numbers in these views, so... */\n  padding-top: 1px;\n  /* add a pixel to make sure there are 2px padding above events */\n  padding-bottom: 1em;\n  /* ensure a space at bottom of cell for user selecting/clicking */ }\n\n.fc-basic-view .fc-body .fc-row {\n  min-height: 4em;\n  /* ensure that all rows are at least this tall */ }\n\n/* a \"rigid\" row will take up a constant amount of height because content-skeleton is absolute */\n.fc-row.fc-rigid {\n  overflow: hidden; }\n\n.fc-row.fc-rigid .fc-content-skeleton {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0; }\n\n/* week and day number styling */\n.fc-basic-view .fc-week-number,\n.fc-basic-view .fc-day-number {\n  padding: 0 2px; }\n\n.fc-basic-view td.fc-week-number span,\n.fc-basic-view td.fc-day-number {\n  padding-top: 2px;\n  padding-bottom: 2px; }\n\n.fc-basic-view .fc-week-number {\n  text-align: center; }\n\n.fc-basic-view .fc-week-number span {\n  /* work around the way we do column resizing and ensure a minimum width */\n  display: inline-block;\n  min-width: 1.25em; }\n\n.fc-ltr .fc-basic-view .fc-day-number {\n  text-align: right; }\n\n.fc-rtl .fc-basic-view .fc-day-number {\n  text-align: left; }\n\n.fc-day-number.fc-other-month {\n  opacity: 0.3;\n  filter: alpha(opacity=30);\n  /* for IE */\n  /* opacity with small font can sometimes look too faded\n\t   might want to set the 'color' property instead\n\t   making day-numbers bold also fixes the problem */ }\n\n/* AgendaView all-day area\n--------------------------------------------------------------------------------------------------*/\n.fc-agenda-view .fc-day-grid {\n  position: relative;\n  z-index: 2;\n  /* so the \"more..\" popover will be over the time grid */ }\n\n.fc-agenda-view .fc-day-grid .fc-row {\n  min-height: 3em;\n  /* all-day section will never get shorter than this */ }\n\n.fc-agenda-view .fc-day-grid .fc-row .fc-content-skeleton {\n  padding-top: 1px;\n  /* add a pixel to make sure there are 2px padding above events */\n  padding-bottom: 1em;\n  /* give space underneath events for clicking/selecting days */ }\n\n/* TimeGrid axis running down the side (for both the all-day area and the slot area)\n--------------------------------------------------------------------------------------------------*/\n.fc .fc-axis {\n  /* .fc to overcome default cell styles */\n  vertical-align: middle;\n  padding: 0 4px;\n  white-space: nowrap; }\n\n.fc-ltr .fc-axis {\n  text-align: right; }\n\n.fc-rtl .fc-axis {\n  text-align: left; }\n\n.ui-widget td.fc-axis {\n  font-weight: normal;\n  /* overcome jqui theme making it bold */ }\n\n/* TimeGrid Structure\n--------------------------------------------------------------------------------------------------*/\n.fc-time-grid-container,\n.fc-time-grid {\n  /* so slats/bg/content/etc positions get scoped within here */\n  position: relative;\n  z-index: 1; }\n\n.fc-time-grid {\n  min-height: 100%;\n  /* so if height setting is 'auto', .fc-bg stretches to fill height */ }\n\n.fc-time-grid table {\n  /* don't put outer borders on slats/bg/content/etc */\n  border: 0 hidden transparent; }\n\n.fc-time-grid > .fc-bg {\n  z-index: 1; }\n\n.fc-time-grid .fc-slats,\n.fc-time-grid > hr {\n  /* the <hr> AgendaView injects when grid is shorter than scroller */\n  position: relative;\n  z-index: 2; }\n\n.fc-time-grid .fc-bgevent-skeleton,\n.fc-time-grid .fc-content-skeleton {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0; }\n\n.fc-time-grid .fc-bgevent-skeleton {\n  z-index: 3; }\n\n.fc-time-grid .fc-highlight-skeleton {\n  z-index: 4; }\n\n.fc-time-grid .fc-content-skeleton {\n  z-index: 5; }\n\n.fc-time-grid .fc-helper-skeleton {\n  z-index: 6; }\n\n/* TimeGrid Slats (lines that run horizontally)\n--------------------------------------------------------------------------------------------------*/\n.fc-time-grid .fc-slats td {\n  height: 1.5em;\n  border-bottom: 0;\n  /* each cell is responsible for its top border */ }\n\n.fc-time-grid .fc-slats .fc-minor td {\n  border-top-style: dotted; }\n\n.fc-time-grid .fc-slats .ui-widget-content {\n  /* for jqui theme */\n  background: none;\n  /* see through to fc-bg */ }\n\n/* TimeGrid Highlighting Slots\n--------------------------------------------------------------------------------------------------*/\n.fc-time-grid .fc-highlight-container {\n  /* a div within a cell within the fc-highlight-skeleton */\n  position: relative;\n  /* scopes the left/right of the fc-highlight to be in the column */ }\n\n.fc-time-grid .fc-highlight {\n  position: absolute;\n  left: 0;\n  right: 0;\n  /* top and bottom will be in by JS */ }\n\n/* TimeGrid Event Containment\n--------------------------------------------------------------------------------------------------*/\n.fc-time-grid .fc-event-container,\n.fc-time-grid .fc-bgevent-container {\n  /* a div within a cell within the fc-bgevent-skeleton */\n  position: relative; }\n\n.fc-ltr .fc-time-grid .fc-event-container {\n  /* space on the sides of events for LTR (default) */\n  margin: 0 2.5% 0 2px; }\n\n.fc-rtl .fc-time-grid .fc-event-container {\n  /* space on the sides of events for RTL */\n  margin: 0 2px 0 2.5%; }\n\n.fc-time-grid .fc-event,\n.fc-time-grid .fc-bgevent {\n  position: absolute;\n  z-index: 1;\n  /* scope inner z-index's */ }\n\n.fc-time-grid .fc-bgevent {\n  /* background events always span full width */\n  left: 0;\n  right: 0; }\n\n/* Generic Vertical Event\n--------------------------------------------------------------------------------------------------*/\n.fc-v-event.fc-not-start {\n  /* events that are continuing from another day */\n  /* replace space made by the top border with padding */\n  border-top-width: 0;\n  padding-top: 1px;\n  /* remove top rounded corners */\n  border-top-left-radius: 0;\n  border-top-right-radius: 0; }\n\n.fc-v-event.fc-not-end {\n  /* replace space made by the top border with padding */\n  border-bottom-width: 0;\n  padding-bottom: 1px;\n  /* remove bottom rounded corners */\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0; }\n\n/* TimeGrid Event Styling\n----------------------------------------------------------------------------------------------------\nWe use the full \"fc-time-grid-event\" class instead of using descendants because the event won't\nbe a descendant of the grid when it is being dragged.\n*/\n.fc-time-grid-event {\n  overflow: hidden;\n  /* don't let the bg flow over rounded corners */ }\n\n.fc-time-grid-event .fc-time,\n.fc-time-grid-event .fc-title {\n  padding: 0 1px; }\n\n.fc-time-grid-event .fc-time {\n  font-size: .85em;\n  white-space: nowrap; }\n\n/* short mode, where time and title are on the same line */\n.fc-time-grid-event.fc-short .fc-content {\n  /* don't wrap to second line (now that contents will be inline) */\n  white-space: nowrap; }\n\n.fc-time-grid-event.fc-short .fc-time,\n.fc-time-grid-event.fc-short .fc-title {\n  /* put the time and title on the same line */\n  display: inline-block;\n  vertical-align: top; }\n\n.fc-time-grid-event.fc-short .fc-time span {\n  display: none;\n  /* don't display the full time text... */ }\n\n.fc-time-grid-event.fc-short .fc-time:before {\n  content: attr(data-start);\n  /* ...instead, display only the start time */ }\n\n.fc-time-grid-event.fc-short .fc-time:after {\n  content: \"\\000A0-\\000A0\";\n  /* seperate with a dash, wrapped in nbsp's */ }\n\n.fc-time-grid-event.fc-short .fc-title {\n  font-size: .85em;\n  /* make the title text the same size as the time */\n  padding: 0;\n  /* undo padding from above */ }\n\n/* resizer */\n.fc-time-grid-event .fc-resizer {\n  left: 0;\n  right: 0;\n  bottom: 0;\n  height: 8px;\n  overflow: hidden;\n  line-height: 8px;\n  font-size: 11px;\n  font-family: monospace;\n  text-align: center;\n  cursor: s-resize; }\n\n.fc-time-grid-event .fc-resizer:after {\n  content: \"=\"; }\n\n.gaugejs-wrap {\n  position: relative;\n  margin: 0 auto; }\n  .gaugejs-wrap canvas.gaugejs {\n    width: 100% !important;\n    height: auto !important; }\n  .gaugejs-wrap i {\n    position: absolute;\n    top: 50%;\n    left: 0;\n    z-index: 1000;\n    display: block;\n    width: 100%;\n    margin-top: -15px;\n    font-size: 30px;\n    text-align: center; }\n\n.gaugejs-wrap.type-2 .value {\n  display: block;\n  margin-top: -85px; }\n\n.gaugejs-wrap.type-2 label {\n  display: block;\n  margin-top: -10px;\n  font-size: 10px;\n  font-weight: 600;\n  color: #818a91;\n  text-transform: uppercase; }\n\n.gaugejs-wrap.sparkline {\n  position: relative; }\n  .gaugejs-wrap.sparkline .value {\n    position: absolute;\n    top: 50%;\n    display: block;\n    width: 100%;\n    margin-top: -5px;\n    font-size: 10px;\n    line-height: 10px;\n    text-align: center; }\n\n/* Ion.RangeSlider\n// css version 2.0.3\n// © 2013-2014 Denis Ineshin | IonDen.com\n// ===================================================================================================================*/\n/* =====================================================================================================================\n// RangeSlider */\n.irs {\n  position: relative;\n  display: block;\n  -webkit-touch-callout: none;\n  -webkit-user-select: none;\n  -khtml-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none; }\n\n.irs-line {\n  position: relative;\n  display: block;\n  overflow: hidden;\n  outline: none !important; }\n\n.irs-line-left, .irs-line-mid, .irs-line-right {\n  position: absolute;\n  display: block;\n  top: 0; }\n\n.irs-line-left {\n  left: 0;\n  width: 11%; }\n\n.irs-line-mid {\n  left: 9%;\n  width: 82%; }\n\n.irs-line-right {\n  right: 0;\n  width: 11%; }\n\n.irs-bar {\n  position: absolute;\n  display: block;\n  left: 0;\n  width: 0; }\n\n.irs-bar-edge {\n  position: absolute;\n  display: block;\n  top: 0;\n  left: 0; }\n\n.irs-shadow {\n  position: absolute;\n  display: none;\n  left: 0;\n  width: 0; }\n\n.irs-slider {\n  position: absolute;\n  display: block;\n  cursor: default;\n  z-index: 1; }\n\n.irs-slider.type_last {\n  z-index: 2; }\n\n.irs-min {\n  position: absolute;\n  display: block;\n  left: 0;\n  cursor: default; }\n\n.irs-max {\n  position: absolute;\n  display: block;\n  right: 0;\n  cursor: default; }\n\n.irs-from, .irs-to, .irs-single {\n  position: absolute;\n  display: block;\n  top: 0;\n  left: 0;\n  cursor: default;\n  white-space: nowrap; }\n\n.irs-grid {\n  position: absolute;\n  display: none;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  height: 20px; }\n\n.irs-with-grid .irs-grid {\n  display: block; }\n\n.irs-grid-pol {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 1px;\n  height: 8px;\n  background: #000; }\n\n.irs-grid-pol.small {\n  height: 4px; }\n\n.irs-grid-text {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  white-space: nowrap;\n  text-align: center;\n  font-size: 9px;\n  line-height: 9px;\n  padding: 0 3px;\n  color: #000; }\n\n.irs-disable-mask {\n  position: absolute;\n  display: block;\n  top: 0;\n  left: -1%;\n  width: 102%;\n  height: 100%;\n  cursor: default;\n  background: transparent;\n  z-index: 2; }\n\n.lt-ie9 .irs-disable-mask {\n  background: #000;\n  filter: alpha(opacity=0);\n  cursor: not-allowed; }\n\n.irs-disabled {\n  opacity: 0.4; }\n\n.irs-hidden-input {\n  position: absolute !important;\n  display: block !important;\n  top: 0 !important;\n  left: 0 !important;\n  width: 0 !important;\n  height: 0 !important;\n  font-size: 0 !important;\n  line-height: 0 !important;\n  padding: 0 !important;\n  margin: 0 !important;\n  outline: none !important;\n  z-index: -9999 !important;\n  background: none !important;\n  border-style: solid !important;\n  border-color: transparent !important; }\n\n/* Ion.RangeSlider, Modern Skin\n// css version 2.0.3\n// © Denis Ineshin, 2014    https://github.com/IonDen\n// ===================================================================================================================*/\n/* =====================================================================================================================\n// Skin details */\n.irs-line-mid,\n.irs-line-left,\n.irs-line-right,\n.irs-bar,\n.irs-bar-edge,\n.irs-slider {\n  background: url(../img/sprite-skin-modern.png) repeat-x; }\n\n.irs {\n  height: 50px; }\n\n.irs-with-grid {\n  height: 70px; }\n\n.irs-line {\n  height: 6px;\n  top: 25px; }\n\n.irs-line-left {\n  height: 6px;\n  background: #d1d4d7; }\n\n.irs-line-mid {\n  height: 6px;\n  background: #d1d4d7; }\n\n.irs-line-right {\n  height: 6px;\n  background: #d1d4d7; }\n\n.irs-bar {\n  height: 6px;\n  top: 25px;\n  background: #20a8d8; }\n\n.irs-bar-edge {\n  top: 25px;\n  height: 6px;\n  width: 7px;\n  background: #20a8d8; }\n\n.irs-shadow {\n  height: 5px;\n  top: 25px;\n  background: #000;\n  opacity: 0.25; }\n\n.lt-ie9 .irs-shadow {\n  filter: alpha(opacity=25); }\n\n.irs-slider {\n  width: 11px;\n  height: 18px;\n  top: 31px;\n  background-position: 0 -120px; }\n\n.irs-slider.state_hover, .irs-slider:hover {\n  background-position: 0 -150px; }\n\n.irs-min, .irs-max {\n  color: #55595c;\n  font-size: 10px;\n  line-height: 1.333;\n  text-shadow: none;\n  top: 0;\n  padding: 2px 5px;\n  background: #d1d4d7; }\n\n.irs-from, .irs-to, .irs-single {\n  color: #fff;\n  font-size: 10px;\n  line-height: 1.333;\n  text-shadow: none;\n  padding: 2px 5px;\n  background: #d1d4d7; }\n\n.irs-from:after, .irs-to:after, .irs-single:after {\n  position: absolute;\n  display: block;\n  content: \"\";\n  bottom: -6px;\n  left: 50%;\n  width: 0;\n  height: 0;\n  margin-left: -3px;\n  overflow: hidden;\n  border: 3px solid transparent;\n  border-top-color: #d1d4d7; }\n\n.irs-grid {\n  height: 34px; }\n\n.irs-grid-pol {\n  background: #d1d4d7; }\n\n.irs-grid-text {\n  bottom: 12px;\n  color: #d1d4d7; }\n\n/*!\n* Ladda\n* http://lab.hakim.se/ladda\n* MIT licensed\n*\n* Copyright (C) 2016 Hakim El Hattab, http://hakim.se\n*/\n/*************************************\n* CONFIG\n*/\n/*************************************\n* MIXINS\n*/\n/*************************************\n* BUTTON BASE\n*/\n.ladda-button {\n  position: relative; }\n\n/* Spinner animation */\n.ladda-button .ladda-spinner {\n  position: absolute;\n  z-index: 2;\n  display: inline-block;\n  width: 32px;\n  height: 32px;\n  top: 50%;\n  margin-top: 0;\n  opacity: 0;\n  pointer-events: none; }\n\n/* Button label */\n.ladda-button .ladda-label {\n  position: relative;\n  z-index: 3; }\n\n/* Progress bar */\n.ladda-button .ladda-progress {\n  position: absolute;\n  width: 0;\n  height: 100%;\n  left: 0;\n  top: 0;\n  background: rgba(0, 0, 0, 0.2);\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: 0.1s linear all !important;\n  -moz-transition: 0.1s linear all !important;\n  -ms-transition: 0.1s linear all !important;\n  -o-transition: 0.1s linear all !important;\n  transition: 0.1s linear all !important; }\n\n.ladda-button[data-loading] .ladda-progress {\n  opacity: 1;\n  visibility: visible; }\n\n/*************************************\n* EASING\n*/\n.ladda-button,\n.ladda-button .ladda-spinner,\n.ladda-button .ladda-label {\n  -webkit-transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) all !important;\n  -moz-transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) all !important;\n  -ms-transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) all !important;\n  -o-transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) all !important;\n  transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) all !important; }\n\n.ladda-button[data-style=zoom-in],\n.ladda-button[data-style=zoom-in] .ladda-spinner,\n.ladda-button[data-style=zoom-in] .ladda-label,\n.ladda-button[data-style=zoom-out],\n.ladda-button[data-style=zoom-out] .ladda-spinner,\n.ladda-button[data-style=zoom-out] .ladda-label {\n  -webkit-transition: 0.3s ease all !important;\n  -moz-transition: 0.3s ease all !important;\n  -ms-transition: 0.3s ease all !important;\n  -o-transition: 0.3s ease all !important;\n  transition: 0.3s ease all !important; }\n\n/*************************************\n* EXPAND LEFT\n*/\n.ladda-button[data-style=expand-right] .ladda-spinner {\n  right: -6px; }\n\n.ladda-button[data-style=expand-right][data-size=\"s\"] .ladda-spinner,\n.ladda-button[data-style=expand-right][data-size=\"xs\"] .ladda-spinner {\n  right: -12px; }\n\n.ladda-button[data-style=expand-right][data-loading] {\n  padding-right: 56px; }\n  .ladda-button[data-style=expand-right][data-loading] .ladda-spinner {\n    opacity: 1; }\n  .ladda-button[data-style=expand-right][data-loading][data-size=\"s\"], .ladda-button[data-style=expand-right][data-loading][data-size=\"xs\"] {\n    padding-right: 40px; }\n\n/*************************************\n* EXPAND RIGHT\n*/\n.ladda-button[data-style=expand-left] .ladda-spinner {\n  left: 26px; }\n\n.ladda-button[data-style=expand-left][data-size=\"s\"] .ladda-spinner,\n.ladda-button[data-style=expand-left][data-size=\"xs\"] .ladda-spinner {\n  left: 4px; }\n\n.ladda-button[data-style=expand-left][data-loading] {\n  padding-left: 56px; }\n  .ladda-button[data-style=expand-left][data-loading] .ladda-spinner {\n    opacity: 1; }\n  .ladda-button[data-style=expand-left][data-loading][data-size=\"s\"], .ladda-button[data-style=expand-left][data-loading][data-size=\"xs\"] {\n    padding-left: 40px; }\n\n/*************************************\n* EXPAND UP\n*/\n.ladda-button[data-style=expand-up] {\n  overflow: hidden; }\n  .ladda-button[data-style=expand-up] .ladda-spinner {\n    top: -32px;\n    left: 50%;\n    margin-left: 0; }\n  .ladda-button[data-style=expand-up][data-loading] {\n    padding-top: 54px; }\n    .ladda-button[data-style=expand-up][data-loading] .ladda-spinner {\n      opacity: 1;\n      top: 26px;\n      margin-top: 0; }\n    .ladda-button[data-style=expand-up][data-loading][data-size=\"s\"], .ladda-button[data-style=expand-up][data-loading][data-size=\"xs\"] {\n      padding-top: 32px; }\n      .ladda-button[data-style=expand-up][data-loading][data-size=\"s\"] .ladda-spinner, .ladda-button[data-style=expand-up][data-loading][data-size=\"xs\"] .ladda-spinner {\n        top: 4px; }\n\n/*************************************\n* EXPAND DOWN\n*/\n.ladda-button[data-style=expand-down] {\n  overflow: hidden; }\n  .ladda-button[data-style=expand-down] .ladda-spinner {\n    top: 62px;\n    left: 50%;\n    margin-left: 0; }\n  .ladda-button[data-style=expand-down][data-size=\"s\"] .ladda-spinner,\n  .ladda-button[data-style=expand-down][data-size=\"xs\"] .ladda-spinner {\n    top: 40px; }\n  .ladda-button[data-style=expand-down][data-loading] {\n    padding-bottom: 54px; }\n    .ladda-button[data-style=expand-down][data-loading] .ladda-spinner {\n      opacity: 1; }\n    .ladda-button[data-style=expand-down][data-loading][data-size=\"s\"], .ladda-button[data-style=expand-down][data-loading][data-size=\"xs\"] {\n      padding-bottom: 32px; }\n\n/*************************************\n* SLIDE LEFT\n*/\n.ladda-button[data-style=slide-left] {\n  overflow: hidden; }\n  .ladda-button[data-style=slide-left] .ladda-label {\n    position: relative; }\n  .ladda-button[data-style=slide-left] .ladda-spinner {\n    left: 100%;\n    margin-left: 0; }\n  .ladda-button[data-style=slide-left][data-loading] .ladda-label {\n    opacity: 0;\n    left: -100%; }\n  .ladda-button[data-style=slide-left][data-loading] .ladda-spinner {\n    opacity: 1;\n    left: 50%; }\n\n/*************************************\n* SLIDE RIGHT\n*/\n.ladda-button[data-style=slide-right] {\n  overflow: hidden; }\n  .ladda-button[data-style=slide-right] .ladda-label {\n    position: relative; }\n  .ladda-button[data-style=slide-right] .ladda-spinner {\n    right: 100%;\n    margin-left: 0;\n    left: 16px; }\n  .ladda-button[data-style=slide-right][data-loading] .ladda-label {\n    opacity: 0;\n    left: 100%; }\n  .ladda-button[data-style=slide-right][data-loading] .ladda-spinner {\n    opacity: 1;\n    left: 50%; }\n\n/*************************************\n* SLIDE UP\n*/\n.ladda-button[data-style=slide-up] {\n  overflow: hidden; }\n  .ladda-button[data-style=slide-up] .ladda-label {\n    position: relative; }\n  .ladda-button[data-style=slide-up] .ladda-spinner {\n    left: 50%;\n    margin-left: 0;\n    margin-top: 1em; }\n  .ladda-button[data-style=slide-up][data-loading] .ladda-label {\n    opacity: 0;\n    top: -1em; }\n  .ladda-button[data-style=slide-up][data-loading] .ladda-spinner {\n    opacity: 1;\n    margin-top: 0; }\n\n/*************************************\n* SLIDE DOWN\n*/\n.ladda-button[data-style=slide-down] {\n  overflow: hidden; }\n  .ladda-button[data-style=slide-down] .ladda-label {\n    position: relative; }\n  .ladda-button[data-style=slide-down] .ladda-spinner {\n    left: 50%;\n    margin-left: 0;\n    margin-top: -2em; }\n  .ladda-button[data-style=slide-down][data-loading] .ladda-label {\n    opacity: 0;\n    top: 1em; }\n  .ladda-button[data-style=slide-down][data-loading] .ladda-spinner {\n    opacity: 1;\n    margin-top: 0; }\n\n/*************************************\n* ZOOM-OUT\n*/\n.ladda-button[data-style=zoom-out] {\n  overflow: hidden; }\n\n.ladda-button[data-style=zoom-out] .ladda-spinner {\n  left: 50%;\n  margin-left: 32px;\n  -webkit-transform: scale(2.5);\n  -moz-transform: scale(2.5);\n  -ms-transform: scale(2.5);\n  -o-transform: scale(2.5);\n  transform: scale(2.5); }\n\n.ladda-button[data-style=zoom-out] .ladda-label {\n  position: relative;\n  display: inline-block; }\n\n.ladda-button[data-style=zoom-out][data-loading] .ladda-label {\n  opacity: 0;\n  -webkit-transform: scale(0.5);\n  -moz-transform: scale(0.5);\n  -ms-transform: scale(0.5);\n  -o-transform: scale(0.5);\n  transform: scale(0.5); }\n\n.ladda-button[data-style=zoom-out][data-loading] .ladda-spinner {\n  opacity: 1;\n  margin-left: 0;\n  -webkit-transform: none;\n  -moz-transform: none;\n  -ms-transform: none;\n  -o-transform: none;\n  transform: none; }\n\n/*************************************\n* ZOOM-IN\n*/\n.ladda-button[data-style=zoom-in] {\n  overflow: hidden; }\n\n.ladda-button[data-style=zoom-in] .ladda-spinner {\n  left: 50%;\n  margin-left: -16px;\n  -webkit-transform: scale(0.2);\n  -moz-transform: scale(0.2);\n  -ms-transform: scale(0.2);\n  -o-transform: scale(0.2);\n  transform: scale(0.2); }\n\n.ladda-button[data-style=zoom-in] .ladda-label {\n  position: relative;\n  display: inline-block; }\n\n.ladda-button[data-style=zoom-in][data-loading] .ladda-label {\n  opacity: 0;\n  -webkit-transform: scale(2.2);\n  -moz-transform: scale(2.2);\n  -ms-transform: scale(2.2);\n  -o-transform: scale(2.2);\n  transform: scale(2.2); }\n\n.ladda-button[data-style=zoom-in][data-loading] .ladda-spinner {\n  opacity: 1;\n  margin-left: 0;\n  -webkit-transform: none;\n  -moz-transform: none;\n  -ms-transform: none;\n  -o-transform: none;\n  transform: none; }\n\n/*************************************\n* CONTRACT\n*/\n.ladda-button[data-style=contract] {\n  overflow: hidden;\n  width: 100px; }\n\n.ladda-button[data-style=contract] .ladda-spinner {\n  left: 50%;\n  margin-left: 0; }\n\n.ladda-button[data-style=contract][data-loading] {\n  border-radius: 50%;\n  width: 52px; }\n\n.ladda-button[data-style=contract][data-loading] .ladda-label {\n  opacity: 0; }\n\n.ladda-button[data-style=contract][data-loading] .ladda-spinner {\n  opacity: 1; }\n\n/*************************************\n* OVERLAY\n*/\n.ladda-button[data-style=contract-overlay] {\n  overflow: hidden;\n  width: 100px;\n  box-shadow: 0px 0px 0px 2000px transparent; }\n\n.ladda-button[data-style=contract-overlay] .ladda-spinner {\n  left: 50%;\n  margin-left: 0; }\n\n.ladda-button[data-style=contract-overlay][data-loading] {\n  border-radius: 50%;\n  width: 52px;\n  /*outline: 10000px solid rgba( 0, 0, 0, 0.5 );*/\n  box-shadow: 0px 0px 0px 2000px rgba(0, 0, 0, 0.8); }\n\n.ladda-button[data-style=contract-overlay][data-loading] .ladda-label {\n  opacity: 0; }\n\n.ladda-button[data-style=contract-overlay][data-loading] .ladda-spinner {\n  opacity: 1; }\n\n/*\nVersion: 3.5.4 Timestamp: Sun Aug 30 13:30:32 EDT 2015\n*/\n.select2-container {\n  margin: 0;\n  position: relative;\n  display: inline-block;\n  vertical-align: middle; }\n\n.select2-container,\n.select2-drop,\n.select2-search,\n.select2-search input {\n  /*\n  Force border-box so that % widths fit the parent\n  container without overlap because of margin/padding.\n  More Info : http://www.quirksmode.org/css/box.html\n  */\n  -webkit-box-sizing: border-box;\n  /* webkit */\n  -moz-box-sizing: border-box;\n  /* firefox */\n  box-sizing: border-box;\n  /* css3 */ }\n\n.select2-container .select2-choice {\n  display: block;\n  height: 26px;\n  padding: 0 0 0 8px;\n  overflow: hidden;\n  position: relative;\n  border: 1px solid #aaa;\n  white-space: nowrap;\n  line-height: 26px;\n  color: #444;\n  text-decoration: none;\n  border-radius: 4px;\n  background-clip: padding-box;\n  -webkit-touch-callout: none;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n  background-color: #fff;\n  background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #eee), color-stop(0.5, #fff));\n  background-image: -webkit-linear-gradient(center bottom, #eee 0%, #fff 50%);\n  background-image: -moz-linear-gradient(center bottom, #eee 0%, #fff 50%);\n  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr = '#ffffff', endColorstr = '#eeeeee', GradientType = 0);\n  background-image: linear-gradient(to top, #eee 0%, #fff 50%); }\n\nhtml[dir=\"rtl\"] .select2-container .select2-choice {\n  padding: 0 8px 0 0; }\n\n.select2-container.select2-drop-above .select2-choice {\n  border-bottom-color: #aaa;\n  border-radius: 0 0 4px 4px;\n  background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #eee), color-stop(0.9, #fff));\n  background-image: -webkit-linear-gradient(center bottom, #eee 0%, #fff 90%);\n  background-image: -moz-linear-gradient(center bottom, #eee 0%, #fff 90%);\n  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#eeeeee', GradientType=0);\n  background-image: linear-gradient(to bottom, #eee 0%, #fff 90%); }\n\n.select2-container.select2-allowclear .select2-choice .select2-chosen {\n  margin-right: 42px; }\n\n.select2-container .select2-choice > .select2-chosen {\n  margin-right: 26px;\n  display: block;\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  float: none;\n  width: auto; }\n\nhtml[dir=\"rtl\"] .select2-container .select2-choice > .select2-chosen {\n  margin-left: 26px;\n  margin-right: 0; }\n\n.select2-container .select2-choice abbr {\n  display: none;\n  width: 12px;\n  height: 12px;\n  position: absolute;\n  right: 24px;\n  top: 8px;\n  font-size: 1px;\n  text-decoration: none;\n  border: 0;\n  background: url(\"../img/select2.png\") right top no-repeat;\n  cursor: pointer;\n  outline: 0; }\n\n.select2-container.select2-allowclear .select2-choice abbr {\n  display: inline-block; }\n\n.select2-container .select2-choice abbr:hover {\n  background-position: right -11px;\n  cursor: pointer; }\n\n.select2-drop-mask {\n  border: 0;\n  margin: 0;\n  padding: 0;\n  position: fixed;\n  left: 0;\n  top: 0;\n  min-height: 100%;\n  min-width: 100%;\n  height: auto;\n  width: auto;\n  opacity: 0;\n  z-index: 9998;\n  /* styles required for IE to work */\n  background-color: #fff;\n  filter: alpha(opacity=0); }\n\n.select2-drop {\n  width: 100%;\n  margin-top: -1px;\n  position: absolute;\n  z-index: 9999;\n  top: 100%;\n  background: #fff;\n  color: #000;\n  border: 1px solid #aaa;\n  border-top: 0;\n  border-radius: 0 0 4px 4px;\n  -webkit-box-shadow: 0 4px 5px rgba(0, 0, 0, 0.15);\n  box-shadow: 0 4px 5px rgba(0, 0, 0, 0.15); }\n\n.select2-drop.select2-drop-above {\n  margin-top: 1px;\n  border-top: 1px solid #aaa;\n  border-bottom: 0;\n  border-radius: 4px 4px 0 0;\n  -webkit-box-shadow: 0 -4px 5px rgba(0, 0, 0, 0.15);\n  box-shadow: 0 -4px 5px rgba(0, 0, 0, 0.15); }\n\n.select2-drop-active {\n  border: 1px solid #5897fb;\n  border-top: none; }\n\n.select2-drop.select2-drop-above.select2-drop-active {\n  border-top: 1px solid #5897fb; }\n\n.select2-drop-auto-width {\n  border-top: 1px solid #aaa;\n  width: auto; }\n\n.select2-container .select2-choice .select2-arrow {\n  display: inline-block;\n  width: 18px;\n  height: 100%;\n  position: absolute;\n  right: 0;\n  top: 0;\n  border-left: 1px solid #aaa;\n  border-radius: 0 4px 4px 0;\n  background-clip: padding-box;\n  background: #ccc;\n  background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #ccc), color-stop(0.6, #eee));\n  background-image: -webkit-linear-gradient(center bottom, #ccc 0%, #eee 60%);\n  background-image: -moz-linear-gradient(center bottom, #ccc 0%, #eee 60%);\n  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr = '#eeeeee', endColorstr = '#cccccc', GradientType = 0);\n  background-image: linear-gradient(to top, #ccc 0%, #eee 60%); }\n\nhtml[dir=\"rtl\"] .select2-container .select2-choice .select2-arrow {\n  left: 0;\n  right: auto;\n  border-left: none;\n  border-right: 1px solid #aaa;\n  border-radius: 4px 0 0 4px; }\n\n.select2-container .select2-choice .select2-arrow b {\n  display: block;\n  width: 100%;\n  height: 100%;\n  background: url(\"../img/select2.png\") no-repeat 0 1px; }\n\nhtml[dir=\"rtl\"] .select2-container .select2-choice .select2-arrow b {\n  background-position: 2px 1px; }\n\n.select2-search {\n  display: inline-block;\n  width: 100%;\n  min-height: 26px;\n  margin: 0;\n  padding: 4px 4px 0 4px;\n  position: relative;\n  z-index: 10000;\n  white-space: nowrap; }\n\n.select2-search input {\n  width: 100%;\n  height: auto !important;\n  min-height: 26px;\n  padding: 4px 20px 4px 5px;\n  margin: 0;\n  outline: 0;\n  font-family: sans-serif;\n  font-size: 1em;\n  border: 1px solid #aaa;\n  border-radius: 0;\n  -webkit-box-shadow: none;\n  box-shadow: none;\n  background: #fff url(\"../img/select2.png\") no-repeat 100% -22px;\n  background: url(\"../img/select2.png\") no-repeat 100% -22px, -webkit-gradient(linear, left bottom, left top, color-stop(0.85, #fff), color-stop(0.99, #eee));\n  background: url(\"../img/select2.png\") no-repeat 100% -22px, -webkit-linear-gradient(center bottom, #fff 85%, #eee 99%);\n  background: url(\"../img/select2.png\") no-repeat 100% -22px, -moz-linear-gradient(center bottom, #fff 85%, #eee 99%);\n  background: url(\"../img/select2.png\") no-repeat 100% -22px, linear-gradient(to bottom, #fff 85%, #eee 99%) 0 0; }\n\nhtml[dir=\"rtl\"] .select2-search input {\n  padding: 4px 5px 4px 20px;\n  background: #fff url(\"../img/select2.png\") no-repeat -37px -22px;\n  background: url(\"../img/select2.png\") no-repeat -37px -22px, -webkit-gradient(linear, left bottom, left top, color-stop(0.85, #fff), color-stop(0.99, #eee));\n  background: url(\"../img/select2.png\") no-repeat -37px -22px, -webkit-linear-gradient(center bottom, #fff 85%, #eee 99%);\n  background: url(\"../img/select2.png\") no-repeat -37px -22px, -moz-linear-gradient(center bottom, #fff 85%, #eee 99%);\n  background: url(\"../img/select2.png\") no-repeat -37px -22px, linear-gradient(to bottom, #fff 85%, #eee 99%) 0 0; }\n\n.select2-search input.select2-active {\n  background: #fff url(\"../img/select2-spinner.gif\") no-repeat 100%;\n  background: url(\"../img/select2-spinner.gif\") no-repeat 100%, -webkit-gradient(linear, left bottom, left top, color-stop(0.85, #fff), color-stop(0.99, #eee));\n  background: url(\"../img/select2-spinner.gif\") no-repeat 100%, -webkit-linear-gradient(center bottom, #fff 85%, #eee 99%);\n  background: url(\"../img/select2-spinner.gif\") no-repeat 100%, -moz-linear-gradient(center bottom, #fff 85%, #eee 99%);\n  background: url(\"../img/select2-spinner.gif\") no-repeat 100%, linear-gradient(to bottom, #fff 85%, #eee 99%) 0 0; }\n\n.select2-container-active .select2-choice,\n.select2-container-active .select2-choices {\n  border: 1px solid #5897fb;\n  outline: none;\n  -webkit-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);\n  box-shadow: 0 0 5px rgba(0, 0, 0, 0.3); }\n\n.select2-dropdown-open .select2-choice {\n  border-bottom-color: transparent;\n  -webkit-box-shadow: 0 1px 0 #fff inset;\n  box-shadow: 0 1px 0 #fff inset;\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n  background-color: #eee;\n  background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #fff), color-stop(0.5, #eee));\n  background-image: -webkit-linear-gradient(center bottom, #fff 0%, #eee 50%);\n  background-image: -moz-linear-gradient(center bottom, #fff 0%, #eee 50%);\n  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#eeeeee', endColorstr='#ffffff', GradientType=0);\n  background-image: linear-gradient(to top, #fff 0%, #eee 50%); }\n\n.select2-dropdown-open.select2-drop-above .select2-choice,\n.select2-dropdown-open.select2-drop-above .select2-choices {\n  border: 1px solid #5897fb;\n  border-top-color: transparent;\n  background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0, #fff), color-stop(0.5, #eee));\n  background-image: -webkit-linear-gradient(center top, #fff 0%, #eee 50%);\n  background-image: -moz-linear-gradient(center top, #fff 0%, #eee 50%);\n  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#eeeeee', endColorstr='#ffffff', GradientType=0);\n  background-image: linear-gradient(to bottom, #fff 0%, #eee 50%); }\n\n.select2-dropdown-open .select2-choice .select2-arrow {\n  background: transparent;\n  border-left: none;\n  filter: none; }\n\nhtml[dir=\"rtl\"] .select2-dropdown-open .select2-choice .select2-arrow {\n  border-right: none; }\n\n.select2-dropdown-open .select2-choice .select2-arrow b {\n  background-position: -18px 1px; }\n\nhtml[dir=\"rtl\"] .select2-dropdown-open .select2-choice .select2-arrow b {\n  background-position: -16px 1px; }\n\n.select2-hidden-accessible {\n  border: 0;\n  clip: rect(0 0 0 0);\n  height: 1px;\n  margin: -1px;\n  overflow: hidden;\n  padding: 0;\n  position: absolute;\n  width: 1px; }\n\n/* results */\n.select2-results {\n  max-height: 200px;\n  padding: 0 0 0 4px;\n  margin: 4px 4px 4px 0;\n  position: relative;\n  overflow-x: hidden;\n  overflow-y: auto;\n  -webkit-tap-highlight-color: transparent; }\n\nhtml[dir=\"rtl\"] .select2-results {\n  padding: 0 4px 0 0;\n  margin: 4px 0 4px 4px; }\n\n.select2-results ul.select2-result-sub {\n  margin: 0;\n  padding-left: 0; }\n\n.select2-results li {\n  list-style: none;\n  display: list-item;\n  background-image: none; }\n\n.select2-results li.select2-result-with-children > .select2-result-label {\n  font-weight: bold; }\n\n.select2-results .select2-result-label {\n  padding: 3px 7px 4px;\n  margin: 0;\n  cursor: pointer;\n  min-height: 1em;\n  -webkit-touch-callout: none;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none; }\n\n.select2-results-dept-1 .select2-result-label {\n  padding-left: 20px; }\n\n.select2-results-dept-2 .select2-result-label {\n  padding-left: 40px; }\n\n.select2-results-dept-3 .select2-result-label {\n  padding-left: 60px; }\n\n.select2-results-dept-4 .select2-result-label {\n  padding-left: 80px; }\n\n.select2-results-dept-5 .select2-result-label {\n  padding-left: 100px; }\n\n.select2-results-dept-6 .select2-result-label {\n  padding-left: 110px; }\n\n.select2-results-dept-7 .select2-result-label {\n  padding-left: 120px; }\n\n.select2-results .select2-highlighted {\n  background: #3875d7;\n  color: #fff; }\n\n.select2-results li em {\n  background: #feffde;\n  font-style: normal; }\n\n.select2-results .select2-highlighted em {\n  background: transparent; }\n\n.select2-results .select2-highlighted ul {\n  background: #fff;\n  color: #000; }\n\n.select2-results .select2-no-results,\n.select2-results .select2-searching,\n.select2-results .select2-ajax-error,\n.select2-results .select2-selection-limit {\n  background: #f4f4f4;\n  display: list-item;\n  padding-left: 5px; }\n\n/*\ndisabled look for disabled choices in the results dropdown\n*/\n.select2-results .select2-disabled.select2-highlighted {\n  color: #666;\n  background: #f4f4f4;\n  display: list-item;\n  cursor: default; }\n\n.select2-results .select2-disabled {\n  background: #f4f4f4;\n  display: list-item;\n  cursor: default; }\n\n.select2-results .select2-selected {\n  display: none; }\n\n.select2-more-results.select2-active {\n  background: #f4f4f4 url(\"../img/select2-spinner.gif\") no-repeat 100%; }\n\n.select2-results .select2-ajax-error {\n  background: rgba(255, 50, 50, 0.2); }\n\n.select2-more-results {\n  background: #f4f4f4;\n  display: list-item; }\n\n/* disabled styles */\n.select2-container.select2-container-disabled .select2-choice {\n  background-color: #f4f4f4;\n  background-image: none;\n  border: 1px solid #ddd;\n  cursor: default; }\n\n.select2-container.select2-container-disabled .select2-choice .select2-arrow {\n  background-color: #f4f4f4;\n  background-image: none;\n  border-left: 0; }\n\n.select2-container.select2-container-disabled .select2-choice abbr {\n  display: none; }\n\n/* multiselect */\n.select2-container-multi .select2-choices {\n  height: auto !important;\n  height: 1%;\n  margin: 0;\n  padding: 0 5px 0 0;\n  position: relative;\n  border: 1px solid #aaa;\n  cursor: text;\n  overflow: hidden;\n  background-color: #fff;\n  background-image: -webkit-gradient(linear, 0% 0%, 0% 100%, color-stop(1%, #eee), color-stop(15%, #fff));\n  background-image: -webkit-linear-gradient(top, #eee 1%, #fff 15%);\n  background-image: -moz-linear-gradient(top, #eee 1%, #fff 15%);\n  background-image: linear-gradient(to bottom, #eee 1%, #fff 15%); }\n\nhtml[dir=\"rtl\"] .select2-container-multi .select2-choices {\n  padding: 0 0 0 5px; }\n\n.select2-locked {\n  padding: 3px 5px 3px 5px !important; }\n\n.select2-container-multi .select2-choices {\n  min-height: 26px; }\n\n.select2-container-multi.select2-container-active .select2-choices {\n  border: 1px solid #5897fb;\n  outline: none;\n  -webkit-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);\n  box-shadow: 0 0 5px rgba(0, 0, 0, 0.3); }\n\n.select2-container-multi .select2-choices li {\n  float: left;\n  list-style: none; }\n\nhtml[dir=\"rtl\"] .select2-container-multi .select2-choices li {\n  float: right; }\n\n.select2-container-multi .select2-choices .select2-search-field {\n  margin: 0;\n  padding: 0;\n  white-space: nowrap; }\n\n.select2-container-multi .select2-choices .select2-search-field input {\n  padding: 5px;\n  margin: 1px 0;\n  font-family: sans-serif;\n  font-size: 100%;\n  color: #666;\n  outline: 0;\n  border: 0;\n  -webkit-box-shadow: none;\n  box-shadow: none;\n  background: transparent !important; }\n\n.select2-container-multi .select2-choices .select2-search-field input.select2-active {\n  background: #fff url(\"../img/select2-spinner.gif\") no-repeat 100% !important; }\n\n.select2-default {\n  color: #999 !important; }\n\n.select2-container-multi .select2-choices .select2-search-choice {\n  padding: 3px 5px 3px 18px;\n  margin: 3px 0 3px 5px;\n  position: relative;\n  line-height: 13px;\n  color: #333;\n  cursor: default;\n  border: 1px solid #aaaaaa;\n  border-radius: 3px;\n  -webkit-box-shadow: 0 0 2px #fff inset, 0 1px 0 rgba(0, 0, 0, 0.05);\n  box-shadow: 0 0 2px #fff inset, 0 1px 0 rgba(0, 0, 0, 0.05);\n  background-clip: padding-box;\n  -webkit-touch-callout: none;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n  background-color: #e4e4e4;\n  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#eeeeee', endColorstr='#f4f4f4', GradientType=0);\n  background-image: -webkit-gradient(linear, 0% 0%, 0% 100%, color-stop(20%, #f4f4f4), color-stop(50%, #f0f0f0), color-stop(52%, #e8e8e8), color-stop(100%, #eee));\n  background-image: -webkit-linear-gradient(top, #f4f4f4 20%, #f0f0f0 50%, #e8e8e8 52%, #eee 100%);\n  background-image: -moz-linear-gradient(top, #f4f4f4 20%, #f0f0f0 50%, #e8e8e8 52%, #eee 100%);\n  background-image: linear-gradient(to bottom, #f4f4f4 20%, #f0f0f0 50%, #e8e8e8 52%, #eee 100%); }\n\nhtml[dir=\"rtl\"] .select2-container-multi .select2-choices .select2-search-choice {\n  margin: 3px 5px 3px 0;\n  padding: 3px 18px 3px 5px; }\n\n.select2-container-multi .select2-choices .select2-search-choice .select2-chosen {\n  cursor: default; }\n\n.select2-container-multi .select2-choices .select2-search-choice-focus {\n  background: #d4d4d4; }\n\n.select2-search-choice-close {\n  display: block;\n  width: 12px;\n  height: 13px;\n  position: absolute;\n  right: 3px;\n  top: 4px;\n  font-size: 1px;\n  outline: none;\n  background: url(\"../img/select2.png\") right top no-repeat; }\n\nhtml[dir=\"rtl\"] .select2-search-choice-close {\n  right: auto;\n  left: 3px; }\n\n.select2-container-multi .select2-search-choice-close {\n  left: 3px; }\n\nhtml[dir=\"rtl\"] .select2-container-multi .select2-search-choice-close {\n  left: auto;\n  right: 2px; }\n\n.select2-container-multi .select2-choices .select2-search-choice .select2-search-choice-close:hover {\n  background-position: right -11px; }\n\n.select2-container-multi .select2-choices .select2-search-choice-focus .select2-search-choice-close {\n  background-position: right -11px; }\n\n/* disabled styles */\n.select2-container-multi.select2-container-disabled .select2-choices {\n  background-color: #f4f4f4;\n  background-image: none;\n  border: 1px solid #ddd;\n  cursor: default; }\n\n.select2-container-multi.select2-container-disabled .select2-choices .select2-search-choice {\n  padding: 3px 5px 3px 5px;\n  border: 1px solid #ddd;\n  background-image: none;\n  background-color: #f4f4f4; }\n\n.select2-container-multi.select2-container-disabled .select2-choices .select2-search-choice .select2-search-choice-close {\n  display: none;\n  background: none; }\n\n/* end multiselect */\n.select2-result-selectable .select2-match,\n.select2-result-unselectable .select2-match {\n  text-decoration: underline; }\n\n.select2-offscreen, .select2-offscreen:focus {\n  clip: rect(0 0 0 0) !important;\n  width: 1px !important;\n  height: 1px !important;\n  border: 0 !important;\n  margin: 0 !important;\n  padding: 0 !important;\n  overflow: hidden !important;\n  position: absolute !important;\n  outline: 0 !important;\n  left: 0px !important;\n  top: 0px !important; }\n\n.select2-display-none {\n  display: none; }\n\n.select2-measure-scrollbar {\n  position: absolute;\n  top: -10000px;\n  left: -10000px;\n  width: 100px;\n  height: 100px;\n  overflow: scroll; }\n\n/* Retina-ize icons */\n@media only screen and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min-resolution: 2dppx) {\n  .select2-search input,\n  .select2-search-choice-close,\n  .select2-container .select2-choice abbr,\n  .select2-container .select2-choice .select2-arrow b {\n    background-image: url(\"../img/select2x2.png\") !important;\n    background-repeat: no-repeat !important;\n    background-size: 60px 40px !important; }\n  .select2-search input {\n    background-position: 100% -21px !important; } }\n\n/*! Select2 Bootstrap 3 CSS v1.4.6 | MIT License | github.com/t0m/select2-bootstrap-css */\n/**\n* Reset Bootstrap 3 .form-control styles which - if applied to the\n* original <select>-element the Select2-plugin may be run against -\n* are copied to the .select2-container.\n*\n* 1. Overwrite .select2-container's original display:inline-block\n*    with Bootstrap 3's default for .form-control, display:block;\n*    courtesy of @juristr (@see https://github.com/fk/select2-bootstrap-css/pull/1)\n*/\n.select2-container.form-control, .daterangepicker .select2-container.input-mini, .input-group > .ui-select-bootstrap > input.select2-container.ui-select-search.form-control {\n  background: transparent;\n  box-shadow: none;\n  display: block;\n  /* 1 */\n  margin: 0;\n  padding: 0; }\n\n/**\n* Adjust Select2 inputs to fit Bootstrap 3 default .form-control appearance.\n*/\n.select2-container .select2-choices .select2-search-field input,\n.select2-container .select2-choice,\n.select2-container .select2-choices {\n  background: none;\n  padding: 0;\n  border-color: #cccccc;\n  border-radius: 4px;\n  color: #555555;\n  font-family: \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  background-color: white;\n  filter: progid:DXImageTransform.Microsoft.gradient(enabled = false); }\n\n.select2-search input {\n  border-color: #cccccc;\n  border-radius: 4px;\n  color: #555555;\n  font-family: \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  background-color: white;\n  filter: progid:DXImageTransform.Microsoft.gradient(enabled = false);\n  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);\n  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075); }\n\n.select2-container .select2-choices .select2-search-field input {\n  -webkit-box-shadow: none;\n  box-shadow: none; }\n\n/**\n* Adjust Select2 input heights to match the Bootstrap default.\n*/\n.select2-container .select2-choice {\n  height: 34px;\n  line-height: 1.42857; }\n\n/**\n* Address Multi Select2's height which - depending on how many elements have been selected -\n* may grown higher than their initial size.\n*/\n.select2-container.select2-container-multi.form-control, .daterangepicker .select2-container.select2-container-multi.input-mini, .input-group > .ui-select-bootstrap > input.select2-container.select2-container-multi.ui-select-search.form-control {\n  height: auto; }\n\n/**\n* Address Bootstrap 3 control sizing classes\n* @see http://getbootstrap.com/css/#forms-control-sizes\n*/\n.select2-container.input-sm .select2-choice,\n.input-group-sm .select2-container .select2-choice {\n  height: 30px;\n  line-height: 1.5;\n  border-radius: 3px; }\n\n.select2-container.input-lg .select2-choice,\n.input-group-lg .select2-container .select2-choice {\n  height: 46px;\n  line-height: 1.33333;\n  border-radius: 6px; }\n\n.select2-container-multi .select2-choices .select2-search-field input {\n  height: 32px; }\n\n.select2-container-multi.input-sm .select2-choices .select2-search-field input,\n.input-group-sm .select2-container-multi .select2-choices .select2-search-field input {\n  height: 28px; }\n\n.select2-container-multi.input-lg .select2-choices .select2-search-field input,\n.input-group-lg .select2-container-multi .select2-choices .select2-search-field input {\n  height: 44px; }\n\n/**\n* Adjust height and line-height for .select2-search-field amd multi-select Select2 widgets.\n*\n* 1. Class repetition to address missing .select2-chosen in Select2 < 3.3.2.\n*/\n.select2-container-multi .select2-choices .select2-search-field input {\n  margin: 0; }\n\n.input-sm .select2-chosen,\n.input-group-sm .select2-chosen,\n.input-sm .select2-choice > span:first-child,\n.input-group-sm .select2-choice > span:first-child,\n.input-sm .select2-choices .select2-search-field input,\n.input-group-sm .select2-choices .select2-search-field input {\n  padding: 5px 10px; }\n\n.input-lg .select2-chosen,\n.input-group-lg .select2-chosen,\n.input-lg .select2-choice > span:first-child,\n.input-group-lg .select2-choice > span:first-child,\n.input-lg .select2-choices .select2-search-field input,\n.input-group-lg .select2-choices .select2-search-field input {\n  padding: 10px 16px; }\n\n.select2-container-multi .select2-choices .select2-search-choice {\n  margin-top: 5px;\n  margin-bottom: 3px; }\n\n.select2-container-multi.input-sm .select2-choices .select2-search-choice,\n.input-group-sm .select2-container-multi .select2-choices .select2-search-choice {\n  margin-top: 3px;\n  margin-bottom: 2px; }\n\n.select2-container-multi.input-lg .select2-choices .select2-search-choice,\n.input-group-lg .select2-container-multi .select2-choices .select2-search-choice {\n  line-height: 24px; }\n\n/**\n* Adjust the single Select2's dropdown arrow button appearance.\n*\n* 1. For Select2 v.3.3.2.\n*/\n.select2-container .select2-choice .select2-arrow,\n.select2-container .select2-choice div {\n  border-left: none;\n  background: none;\n  filter: progid:DXImageTransform.Microsoft.gradient(enabled = false); }\n\n.select2-dropdown-open .select2-choice .select2-arrow,\n.select2-dropdown-open .select2-choice div {\n  border-left-color: transparent;\n  background: none;\n  filter: progid:DXImageTransform.Microsoft.gradient(enabled = false); }\n\n/**\n* Adjust the dropdown arrow button icon position for the single-select Select2 elements\n* to make it line up vertically now that we increased the height of .select2-container.\n*\n* 1. Class repetition to address missing .select2-chosen in Select2 v.3.3.2.\n*/\n.select2-container .select2-choice .select2-arrow b,\n.select2-container .select2-choice div b {\n  background-position: 0 3px; }\n\n.select2-dropdown-open .select2-choice .select2-arrow b,\n.select2-dropdown-open .select2-choice div b {\n  background-position: -18px 3px; }\n\n.select2-container.input-sm .select2-choice .select2-arrow b,\n.input-group-sm .select2-container .select2-choice .select2-arrow b,\n.select2-container.input-sm .select2-choice div b,\n.input-group-sm .select2-container .select2-choice div b {\n  background-position: 0 1px; }\n\n.select2-dropdown-open.input-sm .select2-choice .select2-arrow b,\n.input-group-sm .select2-dropdown-open .select2-choice .select2-arrow b,\n.select2-dropdown-open.input-sm .select2-choice div b,\n.input-group-sm .select2-dropdown-open .select2-choice div b {\n  background-position: -18px 1px; }\n\n.select2-container.input-lg .select2-choice .select2-arrow b,\n.input-group-lg .select2-container .select2-choice .select2-arrow b,\n.select2-container.input-lg .select2-choice div b,\n.input-group-lg .select2-container .select2-choice div b {\n  background-position: 0 9px; }\n\n.select2-dropdown-open.input-lg .select2-choice .select2-arrow b,\n.input-group-lg .select2-dropdown-open .select2-choice .select2-arrow b,\n.select2-dropdown-open.input-lg .select2-choice div b,\n.input-group-lg .select2-dropdown-open .select2-choice div b {\n  background-position: -18px 9px; }\n\n/**\n* Address Bootstrap's validation states and change Select2's border colors and focus states.\n* Apply .has-warning, .has-danger or .has-succes to #select2-drop to match Bootstraps' colors.\n*/\n.has-warning .select2-choice,\n.has-warning .select2-choices {\n  border-color: #8a6d3b; }\n\n.has-warning .select2-container-active .select2-choice,\n.has-warning .select2-container-multi.select2-container-active .select2-choices {\n  border-color: #66512c;\n  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;\n  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b; }\n\n.has-warning.select2-drop-active {\n  border-color: #66512c; }\n\n.has-warning.select2-drop-active.select2-drop.select2-drop-above {\n  border-top-color: #66512c; }\n\n.has-error .select2-choice,\n.has-error .select2-choices {\n  border-color: #a94442; }\n\n.has-error .select2-container-active .select2-choice,\n.has-error .select2-container-multi.select2-container-active .select2-choices {\n  border-color: #843534;\n  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;\n  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483; }\n\n.has-error.select2-drop-active {\n  border-color: #843534; }\n\n.has-error.select2-drop-active.select2-drop.select2-drop-above {\n  border-top-color: #843534; }\n\n.has-success .select2-choice,\n.has-success .select2-choices {\n  border-color: #3c763d; }\n\n.has-success .select2-container-active .select2-choice,\n.has-success .select2-container-multi.select2-container-active .select2-choices {\n  border-color: #2b542c;\n  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;\n  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168; }\n\n.has-success.select2-drop-active {\n  border-color: #2b542c; }\n\n.has-success.select2-drop-active.select2-drop.select2-drop-above {\n  border-top-color: #2b542c; }\n\n/**\n* Make Select2's active-styles - applied to .select2-container when the widget receives focus -\n* fit Bootstrap 3's .form-element:focus appearance.\n*/\n.select2-container-active .select2-choice,\n.select2-container-multi.select2-container-active .select2-choices {\n  border-color: #66afe9;\n  outline: none;\n  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);\n  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);\n  -webkit-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;\n  -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;\n  transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s; }\n\n.select2-drop-active {\n  border-color: #66afe9; }\n\n.select2-drop-auto-width,\n.select2-drop.select2-drop-above.select2-drop-active {\n  border-top-color: #66afe9; }\n\n/**\n* Select2 widgets in Bootstrap Input Groups\n*\n* When Select2 widgets are combined with other elements using Bootstrap 3's\n* \"Input Group\" component, we don't want specific edges of the Select2 container\n* to have a border-radius.\n*\n* In Bootstrap 2, input groups required a markup where these style adjustments\n* could be bound to a CSS-class identifying if the additional elements are appended,\n* prepended or both.\n*\n* Bootstrap 3 doesn't rely on these classes anymore, so we have to use our own.\n* Use .select2-bootstrap-prepend and .select2-bootstrap-append on a Bootstrap 3 .input-group\n* to let the contained Select2 widget know which edges should not be rounded as they are\n* directly followed by another element.\n*\n* @see http://getbootstrap.com/components/#input-groups\n*/\n.input-group.select2-bootstrap-prepend [class^=\"select2-choice\"] {\n  border-bottom-left-radius: 0 !important;\n  border-top-left-radius: 0 !important; }\n\n.input-group.select2-bootstrap-append [class^=\"select2-choice\"] {\n  border-bottom-right-radius: 0 !important;\n  border-top-right-radius: 0 !important; }\n\n.select2-dropdown-open [class^=\"select2-choice\"] {\n  border-bottom-right-radius: 0 !important;\n  border-bottom-left-radius: 0 !important; }\n\n.select2-dropdown-open.select2-drop-above [class^=\"select2-choice\"] {\n  border-top-right-radius: 0 !important;\n  border-top-left-radius: 0 !important;\n  border-bottom-right-radius: 4px !important;\n  border-bottom-left-radius: 4px !important;\n  background: white;\n  filter: none; }\n\n.input-group.select2-bootstrap-prepend .select2-dropdown-open.select2-drop-above [class^=\"select2-choice\"] {\n  border-bottom-left-radius: 0 !important;\n  border-top-left-radius: 0 !important; }\n\n.input-group.select2-bootstrap-append .select2-dropdown-open.select2-drop-above [class^=\"select2-choice\"] {\n  border-bottom-right-radius: 0 !important;\n  border-top-right-radius: 0 !important; }\n\n.input-group.input-group-sm.select2-bootstrap-prepend .select2-dropdown-open.select2-drop-above [class^=\"select2-choice\"] {\n  border-bottom-right-radius: 3px !important; }\n\n.input-group.input-group-lg.select2-bootstrap-prepend .select2-dropdown-open.select2-drop-above [class^=\"select2-choice\"] {\n  border-bottom-right-radius: 6px !important; }\n\n.input-group.input-group-sm.select2-bootstrap-append .select2-dropdown-open.select2-drop-above [class^=\"select2-choice\"] {\n  border-bottom-left-radius: 3px !important; }\n\n.input-group.input-group-lg.select2-bootstrap-append .select2-dropdown-open.select2-drop-above [class^=\"select2-choice\"] {\n  border-bottom-left-radius: 6px !important; }\n\n/**\n* Adjust Select2's choices hover and selected styles to match Bootstrap 3's default dropdown styles.\n*/\n.select2-results .select2-highlighted {\n  color: white;\n  background-color: #20a8d8; }\n\n/**\n* Adjust alignment of Bootstrap 3 buttons in Bootstrap 3 Input Groups to address\n* Multi Select2's height which - depending on how many elements have been selected -\n* may grown higher than their initial size.\n*/\n.select2-bootstrap-append .select2-container-multiple,\n.select2-bootstrap-append .input-group-btn,\n.select2-bootstrap-append .input-group-btn .btn,\n.select2-bootstrap-append .input-group-btn .fc button, .fc\n.select2-bootstrap-append .input-group-btn button,\n.select2-bootstrap-prepend .select2-container-multiple,\n.select2-bootstrap-prepend .input-group-btn,\n.select2-bootstrap-prepend .input-group-btn .btn,\n.select2-bootstrap-prepend .input-group-btn .fc button, .fc\n.select2-bootstrap-prepend .input-group-btn button {\n  vertical-align: top; }\n\n/**\n* Make Multi Select2's choices match Bootstrap 3's default button styles.\n*/\n.select2-container-multi .select2-choices .select2-search-choice {\n  color: #555555;\n  background: white;\n  border-color: #cccccc;\n  filter: progid:DXImageTransform.Microsoft.gradient(enabled = false);\n  -webkit-box-shadow: none;\n  box-shadow: none; }\n\n.select2-container-multi .select2-choices .select2-search-choice-focus {\n  background: #ebebeb;\n  border-color: #adadad;\n  color: #333333;\n  -webkit-box-shadow: none;\n  box-shadow: none; }\n\n/**\n* Address Multi Select2's choice close-button vertical alignment.\n*/\n.select2-search-choice-close {\n  margin-top: -7px;\n  top: 50%; }\n\n/**\n* Adjust the single Select2's clear button position (used to reset the select box\n* back to the placeholder value and visible once a selection is made\n* activated by Select2's \"allowClear\" option).\n*/\n.select2-container .select2-choice abbr {\n  top: 50%; }\n\n/**\n* Adjust \"no results\" and \"selection limit\" messages to make use\n* of Bootstrap 3's default \"Alert\" style.\n*\n* @see http://getbootstrap.com/components/#alerts-default\n*/\n.select2-results .select2-no-results,\n.select2-results .select2-searching,\n.select2-results .select2-selection-limit {\n  background-color: #fcf8e3;\n  color: #8a6d3b; }\n\n/**\n* Address disabled Select2 styles.\n*\n* 1. For Select2 v.3.3.2.\n* 2. Revert border-left:0 inherited from Select2's CSS to prevent the arrow\n*    from jumping when switching from disabled to enabled state and vice versa.\n*/\n.select2-container.select2-container-disabled .select2-choice,\n.select2-container.select2-container-disabled .select2-choices {\n  cursor: not-allowed;\n  background-color: #eeeeee;\n  border-color: #cccccc; }\n\n.select2-container.select2-container-disabled .select2-choice .select2-arrow,\n.select2-container.select2-container-disabled .select2-choice div,\n.select2-container.select2-container-disabled .select2-choices .select2-arrow,\n.select2-container.select2-container-disabled .select2-choices div {\n  background-color: transparent;\n  border-left: 1px solid transparent;\n  /* 2 */ }\n\n/**\n* Address Select2's loading indicator position - which should not stick\n* to the right edge of Select2's search input.\n*\n* 1. in .select2-search input\n* 2. in Multi Select2's .select2-search-field input\n* 3. in the status-message of infinite-scroll with remote data (@see http://ivaynberg.github.io/select2/#infinite)\n*\n* These styles alter Select2's default background-position of 100%\n* and supply the new background-position syntax to browsers which support it:\n*\n* 1. Android, Safari < 6/Mobile, IE<9: change to a relative background-position of 99%\n* 2. Chrome 25+, Firefox 13+, IE 9+, Opera 10.5+: use the new CSS3-background-position syntax\n*\n* @see http://www.w3.org/TR/css3-background/#background-position\n*\n* @todo Since both Select2 and Bootstrap 3 only support IE8 and above,\n* we could use the :after-pseudo-element to display the loading indicator.\n* Alternatively, we could supply an altered loading indicator image which already\n* contains an offset to the right.\n*/\n.select2-search input.select2-active,\n.select2-container-multi .select2-choices .select2-search-field input.select2-active,\n.select2-more-results.select2-active {\n  background-position: 99%;\n  /* 4 */\n  background-position: right 4px center;\n  /* 5 */ }\n\n/**\n* To support Select2 pre v3.4.2 in combination with Bootstrap v3.2.0,\n* ensure that .select2-offscreen width, height and position can not be overwritten.\n*\n* This adresses changes in Bootstrap somewhere after the initial v3.0.0 which -\n* in combination with Select2's pre-v3.4.2 CSS missing the \"!important\" after\n* the following rules - allow Bootstrap to overwrite the latter, which results in\n* the original <select> element Select2 is replacing not be properly being hidden\n* when used in a \"Bootstrap Input Group with Addon\".\n**/\n.select2-offscreen,\n.select2-offscreen:focus {\n  width: 1px !important;\n  height: 1px !important;\n  position: absolute !important; }\n\n/*!\n* ui-select\n* http://github.com/angular-ui/ui-select\n* Version: 0.13.1 - 2015-09-30T05:39:26.659Z\n* License: MIT\n*/\n/* Style when highlighting a search. */\n.ui-select-highlight {\n  font-weight: bold; }\n\n.ui-select-offscreen {\n  clip: rect(0 0 0 0) !important;\n  width: 1px !important;\n  height: 1px !important;\n  border: 0 !important;\n  margin: 0 !important;\n  padding: 0 !important;\n  overflow: hidden !important;\n  position: absolute !important;\n  outline: 0 !important;\n  left: 0px !important;\n  top: 0px !important; }\n\n.ui-select-choices-row:hover {\n  background-color: #f5f5f5; }\n\n/* Select2 theme */\n/* Mark invalid Select2 */\n.ng-dirty.ng-invalid > a.select2-choice {\n  border-color: #D44950; }\n\n.select2-result-single {\n  padding-left: 0; }\n\n.select2-locked > .select2-search-choice-close {\n  display: none; }\n\n.select-locked > .ui-select-match-close {\n  display: none; }\n\nbody > .select2-container.open {\n  z-index: 9999;\n  /* The z-index Select2 applies to the select2-drop */ }\n\n/* Handle up direction Select2 */\n.ui-select-container[theme=\"select2\"].direction-up .ui-select-match {\n  border-radius: 4px;\n  /* FIXME hardcoded value :-/ */\n  border-top-left-radius: 0;\n  border-top-right-radius: 0; }\n\n.ui-select-container[theme=\"select2\"].direction-up .ui-select-dropdown {\n  border-radius: 4px;\n  /* FIXME hardcoded value :-/ */\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n  border-top-width: 1px;\n  /* FIXME hardcoded value :-/ */\n  border-top-style: solid;\n  box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.25);\n  margin-top: -4px;\n  /* FIXME hardcoded value :-/ */ }\n\n.ui-select-container[theme=\"select2\"].direction-up .ui-select-dropdown .select2-search {\n  margin-top: 4px;\n  /* FIXME hardcoded value :-/ */ }\n\n.ui-select-container[theme=\"select2\"].direction-up.select2-dropdown-open .ui-select-match {\n  border-bottom-color: #5897fb; }\n\n/* Bootstrap theme */\n/* Helper class to show styles when focus */\n.btn-default-focus {\n  border-color: #20a8d8; }\n\n.btn-default {\n  border-color: #d1d4d7;\n  outline: 0;\n  padding-left: 12px; }\n\n.ui-select-bootstrap .ui-select-toggle {\n  position: relative; }\n\n.ui-select-bootstrap .ui-select-toggle > .caret {\n  position: absolute;\n  height: 10px;\n  top: 50%;\n  right: 10px;\n  margin-top: -2px; }\n\n/* Fix Bootstrap dropdown position when inside a input-group */\n.input-group > .ui-select-bootstrap.dropdown {\n  /* Instead of relative */\n  position: static; }\n\n.daterangepicker .input-group > .ui-select-bootstrap > input.ui-select-search.input-mini, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control, .input-group > .ui-select-bootstrap > input.ui-select-search.form-control.direction-up {\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0; }\n\n.daterangepicker .input-group > .ui-select-bootstrap > input.ui-select-search.direction-up.input-mini, .input-group > .ui-select-bootstrap > input.ui-select-search.direction-up.form-control {\n  border-top-right-radius: 0 !important;\n  border-bottom-right-radius: 0; }\n\n.ui-select-bootstrap > .ui-select-match > .btn, .fc .ui-select-bootstrap > .ui-select-match > button {\n  /* Instead of center because of .btn */\n  text-align: left !important; }\n\n.ui-select-bootstrap > .ui-select-match > .caret {\n  position: absolute;\n  top: 45%;\n  right: 15px; }\n\n/* See Scrollable Menu with Bootstrap 3 http://stackoverflow.com/questions/19227496 */\n.ui-select-bootstrap > .ui-select-choices {\n  width: 100%;\n  height: auto;\n  max-height: 200px;\n  overflow-x: hidden;\n  margin-top: -1px; }\n\nbody > .ui-select-bootstrap.open {\n  z-index: 1000;\n  /* Standard Bootstrap dropdown z-index */ }\n\n.ui-select-multiple.ui-select-bootstrap {\n  height: auto;\n  padding: 3px 3px 0 3px; }\n\n.ui-select-multiple.ui-select-bootstrap input.ui-select-search {\n  background-color: transparent !important;\n  /* To prevent double background when disabled */\n  border: none;\n  outline: none;\n  height: 1.666666em;\n  margin-bottom: 3px; }\n\n.ui-select-multiple.ui-select-bootstrap .ui-select-match .close {\n  font-size: 1.6em;\n  line-height: 0.75; }\n\n.ui-select-multiple.ui-select-bootstrap .ui-select-match-item {\n  outline: 0;\n  margin: 0 3px 3px 0; }\n\n.ui-select-multiple .ui-select-match-item {\n  position: relative; }\n\n.ui-select-multiple .ui-select-match-item.dropping-before:before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  right: 100%;\n  height: 100%;\n  margin-right: 2px;\n  border-left: 1px solid #428bca; }\n\n.ui-select-multiple .ui-select-match-item.dropping-after:after {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 100%;\n  height: 100%;\n  margin-left: 2px;\n  border-right: 1px solid #428bca; }\n\n.ui-select-bootstrap .ui-select-choices-row > a {\n  display: block;\n  padding: 3px 20px;\n  clear: both;\n  font-weight: 400;\n  line-height: 1.42857143;\n  color: #333;\n  white-space: nowrap; }\n\n.ui-select-bootstrap .ui-select-choices-row > a:hover, .ui-select-bootstrap .ui-select-choices-row > a:focus {\n  text-decoration: none;\n  color: #262626;\n  background-color: #f5f5f5; }\n\n.ui-select-bootstrap .ui-select-choices-row.active > a {\n  color: #fff;\n  text-decoration: none;\n  outline: 0;\n  background-color: #428bca; }\n\n.ui-select-bootstrap .ui-select-choices-row.disabled > a,\n.ui-select-bootstrap .ui-select-choices-row.active.disabled > a {\n  color: #777;\n  cursor: not-allowed;\n  background-color: #fff; }\n\n/* fix hide/show angular animation */\n.ui-select-match.ng-hide-add,\n.ui-select-search.ng-hide-add {\n  display: none !important; }\n\n/* Mark invalid Bootstrap */\n.ui-select-bootstrap.ng-dirty.ng-invalid > button.btn.ui-select-match, .fc .ui-select-bootstrap.ng-dirty.ng-invalid > button.ui-select-match {\n  border-color: #D44950; }\n\n/* Handle up direction Bootstrap */\n.ui-select-container[theme=\"bootstrap\"].direction-up .ui-select-dropdown {\n  box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.25); }\n\n.ui-select-container {\n  width: 100% !important; }\n  .ui-select-container .ui-select-match .ui-select-toggle {\n    outline: 0; }\n\nselect {\n  background: white url(\"../img/select.png\") no-repeat !important;\n  background-size: 24px 20px !important;\n  background-position: right center !important;\n  border-radius: 0px !important;\n  border: 1px solid #d1d4d7 !important;\n  color: #888;\n  border: none;\n  outline: none;\n  display: inline-block;\n  -webkit-appearance: none;\n  -ms-appearance: none;\n  appearance: none;\n  cursor: pointer; }\n\n.select2-container.form-control, .daterangepicker .select2-container.input-mini, .input-group > .ui-select-bootstrap > input.select2-container.ui-select-search.form-control {\n  background: transparent;\n  box-shadow: none;\n  display: block;\n  /* 1 */\n  margin: 0;\n  padding: 0;\n  line-height: 1px !important; }\n\n.select2-container .select2-choice {\n  height: 32px;\n  padding: 6px 0 0 12px;\n  border: none; }\n\n.select2-container .select2-choice .select2-arrow {\n  right: 0px;\n  top: 0px;\n  background: #f8f9fa;\n  border: none; }\n\n.select2-container-active .select2-choice,\n.select2-container-active .select2-choices {\n  box-shadow: none; }\n\n.select2-drop {\n  color: #2a2c36;\n  border: 1px solid #d1d4d7;\n  border-radius: 0;\n  box-shadow: none; }\n\n.select2-container.select2-dropdown-open {\n  border-color: #d1d4d7 !important;\n  border-radius: 0; }\n\n.select2-container-multi .select2-choices {\n  box-shadow: none;\n  border-radius: 0 !important;\n  border: 0;\n  background: white; }\n\n.select2-default {\n  color: #09090b !important;\n  padding-left: 12px !important; }\n\n.select2-container-multi .select2-choices .select2-search-choice {\n  padding: 3px 5px 4px 18px;\n  margin: 5px 0 3px 5px;\n  border: 1px solid #d1d4d7;\n  border-radius: 0;\n  box-shadow: none;\n  background-color: #f8f9fa;\n  filter: none;\n  background-image: none;\n  font-size: 11px; }\n\n.select2-container-multi .select2-choices .select2-search-field input {\n  color: #2a2c36; }\n\n.select2-container-active .select2-choice,\n.select2-container-multi.select2-container-active .select2-choices {\n  border-color: #20a8d8 !important;\n  box-shadow: none; }\n\n.select2-search-choice-close {\n  background: url(\"../img/select2.png\") right top no-repeat; }\n\n@media only screen and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min-resolution: 2dppx) {\n  .select2-search input,\n  .select2-search-choice-close,\n  .select2-container .select2-choice abbr,\n  .select2-container .select2-choice .select2-arrow b {\n    background-image: url(\"../img/select2x2.png\") !important; } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-rotating-plane\"></div>\n *\n */\n.sk-rotating-plane {\n  width: 40px;\n  height: 40px;\n  background-color: #333;\n  margin: 40px auto;\n  animation: sk-rotatePlane 1.2s infinite ease-in-out; }\n\n@keyframes sk-rotatePlane {\n  0% {\n    transform: perspective(120px) rotateX(0deg) rotateY(0deg); }\n  50% {\n    transform: perspective(120px) rotateX(-180.1deg) rotateY(0deg); }\n  100% {\n    transform: perspective(120px) rotateX(-180deg) rotateY(-179.9deg); } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-double-bounce\">\n        <div class=\"sk-child sk-double-bounce1\"></div>\n        <div class=\"sk-child sk-double-bounce2\"></div>\n      </div>\n *\n */\n.sk-double-bounce {\n  width: 40px;\n  height: 40px;\n  position: relative;\n  margin: 40px auto; }\n  .sk-double-bounce .sk-child {\n    width: 100%;\n    height: 100%;\n    border-radius: 50%;\n    background-color: #333;\n    opacity: 0.6;\n    position: absolute;\n    top: 0;\n    left: 0;\n    animation: sk-doubleBounce 2.0s infinite ease-in-out; }\n  .sk-double-bounce .sk-double-bounce2 {\n    animation-delay: -1.0s; }\n\n@keyframes sk-doubleBounce {\n  0%, 100% {\n    transform: scale(0); }\n  50% {\n    transform: scale(1); } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-wave\">\n        <div class=\"sk-rect sk-rect1\"></div>\n        <div class=\"sk-rect sk-rect2\"></div>\n        <div class=\"sk-rect sk-rect3\"></div>\n        <div class=\"sk-rect sk-rect4\"></div>\n        <div class=\"sk-rect sk-rect5\"></div>\n      </div>\n *\n */\n.sk-wave {\n  margin: 40px auto;\n  width: 50px;\n  height: 40px;\n  text-align: center;\n  font-size: 10px; }\n  .sk-wave .sk-rect {\n    background-color: #333;\n    height: 100%;\n    width: 6px;\n    display: inline-block;\n    animation: sk-waveStretchDelay 1.2s infinite ease-in-out; }\n  .sk-wave .sk-rect1 {\n    animation-delay: -1.2s; }\n  .sk-wave .sk-rect2 {\n    animation-delay: -1.1s; }\n  .sk-wave .sk-rect3 {\n    animation-delay: -1s; }\n  .sk-wave .sk-rect4 {\n    animation-delay: -0.9s; }\n  .sk-wave .sk-rect5 {\n    animation-delay: -0.8s; }\n\n@keyframes sk-waveStretchDelay {\n  0%, 40%, 100% {\n    transform: scaleY(0.4); }\n  20% {\n    transform: scaleY(1); } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-wandering-cubes\">\n        <div class=\"sk-cube sk-cube1\"></div>\n        <div class=\"sk-cube sk-cube2\"></div>\n      </div>\n *\n */\n.sk-wandering-cubes {\n  margin: 40px auto;\n  width: 40px;\n  height: 40px;\n  position: relative; }\n  .sk-wandering-cubes .sk-cube {\n    background-color: #333;\n    width: 10px;\n    height: 10px;\n    position: absolute;\n    top: 0;\n    left: 0;\n    animation: sk-wanderingCube 1.8s ease-in-out -1.8s infinite both; }\n  .sk-wandering-cubes .sk-cube2 {\n    animation-delay: -0.9s; }\n\n@keyframes sk-wanderingCube {\n  0% {\n    transform: rotate(0deg); }\n  25% {\n    transform: translateX(30px) rotate(-90deg) scale(0.5); }\n  50% {\n    /* Hack to make FF rotate in the right direction */\n    transform: translateX(30px) translateY(30px) rotate(-179deg); }\n  50.1% {\n    transform: translateX(30px) translateY(30px) rotate(-180deg); }\n  75% {\n    transform: translateX(0) translateY(30px) rotate(-270deg) scale(0.5); }\n  100% {\n    transform: rotate(-360deg); } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-spinner sk-spinner-pulse\"></div>\n *\n */\n.sk-spinner-pulse {\n  width: 40px;\n  height: 40px;\n  margin: 40px auto;\n  background-color: #333;\n  border-radius: 100%;\n  animation: sk-pulseScaleOut 1.0s infinite ease-in-out; }\n\n@keyframes sk-pulseScaleOut {\n  0% {\n    transform: scale(0); }\n  100% {\n    transform: scale(1);\n    opacity: 0; } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-chasing-dots\">\n        <div class=\"sk-child sk-dot1\"></div>\n        <div class=\"sk-child sk-dot2\"></div>\n      </div>\n *\n */\n.sk-chasing-dots {\n  margin: 40px auto;\n  width: 40px;\n  height: 40px;\n  position: relative;\n  text-align: center;\n  animation: sk-chasingDotsRotate 2s infinite linear; }\n  .sk-chasing-dots .sk-child {\n    width: 60%;\n    height: 60%;\n    display: inline-block;\n    position: absolute;\n    top: 0;\n    background-color: #333;\n    border-radius: 100%;\n    animation: sk-chasingDotsBounce 2s infinite ease-in-out; }\n  .sk-chasing-dots .sk-dot2 {\n    top: auto;\n    bottom: 0;\n    animation-delay: -1s; }\n\n@keyframes sk-chasingDotsRotate {\n  100% {\n    transform: rotate(360deg); } }\n\n@keyframes sk-chasingDotsBounce {\n  0%, 100% {\n    transform: scale(0); }\n  50% {\n    transform: scale(1); } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-three-bounce\">\n        <div class=\"sk-child sk-bounce1\"></div>\n        <div class=\"sk-child sk-bounce2\"></div>\n        <div class=\"sk-child sk-bounce3\"></div>\n      </div>\n *\n */\n.sk-three-bounce {\n  margin: 40px auto;\n  width: 80px;\n  text-align: center; }\n  .sk-three-bounce .sk-child {\n    width: 20px;\n    height: 20px;\n    background-color: #333;\n    border-radius: 100%;\n    display: inline-block;\n    animation: sk-three-bounce 1.4s ease-in-out 0s infinite both; }\n  .sk-three-bounce .sk-bounce1 {\n    animation-delay: -0.32s; }\n  .sk-three-bounce .sk-bounce2 {\n    animation-delay: -0.16s; }\n\n@keyframes sk-three-bounce {\n  0%, 80%, 100% {\n    transform: scale(0); }\n  40% {\n    transform: scale(1); } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-circle\">\n        <div class=\"sk-circle1 sk-child\"></div>\n        <div class=\"sk-circle2 sk-child\"></div>\n        <div class=\"sk-circle3 sk-child\"></div>\n        <div class=\"sk-circle4 sk-child\"></div>\n        <div class=\"sk-circle5 sk-child\"></div>\n        <div class=\"sk-circle6 sk-child\"></div>\n        <div class=\"sk-circle7 sk-child\"></div>\n        <div class=\"sk-circle8 sk-child\"></div>\n        <div class=\"sk-circle9 sk-child\"></div>\n        <div class=\"sk-circle10 sk-child\"></div>\n        <div class=\"sk-circle11 sk-child\"></div>\n        <div class=\"sk-circle12 sk-child\"></div>\n      </div>\n *\n */\n.sk-circle {\n  margin: 40px auto;\n  width: 40px;\n  height: 40px;\n  position: relative; }\n  .sk-circle .sk-child {\n    width: 100%;\n    height: 100%;\n    position: absolute;\n    left: 0;\n    top: 0; }\n  .sk-circle .sk-child:before {\n    content: '';\n    display: block;\n    margin: 0 auto;\n    width: 15%;\n    height: 15%;\n    background-color: #333;\n    border-radius: 100%;\n    animation: sk-circleBounceDelay 1.2s infinite ease-in-out both; }\n  .sk-circle .sk-circle2 {\n    transform: rotate(30deg); }\n  .sk-circle .sk-circle3 {\n    transform: rotate(60deg); }\n  .sk-circle .sk-circle4 {\n    transform: rotate(90deg); }\n  .sk-circle .sk-circle5 {\n    transform: rotate(120deg); }\n  .sk-circle .sk-circle6 {\n    transform: rotate(150deg); }\n  .sk-circle .sk-circle7 {\n    transform: rotate(180deg); }\n  .sk-circle .sk-circle8 {\n    transform: rotate(210deg); }\n  .sk-circle .sk-circle9 {\n    transform: rotate(240deg); }\n  .sk-circle .sk-circle10 {\n    transform: rotate(270deg); }\n  .sk-circle .sk-circle11 {\n    transform: rotate(300deg); }\n  .sk-circle .sk-circle12 {\n    transform: rotate(330deg); }\n  .sk-circle .sk-circle2:before {\n    animation-delay: -1.1s; }\n  .sk-circle .sk-circle3:before {\n    animation-delay: -1s; }\n  .sk-circle .sk-circle4:before {\n    animation-delay: -0.9s; }\n  .sk-circle .sk-circle5:before {\n    animation-delay: -0.8s; }\n  .sk-circle .sk-circle6:before {\n    animation-delay: -0.7s; }\n  .sk-circle .sk-circle7:before {\n    animation-delay: -0.6s; }\n  .sk-circle .sk-circle8:before {\n    animation-delay: -0.5s; }\n  .sk-circle .sk-circle9:before {\n    animation-delay: -0.4s; }\n  .sk-circle .sk-circle10:before {\n    animation-delay: -0.3s; }\n  .sk-circle .sk-circle11:before {\n    animation-delay: -0.2s; }\n  .sk-circle .sk-circle12:before {\n    animation-delay: -0.1s; }\n\n@keyframes sk-circleBounceDelay {\n  0%, 80%, 100% {\n    transform: scale(0); }\n  40% {\n    transform: scale(1); } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-cube-grid\">\n        <div class=\"sk-cube sk-cube1\"></div>\n        <div class=\"sk-cube sk-cube2\"></div>\n        <div class=\"sk-cube sk-cube3\"></div>\n        <div class=\"sk-cube sk-cube4\"></div>\n        <div class=\"sk-cube sk-cube5\"></div>\n        <div class=\"sk-cube sk-cube6\"></div>\n        <div class=\"sk-cube sk-cube7\"></div>\n        <div class=\"sk-cube sk-cube8\"></div>\n        <div class=\"sk-cube sk-cube9\"></div>\n      </div>\n *\n */\n.sk-cube-grid {\n  width: 40px;\n  height: 40px;\n  margin: 40px auto;\n  /*\n   * Spinner positions\n   * 1 2 3\n   * 4 5 6\n   * 7 8 9\n   */ }\n  .sk-cube-grid .sk-cube {\n    width: 33.33%;\n    height: 33.33%;\n    background-color: #333;\n    float: left;\n    animation: sk-cubeGridScaleDelay 1.3s infinite ease-in-out; }\n  .sk-cube-grid .sk-cube1 {\n    animation-delay: 0.2s; }\n  .sk-cube-grid .sk-cube2 {\n    animation-delay: 0.3s; }\n  .sk-cube-grid .sk-cube3 {\n    animation-delay: 0.4s; }\n  .sk-cube-grid .sk-cube4 {\n    animation-delay: 0.1s; }\n  .sk-cube-grid .sk-cube5 {\n    animation-delay: 0.2s; }\n  .sk-cube-grid .sk-cube6 {\n    animation-delay: 0.3s; }\n  .sk-cube-grid .sk-cube7 {\n    animation-delay: 0.0s; }\n  .sk-cube-grid .sk-cube8 {\n    animation-delay: 0.1s; }\n  .sk-cube-grid .sk-cube9 {\n    animation-delay: 0.2s; }\n\n@keyframes sk-cubeGridScaleDelay {\n  0%, 70%, 100% {\n    transform: scale3D(1, 1, 1); }\n  35% {\n    transform: scale3D(0, 0, 1); } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-fading-circle\">\n        <div class=\"sk-circle1 sk-circle\"></div>\n        <div class=\"sk-circle2 sk-circle\"></div>\n        <div class=\"sk-circle3 sk-circle\"></div>\n        <div class=\"sk-circle4 sk-circle\"></div>\n        <div class=\"sk-circle5 sk-circle\"></div>\n        <div class=\"sk-circle6 sk-circle\"></div>\n        <div class=\"sk-circle7 sk-circle\"></div>\n        <div class=\"sk-circle8 sk-circle\"></div>\n        <div class=\"sk-circle9 sk-circle\"></div>\n        <div class=\"sk-circle10 sk-circle\"></div>\n        <div class=\"sk-circle11 sk-circle\"></div>\n        <div class=\"sk-circle12 sk-circle\"></div>\n      </div>\n *\n */\n.sk-fading-circle {\n  margin: 40px auto;\n  width: 40px;\n  height: 40px;\n  position: relative; }\n  .sk-fading-circle .sk-circle {\n    width: 100%;\n    height: 100%;\n    position: absolute;\n    left: 0;\n    top: 0; }\n  .sk-fading-circle .sk-circle:before {\n    content: '';\n    display: block;\n    margin: 0 auto;\n    width: 15%;\n    height: 15%;\n    background-color: #333;\n    border-radius: 100%;\n    animation: sk-circleFadeDelay 1.2s infinite ease-in-out both; }\n  .sk-fading-circle .sk-circle2 {\n    transform: rotate(30deg); }\n  .sk-fading-circle .sk-circle3 {\n    transform: rotate(60deg); }\n  .sk-fading-circle .sk-circle4 {\n    transform: rotate(90deg); }\n  .sk-fading-circle .sk-circle5 {\n    transform: rotate(120deg); }\n  .sk-fading-circle .sk-circle6 {\n    transform: rotate(150deg); }\n  .sk-fading-circle .sk-circle7 {\n    transform: rotate(180deg); }\n  .sk-fading-circle .sk-circle8 {\n    transform: rotate(210deg); }\n  .sk-fading-circle .sk-circle9 {\n    transform: rotate(240deg); }\n  .sk-fading-circle .sk-circle10 {\n    transform: rotate(270deg); }\n  .sk-fading-circle .sk-circle11 {\n    transform: rotate(300deg); }\n  .sk-fading-circle .sk-circle12 {\n    transform: rotate(330deg); }\n  .sk-fading-circle .sk-circle2:before {\n    animation-delay: -1.1s; }\n  .sk-fading-circle .sk-circle3:before {\n    animation-delay: -1s; }\n  .sk-fading-circle .sk-circle4:before {\n    animation-delay: -0.9s; }\n  .sk-fading-circle .sk-circle5:before {\n    animation-delay: -0.8s; }\n  .sk-fading-circle .sk-circle6:before {\n    animation-delay: -0.7s; }\n  .sk-fading-circle .sk-circle7:before {\n    animation-delay: -0.6s; }\n  .sk-fading-circle .sk-circle8:before {\n    animation-delay: -0.5s; }\n  .sk-fading-circle .sk-circle9:before {\n    animation-delay: -0.4s; }\n  .sk-fading-circle .sk-circle10:before {\n    animation-delay: -0.3s; }\n  .sk-fading-circle .sk-circle11:before {\n    animation-delay: -0.2s; }\n  .sk-fading-circle .sk-circle12:before {\n    animation-delay: -0.1s; }\n\n@keyframes sk-circleFadeDelay {\n  0%, 39%, 100% {\n    opacity: 0; }\n  40% {\n    opacity: 1; } }\n\n/*\n *  Usage:\n *\n      <div class=\"sk-folding-cube\">\n        <div class=\"sk-cube1 sk-cube\"></div>\n        <div class=\"sk-cube2 sk-cube\"></div>\n        <div class=\"sk-cube4 sk-cube\"></div>\n        <div class=\"sk-cube3 sk-cube\"></div>\n      </div>\n *\n */\n.sk-folding-cube {\n  margin: 40px auto;\n  width: 40px;\n  height: 40px;\n  position: relative;\n  transform: rotateZ(45deg); }\n  .sk-folding-cube .sk-cube {\n    float: left;\n    width: 50%;\n    height: 50%;\n    position: relative;\n    transform: scale(1.1); }\n  .sk-folding-cube .sk-cube:before {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background-color: #333;\n    animation: sk-foldCubeAngle 2.4s infinite linear both;\n    transform-origin: 100% 100%; }\n  .sk-folding-cube .sk-cube2 {\n    transform: scale(1.1) rotateZ(90deg); }\n  .sk-folding-cube .sk-cube3 {\n    transform: scale(1.1) rotateZ(180deg); }\n  .sk-folding-cube .sk-cube4 {\n    transform: scale(1.1) rotateZ(270deg); }\n  .sk-folding-cube .sk-cube2:before {\n    animation-delay: 0.3s; }\n  .sk-folding-cube .sk-cube3:before {\n    animation-delay: 0.6s; }\n  .sk-folding-cube .sk-cube4:before {\n    animation-delay: 0.9s; }\n\n@keyframes sk-foldCubeAngle {\n  0%, 10% {\n    transform: perspective(140px) rotateX(-180deg);\n    opacity: 0; }\n  25%, 75% {\n    transform: perspective(140px) rotateX(0deg);\n    opacity: 1; }\n  90%, 100% {\n    transform: perspective(140px) rotateY(180deg);\n    opacity: 0; } }\n\nbody {\n  -moz-osx-font-smoothing: grayscale;\n  -webkit-font-smoothing: antialiased; }\n\n.font-xs {\n  font-size: .75rem !important; }\n\n.font-sm {\n  font-size: .85rem !important; }\n\n.font-lg {\n  font-size: 1rem !important; }\n\n.font-xl {\n  font-size: 1.25rem !important; }\n\n.font-2xl {\n  font-size: 1.5rem !important; }\n\n.font-3xl {\n  font-size: 1.75rem !important; }\n\n.font-4xl {\n  font-size: 2rem !important; }\n\n.font-5xl {\n  font-size: 2.5rem !important; }\n\n.animated {\n  -webkit-animation-duration: 1s;\n  animation-duration: 1s;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both; }\n\n.animated.infinite {\n  -webkit-animation-iteration-count: infinite;\n  animation-iteration-count: infinite; }\n\n.animated.hinge {\n  -webkit-animation-duration: 2s;\n  animation-duration: 2s; }\n\n@-webkit-keyframes fadeIn {\n  from {\n    opacity: 0; }\n  to {\n    opacity: 1; } }\n\n@keyframes fadeIn {\n  from {\n    opacity: 0; }\n  to {\n    opacity: 1; } }\n\n.fadeIn {\n  -webkit-animation-name: fadeIn;\n  animation-name: fadeIn; }\n\n.row.row-equal {\n  padding-right: 7.5px;\n  padding-left: 7.5px;\n  margin-right: -15px;\n  margin-left: -15px; }\n  .row.row-equal [class*=\"col-\"] {\n    padding-right: 7.5px;\n    padding-left: 7.5px; }\n\n.main .container-fluid {\n  padding: 0 30px; }\n\n.app,\napp-dashboard,\napp-root {\n  display: flex;\n  flex-direction: column;\n  min-height: 100vh; }\n\n.app-header {\n  flex: 0 0 55px; }\n\n.app-footer {\n  flex: 0 0 50px; }\n\n.app-body {\n  display: flex;\n  flex: 1;\n  flex-direction: row;\n  overflow-x: hidden; }\n  .app-body .main {\n    flex: 1; }\n  .app-body .sidebar {\n    flex: 0 0 200px;\n    order: -1; }\n  .app-body .aside-menu {\n    flex: 0 0 250px; }\n\n.header-fixed .app-header {\n  position: fixed;\n  z-index: 1000;\n  width: 100%; }\n\n.header-fixed .app-body {\n  margin-top: 55px; }\n\n.sidebar-hidden .sidebar {\n  margin-left: -200px; }\n\n.sidebar-fixed .sidebar {\n  position: fixed;\n  height: 100%; }\n  .sidebar-fixed .sidebar .sidebar-nav {\n    height: calc(100vh - 55px); }\n\n.sidebar-fixed .main, .sidebar-fixed .app-footer {\n  margin-left: 200px; }\n\n.sidebar-fixed.sidebar-hidden .main, .sidebar-fixed.sidebar-hidden .app-footer {\n  margin-left: 0; }\n\n.sidebar-off-canvas .sidebar {\n  position: fixed;\n  z-index: 999;\n  height: 100%; }\n  .sidebar-off-canvas .sidebar .sidebar-nav {\n    height: calc(100vh - 55px); }\n\n.sidebar-compact .sidebar {\n  flex: 0 0 50px; }\n\n.sidebar-compact.sidebar-hidden .sidebar {\n  margin-left: -50px; }\n\n.sidebar-compact.sidebar-fixed .main, .sidebar-compact.sidebar-fixed .app-footer {\n  margin-left: 50px; }\n\n.sidebar-compact.sidebar-fixed.sidebar-hidden .main, .sidebar-compact.sidebar-fixed.sidebar-hidden .app-footer {\n  margin-left: 0; }\n\n.aside-menu-hidden .aside-menu {\n  margin-right: -250px; }\n\n.aside-menu-fixed .aside-menu {\n  position: fixed;\n  right: 0;\n  height: 100%; }\n  .aside-menu-fixed .aside-menu .tab-content {\n    height: calc(100vh - 2.375rem - 55px); }\n\n.aside-menu-fixed .main, .aside-menu-fixed .app-footer {\n  margin-right: 250px; }\n\n.aside-menu-fixed.aside-menu-hidden .main, .aside-menu-fixed.aside-menu-hidden .app-footer {\n  margin-right: 0; }\n\n.aside-menu-off-canvas .aside-menu {\n  position: fixed;\n  right: 0;\n  z-index: 999;\n  height: 100%; }\n  .aside-menu-off-canvas .aside-menu .tab-content {\n    height: calc(100vh - 2.375rem - 55px); }\n\n.footer-fixed .app-footer {\n  position: fixed;\n  bottom: 0;\n  z-index: 1000;\n  width: 100%; }\n\n.footer-fixed .app-body {\n  margin-bottom: 50px; }\n\n.app-header,\n.app-footer,\n.sidebar,\n.main,\n.aside-menu {\n  transition-duration: 0.25s, 0.25s;\n  transition-property: margin-left, margin-right; }\n\n@media (max-width: 991px) {\n  .app-header {\n    position: fixed !important;\n    z-index: 1000;\n    width: 100%; }\n    .app-header .navbar-toggler {\n      position: absolute;\n      top: 0;\n      left: 0;\n      width: 70px;\n      height: inherit; }\n    .app-header .navbar-toggler {\n      color: #fff; }\n    .app-header .navbar-brand {\n      width: 100% !important;\n      margin: 0 auto !important; }\n    .app-header .navbar-nav {\n      position: absolute;\n      top: 0;\n      right: 15px;\n      height: inherit; }\n  .app-body {\n    margin-top: 55px; }\n  .sidebar {\n    position: fixed;\n    width: 200px;\n    height: 100%;\n    margin-left: -200px; }\n    .sidebar .sidebar-nav,\n    .sidebar .nav {\n      width: 200px !important; }\n  .main, .app-footer {\n    margin-left: 0 !important; }\n  .aside-menu {\n    margin-right: -250px; }\n  .sidebar-mobile-show .sidebar {\n    width: 200px;\n    margin-left: 0; }\n    .sidebar-mobile-show .sidebar .sidebar-nav {\n      height: calc(100vh - 55px); }\n  .sidebar-mobile-show .main {\n    margin-right: -200px !important;\n    margin-left: 200px !important; } }\n\n.sidebar {\n  padding: 0;\n  color: #fff;\n  background: #2a2c36; }\n  .sidebar .sidebar-close {\n    position: absolute;\n    right: 0;\n    display: none;\n    padding: 0 1rem;\n    font-size: 24px;\n    font-weight: 800;\n    line-height: 55px;\n    color: #fff;\n    background: 0;\n    border: 0;\n    opacity: .8; }\n    .sidebar .sidebar-close:hover {\n      opacity: 1; }\n  .sidebar .sidebar-nav {\n    position: relative;\n    overflow-x: hidden;\n    overflow-y: auto;\n    -ms-overflow-style: -ms-autohiding-scrollbar;\n    width: 200px; }\n    .sidebar .sidebar-nav::-webkit-scrollbar {\n      width: 10px;\n      margin-left: -10px;\n      -webkit-appearance: none; }\n    .sidebar .sidebar-nav::-webkit-scrollbar-track {\n      background-color: #353844;\n      border-right: 1px solid #1f2028;\n      border-left: 1px solid #1f2028; }\n    .sidebar .sidebar-nav::-webkit-scrollbar-thumb {\n      height: 50px;\n      background-color: #141519;\n      background-clip: content-box;\n      border-color: transparent;\n      border-style: solid;\n      border-width: 1px 2px; }\n  .sidebar ul.nav {\n    width: 200px;\n    flex-direction: column !important; }\n    .sidebar ul.nav li.nav-title {\n      padding: 0.75rem 1rem;\n      font-size: 11px;\n      font-weight: 600;\n      color: #d1d4d7;\n      text-transform: uppercase; }\n    .sidebar ul.nav li.divider {\n      height: 10px; }\n    .sidebar ul.nav li.nav-item {\n      position: relative;\n      margin: 0;\n      transition: background .3s ease-in-out; }\n      .sidebar ul.nav li.nav-item ul {\n        max-height: 0;\n        padding: 0;\n        margin: 0;\n        overflow-y: hidden;\n        transition: max-height .3s ease-in-out; }\n        .sidebar ul.nav li.nav-item ul li {\n          padding: 0;\n          list-style: none; }\n      .sidebar ul.nav li.nav-item a.nav-link {\n        display: block;\n        padding: 0.75rem 1rem;\n        color: #fff;\n        text-decoration: none;\n        background: transparent; }\n        .sidebar ul.nav li.nav-item a.nav-link:hover {\n          color: #fff !important;\n          background: #20a8d8 !important; }\n          .sidebar ul.nav li.nav-item a.nav-link:hover i {\n            color: #fff !important; }\n        .sidebar ul.nav li.nav-item a.nav-link.active {\n          color: #fff;\n          background: #353844; }\n          .sidebar ul.nav li.nav-item a.nav-link.active i {\n            color: #20a8d8; }\n        .sidebar ul.nav li.nav-item a.nav-link [class^=\"icon-\"], .sidebar ul.nav li.nav-item a.nav-link [class*=\" icon-\"] {\n          display: inline-block;\n          margin-top: -4px;\n          vertical-align: middle; }\n        .sidebar ul.nav li.nav-item a.nav-link i {\n          width: 20px;\n          margin: 0 0.5rem 0 0;\n          font-size: 14px;\n          color: #818a91;\n          text-align: center; }\n        .sidebar ul.nav li.nav-item a.nav-link .badge {\n          float: right;\n          margin-top: 2px; }\n        .sidebar ul.nav li.nav-item a.nav-link.nav-dropdown-toggle::before {\n          position: absolute;\n          top: 0.96875rem;\n          right: 1rem;\n          display: block;\n          width: 0.875rem;\n          height: 0.875rem;\n          padding: 0;\n          font-size: 0.875rem;\n          line-height: 0.65625rem;\n          text-align: center;\n          content: \"\\2039\";\n          transition: .3s; }\n      .sidebar ul.nav li.nav-item.nav-dropdown.open {\n        background: rgba(0, 0, 0, 0.2); }\n        .sidebar ul.nav li.nav-item.nav-dropdown.open > ul, .sidebar ul.nav li.nav-item.nav-dropdown.open > ol {\n          max-height: 1000px; }\n        .sidebar ul.nav li.nav-item.nav-dropdown.open a.nav-link {\n          color: #fff;\n          border-left: 0 !important; }\n        .sidebar ul.nav li.nav-item.nav-dropdown.open > a.nav-link.nav-dropdown-toggle::before {\n          -webkit-transform: rotate(-90deg);\n          transform: rotate(-90deg); }\n        .sidebar ul.nav li.nav-item.nav-dropdown.open .nav-dropdown.open {\n          border-left: 0; }\n      .sidebar ul.nav li.nav-item.nav-dropdown.nt {\n        transition: 0s !important; }\n        .sidebar ul.nav li.nav-item.nav-dropdown.nt > ul, .sidebar ul.nav li.nav-item.nav-dropdown.nt > ol {\n          transition: 0s !important; }\n        .sidebar ul.nav li.nav-item.nav-dropdown.nt a.nav-link.nav-dropdown-toggle::before {\n          transition: 0s !important; }\n      .sidebar ul.nav li.nav-item a.nav-label {\n        display: block;\n        padding: 0.09375rem 1rem;\n        color: #d1d4d7; }\n        .sidebar ul.nav li.nav-item a.nav-label:hover {\n          color: #fff;\n          text-decoration: none; }\n        .sidebar ul.nav li.nav-item a.nav-label i {\n          width: 20px;\n          margin: -3px 0.5rem 0 0;\n          font-size: 10px;\n          color: #818a91;\n          text-align: center;\n          vertical-align: middle; }\n      .sidebar ul.nav li.nav-item .progress {\n        background-color: #4b4f61 !important; }\n\n@media (min-width: 576px) {\n  body.sidebar-compact .hidden-cn {\n    display: none; }\n  body.sidebar-compact .sidebar {\n    z-index: 999;\n    width: 50px; }\n    body.sidebar-compact .sidebar .sidebar-nav {\n      overflow: visible; }\n    body.sidebar-compact .sidebar ul.nav li.nav-title, body.sidebar-compact .sidebar ul.nav li.divider {\n      display: none; }\n    body.sidebar-compact .sidebar ul.nav li.nav-item {\n      width: 50px;\n      overflow: hidden;\n      border-left: 0 !important; }\n      body.sidebar-compact .sidebar ul.nav li.nav-item ul {\n        background: #2a2c36; }\n      body.sidebar-compact .sidebar ul.nav li.nav-item a.nav-link {\n        position: relative;\n        padding: 0 15px 0 0;\n        margin: 0;\n        line-height: 50px;\n        white-space: nowrap;\n        border-left: 0 !important; }\n        body.sidebar-compact .sidebar ul.nav li.nav-item a.nav-link.nav-dropdown-toggle::before {\n          display: none; }\n        body.sidebar-compact .sidebar ul.nav li.nav-item a.nav-link i {\n          display: block;\n          float: left;\n          width: 50px;\n          height: 50px;\n          padding: 0;\n          margin: 0 !important;\n          font-size: 18px;\n          line-height: 50px; }\n        body.sidebar-compact .sidebar ul.nav li.nav-item a.nav-link .badge {\n          position: absolute;\n          top: 14px;\n          right: 15px;\n          display: none; }\n        body.sidebar-compact .sidebar ul.nav li.nav-item a.nav-link:hover {\n          width: 200px; }\n          body.sidebar-compact .sidebar ul.nav li.nav-item a.nav-link:hover .badge {\n            display: inline; }\n      body.sidebar-compact .sidebar ul.nav li.nav-item ul {\n        position: absolute;\n        top: 50px;\n        left: 50px; }\n        body.sidebar-compact .sidebar ul.nav li.nav-item ul li {\n          position: relative;\n          padding: 0; }\n          body.sidebar-compact .sidebar ul.nav li.nav-item ul li a.nav-link {\n            width: 150px; }\n          body.sidebar-compact .sidebar ul.nav li.nav-item ul li ul, body.sidebar-compact .sidebar ul.nav li.nav-item ul li ol {\n            position: absolute;\n            top: 0;\n            left: 100%; }\n      body.sidebar-compact .sidebar ul.nav li.nav-item.nav-dropdown.open {\n        background: #353844; }\n        body.sidebar-compact .sidebar ul.nav li.nav-item.nav-dropdown.open > a.nav-link i {\n          color: #20a8d8; }\n        body.sidebar-compact .sidebar ul.nav li.nav-item.nav-dropdown.open > ul, body.sidebar-compact .sidebar ul.nav li.nav-item.nav-dropdown.open > ol {\n          display: none; }\n      body.sidebar-compact .sidebar ul.nav li.nav-item:hover {\n        width: 250px;\n        overflow: visible;\n        background: #20a8d8;\n        transition: 0s; }\n        body.sidebar-compact .sidebar ul.nav li.nav-item:hover > a.nav-link {\n          width: 250px; }\n        body.sidebar-compact .sidebar ul.nav li.nav-item:hover > ul, body.sidebar-compact .sidebar ul.nav li.nav-item:hover > ol {\n          display: inline;\n          max-height: 10000px;\n          transition: 0s; }\n          body.sidebar-compact .sidebar ul.nav li.nav-item:hover > ul li, body.sidebar-compact .sidebar ul.nav li.nav-item:hover > ol li {\n            width: 200px; }\n            body.sidebar-compact .sidebar ul.nav li.nav-item:hover > ul li a.nav-link, body.sidebar-compact .sidebar ul.nav li.nav-item:hover > ol li a.nav-link {\n              width: 200px; }\n        body.sidebar-compact .sidebar ul.nav li.nav-item:hover.nav-dropdown.open > ul, body.sidebar-compact .sidebar ul.nav li.nav-item:hover.nav-dropdown.open > ol {\n          display: inline; } }\n\nnav.top-nav {\n  position: absolute;\n  top: 55px;\n  left: 0;\n  z-index: 999;\n  display: inline !important;\n  width: 100%;\n  height: 40px;\n  background: #fff;\n  border-bottom: 1px solid #d1d4d7; }\n  nav.top-nav ul.nav {\n    white-space: nowrap; }\n    nav.top-nav ul.nav li.nav-item {\n      position: relative;\n      display: inline-block;\n      margin: 0; }\n      nav.top-nav ul.nav li.nav-item ul {\n        display: none;\n        padding: 0;\n        margin: 0;\n        white-space: normal;\n        background: #fff;\n        border: 1px solid #d1d4d7; }\n        nav.top-nav ul.nav li.nav-item ul li {\n          padding: 0;\n          list-style: none; }\n      nav.top-nav ul.nav li.nav-item a.nav-link {\n        display: block;\n        padding: 0 15px;\n        font-size: 12px;\n        font-weight: 400;\n        line-height: 40px;\n        color: #2a2c36;\n        text-decoration: none;\n        text-transform: uppercase; }\n        nav.top-nav ul.nav li.nav-item a.nav-link i {\n          display: block;\n          float: left;\n          width: 20px;\n          margin: 0 10px 0 0;\n          font-size: 14px;\n          line-height: 39px;\n          text-align: center; }\n        nav.top-nav ul.nav li.nav-item a.nav-link .tag {\n          float: right;\n          margin-top: 13px;\n          margin-left: 10px; }\n        nav.top-nav ul.nav li.nav-item a.nav-link:hover {\n          color: #fff;\n          background: #20a8d8; }\n        nav.top-nav ul.nav li.nav-item a.nav-link.active {\n          color: #fff;\n          background: #20a8d8; }\n      nav.top-nav ul.nav li.nav-item ul {\n        position: absolute;\n        top: 39px;\n        left: 0; }\n        nav.top-nav ul.nav li.nav-item ul li {\n          position: relative;\n          padding: 0; }\n          nav.top-nav ul.nav li.nav-item ul li a.nav-link {\n            min-width: 200px; }\n          nav.top-nav ul.nav li.nav-item ul li ul {\n            position: absolute;\n            top: 0;\n            left: 100%; }\n      nav.top-nav ul.nav li.nav-item.nav-more ul {\n        right: 0;\n        left: auto; }\n        nav.top-nav ul.nav li.nav-item.nav-more ul li ul {\n          right: 100%;\n          left: auto; }\n      nav.top-nav ul.nav li.nav-item:hover > ul {\n        display: inline; }\n\n.aside-menu {\n  z-index: 999;\n  width: 250px;\n  color: #2a2c36;\n  background: #fff;\n  border-left: 1px solid #d1d4d7; }\n  .aside-menu .nav-tabs {\n    border-color: #d1d4d7; }\n    .aside-menu .nav-tabs .nav-link {\n      padding: 0.75rem 1rem;\n      color: #2a2c36;\n      border-top: 0; }\n      .aside-menu .nav-tabs .nav-link.active {\n        color: #20a8d8;\n        border-right-color: #d1d4d7;\n        border-left-color: #d1d4d7; }\n    .aside-menu .nav-tabs .nav-item:first-child .nav-link {\n      border-left: 0; }\n  .aside-menu .tab-content {\n    position: relative;\n    overflow-x: hidden;\n    overflow-y: auto;\n    border: 0;\n    border-top: 1px solid #d1d4d7;\n    -ms-overflow-style: -ms-autohiding-scrollbar; }\n    .aside-menu .tab-content::-webkit-scrollbar {\n      width: 10px;\n      margin-left: -10px;\n      -webkit-appearance: none; }\n    .aside-menu .tab-content::-webkit-scrollbar-track {\n      background-color: white;\n      border-right: 1px solid #f2f2f2;\n      border-left: 1px solid #f2f2f2; }\n    .aside-menu .tab-content::-webkit-scrollbar-thumb {\n      height: 50px;\n      background-color: #e6e6e6;\n      background-clip: content-box;\n      border-color: transparent;\n      border-style: solid;\n      border-width: 1px 2px; }\n    .aside-menu .tab-content .tab-pane {\n      padding: 0; }\n\n#loading-bar,\n#loading-bar-spinner {\n  -webkit-pointer-events: none;\n  pointer-events: none;\n  -moz-transition: 350ms linear all;\n  -o-transition: 350ms linear all;\n  -webkit-transition: 350ms linear all;\n  transition: 350ms linear all; }\n\n#loading-bar.ng-enter,\n#loading-bar.ng-leave.ng-leave-active,\n#loading-bar-spinner.ng-enter,\n#loading-bar-spinner.ng-leave.ng-leave-active {\n  opacity: 0; }\n\n#loading-bar.ng-enter.ng-enter-active,\n#loading-bar.ng-leave,\n#loading-bar-spinner.ng-enter.ng-enter-active,\n#loading-bar-spinner.ng-leave {\n  opacity: 1; }\n\n#loading-bar .bar {\n  position: fixed;\n  top: 0;\n  left: 0;\n  z-index: 20002;\n  width: 100%;\n  height: 2px;\n  background: #20a8d8;\n  border-top-right-radius: 1px;\n  border-bottom-right-radius: 1px;\n  -moz-transition: width 350ms;\n  -o-transition: width 350ms;\n  -webkit-transition: width 350ms;\n  transition: width 350ms; }\n\n#loading-bar .peg {\n  position: absolute;\n  top: 0;\n  right: 0;\n  width: 70px;\n  height: 2px;\n  -moz-border-radius: 100%;\n  -webkit-border-radius: 100%;\n  border-radius: 100%;\n  -moz-box-shadow: #29d 1px 0 6px 1px;\n  -ms-box-shadow: #29d 1px 0 6px 1px;\n  -webkit-box-shadow: #29d 1px 0 6px 1px;\n  box-shadow: #29d 1px 0 6px 1px;\n  opacity: .45; }\n\n#loading-bar-spinner {\n  position: fixed;\n  top: 10px;\n  left: 10px;\n  z-index: 10002;\n  display: block; }\n\n#loading-bar-spinner .spinner-icon {\n  width: 14px;\n  height: 14px;\n  border: solid 2px transparent;\n  border-top-color: #29d;\n  border-left-color: #29d;\n  border-radius: 50%;\n  -moz-animation: loading-bar-spinner 400ms linear infinite;\n  -ms-animation: loading-bar-spinner 400ms linear infinite;\n  -o-animation: loading-bar-spinner 400ms linear infinite;\n  -webkit-animation: loading-bar-spinner 400ms linear infinite;\n  animation: loading-bar-spinner 400ms linear infinite; }\n\n@-webkit-keyframes loading-bar-spinner {\n  0% {\n    -webkit-transform: rotate(0deg);\n    transform: rotate(0deg); }\n  100% {\n    -webkit-transform: rotate(360deg);\n    transform: rotate(360deg); } }\n\n@-moz-keyframes loading-bar-spinner {\n  0% {\n    -moz-transform: rotate(0deg);\n    transform: rotate(0deg); }\n  100% {\n    -moz-transform: rotate(360deg);\n    transform: rotate(360deg); } }\n\n@-o-keyframes loading-bar-spinner {\n  0% {\n    -o-transform: rotate(0deg);\n    transform: rotate(0deg); }\n  100% {\n    -o-transform: rotate(360deg);\n    transform: rotate(360deg); } }\n\n@-ms-keyframes loading-bar-spinner {\n  0% {\n    -ms-transform: rotate(0deg);\n    transform: rotate(0deg); }\n  100% {\n    -ms-transform: rotate(360deg);\n    transform: rotate(360deg); } }\n\n@keyframes loading-bar-spinner {\n  0% {\n    transform: rotate(0deg);\n    transform: rotate(0deg); }\n  100% {\n    transform: rotate(360deg);\n    transform: rotate(360deg); } }\n\n.pace {\n  -webkit-pointer-events: none;\n  pointer-events: none;\n  -moz-user-select: none;\n  -webkit-user-select: none;\n  user-select: none; }\n\n.pace-inactive {\n  display: none; }\n\n.pace .pace-progress {\n  position: fixed;\n  top: 0;\n  right: 100%;\n  z-index: 2000;\n  width: 100%;\n  height: 2px;\n  background: #20a8d8; }\n\n.social-box {\n  min-height: 160px;\n  margin-bottom: 1.5rem;\n  text-align: center;\n  background: #fff;\n  border: 1px solid #d1d4d7; }\n  .social-box i {\n    display: block;\n    margin: -1px -1px 0;\n    font-size: 40px;\n    line-height: 90px;\n    background: #d1d4d7; }\n  .social-box .chart-wrapper {\n    height: 90px;\n    margin: -90px 0 0; }\n    .social-box .chart-wrapper canvas {\n      width: 100% !important;\n      height: 90px !important; }\n  .social-box ul {\n    padding: 10px 0;\n    list-style: none; }\n    .social-box ul li {\n      display: block;\n      float: left;\n      width: 50%; }\n      .social-box ul li:first-child {\n        border-right: 1px solid #d1d4d7; }\n      .social-box ul li strong {\n        display: block;\n        font-size: 20px; }\n      .social-box ul li span {\n        font-size: 10px;\n        font-weight: 500;\n        color: #d1d4d7;\n        text-transform: uppercase; }\n  .social-box.facebook i {\n    color: #fff;\n    background: #3b5998; }\n  .social-box.twitter i {\n    color: #fff;\n    background: #00aced; }\n  .social-box.linkedin i {\n    color: #fff;\n    background: #4875b4; }\n  .social-box.google-plus i {\n    color: #fff;\n    background: #bb4b39; }\n\n.horizontal-bars {\n  padding: 0;\n  margin: 0;\n  list-style: none; }\n  .horizontal-bars li {\n    position: relative;\n    height: 40px;\n    line-height: 40px;\n    vertical-align: middle; }\n    .horizontal-bars li .title {\n      width: 100px;\n      font-size: 12px;\n      font-weight: 600;\n      color: #818a91;\n      vertical-align: middle; }\n    .horizontal-bars li .bars {\n      position: absolute;\n      top: 15px;\n      width: 100%;\n      padding-left: 100px; }\n      .horizontal-bars li .bars .progress:first-child {\n        margin-bottom: 2px; }\n    .horizontal-bars li.legend {\n      text-align: center; }\n      .horizontal-bars li.legend .badge {\n        display: inline-block;\n        width: 8px;\n        height: 8px;\n        padding: 0; }\n    .horizontal-bars li.divider {\n      height: 40px; }\n      .horizontal-bars li.divider i {\n        margin: 0 !important; }\n  .horizontal-bars.type-2 li {\n    overflow: hidden; }\n    .horizontal-bars.type-2 li i {\n      display: inline-block;\n      margin-right: 1rem;\n      margin-left: 5px;\n      font-size: 18px;\n      line-height: 40px; }\n    .horizontal-bars.type-2 li .title {\n      display: inline-block;\n      width: auto;\n      margin-top: -9px;\n      font-size: 0.875rem;\n      font-weight: normal;\n      line-height: 40px;\n      color: #2a2c36; }\n    .horizontal-bars.type-2 li .value {\n      float: right;\n      font-weight: 600; }\n    .horizontal-bars.type-2 li .bars {\n      position: absolute;\n      top: auto;\n      bottom: 0;\n      padding: 0; }\n\nul.icons-list {\n  padding: 0;\n  margin: 0;\n  list-style: none; }\n  ul.icons-list li {\n    position: relative;\n    height: 40px;\n    vertical-align: middle; }\n    ul.icons-list li i {\n      display: block;\n      float: left;\n      width: 35px !important;\n      height: 35px !important;\n      margin: 2px;\n      line-height: 35px !important;\n      text-align: center; }\n    ul.icons-list li .desc {\n      height: 40px;\n      margin-left: 50px;\n      border-bottom: 1px solid #d1d4d7; }\n      ul.icons-list li .desc .title {\n        padding: 2px 0 0;\n        margin: 0; }\n      ul.icons-list li .desc small {\n        display: block;\n        margin-top: -4px;\n        color: #818a91; }\n    ul.icons-list li .value {\n      position: absolute;\n      top: 2px;\n      right: 45px;\n      text-align: right; }\n      ul.icons-list li .value strong {\n        display: block;\n        margin-top: -3px; }\n    ul.icons-list li .actions {\n      position: absolute;\n      top: -4px;\n      right: 10px;\n      width: 40px;\n      height: 40px;\n      line-height: 40px;\n      text-align: center; }\n      ul.icons-list li .actions i {\n        float: none;\n        width: auto;\n        height: auto;\n        padding: 0;\n        margin: 0;\n        line-height: normal; }\n    ul.icons-list li.divider {\n      height: 40px; }\n      ul.icons-list li.divider i {\n        width: auto;\n        height: auto;\n        margin: 2px 0 0;\n        font-size: 18px; }\n\n.app-footer {\n  min-height: 50px;\n  padding: 0 1rem;\n  line-height: 50px;\n  color: #2a2c36;\n  background: #f8f9fa;\n  border-top: 1px solid #d1d4d7; }\n\n.btn-transparent {\n  color: #fff;\n  background-color: transparent;\n  border-color: transparent; }\n  .btn-transparent:hover {\n    color: #fff;\n    background-color: transparent;\n    border-color: transparent; }\n  .btn-transparent:focus, .btn-transparent.focus {\n    box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.5); }\n  .btn-transparent.disabled, .btn-transparent:disabled {\n    background-color: transparent;\n    border-color: transparent; }\n  .btn-transparent:active, .btn-transparent.active,\n  .show > .btn-transparent.dropdown-toggle {\n    color: #fff;\n    background-color: transparent;\n    background-image: none;\n    border-color: transparent; }\n\n.btn [class^=\"icon-\"], .fc button [class^=\"icon-\"], .btn [class*=\" icon-\"], .fc button [class*=\" icon-\"] {\n  display: inline-block;\n  margin-top: -2px;\n  vertical-align: middle; }\n\n.btn-facebook,\n.btn-twitter,\n.btn-linkedin,\n.btn-flickr,\n.btn-tumblr,\n.btn-xing,\n.btn-github,\n.btn-html5,\n.btn-openid,\n.btn-stack-overflow,\n.btn-youtube,\n.btn-css3,\n.btn-dribbble,\n.btn-google-plus,\n.btn-instagram,\n.btn-pinterest,\n.btn-vk,\n.btn-yahoo,\n.btn-behance,\n.btn-dropbox,\n.btn-reddit,\n.btn-spotify,\n.btn-vine,\n.btn-foursquare,\n.btn-vimeo {\n  position: relative;\n  overflow: hidden;\n  color: #fff !important;\n  text-align: center;\n  padding: 0.5rem 1rem;\n  font-size: 0.875rem;\n  line-height: 1.5;\n  border: 0; }\n  .btn-facebook::before,\n  .btn-twitter::before,\n  .btn-linkedin::before,\n  .btn-flickr::before,\n  .btn-tumblr::before,\n  .btn-xing::before,\n  .btn-github::before,\n  .btn-html5::before,\n  .btn-openid::before,\n  .btn-stack-overflow::before,\n  .btn-youtube::before,\n  .btn-css3::before,\n  .btn-dribbble::before,\n  .btn-google-plus::before,\n  .btn-instagram::before,\n  .btn-pinterest::before,\n  .btn-vk::before,\n  .btn-yahoo::before,\n  .btn-behance::before,\n  .btn-dropbox::before,\n  .btn-reddit::before,\n  .btn-spotify::before,\n  .btn-vine::before,\n  .btn-foursquare::before,\n  .btn-vimeo::before {\n    position: absolute;\n    top: 0;\n    left: 0;\n    display: block;\n    font-family: 'FontAwesome';\n    font-style: normal;\n    font-weight: normal;\n    -moz-osx-font-smoothing: grayscale;\n    -webkit-font-smoothing: antialiased; }\n  .btn-facebook:hover,\n  .btn-twitter:hover,\n  .btn-linkedin:hover,\n  .btn-flickr:hover,\n  .btn-tumblr:hover,\n  .btn-xing:hover,\n  .btn-github:hover,\n  .btn-html5:hover,\n  .btn-openid:hover,\n  .btn-stack-overflow:hover,\n  .btn-youtube:hover,\n  .btn-css3:hover,\n  .btn-dribbble:hover,\n  .btn-google-plus:hover,\n  .btn-instagram:hover,\n  .btn-pinterest:hover,\n  .btn-vk:hover,\n  .btn-yahoo:hover,\n  .btn-behance:hover,\n  .btn-dropbox:hover,\n  .btn-reddit:hover,\n  .btn-spotify:hover,\n  .btn-vine:hover,\n  .btn-foursquare:hover,\n  .btn-vimeo:hover {\n    color: #fff; }\n  .btn-facebook.icon span,\n  .btn-twitter.icon span,\n  .btn-linkedin.icon span,\n  .btn-flickr.icon span,\n  .btn-tumblr.icon span,\n  .btn-xing.icon span,\n  .btn-github.icon span,\n  .btn-html5.icon span,\n  .btn-openid.icon span,\n  .btn-stack-overflow.icon span,\n  .btn-youtube.icon span,\n  .btn-css3.icon span,\n  .btn-dribbble.icon span,\n  .btn-google-plus.icon span,\n  .btn-instagram.icon span,\n  .btn-pinterest.icon span,\n  .btn-vk.icon span,\n  .btn-yahoo.icon span,\n  .btn-behance.icon span,\n  .btn-dropbox.icon span,\n  .btn-reddit.icon span,\n  .btn-spotify.icon span,\n  .btn-vine.icon span,\n  .btn-foursquare.icon span,\n  .btn-vimeo.icon span {\n    display: none; }\n  .btn-facebook.text::before,\n  .btn-twitter.text::before,\n  .btn-linkedin.text::before,\n  .btn-flickr.text::before,\n  .btn-tumblr.text::before,\n  .btn-xing.text::before,\n  .btn-github.text::before,\n  .btn-html5.text::before,\n  .btn-openid.text::before,\n  .btn-stack-overflow.text::before,\n  .btn-youtube.text::before,\n  .btn-css3.text::before,\n  .btn-dribbble.text::before,\n  .btn-google-plus.text::before,\n  .btn-instagram.text::before,\n  .btn-pinterest.text::before,\n  .btn-vk.text::before,\n  .btn-yahoo.text::before,\n  .btn-behance.text::before,\n  .btn-dropbox.text::before,\n  .btn-reddit.text::before,\n  .btn-spotify.text::before,\n  .btn-vine.text::before,\n  .btn-foursquare.text::before,\n  .btn-vimeo.text::before {\n    display: none; }\n  .btn-facebook.text span,\n  .btn-twitter.text span,\n  .btn-linkedin.text span,\n  .btn-flickr.text span,\n  .btn-tumblr.text span,\n  .btn-xing.text span,\n  .btn-github.text span,\n  .btn-html5.text span,\n  .btn-openid.text span,\n  .btn-stack-overflow.text span,\n  .btn-youtube.text span,\n  .btn-css3.text span,\n  .btn-dribbble.text span,\n  .btn-google-plus.text span,\n  .btn-instagram.text span,\n  .btn-pinterest.text span,\n  .btn-vk.text span,\n  .btn-yahoo.text span,\n  .btn-behance.text span,\n  .btn-dropbox.text span,\n  .btn-reddit.text span,\n  .btn-spotify.text span,\n  .btn-vine.text span,\n  .btn-foursquare.text span,\n  .btn-vimeo.text span {\n    margin-left: 0 !important; }\n  .btn-facebook::before,\n  .btn-twitter::before,\n  .btn-linkedin::before,\n  .btn-flickr::before,\n  .btn-tumblr::before,\n  .btn-xing::before,\n  .btn-github::before,\n  .btn-html5::before,\n  .btn-openid::before,\n  .btn-stack-overflow::before,\n  .btn-youtube::before,\n  .btn-css3::before,\n  .btn-dribbble::before,\n  .btn-google-plus::before,\n  .btn-instagram::before,\n  .btn-pinterest::before,\n  .btn-vk::before,\n  .btn-yahoo::before,\n  .btn-behance::before,\n  .btn-dropbox::before,\n  .btn-reddit::before,\n  .btn-spotify::before,\n  .btn-vine::before,\n  .btn-foursquare::before,\n  .btn-vimeo::before {\n    width: 2.3125rem;\n    height: 2.3125rem;\n    padding: 0.5rem 0;\n    font-size: 0.875rem;\n    line-height: 1.5; }\n  .btn-facebook span,\n  .btn-twitter span,\n  .btn-linkedin span,\n  .btn-flickr span,\n  .btn-tumblr span,\n  .btn-xing span,\n  .btn-github span,\n  .btn-html5 span,\n  .btn-openid span,\n  .btn-stack-overflow span,\n  .btn-youtube span,\n  .btn-css3 span,\n  .btn-dribbble span,\n  .btn-google-plus span,\n  .btn-instagram span,\n  .btn-pinterest span,\n  .btn-vk span,\n  .btn-yahoo span,\n  .btn-behance span,\n  .btn-dropbox span,\n  .btn-reddit span,\n  .btn-spotify span,\n  .btn-vine span,\n  .btn-foursquare span,\n  .btn-vimeo span {\n    margin-left: 2.3125rem; }\n  .btn-facebook.icon,\n  .btn-twitter.icon,\n  .btn-linkedin.icon,\n  .btn-flickr.icon,\n  .btn-tumblr.icon,\n  .btn-xing.icon,\n  .btn-github.icon,\n  .btn-html5.icon,\n  .btn-openid.icon,\n  .btn-stack-overflow.icon,\n  .btn-youtube.icon,\n  .btn-css3.icon,\n  .btn-dribbble.icon,\n  .btn-google-plus.icon,\n  .btn-instagram.icon,\n  .btn-pinterest.icon,\n  .btn-vk.icon,\n  .btn-yahoo.icon,\n  .btn-behance.icon,\n  .btn-dropbox.icon,\n  .btn-reddit.icon,\n  .btn-spotify.icon,\n  .btn-vine.icon,\n  .btn-foursquare.icon,\n  .btn-vimeo.icon {\n    width: 2.3125rem;\n    height: 2.3125rem; }\n  .btn-facebook.btn-lg, .btn-group-lg > .btn-facebook.btn, .fc .btn-group-lg > button.btn-facebook,\n  .btn-twitter.btn-lg,\n  .btn-group-lg > .btn-twitter.btn,\n  .fc .btn-group-lg > button.btn-twitter,\n  .btn-linkedin.btn-lg,\n  .btn-group-lg > .btn-linkedin.btn,\n  .fc .btn-group-lg > button.btn-linkedin,\n  .btn-flickr.btn-lg,\n  .btn-group-lg > .btn-flickr.btn,\n  .fc .btn-group-lg > button.btn-flickr,\n  .btn-tumblr.btn-lg,\n  .btn-group-lg > .btn-tumblr.btn,\n  .fc .btn-group-lg > button.btn-tumblr,\n  .btn-xing.btn-lg,\n  .btn-group-lg > .btn-xing.btn,\n  .fc .btn-group-lg > button.btn-xing,\n  .btn-github.btn-lg,\n  .btn-group-lg > .btn-github.btn,\n  .fc .btn-group-lg > button.btn-github,\n  .btn-html5.btn-lg,\n  .btn-group-lg > .btn-html5.btn,\n  .fc .btn-group-lg > button.btn-html5,\n  .btn-openid.btn-lg,\n  .btn-group-lg > .btn-openid.btn,\n  .fc .btn-group-lg > button.btn-openid,\n  .btn-stack-overflow.btn-lg,\n  .btn-group-lg > .btn-stack-overflow.btn,\n  .fc .btn-group-lg > button.btn-stack-overflow,\n  .btn-youtube.btn-lg,\n  .btn-group-lg > .btn-youtube.btn,\n  .fc .btn-group-lg > button.btn-youtube,\n  .btn-css3.btn-lg,\n  .btn-group-lg > .btn-css3.btn,\n  .fc .btn-group-lg > button.btn-css3,\n  .btn-dribbble.btn-lg,\n  .btn-group-lg > .btn-dribbble.btn,\n  .fc .btn-group-lg > button.btn-dribbble,\n  .btn-google-plus.btn-lg,\n  .btn-group-lg > .btn-google-plus.btn,\n  .fc .btn-group-lg > button.btn-google-plus,\n  .btn-instagram.btn-lg,\n  .btn-group-lg > .btn-instagram.btn,\n  .fc .btn-group-lg > button.btn-instagram,\n  .btn-pinterest.btn-lg,\n  .btn-group-lg > .btn-pinterest.btn,\n  .fc .btn-group-lg > button.btn-pinterest,\n  .btn-vk.btn-lg,\n  .btn-group-lg > .btn-vk.btn,\n  .fc .btn-group-lg > button.btn-vk,\n  .btn-yahoo.btn-lg,\n  .btn-group-lg > .btn-yahoo.btn,\n  .fc .btn-group-lg > button.btn-yahoo,\n  .btn-behance.btn-lg,\n  .btn-group-lg > .btn-behance.btn,\n  .fc .btn-group-lg > button.btn-behance,\n  .btn-dropbox.btn-lg,\n  .btn-group-lg > .btn-dropbox.btn,\n  .fc .btn-group-lg > button.btn-dropbox,\n  .btn-reddit.btn-lg,\n  .btn-group-lg > .btn-reddit.btn,\n  .fc .btn-group-lg > button.btn-reddit,\n  .btn-spotify.btn-lg,\n  .btn-group-lg > .btn-spotify.btn,\n  .fc .btn-group-lg > button.btn-spotify,\n  .btn-vine.btn-lg,\n  .btn-group-lg > .btn-vine.btn,\n  .fc .btn-group-lg > button.btn-vine,\n  .btn-foursquare.btn-lg,\n  .btn-group-lg > .btn-foursquare.btn,\n  .fc .btn-group-lg > button.btn-foursquare,\n  .btn-vimeo.btn-lg,\n  .btn-group-lg > .btn-vimeo.btn,\n  .fc .btn-group-lg > button.btn-vimeo {\n    padding: 0.75rem 1.5rem;\n    font-size: 1.25rem;\n    line-height: 1.33333;\n    border: 0; }\n    .btn-facebook.btn-lg::before, .btn-group-lg > .btn-facebook.btn::before, .fc .btn-group-lg > button.btn-facebook::before,\n    .btn-twitter.btn-lg::before,\n    .btn-group-lg > .btn-twitter.btn::before,\n    .fc .btn-group-lg > button.btn-twitter::before,\n    .btn-linkedin.btn-lg::before,\n    .btn-group-lg > .btn-linkedin.btn::before,\n    .fc .btn-group-lg > button.btn-linkedin::before,\n    .btn-flickr.btn-lg::before,\n    .btn-group-lg > .btn-flickr.btn::before,\n    .fc .btn-group-lg > button.btn-flickr::before,\n    .btn-tumblr.btn-lg::before,\n    .btn-group-lg > .btn-tumblr.btn::before,\n    .fc .btn-group-lg > button.btn-tumblr::before,\n    .btn-xing.btn-lg::before,\n    .btn-group-lg > .btn-xing.btn::before,\n    .fc .btn-group-lg > button.btn-xing::before,\n    .btn-github.btn-lg::before,\n    .btn-group-lg > .btn-github.btn::before,\n    .fc .btn-group-lg > button.btn-github::before,\n    .btn-html5.btn-lg::before,\n    .btn-group-lg > .btn-html5.btn::before,\n    .fc .btn-group-lg > button.btn-html5::before,\n    .btn-openid.btn-lg::before,\n    .btn-group-lg > .btn-openid.btn::before,\n    .fc .btn-group-lg > button.btn-openid::before,\n    .btn-stack-overflow.btn-lg::before,\n    .btn-group-lg > .btn-stack-overflow.btn::before,\n    .fc .btn-group-lg > button.btn-stack-overflow::before,\n    .btn-youtube.btn-lg::before,\n    .btn-group-lg > .btn-youtube.btn::before,\n    .fc .btn-group-lg > button.btn-youtube::before,\n    .btn-css3.btn-lg::before,\n    .btn-group-lg > .btn-css3.btn::before,\n    .fc .btn-group-lg > button.btn-css3::before,\n    .btn-dribbble.btn-lg::before,\n    .btn-group-lg > .btn-dribbble.btn::before,\n    .fc .btn-group-lg > button.btn-dribbble::before,\n    .btn-google-plus.btn-lg::before,\n    .btn-group-lg > .btn-google-plus.btn::before,\n    .fc .btn-group-lg > button.btn-google-plus::before,\n    .btn-instagram.btn-lg::before,\n    .btn-group-lg > .btn-instagram.btn::before,\n    .fc .btn-group-lg > button.btn-instagram::before,\n    .btn-pinterest.btn-lg::before,\n    .btn-group-lg > .btn-pinterest.btn::before,\n    .fc .btn-group-lg > button.btn-pinterest::before,\n    .btn-vk.btn-lg::before,\n    .btn-group-lg > .btn-vk.btn::before,\n    .fc .btn-group-lg > button.btn-vk::before,\n    .btn-yahoo.btn-lg::before,\n    .btn-group-lg > .btn-yahoo.btn::before,\n    .fc .btn-group-lg > button.btn-yahoo::before,\n    .btn-behance.btn-lg::before,\n    .btn-group-lg > .btn-behance.btn::before,\n    .fc .btn-group-lg > button.btn-behance::before,\n    .btn-dropbox.btn-lg::before,\n    .btn-group-lg > .btn-dropbox.btn::before,\n    .fc .btn-group-lg > button.btn-dropbox::before,\n    .btn-reddit.btn-lg::before,\n    .btn-group-lg > .btn-reddit.btn::before,\n    .fc .btn-group-lg > button.btn-reddit::before,\n    .btn-spotify.btn-lg::before,\n    .btn-group-lg > .btn-spotify.btn::before,\n    .fc .btn-group-lg > button.btn-spotify::before,\n    .btn-vine.btn-lg::before,\n    .btn-group-lg > .btn-vine.btn::before,\n    .fc .btn-group-lg > button.btn-vine::before,\n    .btn-foursquare.btn-lg::before,\n    .btn-group-lg > .btn-foursquare.btn::before,\n    .fc .btn-group-lg > button.btn-foursquare::before,\n    .btn-vimeo.btn-lg::before,\n    .btn-group-lg > .btn-vimeo.btn::before,\n    .fc .btn-group-lg > button.btn-vimeo::before {\n      width: 3.16667rem;\n      height: 3.16667rem;\n      padding: 0.75rem 0;\n      font-size: 1.25rem;\n      line-height: 1.33333; }\n    .btn-facebook.btn-lg span, .btn-group-lg > .btn-facebook.btn span, .fc .btn-group-lg > button.btn-facebook span,\n    .btn-twitter.btn-lg span, .btn-group-lg > .btn-twitter.btn span, .fc .btn-group-lg > button.btn-twitter span,\n    .btn-linkedin.btn-lg span, .btn-group-lg > .btn-linkedin.btn span, .fc .btn-group-lg > button.btn-linkedin span,\n    .btn-flickr.btn-lg span, .btn-group-lg > .btn-flickr.btn span, .fc .btn-group-lg > button.btn-flickr span,\n    .btn-tumblr.btn-lg span, .btn-group-lg > .btn-tumblr.btn span, .fc .btn-group-lg > button.btn-tumblr span,\n    .btn-xing.btn-lg span, .btn-group-lg > .btn-xing.btn span, .fc .btn-group-lg > button.btn-xing span,\n    .btn-github.btn-lg span, .btn-group-lg > .btn-github.btn span, .fc .btn-group-lg > button.btn-github span,\n    .btn-html5.btn-lg span, .btn-group-lg > .btn-html5.btn span, .fc .btn-group-lg > button.btn-html5 span,\n    .btn-openid.btn-lg span, .btn-group-lg > .btn-openid.btn span, .fc .btn-group-lg > button.btn-openid span,\n    .btn-stack-overflow.btn-lg span, .btn-group-lg > .btn-stack-overflow.btn span, .fc .btn-group-lg > button.btn-stack-overflow span,\n    .btn-youtube.btn-lg span, .btn-group-lg > .btn-youtube.btn span, .fc .btn-group-lg > button.btn-youtube span,\n    .btn-css3.btn-lg span, .btn-group-lg > .btn-css3.btn span, .fc .btn-group-lg > button.btn-css3 span,\n    .btn-dribbble.btn-lg span, .btn-group-lg > .btn-dribbble.btn span, .fc .btn-group-lg > button.btn-dribbble span,\n    .btn-google-plus.btn-lg span, .btn-group-lg > .btn-google-plus.btn span, .fc .btn-group-lg > button.btn-google-plus span,\n    .btn-instagram.btn-lg span, .btn-group-lg > .btn-instagram.btn span, .fc .btn-group-lg > button.btn-instagram span,\n    .btn-pinterest.btn-lg span, .btn-group-lg > .btn-pinterest.btn span, .fc .btn-group-lg > button.btn-pinterest span,\n    .btn-vk.btn-lg span, .btn-group-lg > .btn-vk.btn span, .fc .btn-group-lg > button.btn-vk span,\n    .btn-yahoo.btn-lg span, .btn-group-lg > .btn-yahoo.btn span, .fc .btn-group-lg > button.btn-yahoo span,\n    .btn-behance.btn-lg span, .btn-group-lg > .btn-behance.btn span, .fc .btn-group-lg > button.btn-behance span,\n    .btn-dropbox.btn-lg span, .btn-group-lg > .btn-dropbox.btn span, .fc .btn-group-lg > button.btn-dropbox span,\n    .btn-reddit.btn-lg span, .btn-group-lg > .btn-reddit.btn span, .fc .btn-group-lg > button.btn-reddit span,\n    .btn-spotify.btn-lg span, .btn-group-lg > .btn-spotify.btn span, .fc .btn-group-lg > button.btn-spotify span,\n    .btn-vine.btn-lg span, .btn-group-lg > .btn-vine.btn span, .fc .btn-group-lg > button.btn-vine span,\n    .btn-foursquare.btn-lg span, .btn-group-lg > .btn-foursquare.btn span, .fc .btn-group-lg > button.btn-foursquare span,\n    .btn-vimeo.btn-lg span, .btn-group-lg > .btn-vimeo.btn span, .fc .btn-group-lg > button.btn-vimeo span {\n      margin-left: 3.16667rem; }\n    .btn-facebook.btn-lg.icon, .btn-group-lg > .btn-facebook.icon.btn, .fc .btn-group-lg > button.btn-facebook.icon,\n    .btn-twitter.btn-lg.icon,\n    .btn-group-lg > .btn-twitter.icon.btn,\n    .fc .btn-group-lg > button.btn-twitter.icon,\n    .btn-linkedin.btn-lg.icon,\n    .btn-group-lg > .btn-linkedin.icon.btn,\n    .fc .btn-group-lg > button.btn-linkedin.icon,\n    .btn-flickr.btn-lg.icon,\n    .btn-group-lg > .btn-flickr.icon.btn,\n    .fc .btn-group-lg > button.btn-flickr.icon,\n    .btn-tumblr.btn-lg.icon,\n    .btn-group-lg > .btn-tumblr.icon.btn,\n    .fc .btn-group-lg > button.btn-tumblr.icon,\n    .btn-xing.btn-lg.icon,\n    .btn-group-lg > .btn-xing.icon.btn,\n    .fc .btn-group-lg > button.btn-xing.icon,\n    .btn-github.btn-lg.icon,\n    .btn-group-lg > .btn-github.icon.btn,\n    .fc .btn-group-lg > button.btn-github.icon,\n    .btn-html5.btn-lg.icon,\n    .btn-group-lg > .btn-html5.icon.btn,\n    .fc .btn-group-lg > button.btn-html5.icon,\n    .btn-openid.btn-lg.icon,\n    .btn-group-lg > .btn-openid.icon.btn,\n    .fc .btn-group-lg > button.btn-openid.icon,\n    .btn-stack-overflow.btn-lg.icon,\n    .btn-group-lg > .btn-stack-overflow.icon.btn,\n    .fc .btn-group-lg > button.btn-stack-overflow.icon,\n    .btn-youtube.btn-lg.icon,\n    .btn-group-lg > .btn-youtube.icon.btn,\n    .fc .btn-group-lg > button.btn-youtube.icon,\n    .btn-css3.btn-lg.icon,\n    .btn-group-lg > .btn-css3.icon.btn,\n    .fc .btn-group-lg > button.btn-css3.icon,\n    .btn-dribbble.btn-lg.icon,\n    .btn-group-lg > .btn-dribbble.icon.btn,\n    .fc .btn-group-lg > button.btn-dribbble.icon,\n    .btn-google-plus.btn-lg.icon,\n    .btn-group-lg > .btn-google-plus.icon.btn,\n    .fc .btn-group-lg > button.btn-google-plus.icon,\n    .btn-instagram.btn-lg.icon,\n    .btn-group-lg > .btn-instagram.icon.btn,\n    .fc .btn-group-lg > button.btn-instagram.icon,\n    .btn-pinterest.btn-lg.icon,\n    .btn-group-lg > .btn-pinterest.icon.btn,\n    .fc .btn-group-lg > button.btn-pinterest.icon,\n    .btn-vk.btn-lg.icon,\n    .btn-group-lg > .btn-vk.icon.btn,\n    .fc .btn-group-lg > button.btn-vk.icon,\n    .btn-yahoo.btn-lg.icon,\n    .btn-group-lg > .btn-yahoo.icon.btn,\n    .fc .btn-group-lg > button.btn-yahoo.icon,\n    .btn-behance.btn-lg.icon,\n    .btn-group-lg > .btn-behance.icon.btn,\n    .fc .btn-group-lg > button.btn-behance.icon,\n    .btn-dropbox.btn-lg.icon,\n    .btn-group-lg > .btn-dropbox.icon.btn,\n    .fc .btn-group-lg > button.btn-dropbox.icon,\n    .btn-reddit.btn-lg.icon,\n    .btn-group-lg > .btn-reddit.icon.btn,\n    .fc .btn-group-lg > button.btn-reddit.icon,\n    .btn-spotify.btn-lg.icon,\n    .btn-group-lg > .btn-spotify.icon.btn,\n    .fc .btn-group-lg > button.btn-spotify.icon,\n    .btn-vine.btn-lg.icon,\n    .btn-group-lg > .btn-vine.icon.btn,\n    .fc .btn-group-lg > button.btn-vine.icon,\n    .btn-foursquare.btn-lg.icon,\n    .btn-group-lg > .btn-foursquare.icon.btn,\n    .fc .btn-group-lg > button.btn-foursquare.icon,\n    .btn-vimeo.btn-lg.icon,\n    .btn-group-lg > .btn-vimeo.icon.btn,\n    .fc .btn-group-lg > button.btn-vimeo.icon {\n      width: 3.16667rem;\n      height: 3.16667rem; }\n  .btn-facebook.btn-sm, .btn-group-sm > .btn-facebook.btn, .fc .btn-group-sm > button.btn-facebook,\n  .btn-twitter.btn-sm,\n  .btn-group-sm > .btn-twitter.btn,\n  .fc .btn-group-sm > button.btn-twitter,\n  .btn-linkedin.btn-sm,\n  .btn-group-sm > .btn-linkedin.btn,\n  .fc .btn-group-sm > button.btn-linkedin,\n  .btn-flickr.btn-sm,\n  .btn-group-sm > .btn-flickr.btn,\n  .fc .btn-group-sm > button.btn-flickr,\n  .btn-tumblr.btn-sm,\n  .btn-group-sm > .btn-tumblr.btn,\n  .fc .btn-group-sm > button.btn-tumblr,\n  .btn-xing.btn-sm,\n  .btn-group-sm > .btn-xing.btn,\n  .fc .btn-group-sm > button.btn-xing,\n  .btn-github.btn-sm,\n  .btn-group-sm > .btn-github.btn,\n  .fc .btn-group-sm > button.btn-github,\n  .btn-html5.btn-sm,\n  .btn-group-sm > .btn-html5.btn,\n  .fc .btn-group-sm > button.btn-html5,\n  .btn-openid.btn-sm,\n  .btn-group-sm > .btn-openid.btn,\n  .fc .btn-group-sm > button.btn-openid,\n  .btn-stack-overflow.btn-sm,\n  .btn-group-sm > .btn-stack-overflow.btn,\n  .fc .btn-group-sm > button.btn-stack-overflow,\n  .btn-youtube.btn-sm,\n  .btn-group-sm > .btn-youtube.btn,\n  .fc .btn-group-sm > button.btn-youtube,\n  .btn-css3.btn-sm,\n  .btn-group-sm > .btn-css3.btn,\n  .fc .btn-group-sm > button.btn-css3,\n  .btn-dribbble.btn-sm,\n  .btn-group-sm > .btn-dribbble.btn,\n  .fc .btn-group-sm > button.btn-dribbble,\n  .btn-google-plus.btn-sm,\n  .btn-group-sm > .btn-google-plus.btn,\n  .fc .btn-group-sm > button.btn-google-plus,\n  .btn-instagram.btn-sm,\n  .btn-group-sm > .btn-instagram.btn,\n  .fc .btn-group-sm > button.btn-instagram,\n  .btn-pinterest.btn-sm,\n  .btn-group-sm > .btn-pinterest.btn,\n  .fc .btn-group-sm > button.btn-pinterest,\n  .btn-vk.btn-sm,\n  .btn-group-sm > .btn-vk.btn,\n  .fc .btn-group-sm > button.btn-vk,\n  .btn-yahoo.btn-sm,\n  .btn-group-sm > .btn-yahoo.btn,\n  .fc .btn-group-sm > button.btn-yahoo,\n  .btn-behance.btn-sm,\n  .btn-group-sm > .btn-behance.btn,\n  .fc .btn-group-sm > button.btn-behance,\n  .btn-dropbox.btn-sm,\n  .btn-group-sm > .btn-dropbox.btn,\n  .fc .btn-group-sm > button.btn-dropbox,\n  .btn-reddit.btn-sm,\n  .btn-group-sm > .btn-reddit.btn,\n  .fc .btn-group-sm > button.btn-reddit,\n  .btn-spotify.btn-sm,\n  .btn-group-sm > .btn-spotify.btn,\n  .fc .btn-group-sm > button.btn-spotify,\n  .btn-vine.btn-sm,\n  .btn-group-sm > .btn-vine.btn,\n  .fc .btn-group-sm > button.btn-vine,\n  .btn-foursquare.btn-sm,\n  .btn-group-sm > .btn-foursquare.btn,\n  .fc .btn-group-sm > button.btn-foursquare,\n  .btn-vimeo.btn-sm,\n  .btn-group-sm > .btn-vimeo.btn,\n  .fc .btn-group-sm > button.btn-vimeo {\n    padding: 0.25rem 0.5rem;\n    font-size: 0.875rem;\n    line-height: 1.5;\n    border: 0; }\n    .btn-facebook.btn-sm::before, .btn-group-sm > .btn-facebook.btn::before, .fc .btn-group-sm > button.btn-facebook::before,\n    .btn-twitter.btn-sm::before,\n    .btn-group-sm > .btn-twitter.btn::before,\n    .fc .btn-group-sm > button.btn-twitter::before,\n    .btn-linkedin.btn-sm::before,\n    .btn-group-sm > .btn-linkedin.btn::before,\n    .fc .btn-group-sm > button.btn-linkedin::before,\n    .btn-flickr.btn-sm::before,\n    .btn-group-sm > .btn-flickr.btn::before,\n    .fc .btn-group-sm > button.btn-flickr::before,\n    .btn-tumblr.btn-sm::before,\n    .btn-group-sm > .btn-tumblr.btn::before,\n    .fc .btn-group-sm > button.btn-tumblr::before,\n    .btn-xing.btn-sm::before,\n    .btn-group-sm > .btn-xing.btn::before,\n    .fc .btn-group-sm > button.btn-xing::before,\n    .btn-github.btn-sm::before,\n    .btn-group-sm > .btn-github.btn::before,\n    .fc .btn-group-sm > button.btn-github::before,\n    .btn-html5.btn-sm::before,\n    .btn-group-sm > .btn-html5.btn::before,\n    .fc .btn-group-sm > button.btn-html5::before,\n    .btn-openid.btn-sm::before,\n    .btn-group-sm > .btn-openid.btn::before,\n    .fc .btn-group-sm > button.btn-openid::before,\n    .btn-stack-overflow.btn-sm::before,\n    .btn-group-sm > .btn-stack-overflow.btn::before,\n    .fc .btn-group-sm > button.btn-stack-overflow::before,\n    .btn-youtube.btn-sm::before,\n    .btn-group-sm > .btn-youtube.btn::before,\n    .fc .btn-group-sm > button.btn-youtube::before,\n    .btn-css3.btn-sm::before,\n    .btn-group-sm > .btn-css3.btn::before,\n    .fc .btn-group-sm > button.btn-css3::before,\n    .btn-dribbble.btn-sm::before,\n    .btn-group-sm > .btn-dribbble.btn::before,\n    .fc .btn-group-sm > button.btn-dribbble::before,\n    .btn-google-plus.btn-sm::before,\n    .btn-group-sm > .btn-google-plus.btn::before,\n    .fc .btn-group-sm > button.btn-google-plus::before,\n    .btn-instagram.btn-sm::before,\n    .btn-group-sm > .btn-instagram.btn::before,\n    .fc .btn-group-sm > button.btn-instagram::before,\n    .btn-pinterest.btn-sm::before,\n    .btn-group-sm > .btn-pinterest.btn::before,\n    .fc .btn-group-sm > button.btn-pinterest::before,\n    .btn-vk.btn-sm::before,\n    .btn-group-sm > .btn-vk.btn::before,\n    .fc .btn-group-sm > button.btn-vk::before,\n    .btn-yahoo.btn-sm::before,\n    .btn-group-sm > .btn-yahoo.btn::before,\n    .fc .btn-group-sm > button.btn-yahoo::before,\n    .btn-behance.btn-sm::before,\n    .btn-group-sm > .btn-behance.btn::before,\n    .fc .btn-group-sm > button.btn-behance::before,\n    .btn-dropbox.btn-sm::before,\n    .btn-group-sm > .btn-dropbox.btn::before,\n    .fc .btn-group-sm > button.btn-dropbox::before,\n    .btn-reddit.btn-sm::before,\n    .btn-group-sm > .btn-reddit.btn::before,\n    .fc .btn-group-sm > button.btn-reddit::before,\n    .btn-spotify.btn-sm::before,\n    .btn-group-sm > .btn-spotify.btn::before,\n    .fc .btn-group-sm > button.btn-spotify::before,\n    .btn-vine.btn-sm::before,\n    .btn-group-sm > .btn-vine.btn::before,\n    .fc .btn-group-sm > button.btn-vine::before,\n    .btn-foursquare.btn-sm::before,\n    .btn-group-sm > .btn-foursquare.btn::before,\n    .fc .btn-group-sm > button.btn-foursquare::before,\n    .btn-vimeo.btn-sm::before,\n    .btn-group-sm > .btn-vimeo.btn::before,\n    .fc .btn-group-sm > button.btn-vimeo::before {\n      width: 1.8125rem;\n      height: 1.8125rem;\n      padding: 0.25rem 0;\n      font-size: 0.875rem;\n      line-height: 1.5; }\n    .btn-facebook.btn-sm span, .btn-group-sm > .btn-facebook.btn span, .fc .btn-group-sm > button.btn-facebook span,\n    .btn-twitter.btn-sm span, .btn-group-sm > .btn-twitter.btn span, .fc .btn-group-sm > button.btn-twitter span,\n    .btn-linkedin.btn-sm span, .btn-group-sm > .btn-linkedin.btn span, .fc .btn-group-sm > button.btn-linkedin span,\n    .btn-flickr.btn-sm span, .btn-group-sm > .btn-flickr.btn span, .fc .btn-group-sm > button.btn-flickr span,\n    .btn-tumblr.btn-sm span, .btn-group-sm > .btn-tumblr.btn span, .fc .btn-group-sm > button.btn-tumblr span,\n    .btn-xing.btn-sm span, .btn-group-sm > .btn-xing.btn span, .fc .btn-group-sm > button.btn-xing span,\n    .btn-github.btn-sm span, .btn-group-sm > .btn-github.btn span, .fc .btn-group-sm > button.btn-github span,\n    .btn-html5.btn-sm span, .btn-group-sm > .btn-html5.btn span, .fc .btn-group-sm > button.btn-html5 span,\n    .btn-openid.btn-sm span, .btn-group-sm > .btn-openid.btn span, .fc .btn-group-sm > button.btn-openid span,\n    .btn-stack-overflow.btn-sm span, .btn-group-sm > .btn-stack-overflow.btn span, .fc .btn-group-sm > button.btn-stack-overflow span,\n    .btn-youtube.btn-sm span, .btn-group-sm > .btn-youtube.btn span, .fc .btn-group-sm > button.btn-youtube span,\n    .btn-css3.btn-sm span, .btn-group-sm > .btn-css3.btn span, .fc .btn-group-sm > button.btn-css3 span,\n    .btn-dribbble.btn-sm span, .btn-group-sm > .btn-dribbble.btn span, .fc .btn-group-sm > button.btn-dribbble span,\n    .btn-google-plus.btn-sm span, .btn-group-sm > .btn-google-plus.btn span, .fc .btn-group-sm > button.btn-google-plus span,\n    .btn-instagram.btn-sm span, .btn-group-sm > .btn-instagram.btn span, .fc .btn-group-sm > button.btn-instagram span,\n    .btn-pinterest.btn-sm span, .btn-group-sm > .btn-pinterest.btn span, .fc .btn-group-sm > button.btn-pinterest span,\n    .btn-vk.btn-sm span, .btn-group-sm > .btn-vk.btn span, .fc .btn-group-sm > button.btn-vk span,\n    .btn-yahoo.btn-sm span, .btn-group-sm > .btn-yahoo.btn span, .fc .btn-group-sm > button.btn-yahoo span,\n    .btn-behance.btn-sm span, .btn-group-sm > .btn-behance.btn span, .fc .btn-group-sm > button.btn-behance span,\n    .btn-dropbox.btn-sm span, .btn-group-sm > .btn-dropbox.btn span, .fc .btn-group-sm > button.btn-dropbox span,\n    .btn-reddit.btn-sm span, .btn-group-sm > .btn-reddit.btn span, .fc .btn-group-sm > button.btn-reddit span,\n    .btn-spotify.btn-sm span, .btn-group-sm > .btn-spotify.btn span, .fc .btn-group-sm > button.btn-spotify span,\n    .btn-vine.btn-sm span, .btn-group-sm > .btn-vine.btn span, .fc .btn-group-sm > button.btn-vine span,\n    .btn-foursquare.btn-sm span, .btn-group-sm > .btn-foursquare.btn span, .fc .btn-group-sm > button.btn-foursquare span,\n    .btn-vimeo.btn-sm span, .btn-group-sm > .btn-vimeo.btn span, .fc .btn-group-sm > button.btn-vimeo span {\n      margin-left: 1.8125rem; }\n    .btn-facebook.btn-sm.icon, .btn-group-sm > .btn-facebook.icon.btn, .fc .btn-group-sm > button.btn-facebook.icon,\n    .btn-twitter.btn-sm.icon,\n    .btn-group-sm > .btn-twitter.icon.btn,\n    .fc .btn-group-sm > button.btn-twitter.icon,\n    .btn-linkedin.btn-sm.icon,\n    .btn-group-sm > .btn-linkedin.icon.btn,\n    .fc .btn-group-sm > button.btn-linkedin.icon,\n    .btn-flickr.btn-sm.icon,\n    .btn-group-sm > .btn-flickr.icon.btn,\n    .fc .btn-group-sm > button.btn-flickr.icon,\n    .btn-tumblr.btn-sm.icon,\n    .btn-group-sm > .btn-tumblr.icon.btn,\n    .fc .btn-group-sm > button.btn-tumblr.icon,\n    .btn-xing.btn-sm.icon,\n    .btn-group-sm > .btn-xing.icon.btn,\n    .fc .btn-group-sm > button.btn-xing.icon,\n    .btn-github.btn-sm.icon,\n    .btn-group-sm > .btn-github.icon.btn,\n    .fc .btn-group-sm > button.btn-github.icon,\n    .btn-html5.btn-sm.icon,\n    .btn-group-sm > .btn-html5.icon.btn,\n    .fc .btn-group-sm > button.btn-html5.icon,\n    .btn-openid.btn-sm.icon,\n    .btn-group-sm > .btn-openid.icon.btn,\n    .fc .btn-group-sm > button.btn-openid.icon,\n    .btn-stack-overflow.btn-sm.icon,\n    .btn-group-sm > .btn-stack-overflow.icon.btn,\n    .fc .btn-group-sm > button.btn-stack-overflow.icon,\n    .btn-youtube.btn-sm.icon,\n    .btn-group-sm > .btn-youtube.icon.btn,\n    .fc .btn-group-sm > button.btn-youtube.icon,\n    .btn-css3.btn-sm.icon,\n    .btn-group-sm > .btn-css3.icon.btn,\n    .fc .btn-group-sm > button.btn-css3.icon,\n    .btn-dribbble.btn-sm.icon,\n    .btn-group-sm > .btn-dribbble.icon.btn,\n    .fc .btn-group-sm > button.btn-dribbble.icon,\n    .btn-google-plus.btn-sm.icon,\n    .btn-group-sm > .btn-google-plus.icon.btn,\n    .fc .btn-group-sm > button.btn-google-plus.icon,\n    .btn-instagram.btn-sm.icon,\n    .btn-group-sm > .btn-instagram.icon.btn,\n    .fc .btn-group-sm > button.btn-instagram.icon,\n    .btn-pinterest.btn-sm.icon,\n    .btn-group-sm > .btn-pinterest.icon.btn,\n    .fc .btn-group-sm > button.btn-pinterest.icon,\n    .btn-vk.btn-sm.icon,\n    .btn-group-sm > .btn-vk.icon.btn,\n    .fc .btn-group-sm > button.btn-vk.icon,\n    .btn-yahoo.btn-sm.icon,\n    .btn-group-sm > .btn-yahoo.icon.btn,\n    .fc .btn-group-sm > button.btn-yahoo.icon,\n    .btn-behance.btn-sm.icon,\n    .btn-group-sm > .btn-behance.icon.btn,\n    .fc .btn-group-sm > button.btn-behance.icon,\n    .btn-dropbox.btn-sm.icon,\n    .btn-group-sm > .btn-dropbox.icon.btn,\n    .fc .btn-group-sm > button.btn-dropbox.icon,\n    .btn-reddit.btn-sm.icon,\n    .btn-group-sm > .btn-reddit.icon.btn,\n    .fc .btn-group-sm > button.btn-reddit.icon,\n    .btn-spotify.btn-sm.icon,\n    .btn-group-sm > .btn-spotify.icon.btn,\n    .fc .btn-group-sm > button.btn-spotify.icon,\n    .btn-vine.btn-sm.icon,\n    .btn-group-sm > .btn-vine.icon.btn,\n    .fc .btn-group-sm > button.btn-vine.icon,\n    .btn-foursquare.btn-sm.icon,\n    .btn-group-sm > .btn-foursquare.icon.btn,\n    .fc .btn-group-sm > button.btn-foursquare.icon,\n    .btn-vimeo.btn-sm.icon,\n    .btn-group-sm > .btn-vimeo.icon.btn,\n    .fc .btn-group-sm > button.btn-vimeo.icon {\n      width: 1.8125rem;\n      height: 1.8125rem; }\n\n.btn-facebook {\n  background: #3b5998; }\n  .btn-facebook::before {\n    content: \"\\f09a\";\n    background: #344e86; }\n  .btn-facebook:hover {\n    background: #344e86; }\n    .btn-facebook:hover::before {\n      background: #2d4373; }\n\n.btn-twitter {\n  background: #00aced; }\n  .btn-twitter::before {\n    content: \"\\f099\";\n    background: #0099d4; }\n  .btn-twitter:hover {\n    background: #0099d4; }\n    .btn-twitter:hover::before {\n      background: #0087ba; }\n\n.btn-linkedin {\n  background: #4875b4; }\n  .btn-linkedin::before {\n    content: \"\\f0e1\";\n    background: #4169a2; }\n  .btn-linkedin:hover {\n    background: #4169a2; }\n    .btn-linkedin:hover::before {\n      background: #395d90; }\n\n.btn-flickr {\n  background: #ff0084; }\n  .btn-flickr::before {\n    content: \"\\f16e\";\n    background: #e60077; }\n  .btn-flickr:hover {\n    background: #e60077; }\n    .btn-flickr:hover::before {\n      background: #cc006a; }\n\n.btn-tumblr {\n  background: #32506d; }\n  .btn-tumblr::before {\n    content: \"\\f173\";\n    background: #2a435c; }\n  .btn-tumblr:hover {\n    background: #2a435c; }\n    .btn-tumblr:hover::before {\n      background: #22364a; }\n\n.btn-xing {\n  background: #026466; }\n  .btn-xing::before {\n    content: \"\\f168\";\n    background: #024b4d; }\n  .btn-xing:hover {\n    background: #024b4d; }\n    .btn-xing:hover::before {\n      background: #013334; }\n\n.btn-github {\n  background: #4183c4; }\n  .btn-github::before {\n    content: \"\\f09b\";\n    background: #3876b4; }\n  .btn-github:hover {\n    background: #3876b4; }\n    .btn-github:hover::before {\n      background: #3269a0; }\n\n.btn-html5 {\n  background: #e34f26; }\n  .btn-html5::before {\n    content: \"\\f13b\";\n    background: #d4431b; }\n  .btn-html5:hover {\n    background: #d4431b; }\n    .btn-html5:hover::before {\n      background: #be3c18; }\n\n.btn-openid {\n  background: #f78c40; }\n  .btn-openid::before {\n    content: \"\\f19b\";\n    background: #f67d28; }\n  .btn-openid:hover {\n    background: #f67d28; }\n    .btn-openid:hover::before {\n      background: #f56f0f; }\n\n.btn-stack-overflow {\n  background: #fe7a15; }\n  .btn-stack-overflow::before {\n    content: \"\\f16c\";\n    background: #f86c01; }\n  .btn-stack-overflow:hover {\n    background: #f86c01; }\n    .btn-stack-overflow:hover::before {\n      background: #df6101; }\n\n.btn-css3 {\n  background: #0170ba; }\n  .btn-css3::before {\n    content: \"\\f13c\";\n    background: #0161a1; }\n  .btn-css3:hover {\n    background: #0161a1; }\n    .btn-css3:hover::before {\n      background: #015187; }\n\n.btn-youtube {\n  background: #b00; }\n  .btn-youtube::before {\n    content: \"\\f167\";\n    background: #a20000; }\n  .btn-youtube:hover {\n    background: #a20000; }\n    .btn-youtube:hover::before {\n      background: #880000; }\n\n.btn-dribbble {\n  background: #ea4c89; }\n  .btn-dribbble::before {\n    content: \"\\f17d\";\n    background: #e7357a; }\n  .btn-dribbble:hover {\n    background: #e7357a; }\n    .btn-dribbble:hover::before {\n      background: #e51e6b; }\n\n.btn-google-plus {\n  background: #bb4b39; }\n  .btn-google-plus::before {\n    content: \"\\f0d5\";\n    background: #a74333; }\n  .btn-google-plus:hover {\n    background: #a74333; }\n    .btn-google-plus:hover::before {\n      background: #943b2d; }\n\n.btn-instagram {\n  background: #517fa4; }\n  .btn-instagram::before {\n    content: \"\\f16d\";\n    background: #497293; }\n  .btn-instagram:hover {\n    background: #497293; }\n    .btn-instagram:hover::before {\n      background: #406582; }\n\n.btn-pinterest {\n  background: #cb2027; }\n  .btn-pinterest::before {\n    content: \"\\f0d2\";\n    background: #b51d23; }\n  .btn-pinterest:hover {\n    background: #b51d23; }\n    .btn-pinterest:hover::before {\n      background: #9f191f; }\n\n.btn-vk {\n  background: #45668e; }\n  .btn-vk::before {\n    content: \"\\f189\";\n    background: #3d5a7d; }\n  .btn-vk:hover {\n    background: #3d5a7d; }\n    .btn-vk:hover::before {\n      background: #344d6c; }\n\n.btn-yahoo {\n  background: #400191; }\n  .btn-yahoo::before {\n    content: \"\\f19e\";\n    background: #350178; }\n  .btn-yahoo:hover {\n    background: #350178; }\n    .btn-yahoo:hover::before {\n      background: #2a015e; }\n\n.btn-behance {\n  background: #1769ff; }\n  .btn-behance::before {\n    content: \"\\f1b4\";\n    background: #0059fd; }\n  .btn-behance:hover {\n    background: #0059fd; }\n    .btn-behance:hover::before {\n      background: #0050e3; }\n\n.btn-dropbox {\n  background: #007ee5; }\n  .btn-dropbox::before {\n    content: \"\\f16b\";\n    background: #0070cc; }\n  .btn-dropbox:hover {\n    background: #0070cc; }\n    .btn-dropbox:hover::before {\n      background: #0062b2; }\n\n.btn-reddit {\n  background: #ff4500; }\n  .btn-reddit::before {\n    content: \"\\f1a1\";\n    background: #e63e00; }\n  .btn-reddit:hover {\n    background: #e63e00; }\n    .btn-reddit:hover::before {\n      background: #cc3700; }\n\n.btn-spotify {\n  background: #7ab800; }\n  .btn-spotify::before {\n    content: \"\\f1bc\";\n    background: #699f00; }\n  .btn-spotify:hover {\n    background: #699f00; }\n    .btn-spotify:hover::before {\n      background: #588500; }\n\n.btn-vine {\n  background: #00bf8f; }\n  .btn-vine::before {\n    content: \"\\f1ca\";\n    background: #00a67c; }\n  .btn-vine:hover {\n    background: #00a67c; }\n    .btn-vine:hover::before {\n      background: #008c69; }\n\n.btn-foursquare {\n  background: #1073af; }\n  .btn-foursquare::before {\n    content: \"\\f180\";\n    background: #0e6498; }\n  .btn-foursquare:hover {\n    background: #0e6498; }\n    .btn-foursquare:hover::before {\n      background: #0c5480; }\n\n.btn-vimeo {\n  background: #aad450; }\n  .btn-vimeo::before {\n    content: \"\\f194\";\n    background: #a0cf3c; }\n  .btn-vimeo:hover {\n    background: #a0cf3c; }\n    .btn-vimeo:hover::before {\n      background: #93c130; }\n\nhr.transparent {\n  border-top: 1px solid transparent; }\n\n.breadcrumb-menu {\n  position: absolute;\n  top: 0;\n  right: 1rem; }\n  .breadcrumb-menu::before {\n    display: none; }\n  .breadcrumb-menu .btn, .breadcrumb-menu .fc button, .fc .breadcrumb-menu button {\n    padding-top: 0.75rem;\n    padding-bottom: 0.75rem; }\n  .breadcrumb-menu .btn.btn-secondary, .breadcrumb-menu .fc button, .fc .breadcrumb-menu button {\n    color: #818a91;\n    border: 0; }\n    .breadcrumb-menu .btn.btn-secondary:hover, .breadcrumb-menu .fc button:hover, .fc .breadcrumb-menu button:hover, .breadcrumb-menu .btn.btn-secondary.active, .breadcrumb-menu .fc button.active, .fc .breadcrumb-menu button.active {\n      color: #2a2c36;\n      background: transparent; }\n  .breadcrumb-menu .open .btn.btn-secondary, .breadcrumb-menu .open .fc button, .fc .breadcrumb-menu .open button {\n    color: #2a2c36;\n    background: transparent; }\n  .breadcrumb-menu .dropdown-menu {\n    min-width: 180px;\n    line-height: 1.5; }\n\n.img-avatar {\n  border-radius: 50em; }\n\n.avatar {\n  position: relative;\n  display: inline-block;\n  width: 36px; }\n  .avatar .img-avatar {\n    width: 36px;\n    height: 36px; }\n  .avatar .avatar-status {\n    position: absolute;\n    right: 0;\n    bottom: 0;\n    display: block;\n    width: 10px;\n    height: 10px;\n    border: 1px solid #fff;\n    border-radius: 50em; }\n\n.avatar.avatar-xs {\n  position: relative;\n  display: inline-block;\n  width: 20px; }\n  .avatar.avatar-xs .img-avatar {\n    width: 20px;\n    height: 20px; }\n  .avatar.avatar-xs .avatar-status {\n    position: absolute;\n    right: 0;\n    bottom: 0;\n    display: block;\n    width: 8px;\n    height: 8px;\n    border: 1px solid #fff;\n    border-radius: 50em; }\n\n.avatar.avatar-sm {\n  position: relative;\n  display: inline-block;\n  width: 24px; }\n  .avatar.avatar-sm .img-avatar {\n    width: 24px;\n    height: 24px; }\n  .avatar.avatar-sm .avatar-status {\n    position: absolute;\n    right: 0;\n    bottom: 0;\n    display: block;\n    width: 8px;\n    height: 8px;\n    border: 1px solid #fff;\n    border-radius: 50em; }\n\n.avatar.avatar-lg {\n  position: relative;\n  display: inline-block;\n  width: 72px; }\n  .avatar.avatar-lg .img-avatar {\n    width: 72px;\n    height: 72px; }\n  .avatar.avatar-lg .avatar-status {\n    position: absolute;\n    right: 0;\n    bottom: 0;\n    display: block;\n    width: 12px;\n    height: 12px;\n    border: 1px solid #fff;\n    border-radius: 50em; }\n\n.avatars-stack .avatar.avatar-xs {\n  margin-right: -10px; }\n\n.avatars-stack .avatar {\n  margin-right: -15px;\n  transition-duration: 0.25s, 0.25s;\n  transition-property: margin-left, margin-right; }\n  .avatars-stack .avatar:hover {\n    margin-right: 0 !important; }\n\n.callout {\n  position: relative;\n  padding: 0 1rem;\n  margin: 1rem 0;\n  border: 0 solid #d1d4d7;\n  border-left-width: .25rem; }\n  .callout .chart-wrapper {\n    position: absolute;\n    top: 18px;\n    left: 45%;\n    float: right;\n    width: 100px; }\n\n.callout-bordered {\n  border: 1px solid #d1d4d7;\n  border-left-width: .25rem; }\n\n.callout code {\n  border-radius: .25rem; }\n\n.callout h4 {\n  margin-top: 0;\n  margin-bottom: .25rem; }\n\n.callout p:last-child {\n  margin-bottom: 0; }\n\n.callout + .callout {\n  margin-top: -0.25rem; }\n\n.callout-default {\n  border-left-color: #818a91; }\n  .callout-default h4 {\n    color: #818a91; }\n\n.callout-primary {\n  border-left-color: #20a8d8; }\n  .callout-primary h4 {\n    color: #20a8d8; }\n\n.callout-info {\n  border-left-color: #63c2de; }\n  .callout-info h4 {\n    color: #63c2de; }\n\n.callout-warning {\n  border-left-color: #f8cb00; }\n  .callout-warning h4 {\n    color: #f8cb00; }\n\n.callout-danger {\n  border-left-color: #f86c6b; }\n  .callout-danger h4 {\n    color: #f86c6b; }\n\n.callout-success {\n  border-left-color: #4dbd74; }\n  .callout-success h4 {\n    color: #4dbd74; }\n\n.switch.switch-default {\n  position: relative;\n  display: inline-block;\n  vertical-align: top;\n  width: 40px;\n  height: 24px;\n  background-color: transparent;\n  cursor: pointer; }\n  .switch.switch-default .switch-input {\n    position: absolute;\n    top: 0;\n    left: 0;\n    opacity: 0; }\n  .switch.switch-default .switch-label {\n    position: relative;\n    display: block;\n    height: inherit;\n    font-size: 10px;\n    font-weight: 600;\n    text-transform: uppercase;\n    background-color: #fff;\n    border: 1px solid #d1d4d7;\n    border-radius: 2px;\n    -moz-transition: .15s ease-out;\n    -o-transition: .15s ease-out;\n    -webkit-transition: .15s ease-out;\n    transition: .15s ease-out;\n    -moz-transition-property: opacity background;\n    -o-transition-property: opacity background;\n    -webkit-transition-property: opacity background;\n    transition-property: opacity background; }\n  .switch.switch-default .switch-input:checked ~ .switch-label::before {\n    opacity: 0; }\n  .switch.switch-default .switch-input:checked ~ .switch-label::after {\n    opacity: 1; }\n  .switch.switch-default .switch-handle {\n    position: absolute;\n    top: 2px;\n    left: 2px;\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    border: 1px solid #d1d4d7;\n    border-radius: 1px;\n    -moz-transition: left .15s ease-out;\n    -o-transition: left .15s ease-out;\n    -webkit-transition: left .15s ease-out;\n    transition: left .15s ease-out; }\n  .switch.switch-default .switch-input:checked ~ .switch-handle {\n    left: 18px; }\n  .switch.switch-default.switch-lg {\n    width: 48px;\n    height: 28px; }\n    .switch.switch-default.switch-lg .switch-label {\n      font-size: 12px; }\n    .switch.switch-default.switch-lg .switch-handle {\n      width: 24px;\n      height: 24px; }\n    .switch.switch-default.switch-lg .switch-input:checked ~ .switch-handle {\n      left: 22px; }\n  .switch.switch-default.switch-sm {\n    width: 32px;\n    height: 20px; }\n    .switch.switch-default.switch-sm .switch-label {\n      font-size: 8px; }\n    .switch.switch-default.switch-sm .switch-handle {\n      width: 16px;\n      height: 16px; }\n    .switch.switch-default.switch-sm .switch-input:checked ~ .switch-handle {\n      left: 14px; }\n  .switch.switch-default.switch-xs {\n    width: 24px;\n    height: 16px; }\n    .switch.switch-default.switch-xs .switch-label {\n      font-size: 7px; }\n    .switch.switch-default.switch-xs .switch-handle {\n      width: 12px;\n      height: 12px; }\n    .switch.switch-default.switch-xs .switch-input:checked ~ .switch-handle {\n      left: 10px; }\n\n.switch.switch-text {\n  position: relative;\n  display: inline-block;\n  vertical-align: top;\n  width: 48px;\n  height: 24px;\n  background-color: transparent;\n  cursor: pointer; }\n  .switch.switch-text .switch-input {\n    position: absolute;\n    top: 0;\n    left: 0;\n    opacity: 0; }\n  .switch.switch-text .switch-label {\n    position: relative;\n    display: block;\n    height: inherit;\n    font-size: 10px;\n    font-weight: 600;\n    text-transform: uppercase;\n    background-color: #fff;\n    border: 1px solid #d1d4d7;\n    border-radius: 2px;\n    -moz-transition: .15s ease-out;\n    -o-transition: .15s ease-out;\n    -webkit-transition: .15s ease-out;\n    transition: .15s ease-out;\n    -moz-transition-property: opacity background;\n    -o-transition-property: opacity background;\n    -webkit-transition-property: opacity background;\n    transition-property: opacity background; }\n  .switch.switch-text .switch-label::before,\n  .switch.switch-text .switch-label::after {\n    position: absolute;\n    top: 50%;\n    width: 50%;\n    margin-top: -.5em;\n    line-height: 1;\n    text-align: center;\n    -moz-transition: inherit;\n    -o-transition: inherit;\n    -webkit-transition: inherit;\n    transition: inherit; }\n  .switch.switch-text .switch-label::before {\n    right: 1px;\n    color: #d1d4d7;\n    content: attr(data-off); }\n  .switch.switch-text .switch-label::after {\n    left: 1px;\n    color: #fff;\n    content: attr(data-on);\n    opacity: 0; }\n  .switch.switch-text .switch-input:checked ~ .switch-label::before {\n    opacity: 0; }\n  .switch.switch-text .switch-input:checked ~ .switch-label::after {\n    opacity: 1; }\n  .switch.switch-text .switch-handle {\n    position: absolute;\n    top: 2px;\n    left: 2px;\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    border: 1px solid #d1d4d7;\n    border-radius: 1px;\n    -moz-transition: left .15s ease-out;\n    -o-transition: left .15s ease-out;\n    -webkit-transition: left .15s ease-out;\n    transition: left .15s ease-out; }\n  .switch.switch-text .switch-input:checked ~ .switch-handle {\n    left: 26px; }\n  .switch.switch-text.switch-lg {\n    width: 56px;\n    height: 28px; }\n    .switch.switch-text.switch-lg .switch-label {\n      font-size: 12px; }\n    .switch.switch-text.switch-lg .switch-handle {\n      width: 24px;\n      height: 24px; }\n    .switch.switch-text.switch-lg .switch-input:checked ~ .switch-handle {\n      left: 30px; }\n  .switch.switch-text.switch-sm {\n    width: 40px;\n    height: 20px; }\n    .switch.switch-text.switch-sm .switch-label {\n      font-size: 8px; }\n    .switch.switch-text.switch-sm .switch-handle {\n      width: 16px;\n      height: 16px; }\n    .switch.switch-text.switch-sm .switch-input:checked ~ .switch-handle {\n      left: 22px; }\n  .switch.switch-text.switch-xs {\n    width: 32px;\n    height: 16px; }\n    .switch.switch-text.switch-xs .switch-label {\n      font-size: 7px; }\n    .switch.switch-text.switch-xs .switch-handle {\n      width: 12px;\n      height: 12px; }\n    .switch.switch-text.switch-xs .switch-input:checked ~ .switch-handle {\n      left: 18px; }\n\n.switch.switch-icon {\n  position: relative;\n  display: inline-block;\n  vertical-align: top;\n  width: 48px;\n  height: 24px;\n  background-color: transparent;\n  cursor: pointer; }\n  .switch.switch-icon .switch-input {\n    position: absolute;\n    top: 0;\n    left: 0;\n    opacity: 0; }\n  .switch.switch-icon .switch-label {\n    position: relative;\n    display: block;\n    height: inherit;\n    font-family: FontAwesome;\n    font-size: 10px;\n    font-weight: 600;\n    text-transform: uppercase;\n    background-color: #fff;\n    border: 1px solid #d1d4d7;\n    border-radius: 2px;\n    -moz-transition: .15s ease-out;\n    -o-transition: .15s ease-out;\n    -webkit-transition: .15s ease-out;\n    transition: .15s ease-out;\n    -moz-transition-property: opacity background;\n    -o-transition-property: opacity background;\n    -webkit-transition-property: opacity background;\n    transition-property: opacity background; }\n  .switch.switch-icon .switch-label::before,\n  .switch.switch-icon .switch-label::after {\n    position: absolute;\n    top: 50%;\n    width: 50%;\n    margin-top: -.5em;\n    line-height: 1;\n    text-align: center;\n    -moz-transition: inherit;\n    -o-transition: inherit;\n    -webkit-transition: inherit;\n    transition: inherit; }\n  .switch.switch-icon .switch-label::before {\n    right: 1px;\n    color: #d1d4d7;\n    content: attr(data-off); }\n  .switch.switch-icon .switch-label::after {\n    left: 1px;\n    color: #fff;\n    content: attr(data-on);\n    opacity: 0; }\n  .switch.switch-icon .switch-input:checked ~ .switch-label::before {\n    opacity: 0; }\n  .switch.switch-icon .switch-input:checked ~ .switch-label::after {\n    opacity: 1; }\n  .switch.switch-icon .switch-handle {\n    position: absolute;\n    top: 2px;\n    left: 2px;\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    border: 1px solid #d1d4d7;\n    border-radius: 1px;\n    -moz-transition: left .15s ease-out;\n    -o-transition: left .15s ease-out;\n    -webkit-transition: left .15s ease-out;\n    transition: left .15s ease-out; }\n  .switch.switch-icon .switch-input:checked ~ .switch-handle {\n    left: 26px; }\n  .switch.switch-icon.switch-lg {\n    width: 56px;\n    height: 28px; }\n    .switch.switch-icon.switch-lg .switch-label {\n      font-size: 12px; }\n    .switch.switch-icon.switch-lg .switch-handle {\n      width: 24px;\n      height: 24px; }\n    .switch.switch-icon.switch-lg .switch-input:checked ~ .switch-handle {\n      left: 30px; }\n  .switch.switch-icon.switch-sm {\n    width: 40px;\n    height: 20px; }\n    .switch.switch-icon.switch-sm .switch-label {\n      font-size: 8px; }\n    .switch.switch-icon.switch-sm .switch-handle {\n      width: 16px;\n      height: 16px; }\n    .switch.switch-icon.switch-sm .switch-input:checked ~ .switch-handle {\n      left: 22px; }\n  .switch.switch-icon.switch-xs {\n    width: 32px;\n    height: 16px; }\n    .switch.switch-icon.switch-xs .switch-label {\n      font-size: 7px; }\n    .switch.switch-icon.switch-xs .switch-handle {\n      width: 12px;\n      height: 12px; }\n    .switch.switch-icon.switch-xs .switch-input:checked ~ .switch-handle {\n      left: 18px; }\n\n.switch.switch-3d {\n  position: relative;\n  display: inline-block;\n  vertical-align: top;\n  width: 40px;\n  height: 24px;\n  background-color: transparent;\n  cursor: pointer; }\n  .switch.switch-3d .switch-input {\n    position: absolute;\n    top: 0;\n    left: 0;\n    opacity: 0; }\n  .switch.switch-3d .switch-label {\n    position: relative;\n    display: block;\n    height: inherit;\n    font-size: 10px;\n    font-weight: 600;\n    text-transform: uppercase;\n    background-color: #f8f9fa;\n    border: 1px solid #d1d4d7;\n    border-radius: 2px;\n    -moz-transition: .15s ease-out;\n    -o-transition: .15s ease-out;\n    -webkit-transition: .15s ease-out;\n    transition: .15s ease-out;\n    -moz-transition-property: opacity background;\n    -o-transition-property: opacity background;\n    -webkit-transition-property: opacity background;\n    transition-property: opacity background; }\n  .switch.switch-3d .switch-input:checked ~ .switch-label::before {\n    opacity: 0; }\n  .switch.switch-3d .switch-input:checked ~ .switch-label::after {\n    opacity: 1; }\n  .switch.switch-3d .switch-handle {\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 24px;\n    height: 24px;\n    background: #fff;\n    border: 1px solid #d1d4d7;\n    border-radius: 1px;\n    -moz-transition: left .15s ease-out;\n    -o-transition: left .15s ease-out;\n    -webkit-transition: left .15s ease-out;\n    transition: left .15s ease-out;\n    border: 0;\n    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); }\n  .switch.switch-3d .switch-input:checked ~ .switch-handle {\n    left: 16px; }\n  .switch.switch-3d.switch-lg {\n    width: 48px;\n    height: 28px; }\n    .switch.switch-3d.switch-lg .switch-label {\n      font-size: 12px; }\n    .switch.switch-3d.switch-lg .switch-handle {\n      width: 28px;\n      height: 28px; }\n    .switch.switch-3d.switch-lg .switch-input:checked ~ .switch-handle {\n      left: 20px; }\n  .switch.switch-3d.switch-sm {\n    width: 32px;\n    height: 20px; }\n    .switch.switch-3d.switch-sm .switch-label {\n      font-size: 8px; }\n    .switch.switch-3d.switch-sm .switch-handle {\n      width: 20px;\n      height: 20px; }\n    .switch.switch-3d.switch-sm .switch-input:checked ~ .switch-handle {\n      left: 12px; }\n  .switch.switch-3d.switch-xs {\n    width: 24px;\n    height: 16px; }\n    .switch.switch-3d.switch-xs .switch-label {\n      font-size: 7px; }\n    .switch.switch-3d.switch-xs .switch-handle {\n      width: 16px;\n      height: 16px; }\n    .switch.switch-3d.switch-xs .switch-input:checked ~ .switch-handle {\n      left: 8px; }\n\n.switch-pill .switch-label, .switch.switch-3d .switch-label,\n.switch-pill .switch-handle, .switch.switch-3d .switch-handle {\n  border-radius: 50em !important; }\n\n.switch-pill .switch-label::before, .switch.switch-3d .switch-label::before {\n  right: 2px !important; }\n\n.switch-pill .switch-label::after, .switch.switch-3d .switch-label::after {\n  left: 2px !important; }\n\n.switch-primary > .switch-input:checked ~ .switch-label {\n  background: #20a8d8 !important;\n  border-color: #1985ac; }\n\n.switch-primary > .switch-input:checked ~ .switch-handle {\n  border-color: #1985ac; }\n\n.switch-primary-outline > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #20a8d8; }\n  .switch-primary-outline > .switch-input:checked ~ .switch-label::after {\n    color: #20a8d8; }\n\n.switch-primary-outline > .switch-input:checked ~ .switch-handle {\n  border-color: #20a8d8; }\n\n.switch-primary-outline-alt > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #20a8d8; }\n  .switch-primary-outline-alt > .switch-input:checked ~ .switch-label::after {\n    color: #20a8d8; }\n\n.switch-primary-outline-alt > .switch-input:checked ~ .switch-handle {\n  background: #20a8d8 !important;\n  border-color: #20a8d8; }\n\n.switch-secondary > .switch-input:checked ~ .switch-label {\n  background: #d1d4d7 !important;\n  border-color: #b6bbbf; }\n\n.switch-secondary > .switch-input:checked ~ .switch-handle {\n  border-color: #b6bbbf; }\n\n.switch-secondary-outline > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #d1d4d7; }\n  .switch-secondary-outline > .switch-input:checked ~ .switch-label::after {\n    color: #d1d4d7; }\n\n.switch-secondary-outline > .switch-input:checked ~ .switch-handle {\n  border-color: #d1d4d7; }\n\n.switch-secondary-outline-alt > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #d1d4d7; }\n  .switch-secondary-outline-alt > .switch-input:checked ~ .switch-label::after {\n    color: #d1d4d7; }\n\n.switch-secondary-outline-alt > .switch-input:checked ~ .switch-handle {\n  background: #d1d4d7 !important;\n  border-color: #d1d4d7; }\n\n.switch-success > .switch-input:checked ~ .switch-label {\n  background: #4dbd74 !important;\n  border-color: #3a9d5d; }\n\n.switch-success > .switch-input:checked ~ .switch-handle {\n  border-color: #3a9d5d; }\n\n.switch-success-outline > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #4dbd74; }\n  .switch-success-outline > .switch-input:checked ~ .switch-label::after {\n    color: #4dbd74; }\n\n.switch-success-outline > .switch-input:checked ~ .switch-handle {\n  border-color: #4dbd74; }\n\n.switch-success-outline-alt > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #4dbd74; }\n  .switch-success-outline-alt > .switch-input:checked ~ .switch-label::after {\n    color: #4dbd74; }\n\n.switch-success-outline-alt > .switch-input:checked ~ .switch-handle {\n  background: #4dbd74 !important;\n  border-color: #4dbd74; }\n\n.switch-info > .switch-input:checked ~ .switch-label {\n  background: #63c2de !important;\n  border-color: #39b2d5; }\n\n.switch-info > .switch-input:checked ~ .switch-handle {\n  border-color: #39b2d5; }\n\n.switch-info-outline > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #63c2de; }\n  .switch-info-outline > .switch-input:checked ~ .switch-label::after {\n    color: #63c2de; }\n\n.switch-info-outline > .switch-input:checked ~ .switch-handle {\n  border-color: #63c2de; }\n\n.switch-info-outline-alt > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #63c2de; }\n  .switch-info-outline-alt > .switch-input:checked ~ .switch-label::after {\n    color: #63c2de; }\n\n.switch-info-outline-alt > .switch-input:checked ~ .switch-handle {\n  background: #63c2de !important;\n  border-color: #63c2de; }\n\n.switch-warning > .switch-input:checked ~ .switch-label {\n  background: #f8cb00 !important;\n  border-color: #c5a100; }\n\n.switch-warning > .switch-input:checked ~ .switch-handle {\n  border-color: #c5a100; }\n\n.switch-warning-outline > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #f8cb00; }\n  .switch-warning-outline > .switch-input:checked ~ .switch-label::after {\n    color: #f8cb00; }\n\n.switch-warning-outline > .switch-input:checked ~ .switch-handle {\n  border-color: #f8cb00; }\n\n.switch-warning-outline-alt > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #f8cb00; }\n  .switch-warning-outline-alt > .switch-input:checked ~ .switch-label::after {\n    color: #f8cb00; }\n\n.switch-warning-outline-alt > .switch-input:checked ~ .switch-handle {\n  background: #f8cb00 !important;\n  border-color: #f8cb00; }\n\n.switch-danger > .switch-input:checked ~ .switch-label {\n  background: #f86c6b !important;\n  border-color: #f63c3a; }\n\n.switch-danger > .switch-input:checked ~ .switch-handle {\n  border-color: #f63c3a; }\n\n.switch-danger-outline > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #f86c6b; }\n  .switch-danger-outline > .switch-input:checked ~ .switch-label::after {\n    color: #f86c6b; }\n\n.switch-danger-outline > .switch-input:checked ~ .switch-handle {\n  border-color: #f86c6b; }\n\n.switch-danger-outline-alt > .switch-input:checked ~ .switch-label {\n  background: #fff !important;\n  border-color: #f86c6b; }\n  .switch-danger-outline-alt > .switch-input:checked ~ .switch-label::after {\n    color: #f86c6b; }\n\n.switch-danger-outline-alt > .switch-input:checked ~ .switch-handle {\n  background: #f86c6b !important;\n  border-color: #f86c6b; }\n\n.chart-wrapper canvas {\n  width: 100% !important; }\n\nbase-chart.chart {\n  display: block !important; }\n\n.b-a-0 {\n  border: 0 !important; }\n\n.b-t-0 {\n  border-top: 0 !important; }\n\n.b-r-0 {\n  border-right: 0 !important; }\n\n.b-b-0 {\n  border-bottom: 0 !important; }\n\n.b-l-0 {\n  border-left: 0 !important; }\n\n.b-a-1 {\n  border: 1px solid #d1d4d7 !important; }\n\n.b-t-1 {\n  border-top: 1px solid #d1d4d7 !important; }\n\n.b-r-1 {\n  border-right: 1px solid #d1d4d7 !important; }\n\n.b-b-1 {\n  border-bottom: 1px solid #d1d4d7 !important; }\n\n.b-l-1 {\n  border-left: 1px solid #d1d4d7 !important; }\n\n.b-a-2 {\n  border: 2px solid #d1d4d7 !important; }\n\n.b-t-2 {\n  border-top: 2px solid #d1d4d7 !important; }\n\n.b-r-2 {\n  border-right: 2px solid #d1d4d7 !important; }\n\n.b-b-2 {\n  border-bottom: 2px solid #d1d4d7 !important; }\n\n.b-l-2 {\n  border-left: 2px solid #d1d4d7 !important; }\n\n.label-pill {\n  border-radius: 1rem !important; }\n\n.page-header {\n  padding: 1rem 0;\n  background: #fff;\n  border-bottom: 1px solid #d1d4d7; }\n  .page-header h1 {\n    margin: 0; }\n  .page-header .chart-wrapper {\n    max-width: 140px;\n    margin: 0 auto;\n    overflow: visible; }\n  .page-header .charts .title {\n    margin-top: 2px; }\n\nbody:not(.top-nav) .sidebar .sidebar-header {\n  height: 200px;\n  padding-bottom: 10px;\n  text-align: center;\n  background: rgba(0, 0, 0, 0.2); }\n  body:not(.top-nav) .sidebar .sidebar-header .img-avatar {\n    width: 80px;\n    margin: 20px auto 10px;\n    border-radius: 50em; }\n  body:not(.top-nav) .sidebar .sidebar-header .text-muted {\n    margin-top: -5px; }\n  body:not(.top-nav) .sidebar .sidebar-header > .btn-group, body:not(.top-nav) .sidebar .sidebar-header > .fc-button-group {\n    margin-top: 10px; }\n  body:not(.top-nav) .sidebar .sidebar-header .btn-link {\n    color: #818a91; }\n    body:not(.top-nav) .sidebar .sidebar-header .btn-link:hover {\n      color: #fff;\n      text-decoration: none; }\n\nbody:not(.top-nav) .sidebar .sidebar-header + .sidebar-nav {\n  height: calc(100vh - 55px - 200px) !important; }\n\n@media (min-width: 576px) {\n  body.sidebar-nav.compact-nav .sidebar .sidebar-header {\n    padding: 0; }\n    body.sidebar-nav.compact-nav .sidebar .sidebar-header .img-avatar {\n      width: 40px;\n      margin: 5px auto; }\n    body.sidebar-nav.compact-nav .sidebar .sidebar-header div {\n      display: none; } }\n\n.email-app {\n  display: flex;\n  flex: 1;\n  flex-direction: row;\n  overflow-x: hidden; }\n  .email-app nav {\n    flex: 0 0 200px;\n    order: -1;\n    padding: 15px;\n    border-right: 1px solid #d1d4d7; }\n    .email-app nav .btn-block {\n      margin-bottom: 15px; }\n    .email-app nav ul.nav {\n      flex-direction: column; }\n      .email-app nav ul.nav li.nav-item {\n        margin: 0;\n        position: relative; }\n        .email-app nav ul.nav li.nav-item a.nav-link {\n          font-size: 12px;\n          font-weight: 400;\n          text-transform: uppercase;\n          text-decoration: none;\n          display: block;\n          padding: 0 10px; }\n          .email-app nav ul.nav li.nav-item a.nav-link i {\n            width: 20px;\n            text-align: center;\n            margin: 0 10px 0 0;\n            font-size: 14px; }\n          .email-app nav ul.nav li.nav-item a.nav-link .tag {\n            float: right;\n            margin-top: 16px;\n            margin-left: 10px; }\n        .email-app nav ul.nav li.nav-item a.nav-link {\n          line-height: 40px;\n          color: #2a2c36;\n          border-bottom: 1px solid #d1d4d7; }\n  .email-app main {\n    flex: 1;\n    padding: 15px; }\n    .email-app main .toolbar {\n      margin: -15px -15px 15px -15px;\n      padding: 15px;\n      border-bottom: 1px solid #d1d4d7; }\n    .email-app main ul.messages-list {\n      list-style: none;\n      margin: 15px -15px 0 -15px;\n      padding: 15px 15px 0 15px; }\n      .email-app main ul.messages-list li {\n        cursor: pointer;\n        margin-bottom: 10px;\n        padding: 10px; }\n        .email-app main ul.messages-list li a {\n          color: black; }\n          .email-app main ul.messages-list li a:hover {\n            text-decoration: none; }\n        .email-app main ul.messages-list li.unread .header, .email-app main ul.messages-list li.unread .title {\n          font-weight: bold; }\n        .email-app main ul.messages-list li:hover {\n          border: 1px solid #d1d4d7;\n          padding: 9px; }\n          .email-app main ul.messages-list li:hover .action {\n            color: #d1d4d7; }\n        .email-app main ul.messages-list li .header {\n          margin: 0 0 5px 0; }\n          .email-app main ul.messages-list li .header .from {\n            width: 49.9%;\n            white-space: nowrap;\n            overflow: hidden !important;\n            text-overflow: ellipsis; }\n          .email-app main ul.messages-list li .header .date {\n            width: 50%;\n            text-align: right;\n            float: right; }\n        .email-app main ul.messages-list li .title {\n          margin: 0 0 5px 0;\n          white-space: nowrap;\n          overflow: hidden !important;\n          text-overflow: ellipsis; }\n        .email-app main ul.messages-list li .description {\n          font-size: 12px;\n          padding-left: 29px; }\n        .email-app main ul.messages-list li .action {\n          display: inline-block;\n          width: 16px;\n          text-align: center;\n          margin-right: 10px;\n          color: #d1d4d7; }\n          .email-app main ul.messages-list li .action .fa-check-square-o {\n            margin: 0 -1px 0 1px; }\n          .email-app main ul.messages-list li .action .fa-square {\n            float: left;\n            margin-top: -16px;\n            margin-left: 4px;\n            font-size: 11px;\n            color: white; }\n          .email-app main ul.messages-list li .action .fa-star.bg {\n            float: left;\n            margin-top: -16px;\n            margin-left: 3px;\n            font-size: 12px;\n            color: white; }\n    .email-app main .message .message-title {\n      margin-top: 30px;\n      padding-top: 10px;\n      font-weight: bold;\n      font-size: 14px; }\n    .email-app main .message .header {\n      margin: 20px 0 30px 0;\n      padding: 10px 0 10px 0;\n      border-top: 1px solid #d1d4d7;\n      border-bottom: 1px solid #d1d4d7; }\n      .email-app main .message .header .avatar {\n        height: 34px;\n        width: 34px;\n        float: left;\n        margin-right: 10px; }\n      .email-app main .message .header i {\n        margin-top: 1px; }\n      .email-app main .message .header .from {\n        display: inline-block;\n        width: 50%;\n        font-size: 12px;\n        margin-top: -2px;\n        color: #d1d4d7; }\n        .email-app main .message .header .from span {\n          display: block;\n          font-size: 14px;\n          font-weight: bold; }\n      .email-app main .message .header .date {\n        display: inline-block;\n        width: 29%;\n        text-align: right;\n        float: right;\n        font-size: 12px;\n        margin-top: 18px; }\n    .email-app main .message .attachments {\n      border-top: 3px solid #f8f9fa;\n      border-bottom: 3px solid #f8f9fa;\n      padding: 10px 0px;\n      margin-bottom: 20px;\n      font-size: 12px; }\n      .email-app main .message .attachments ul {\n        list-style: none;\n        margin: 0 0 0 -40px; }\n        .email-app main .message .attachments ul li {\n          margin: 10px 0; }\n          .email-app main .message .attachments ul li .tag {\n            padding: 2px 4px; }\n          .email-app main .message .attachments ul li span.quickMenu {\n            float: right;\n            text-align: right; }\n            .email-app main .message .attachments ul li span.quickMenu .fa {\n              padding: 5px 0 5px 25px;\n              font-size: 14px;\n              margin: -2px 0px 0px 5px;\n              color: #d1d4d7; }\n\nheader.navbar .navbar-brand {\n  background-size: 180px auto; }\n\n.backoffice-flex {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n  -ms-flex-direction: column;\n  flex-direction: column;\n  min-height: 100vh; }\n\n[routerLink] {\n  cursor: pointer; }\n\nselect {\n  background-image: url(\"/backoffice/img/select.png\") !important; }\n\nbody:not(.top-nav) .sidebar .sidebar-header {\n  height: 160px; }\n\nbody:not(.top-nav) .sidebar .sidebar-header + .sidebar-nav {\n  height: calc(100vh - 55px - 160px) !important; }\n";

var __decorate$12 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$12 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var BackofficeComponent = (function () {
    // public backofficeVersion: string = versions.smallstack;
    function BackofficeComponent(ngZone, router) {
        this.ngZone = ngZone;
        this.router = router;
        this.navigationEntries = [];
        this.isLoading = true;
        this.configurationService = _smallstack_coreCommon.IOC.get("configurationService");
        this.userService = _smallstack_coreCommon.IOC.get("userService");
        this.navigationService = _smallstack_coreCommon.IOC.get("navigationService");
        this.rolesService = _smallstack_coreCommon.IOC.get("rolesService");
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
        this.projectName = this.configurationService.get("backoffice.application.projectname", "");
        this.applicationName = this.configurationService.get("backoffice.application.name", "Backoffice");
    }
    BackofficeComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("body").addClass("header-fixed sidebar-fixed");
        var myUserQuery = this.userService.getMyUser();
        myUserQuery.subscribe(function (cursor) {
            _this.ngZone.run(function () {
                _this.currentUser = myUserQuery.getModels()[0];
                _this.navigationService.onNavigationEntryAdd(_this.loadNavigationEntries, _this);
                _this.isLoading = false;
            });
        });
    };
    BackofficeComponent.prototype.ngOnDestroy = function () {
        $("body").removeClass("header-fixed sidebar-fixed");
    };
    BackofficeComponent.prototype.loadNavigationEntries = function () {
        var _this = this;
        var entries = [];
        this.navigationEntries = _.filter(this.navigationService.getNavigationEntries(), function (entry) {
            if (entry.getType() !== "backoffice")
                return false;
            if (entry.isVisible() === false)
                return false;
            if (entry.getRequiredRole() !== undefined && !_this.rolesService.userHasRole(_this.currentUser, entry.getRequiredRole()))
                return false;
            // if (entry.isAbstract())
            //     return true;
            if (entry.getChildOfRoute() !== "manage")
                return false;
            if (entry.getRoute() === "/login" && _this.dataBridge.getCurrentUserId() !== null)
                return false;
            if (entry.getRoute() === "/register" && _this.dataBridge.getCurrentUserId() !== null)
                return false;
            if (entry.doesRequireAuthentication() && _this.dataBridge.getCurrentUserId() === null)
                return false;
            return true;
        });
        this.navigationEntries.sort(function (a, b) {
            return a.getIndex() - b.getIndex();
        });
    };
    BackofficeComponent.prototype.isNavigationEntryActive = function (entry) {
        // if (entry.isAbstract()) {
        //     var subEntries: NavigationEntry[] = this.getSubEntries(entry.getStateName());
        //     for (var i = 0; i < subEntries.length; i++) {
        //         if (this.isNavigationEntryActive(subEntries[i]))
        //             return true;
        //     }
        //     return false;
        // }
        // else
        //     return this.$state.current.url === entry.getRoute();
    };
    BackofficeComponent.prototype.getSubEntries = function (entry) {
        var subEntries = [];
        _.each(this.navigationService.getNavigationEntries(), function (navEntry) {
            if (navEntry.getChildOfRoute() === entry.route)
                subEntries.push(navEntry);
        });
        return subEntries;
    };
    BackofficeComponent.prototype.logout = function () {
        var _this = this;
        this.dataBridge.logout(function () {
            _this.router.navigate(["manage/login"]);
        });
    };
    BackofficeComponent.prototype.hasRole = function (role) {
        return _smallstack_coreCommon.RolesService.instance().userHasRole(this.currentUser, role);
    };
    return BackofficeComponent;
}());
BackofficeComponent = __decorate$12([
    _angular_core.Component({
        template: template,
        styles: [style],
        encapsulation: _angular_core.ViewEncapsulation.None
    }),
    __metadata$12("design:paramtypes", [_angular_core.NgZone, _angular_router.Router])
], BackofficeComponent);
Angular2Component.new("backoffice", BackofficeComponent)
    .setInitializeAngularComponent(false)
    .register();
_smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
    navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
        .setRequiredRole("backoffice")
        .setRoute("/manage")
        .setRequiresAuthentication(true, "/manage/login")
        .setComponent(BackofficeComponent)
        .setRedirectTo("dashboard"));
});

var template$1 = "<div class=\"container d-table\"><div class=\"d-100vh-va-middle\"><div class=\"row\"><div class=\"col-md-4 offset-md-4\"><div class=\"card-group\"><div class=\"card card-default\"><div class=\"card-block\"><h5>{{projectName}}<b>{{applicationName}}</b></h5><p class=\"text-muted\">Sign In to your account</p><Login [data]=\"{showRegistration: false, showLogin: true}\" componentId=\"backofficeLogin\"></Login></div></div></div></div></div></div></div>";

var __decorate$13 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$13 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var BackofficeLoginComponent = (function () {
    function BackofficeLoginComponent() {
        Session.set("routeBeforeLogin", "/manage");
    }
    return BackofficeLoginComponent;
}());
BackofficeLoginComponent = __decorate$13([
    _angular_core.Component({
        template: template$1,
        styles: [style],
        encapsulation: _angular_core.ViewEncapsulation.None
    }),
    __metadata$13("design:paramtypes", [])
], BackofficeLoginComponent);
Angular2Component.new("backoffice-login", BackofficeLoginComponent)
    .setInitializeAngularComponent(false)
    .register();
_smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
    navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
        .setRoute("/manage/login")
        .setRequiresAuthentication(false)
        .setComponent(BackofficeLoginComponent)
        .setType("main")
        .setIndex(1));
});

var template$2 = "<div class=\"animated fadeIn\"><div class=\"card\"><div class=\"card-header\">Backup <button class=\"btn btn-sm btn-primary float-xs-right\" (click)=\"selectNone()\">Select None</button> <button class=\"btn btn-sm btn-primary float-xs-right\" (click)=\"selectAll()\">Select All</button></div><div class=\"card-block row\"><div class=\"col-xs-12 col-md-4 col-lg-3\" *ngFor=\"let collection of allCollections\"><label class=\"switch switch-text switch-secondary\"><input [(ngModel)]=\"backupCollectionNames[collection.name]\" class=\"switch-input\" type=\"checkbox\"> <span class=\"switch-label\" data-off=\"Off\" data-on=\"On\"></span> <span class=\"switch-handle\"></span></label>{{collection.name}} ({{collection.count}})</div></div><div class=\"card-footer\"><button (click)=\"createBackup()\" class=\"btn btn-warning\">Create MongoDB Backup</button><div id=\"downloadContainer\"></div></div></div><div class=\"card\"><div class=\"card-header\">Restore</div><div class=\"card-block\"><p>Upload JSON Backup: <input type=\"file\" (change)=\"uploadFile($event)\" class=\"btn btn-default\"></p><div *ngIf=\"restoreFile && !restorePerformed\"><table class=\"table table-striped\"><thead><tr><th><input type=\"checkbox\" (click)=\"toggleRestoreCheckboxes($event)\"></th><th>Collection</th><th>Current Database</th><th>{{restoreFileName}}</th><th>Warnings</th></tr></thead><tbody><template let-collection ngFor [ngForOf]=\"allCollections\"><tr><td><input type=\"checkbox\" [(ngModel)]=\"restoreCollectionNames[collection.name]\" [disabled]=\"!restoreFile[collection.name] || restoreCurrentCollectionNames.indexOf(collection.name) === -1\"></td><td>{{collection.name}}</td><td>{{collection.count}}</td><td>{{restoreFile[collection.name]?.length}}</td><td><span class=\"tag tag-danger\" *ngIf=\"restoreCurrentCollectionNames.indexOf(collection.name) === -1\">unknown collection</span> <span class=\"tag tag-danger\" *ngIf=\"!restoreFile[collection.name]\">collection missing in backup</span> <span class=\"tag tag-success\" *ngIf=\"restoreFile[collection.name]?.length > getCollectionCountFor(collection.name)\">+{{restoreFile[collection.name].length - getCollectionCountFor(collection.name)}}</span> <span class=\"tag tag-danger\" *ngIf=\"restoreFile[collection.name]?.length < getCollectionCountFor(collection.name)\">-{{getCollectionCountFor(collection.name) - restoreFile[collection.name]?.length}}</span></td></tr></template></tbody></table><div class=\"alert alert-warning\" role=\"alert\"><strong>Warning!</strong> If you modify your own user by restoring your user record via a backup you will most likely get logged out and have to login again!</div><p></p><div align=\"right\"><div class=\"checkbox\"><label><input type=\"checkbox\" [(ngModel)]=\"dropCollections\"> Drop related collections before restore</label></div><button (click)=\"restoreBackup()\" class=\"btn btn-warning\">Restore selected collections</button></div><p></p></div><div *ngIf=\"restorePerformed\"><div class=\"alert alert-success\">Restore performed successfully!</div><div ng-repeat=\"log in restoreLogs\">{{log}}</div></div></div></div></div>";

var __extends$2 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var BackupPanelController = (function (_super) {
    __extends$2(BackupPanelController, _super);
    function BackupPanelController() {
        var _this = _super.apply(this, arguments) || this;
        _this.allCollections = [];
        _this.backupCollectionNames = {};
        _this.backupAvailable = false;
        _this.restoreCollectionNames = {};
        _this.restorePerformed = false;
        _this.dropCollections = false;
        return _this;
    }
    BackupPanelController.prototype.afterInitialization = function () {
        var _this = this;
        _.each(_.keys(this.collectionsService.getAllCollections()).sort(), function (collectionName) {
            if (collectionName !== "counts")
                _this.backupCollectionNames[collectionName] = true;
        });
        this.restoreCurrentCollectionNames = _.without(_.keys(this.collectionsService.getAllCollections()).sort(), "counts");
        this.dataBridge.callMethod("backoffice-collectionCounts", {}, function (error$$1, counts) {
            if (error$$1)
                _this.notificationService.getStandardErrorPopup(error$$1);
            else {
                _this.ngZone.run(function () {
                    _this.allCollections = counts;
                });
            }
        });
    };
    BackupPanelController.prototype.getCollectionCountFor = function (collectionName) {
        if (!this.allCollections)
            return -1;
        var count = -1;
        _.each(this.allCollections, function (collCount) {
            if (collCount.name === collectionName)
                count = collCount.count;
        });
        return count;
    };
    BackupPanelController.prototype.createBackup = function () {
        var _this = this;
        var collectionsToBackup = [];
        _.each(this.backupCollectionNames, function (val, name) { if (val)
            collectionsToBackup.push(name); });
        this.dataBridge.callMethod("backoffice-backup", collectionsToBackup, function (error$$1, result) {
            if (error$$1)
                _this.notificationService.getStandardErrorPopup(error$$1);
            else {
                _this.ngZone.run(function () {
                    var data = "text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(result, null, 2));
                    // $('#downloadContainer').html('<a class="btn btn-default" href="data:' + data + '" download="backup-' + versions.projectName + '-' + moment().format("YYYY-MM-DD-HHmmss") + '.json">download backup-' + versions.projectName + '-' + moment().format("YYYY-MM-DD-HHmmss") + '.json</a>');
                    $('#downloadContainer').html('<a class="btn btn-default" href="data:' + data + '" download="backup-' + moment().format("YYYY-MM-DD-HHmmss") + '.json">download backup-' + moment().format("YYYY-MM-DD-HHmmss") + '.json</a>');
                    _this.backupAvailable = true;
                });
            }
        });
    };
    BackupPanelController.prototype.selectAll = function () {
        var _this = this;
        _.each(this.backupCollectionNames, function (val, collection) { _this.backupCollectionNames[collection] = true; });
    };
    BackupPanelController.prototype.selectNone = function () {
        var _this = this;
        _.each(this.backupCollectionNames, function (val, collection) { _this.backupCollectionNames[collection] = false; });
    };
    BackupPanelController.prototype.toggleRestoreCheckboxes = function (event) {
        var _this = this;
        var checked = event.currentTarget.checked;
        _.each(this.restoreCollectionNames, function (val, collection) {
            if (_this.restoreFile[collection] && _this.restoreCurrentCollectionNames.indexOf(collection) !== -1)
                _this.restoreCollectionNames[collection] = checked;
        });
    };
    BackupPanelController.prototype.uploadFile = function (event) {
        var _this = this;
        var files = event.srcElement.files;
        // this.f = file;
        // this.errFile = errFiles && errFiles[0];
        if (files && files[0]) {
            var fileReader_1 = new FileReader();
            fileReader_1.onloadend = function () {
                try {
                    var json_1 = JSON.parse(fileReader_1.result);
                    _this.ngZone.run(function () {
                        _this.restoreLogs = undefined;
                        _this.restorePerformed = false;
                        _this.restoreFileName = files[0].name;
                        _this.restoreFile = json_1;
                        _this.restoreCollectionNames = {};
                        _.each(_.union(_this.restoreCurrentCollectionNames, _.keys(json_1)), function (collectionName) { _this.restoreCollectionNames[collectionName] = false; });
                    });
                }
                catch (e) {
                    _this.notificationService.getStandardErrorPopup(e);
                }
            };
            fileReader_1.readAsText(files[0], "UTF-8");
        }
    };
    BackupPanelController.prototype.restoreBackup = function () {
        var _this = this;
        var collectionsToRestore = [];
        _.each(this.restoreCollectionNames, function (val, name) { if (val)
            collectionsToRestore.push(name); });
        var restore = {};
        _.each(collectionsToRestore, function (collectioName) {
            if (!_this.restoreFile[collectioName])
                _this.notificationService.notification.error("Could not find collection " + collectioName + " in restore file, not adding to restore object!");
            else {
                restore[collectioName] = _this.restoreFile[collectioName];
            }
        });
        this.dataBridge.callMethod("backoffice-restore", { restore: restore, dropCollections: this.dropCollections }, function (error$$1, results) {
            if (error$$1)
                _this.notificationService.getStandardErrorPopup(error$$1, "Could not perform restore!");
            else {
                _this.ngZone.run(function () {
                    _this.restoreLogs = results.logs;
                    _this.restorePerformed = true;
                });
            }
        });
    };
    return BackupPanelController;
}(Angular2BaseComponentController));
Angular2Component.new("backoffice-backup-panel", BackupPanelController)
    .setTemplate(template$2)
    .register();
_smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
    navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
        .setRoute("/backup")
        .setRequiresAuthentication(true, "backoffice_login")
        .setType("backoffice")
        .setIcon("fa fa-database")
        .setI18nLabel("backoffice.navigation.backup")
        .setRequiredRole("administrator")
        .setIndex(4)
        .setComponent(BackupPanelController)
        .setChildOfRoute("manage"));
});

var template$3 = "<section class=\"content-header\"><h1>Configuration</h1><div class=\"pull-right\"><button class=\"btn btn-default\" (click)=\"loadConfiguration()\">Refresh</button></div></section><section class=\"content\"><table class=\"table table-striped\"><thead><tr><th>Key</th><th>Value</th><th>Scope</th></tr></thead><tbody><tr *ngFor=\"let configuration of configurations\"><td>{{configuration.key}}</td><td><input type=\"text\" [(ngModel)]=\"configuration.value\" class=\"form-control\"></td><td><input type=\"text\" [(ngModel)]=\"configuration.scope\" class=\"form-control\"></td><td><button class=\"btn btn-success\" (click)=\"saveConfiguration(configuration.key, configuration.value, configuration.scope)\">Save</button></td></tr><tr><td><input type=\"text\" [(ngModel)]=\"newConfiguration.key\" class=\"form-control\"></td><td><input type=\"text\" [(ngModel)]=\"newConfiguration.value\" class=\"form-control\"></td><td><input type=\"text\" [(ngModel)]=\"newConfiguration.scope\" class=\"form-control\"></td><td><button class=\"btn btn-success\" (click)=\"saveConfiguration(newConfiguration.key, newConfiguration.value, newConfiguration.scope)\">Save New</button></td></tr></tbody></table></section>";

var __extends$3 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate$14 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$14 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ConfigurationBackoffice = (function (_super) {
    __extends$3(ConfigurationBackoffice, _super);
    function ConfigurationBackoffice() {
        var _this = _super.call(this) || this;
        _this.newConfiguration = new _smallstack_coreCommon.Configuration();
        _this.loadConfiguration();
        return _this;
    }
    ConfigurationBackoffice.prototype.loadConfiguration = function () {
        var _this = this;
        this.dataBridge.callMethod("configurations-getCompleteConfiguration", {}, function (error$$1, result) {
            if (error$$1)
                _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error$$1, "Could not recieve complete configuration!");
            _this.ngZone.run(function () {
                _this.configurations = result;
            });
        });
    };
    ConfigurationBackoffice.prototype.saveConfiguration = function (key, value, scope) {
        var _this = this;
        if (key !== undefined && value !== undefined && scope !== undefined) {
            this.dataBridge.callMethod("configurations-updateConfiguration", { key: key, value: value, scope: scope }, function (error$$1, saved) {
                if (error$$1)
                    _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error$$1);
                else {
                    _smallstack_coreCommon.NotificationService.instance().notification.success("Configuration '" + key + "' saved!");
                    _this.loadConfiguration();
                    _this.newConfiguration = new _smallstack_coreCommon.Configuration();
                }
            });
        }
    };
    return ConfigurationBackoffice;
}(Angular2BaseComponentController));
__decorate$14([
    _smallstack_coreCommon.Autowired(),
    __metadata$14("design:type", _smallstack_coreCommon.ConfigurationService)
], ConfigurationBackoffice.prototype, "configurationService", void 0);
Angular2Component.new("ConfigurationBackoffice", ConfigurationBackoffice)
    .setTemplate(template$3)
    .register();
_smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
    navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
        .setRoute("/configuration")
        .setRequiresAuthentication(true, "backoffice_login")
        .setType("backoffice")
        .setIcon("fa fa-gear")
        .setI18nLabel("backoffice.navigation.configuration")
        .setRequiredRole("administrator")
        .setIndex(8)
        .setComponent(ConfigurationBackoffice)
        .setChildOfRoute("manage"));
});

var template$4 = "<section class=\"content\"><div class=\"row\"><div class=\"col-xs-12\"><div class=\"box\"><div class=\"box-header\"><h3 class=\"box-title\">Analytics</h3></div><div class=\"box-body\"><div class=\"input-group\"><label>Google Analytics Tracking ID</label><input type=\"text\" class=\"form-control\" [(ngModel)]=\"gaTrackingId\"></div><button class=\"btn btn-default\" type=\"button\" (click)=\"saveTracking()\">Save</button></div></div></div></div></section>";

var __extends$4 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate$15 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$15 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AnalyticsPanelController = (function (_super) {
    __extends$4(AnalyticsPanelController, _super);
    function AnalyticsPanelController() {
        var _this = _super.call(this) || this;
        _this.gaTrackingId = _this.configurationService.get("googleanalytics.trackingid");
        return _this;
    }
    AnalyticsPanelController.prototype.saveTracking = function () {
        this.dataBridge.callMethod("backoffice-analytics-saveTracking", this.gaTrackingId, _smallstack_coreCommon.NotificationService.instance().getStandardCallback("Could not save TrackingID!", "Successfully saved TrackingID!"));
    };
    return AnalyticsPanelController;
}(Angular2BaseComponentController));
__decorate$15([
    _smallstack_coreCommon.Autowired(),
    __metadata$15("design:type", _smallstack_coreCommon.ConfigurationService)
], AnalyticsPanelController.prototype, "configurationService", void 0);
Angular2Component.new("AnalyticsPanelController", AnalyticsPanelController)
    .setTemplate(template$4)
    .register();
_smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
    navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
        .setRoute("/analytics")
        .setRequiresAuthentication(true, "backoffice_login")
        .setType("backoffice")
        .setIcon("fa fa-line-chart")
        .setLabel("Analytics")
        .setRequiredRole("administrator")
        .setIndex(4)
        .setComponent(AnalyticsPanelController)
        .setChildOfRoute("manage"));
});

var template$5 = "<div class=\"animated fadeIn\"><div class=\"row\"><div class=\"col-sm-6 col-lg-3\"><div class=\"card card-inverse card-primary\"><div class=\"card-block pb-0\"><h4 class=\"mb-0\">{{statistics.totalUsers}}</h4><p>Members total</p></div></div></div></div></div>";

var __extends$5 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var BackofficeDashboardController = (function (_super) {
    __extends$5(BackofficeDashboardController, _super);
    function BackofficeDashboardController() {
        var _this = _super.apply(this, arguments) || this;
        _this.statistics = {};
        _this.statisticsLoading = true;
        return _this;
    }
    BackofficeDashboardController.prototype.afterInitialization = function () {
        var _this = this;
        this.dataBridge.callMethod("backoffice-dashboard-statistics", {}, function (error$$1, statistics) {
            if (error$$1)
                console.error(error$$1);
            else {
                _this.ngZone.run(function () {
                    _this.statistics = statistics;
                    _this.statisticsLoading = false;
                });
            }
        });
    };
    BackofficeDashboardController.prototype.doPing = function () {
        // TimeSync.resync();
        //     $scope.ping = TimeSync.roundTripTime();
        // }
        // $scope.doPing();
    };
    return BackofficeDashboardController;
}(Angular2BaseComponentController));
Angular2Component.new("DashboardBackoffice", BackofficeDashboardController)
    .setTemplate(template$5)
    .register();
_smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
    navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
        .setRoute("/dashboard")
        .setRequiresAuthentication(true, "backoffice_login")
        .setType("backoffice")
        .setI18nLabel("backoffice.navigation.dashboard")
        .setIcon("fa fa-home")
        .setRequiredRole("backoffice")
        .setIndex(1)
        .setComponent(BackofficeDashboardController)
        .setChildOfRoute("manage"));
});

var template$6 = "<div class=\"animated fadeIn\"><div class=\"card\"><div class=\"card-header\">Dynamic Backoffice Modules</div><div class=\"card-block\"><small>A dynamic view in the backoffice is nothing more than a navigation entry with type 'backoffice' and a linked CMS page. So a dynamic backoffice module can either be created via the navigation backoffice or with this tiny assistant:</small><div class=\"row\"><div class=\"form-group col-xs-12 col-md-6\"><label>Menu Entry Label</label><input type=\"text\" class=\"form-control\" [(ngModel)]=\"dynModule.menuLabel\"></div><div class=\"form-group col-xs-12 col-md-6\"><label>Module Link</label><input type=\"text\" class=\"form-control\" [(ngModel)]=\"dynModule.route\"></div><div class=\"form-group col-xs-12 col-md-6\"><label>CMS Page</label><select [(ngModel)]=\"dynModule.pageId\" class=\"form-control\"><option *ngFor=\"let page of pages\" [ngValue]=\"page.id\">{{page.name}}</option></select></div><div class=\"form-group col-xs-12 col-md-6\"><label>Required Role</label><select [(ngModel)]=\"dynModule.role\" class=\"form-control\"><option value=\"\"></option><option *ngFor=\"let role of roles\" [ngValue]=\"role.name\">{{role.name}}</option></select></div><div class=\"col-xs-12\" align=\"right\"><button (click)=\"createDynamicModule()\" class=\"btn btn-success\">Create Dynamic Module</button></div></div></div></div></div>";

var __extends$6 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var DynamicModulePanelController = (function (_super) {
    __extends$6(DynamicModulePanelController, _super);
    function DynamicModulePanelController() {
        var _this = _super.apply(this, arguments) || this;
        _this.pages = [];
        _this.roles = [];
        return _this;
    }
    DynamicModulePanelController.prototype.afterInitialization = function () {
        var _this = this;
        this.dynModule = {
            role: "administrator",
            route: "/manage/newmodule"
        };
        _smallstack_coreClient.PagesService.instance().getAllPages().subscribe(function (error$$1, queryObject) {
            _this.ngZone.run(function () {
                _this.pages = queryObject.getModels();
            });
        });
        this.roles = _smallstack_coreCommon.RolesService.instance().getAllRoles().getModels();
    };
    DynamicModulePanelController.prototype.createDynamicModule = function () {
        this.dataBridge.callMethod("backoffice-add-dynamic-module", this.dynModule, _smallstack_coreCommon.NotificationService.instance().getStandardCallback("Could not create dynamic module!", "Successfully created dynamic module!"));
    };
    return DynamicModulePanelController;
}(Angular2BaseComponentController));
Angular2Component.new("dynamicModulePanel", DynamicModulePanelController)
    .setTemplate(template$6)
    .register();
_smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
    navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
        .setRoute("/dynamicbackofficemodule")
        .setRequiresAuthentication(true, "backoffice_login")
        .setType("backoffice")
        .setIcon("fa fa-plus")
        .setI18nLabel("backoffice.navigation.addView")
        .setRequiredRole("administrator")
        .setIndex(50000)
        .setComponent(DynamicModulePanelController)
        .setChildOfRoute("manage"));
});

var template$7 = "<div class=\"animated fadeIn\"><div class=\"card\"><div class=\"card-header\">Execute Backoffice Jobs</div><div class=\"card-block\"><table class=\"table table-striped\"><thead><tr><th>Name</th><th>Description</th><th>Action</th></tr></thead><tbody><tr *ngFor=\"let job of jobs\"><td>{{job.name}}</td><td>{{job.description}}</td><td><button class=\"btn btn-danger\" (click)=\"executeJob(job.name)\" *ngIf=\"!isBeingExecuted(job)\">Execute</button><Loading *ngIf=\"isBeingExecuted(job)\"></Loading></td></tr></tbody></table></div></div><div class=\"card\"><div class=\"card-header\">Job Console</div><div class=\"card-block\"><div align=\"right\"><div class=\"checkbox\"><label><input type=\"checkbox\" [(ngModel)]=\"scrollToBottom\"> Scroll to Bottom</label></div></div><div class=\"logsDiv\"><pre>\n                    <div *ngFor=\"let log of logs\">{{log}}</div>\n                </pre></div></div></div></div>";

var style$1 = ".logsDiv {\n  height: 200px;\n  overflow: auto;\n  background-color: black;\n  border-radius: 5px;\n  padding: 10px;\n  margin: 10px;\n  color: white;\n  font-size: 12px;\n  font-family: monospace; }\n\n.logsDiv pre {\n  background-color: transparent;\n  border: none;\n  color: white; }\n";

var __decorate$16 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$16 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
if (Meteor.isClient) {
    var ddpEvents = new EventDDP('backoffice-jobs-log', Meteor["connection"]);
    var BackofficeJobsController_1 = (function () {
        function BackofficeJobsController_1(ngZone) {
            var _this = this;
            this.ngZone = ngZone;
            this.scrollToBottom = true;
            this.logs = [];
            this.jobs = [];
            this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
            // getting all jobs, TODO: get reactive
            this.dataBridge.callMethod("backoffice-jobs-getalljobs", {}, function (error$$1, result) {
                if (error$$1)
                    _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error$$1);
                else {
                    ngZone.run(function () {
                        _this.jobs = result;
                    });
                }
            });
            ddpEvents.addListener('push', function (message) {
                ngZone.run(function () {
                    _this.logs.push(message);
                    if (_this.scrollToBottom)
                        $(".logsDiv")[0].scrollTop = $(".logsDiv")[0].scrollHeight;
                });
            });
        }
        BackofficeJobsController_1.prototype.executeJob = function (name) {
            this.dataBridge.callMethod("backoffice-jobs-execute", name, function (error$$1, result) {
                if (error$$1)
                    _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error$$1, "Could not execute Job!");
                else
                    _smallstack_coreCommon.NotificationService.instance().popup.success("Job successfully executed!");
            });
        };
        BackofficeJobsController_1.prototype.isBeingExecuted = function (job) {
            return job.status === _smallstack_coreCommon.BackofficeJobStatus.RUNNING;
        };
        return BackofficeJobsController_1;
    }());
    BackofficeJobsController_1 = __decorate$16([
        _angular_core.Component({
            template: template$7,
            styles: [style$1]
        }),
        __metadata$16("design:paramtypes", [_angular_core.NgZone])
    ], BackofficeJobsController_1);
    Angular2Component.new("jobsPanel", BackofficeJobsController_1)
        .setInitializeAngularComponent(false)
        .register();
    _smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
        navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
            .setRoute("/jobs")
            .setRequiresAuthentication(true, "backoffice_login")
            .setType("backoffice")
            .setIcon("fa fa-code-fork")
            .setI18nLabel("backoffice.navigation.jobs")
            .setRequiredRole("administrator")
            .setIndex(14)
            .setComponent(BackofficeJobsController_1)
            .setChildOfRoute("manage"));
    });
}

var template$8 = "<section class=\"content-header\"><h1>Quick Queries</h1></section><section class=\"content row\"><div class=\"col-xs-12\"><div class=\"box\"><div class=\"box-header\"><h3 class=\"box-title\"><i class=\"fa fa-plug\"></i> Quick Queries</h3></div><div class=\"box-body\"><p>Here you can define temporarily query responses. These in memory queries act like an API and are useful for e.g. domain validation! Each query will get removed again when you redeploy your application.</p><div class=\"form-group\"><label>Path</label><input type=\"text\" [(ngModel)]=\"path\" class=\"form-control\"></div><div class=\"form-group\"><label>Content-Type</label><input type=\"text\" [(ngModel)]=\"contentType\" class=\"form-control\"></div><div class=\"form-group\"><label>Response</label><textarea [(ngModel)]=\"response\" class=\"form-control\" style=\"width:100%\" rows=\"10\"></textarea></div><button class=\"btn btn-success\" (click)=\"addQuery(path, contentType, response)\">Add</button></div></div></div></section>";

var __decorate$17 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$17 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var QueriesBackofficeController = (function () {
    function QueriesBackofficeController() {
        this.contentType = "text/html";
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
    }
    QueriesBackofficeController.prototype.addQuery = function (path, contentType, response) {
        this.dataBridge.callMethod("backoffice-queries-add", { path: path, contentType: contentType, response: response }, _smallstack_coreCommon.NotificationService.instance().getStandardCallback("Could not create quick query!", "Successfully created quick query!"));
    };
    return QueriesBackofficeController;
}());
QueriesBackofficeController = __decorate$17([
    _angular_core.Component({
        template: template$8
    }),
    __metadata$17("design:paramtypes", [])
], QueriesBackofficeController);

// Angular2Component.new("queriesPanel", QueriesBackofficeController).register();
// IOC.get<NavigationService>("navigationService").addNavigationEntry(NavigationEntry.new()
//     .setRoute("/queries")
//     .setRequiresAuthentication(true, "backoffice_login")
//     .setType("backoffice")
//     .setIcon("fa fa-plug")
//     .setLabel("Quick Queries")
//     .setRequiredRole("backoffice.queries")
//     .setIndex(14)
//     .setComponent(QueriesBackofficeController)
//     .setChildOfRoute("manage")
// );

var template$9 = "<section class=\"content-header\"><h1>Roles</h1></section><section class=\"content\"></section>";

var __decorate$18 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$18 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var BackofficeRolesController = (function () {
    function BackofficeRolesController() {
    }
    return BackofficeRolesController;
}());
BackofficeRolesController = __decorate$18([
    _angular_core.Component({
        template: template$9
    }),
    __metadata$18("design:paramtypes", [])
], BackofficeRolesController);
// Angular2Component.new("rolesPanel", BackofficeRolesController).register();
// IOC.get<NavigationService>("navigationService").addNavigationEntry(NavigationEntry.new()
//     .setRoute("/roles")
//     .setRequiresAuthentication(true)
//     .setType("backoffice")
//     .setIcon("fa fa-shield")
//     .setLabel("Roles")
//     .setRequiredRole("administrator")
//     .setIndex(10)
//     .setComponent(BackofficeRolesController)
//     .setChildOfRoute("manage")
// );

var template$10 = "<div class=\"animated fadeIn\"><div class=\"card-deck\"><div class=\"card\"><div class=\"card-block\"><h4 class=\"card-title\">Facebook</h4><p class=\"card-text\"></p><div><ol><li>Goto <a href=\"https://developers.facebook.com/apps\" target=\"_blank\">https://developers.facebook.com/apps</a></li><li>Create or access your \"Website\" App</li><li>Copy the App ID and the App Secret in the fields below</li></ol></div><p></p><p class=\"card-text\"></p><div class=\"form-group\"><label>App ID</label><input [(ngModel)]=\"facebookAppId\" class=\"form-control\"></div><div class=\"form-group\"><label>App Secret</label><input [(ngModel)]=\"facebookSecret\" class=\"form-control\"></div><p></p></div><div class=\"card-footer\"><div class=\"form-group\"><button (click)=\"saveFacebook()\" class=\"btn btn-success\">Save</button></div></div></div><div class=\"card\"><div class=\"card-block\"><h4 class=\"card-title\">Google</h4><p class=\"card-text\"></p><div><ol><li>Goto <a href=\"https://console.developers.google.com/apis/credentials\">https://console.developers.google.com/apis/credentials</a> in your project</li><li>Create or access your OAuth credentials for a Web Application</li><li>Set Javascript Origin to {{rootUrl}}</li><li>Set Redirect URI to {{rootUrl}}/_oauth/google?close</li><li>Copy the client ID and the client secret into the fields below</li></ol></div><p></p><p class=\"card-text\"></p><div class=\"form-group\"><label>Client ID</label><input [(ngModel)]=\"googleClientId\" class=\"form-control\"></div><div class=\"form-group\"><label>Secret</label><input [(ngModel)]=\"googleSecret\" class=\"form-control\"></div><p></p></div><div class=\"card-footer\"><div class=\"form-group\"><button (click)=\"saveGoogle()\" class=\"btn btn-success\">Save</button></div></div></div></div><div class=\"card-deck\"><div class=\"card\"><div class=\"card-block\"><h4 class=\"card-title\">Twitter</h4><p class=\"card-text\"></p><div class=\"form-group\"><label>Consumer Key</label><input [(ngModel)]=\"twitterConsumerKey\" class=\"form-control\"></div><div class=\"form-group\"><label>Secret</label><input [(ngModel)]=\"twitterSecret\" class=\"form-control\"></div><p></p></div><div class=\"card-footer\"><div class=\"form-group\"><button (click)=\"saveTwitter()\" class=\"btn btn-success\">Save</button></div></div></div><div class=\"card\"><div class=\"card-block\"><h4 class=\"card-title\">LinkedIn</h4><p class=\"card-text\"></p><div class=\"form-group\"><label>Client ID</label><input [(ngModel)]=\"linkedInClientId\" class=\"form-control\"></div><div class=\"form-group\"><label>Secret</label><input [(ngModel)]=\"linkedInSecret\" class=\"form-control\"></div><p></p></div><div class=\"card-footer\"><div class=\"form-group\"><button (click)=\"saveLinkedIn()\" class=\"btn btn-success\">Save</button></div></div></div></div></div>";

var __decorate$19 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$19 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var SocialNetworkBackofficeController = (function () {
    function SocialNetworkBackofficeController(ngZone) {
        var _this = this;
        this.rootUrl = Meteor.absoluteUrl("");
        this.notificationService = _smallstack_coreCommon.IOC.get("notificationService");
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
        this.dataBridge.callMethod("backoffice-socialnetworks", {}, function (error$$1, config) {
            if (error$$1)
                _this.notificationService.getStandardErrorPopup(error$$1);
            else {
                ngZone.run(function () {
                    _this.facebookAppId = config.facebookAppId;
                    _this.facebookSecret = config.facebookSecret;
                    _this.googleClientId = config.googleClientId;
                    _this.googleSecret = config.googleSecret;
                    _this.twitterConsumerKey = config.twitterConsumerKey;
                    _this.twitterSecret = config.twitterSecret;
                    _this.linkedInClientId = config.linkedInClientId;
                    _this.linkedInSecret = config.linkedInSecret;
                });
            }
        });
    }
    SocialNetworkBackofficeController.prototype.saveFacebook = function () {
        var that = this;
        this.dataBridge.callMethod("backoffice-socialnetworks-savefacebook", { facebookAppId: this.facebookAppId, facebookSecret: this.facebookSecret }, function (error$$1, success$$1) {
            if (error$$1)
                that.notificationService.getStandardErrorPopup(error$$1);
            else {
                that.notificationService.notification.success("Successfully stored facebook data!");
            }
        });
    };
    SocialNetworkBackofficeController.prototype.saveTwitter = function () {
        var that = this;
        this.dataBridge.callMethod("backoffice-socialnetworks-savetwitter", { twitterKey: this.twitterConsumerKey, twitterSecret: this.twitterSecret }, function (error$$1, success$$1) {
            if (error$$1)
                that.notificationService.getStandardErrorPopup(error$$1);
            else {
                that.notificationService.notification.success("Successfully stored twitter data!");
            }
        });
    };
    SocialNetworkBackofficeController.prototype.saveGoogle = function () {
        var that = this;
        this.dataBridge.callMethod("backoffice-socialnetworks-savegoogle", { googleClientId: this.googleClientId, googleSecret: this.googleSecret }, function (error$$1, success$$1) {
            if (error$$1)
                that.notificationService.getStandardErrorPopup(error$$1);
            else {
                that.notificationService.notification.success("Successfully stored google data!");
            }
        });
    };
    SocialNetworkBackofficeController.prototype.saveLinkedIn = function () {
        var that = this;
        this.dataBridge.callMethod("backoffice-socialnetworks-savelinkedin", { linkedInClientId: this.linkedInClientId, linkedInSecret: this.linkedInSecret }, function (error$$1, success$$1) {
            if (error$$1)
                that.notificationService.getStandardErrorPopup(error$$1);
            else {
                that.notificationService.notification.success("Successfully stored linkedIn data!");
            }
        });
    };
    return SocialNetworkBackofficeController;
}());
SocialNetworkBackofficeController = __decorate$19([
    _angular_core.Component({
        template: template$10
    }),
    __metadata$19("design:paramtypes", [_angular_core.NgZone])
], SocialNetworkBackofficeController);
Angular2Component.new("socialnetworkPanel", SocialNetworkBackofficeController)
    .setInitializeAngularComponent(false)
    .register();
_smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
    navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
        .setRoute("/socialnetworks")
        .setRequiresAuthentication(true, "backoffice_login")
        .setType("backoffice")
        .setIcon("fa fa-facebook-square")
        .setI18nLabel("backoffice.navigation.socialnetworks")
        .setRequiredRole("administrator")
        .setIndex(10)
        .setComponent(SocialNetworkBackofficeController)
        .setChildOfRoute("manage"));
});

var template$11 = "<section class=\"content-header\"><h1>Users Backoffice</h1></section><section class=\"content\"><div class=\"row\"><div class=\"col-xs-12\"><div class=\"box\"><div class=\"box-header\"><h3 class=\"box-title\">Add User</h3></div><div class=\"box-body\"><div class=\"form-group col-md-4 col-xs-12\"><label>Display Name</label><input type=\"text\" ng-model=\"newUser.displayName\" class=\"form-control\"></div><div class=\"form-group col-md-4 col-xs-12\"><label>E-Mail</label><input type=\"text\" ng-model=\"newUser.email\" class=\"form-control\"></div><div class=\"form-group col-md-4 col-xs-12\"><label>Password</label><input type=\"password\" ng-model=\"newUser.password\" class=\"form-control\"></div><div class=\"col-xs-12\"><button ng-click=\"vm.createUser(newUser)\" class=\"btn btn-default\">Create</button></div></div></div></div><div class=\"col-xs-12\"><div class=\"box\"><div class=\"box-header\"><h3 class=\"box-title\">Edit User</h3></div><div class=\"box-body\"><div class=\"input-group\"><label>Search</label><input type=\"text\" ng-model=\"selectedUser\" uib-typeahead=\"user as user.profile.displayName for user in vm.getUser($viewValue)\" typeahead-loading=\"loadingUsers\" typeahead-no-results=\"noUserResults\" class=\"form-control\"> <i ng-show=\"loadingUsers\" class=\"glyphicon glyphicon-refresh\">loading users</i><div ng-show=\"noUserResults\"><i class=\"glyphicon glyphicon-remove\"></i> No Results Found</div></div><div ng-show=\"vm.hasSelectedUser()\"><div class=\"form-group\"><label>New Password</label><input type=\"text\" ng-model=\"newPassword\" class=\"form-control\" ng-disabled=\"!selectedUser\"> <button ng-click=\"vm.setPassword(selectedUser._id, newPassword)\" class=\"btn btn-default\" ng-disabled=\"!selectedUser\">Set Password</button></div><div class=\"form-group\"><label>Add Role</label><input type=\"text\" ng-model=\"newRole\" class=\"form-control\" ng-disabled=\"!selectedUser\"> <button ng-click=\"vm.addRole(selectedUser._id, newRole)\" class=\"btn btn-default\" ng-disabled=\"!selectedUser\">Add</button></div>{{selectedUser}}</div></div></div></div></div></section>";

var __decorate$20 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$20 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var UsersBackofficeController = (function () {
    function UsersBackofficeController(ngZone) {
        this.ngZone = ngZone;
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
    }
    UsersBackofficeController.prototype.getUser = function (userString) {
        return Meteor["callPromise"]("collection-search", { collectionName: "users", queryString: userString });
    };
    UsersBackofficeController.prototype.setPassword = function (userId, newPassword) {
        this.dataBridge.callMethod("backoffice-users-setPassword", { userId: userId, newPassword: newPassword }, _smallstack_coreCommon.NotificationService.instance().getStandardCallback("Could not set password!", "Successfully set password!"));
    };
    UsersBackofficeController.prototype.addRole = function (userId, newRole) {
        this.dataBridge.callMethod("backoffice-users-addRole", { userId: userId, newRole: newRole }, _smallstack_coreCommon.NotificationService.instance().getStandardCallback("Could not add role!", "Successfully added new role!"));
    };
    UsersBackofficeController.prototype.createUser = function (newUser) {
        this.dataBridge.callMethod("backoffice-users-createUser", { displayName: newUser.displayName, email: newUser.email, password: newUser.password }, _smallstack_coreCommon.NotificationService.instance().getStandardCallback("Could not create user!", "Successfully created new user!"));
    };
    UsersBackofficeController.prototype.hasSelectedUser = function () {
        return this.selectedUser !== undefined && typeof this.selectedUser !== "string";
    };
    return UsersBackofficeController;
}());
UsersBackofficeController = __decorate$20([
    _angular_core.Component({
        template: template$11
    }),
    __metadata$20("design:paramtypes", [_angular_core.NgZone])
], UsersBackofficeController);

// Angular2Component.new("usersBackofficePanel", UsersBackofficeController).register();
// IOC.get<NavigationService>("navigationService").addNavigationEntry(NavigationEntry.new()
//     .setRoute("/users")
//     .setRequiresAuthentication(true, "backoffice_login")
//     .setRequiredRole("backoffice.users")
//     .setVisible(true)
//     .setType("backoffice")
//     .setIcon("fa fa-user")
//     .setLabel("Users")
//     .setIndex(6)
//     .setComponent(UsersBackofficeController)
//     .setChildOfRoute("manage")
// );

var template$12 = "<div class=\"animated fadeIn\"><div align=\"right\"><button class=\"btn btn-default\" (click)=\"createNewModel()\">create new</button></div><div class=\"card\"><div class=\"card-header\">{{\"backoffice.collections.searchtitle\" | translate}}</div><div class=\"card-block\"><div class=\"box-body\"><div class=\"input-group\"><input type=\"text\" class=\"form-control\" placeholder=\"{{'backoffice.collections.fulltextsearch' | translate}}\" [(ngModel)]=\"searchText\"> <span class=\"input-group-btn\"><button class=\"btn btn-default\" type=\"button\" (click)=\"searchModels()\">Search</button></span></div></div></div></div><div class=\"card\"><div class=\"card-header\">{{\"backoffice.collections.resultstitle\" | translate}}</div><div class=\"card-block\"><div *ngIf=\"searchError\">{{searchError}}</div><div style=\"width:100%;overflow:auto\"><List (selectedEntry)=\"loadModel($event)\" [models]=\"models\"></List></div></div></div><div class=\"col-xs-12\"><div class=\"box\"><div class=\"box-header\"><h3 class=\"box-title\">{{\"backoffice.collections.editortitle\" | translate}}</h3></div><div class=\"box-body\"><div class=\"col-xs-12\">{{currentModel | json}}<Editor componentId=\"modelEditor\" [type]=\"type\" updateMethod=\"event\" (onSave)=\"saveModel($event)\" [model]=\"currentModel\"></Editor></div></div></div></div></div>";

_smallstack_coreCommon.IOC.onRegister("localizationService", function (localizationService) {
    localizationService.addTranslation("en", {
        "backoffice": {
            "collections": {
                "searchtitle": "Search",
                "searchbutton": "Search",
                "resultstitle": "Results",
                "editortitle": "Model Editor",
                "fulltextsearch": "Full Text Search"
            }
        }
    });
    localizationService.addTranslation("de", {
        "backoffice": {
            "collections": {
                "searchtitle": "Suche",
                "searchbutton": "Suchen",
                "resultstitle": "Resultate",
                "editortitle": "Model Editor",
                "fulltextsearch": "Volltextsuche"
            }
        }
    });
});

var __decorate$21 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$21 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CollectionPanelComponent = (function () {
    function CollectionPanelComponent(ngZone, router) {
        this.ngZone = ngZone;
        this.router = router;
        this.models = [];
        this.typesystem = _smallstack_coreCommon.IOC.get("typesystem");
        this.eventService = _smallstack_coreCommon.IOC.get("eventService");
        this.collectionsService = _smallstack_coreCommon.IOC.get("collectionsService");
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
        this.collectionName = router.url.replace("/manage/collections/", ""); //TODO
        this.type = this.typesystem.getTypeByCollectionName(this.collectionName);
        //  this.dataBridge.callMethod("backoffice-collectionCounts", (error: Meteor.Error, counts: any) => {
        //     if (error)
        //         this.notificationService.getStandardErrorPopup(error);
        //     else {
        //         this.ngZone.run(() => {
        //             this.collections = counts;
        //         });
        //     }
        // });
    }
    CollectionPanelComponent.prototype.searchModels = function () {
        var _this = this;
        this.dataBridge.callMethod("collections-search", { "collectionName": this.collectionName, "searchtext": this.searchText }, function (error$$1, models) {
            if (error$$1)
                _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error$$1);
            else {
                _this.ngZone.run(function () {
                    _this.evaluateSearchResult(models);
                });
            }
        });
    };
    CollectionPanelComponent.prototype.evaluateSearchResult = function (models) {
        var _this = this;
        this.models = [];
        this.keys = [];
        if (models instanceof Array && models.length > 0) {
            this.keys.push("id");
            _.each(models, function (model) {
                _this.models.push(_this.type.getModel().fromDocument(model));
                for (var key in model) {
                    if (key.charAt(0) === "_" || key === "id")
                        continue;
                    if (!_.contains(_this.keys, key))
                        _this.keys.push(key);
                }
            });
        }
        else
            this.searchError = "No Models found!";
    };
    CollectionPanelComponent.prototype.prettyPrint = function (object) {
        return _smallstack_coreCommon.Utils.prettyPrintJson(object, 60);
    };
    CollectionPanelComponent.prototype.loadModel = function (model) {
        var _this = this;
        this.ngZone.run(function () {
            _this.currentModel = model;
        });
    };
    CollectionPanelComponent.prototype.saveModel = function () {
        if (this.currentModel !== undefined) {
            this.dataBridge.callMethod("collections-update", { "collectionName": this.collectionName, "currentModel": this.currentModel }, function (error$$1, success$$1) {
                if (error$$1)
                    _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error$$1);
                else if (!success$$1)
                    _smallstack_coreCommon.NotificationService.instance().popup.error("Somehow, the model could not be saved!");
                else
                    _smallstack_coreCommon.NotificationService.instance().notification.success("Successfully saved Model!");
            });
        }
    };
    CollectionPanelComponent.prototype.removeModel = function () {
        var _this = this;
        if (this.currentModel !== undefined) {
            _smallstack_coreCommon.NotificationService.instance().popup.confirmation("Deleting a Model", "Do you really want to delete that model?", function (answer) {
                if (answer) {
                    _this.dataBridge.callMethod("collections-remove", { "collectionName": _this.collectionName, "currentModel": _this.currentModel }, function (error$$1, success$$1) {
                        if (error$$1)
                            _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error$$1);
                        else if (!success$$1)
                            _smallstack_coreCommon.NotificationService.instance().popup.error("Somehow, the model could not be removed!");
                        else {
                            _smallstack_coreCommon.NotificationService.instance().notification.success("Successfully removed Model!");
                            _this.ngZone.run(function () {
                                _this.currentModel = undefined;
                                _this.loadModel(undefined);
                            });
                        }
                    });
                }
            });
        }
    };
    CollectionPanelComponent.prototype.createNewModel = function () {
        this.currentModel = {};
    };
    return CollectionPanelComponent;
}());
CollectionPanelComponent = __decorate$21([
    _angular_core.Component({
        template: template$12
    }),
    __metadata$21("design:paramtypes", [_angular_core.NgZone, _angular_router.Router])
], CollectionPanelComponent);
Angular2Component.new("collectionPanel", CollectionPanelComponent)
    .setInitializeAngularComponent(false)
    .register();
_smallstack_coreCommon.IOC.onRegister("collectionsService", function (collectionsService) {
    _smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
        var keys$$1 = _.keys(collectionsService.getAllCollections()).sort();
        for (var key in keys$$1) {
            navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
                .setRoute("/" + keys$$1[key])
                .setRequiresAuthentication(true)
                .setType("backoffice")
                .setIcon("fa fa-database")
                .setLabel(_smallstack_coreCommon.Utils.capitalize(keys$$1[key]))
                .setRequiredRole("administrator")
                .setComponent(CollectionPanelComponent)
                .setIndex(50)
                .setChildOfRoute("collections"));
        }
    });
});

var template$13 = "<div class=\"animated fadeIn\"><div class=\"row\"><div class=\"col-sm-6 col-lg-3\" *ngFor=\"let collection of collections\" [routerLink]=\"['/manage/collections/' + collection.name]\" style=\"cursor:pointer\"><div class=\"card card-inverse card-primary\"><div class=\"card-block pb-0\"><h4 class=\"mb-0\">{{collection.count}}</h4><p>{{collection.name | capitalize}}</p></div></div></div></div><router-outlet></router-outlet></div>";

var __decorate$22 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$22 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CollectionsPanelComponent = (function () {
    function CollectionsPanelComponent(ngZone, router, route) {
        var _this = this;
        this.ngZone = ngZone;
        this.router = router;
        this.route = route;
        this.collections = [];
        this.notificationService = _smallstack_coreCommon.IOC.get("notificationService");
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
        this.router.events.filter(function (event) { return event instanceof _angular_router.NavigationEnd; }).subscribe(function (event) {
            if (_smallstack_coreCommon.Utils.stringEndsWith(_this.router.url, "/collections")) {
                _this.dataBridge.callMethod("backoffice-collectionCounts", {}, function (error$$1, counts) {
                    if (error$$1)
                        _this.notificationService.getStandardErrorPopup(error$$1);
                    else {
                        _this.ngZone.run(function () {
                            _this.collections = counts;
                        });
                    }
                });
            }
            else {
                _this.ngZone.run(function () {
                    _this.collections = [];
                });
            }
        });
    }
    return CollectionsPanelComponent;
}());
CollectionsPanelComponent = __decorate$22([
    _angular_core.Component({
        template: template$13
    }),
    __metadata$22("design:paramtypes", [_angular_core.NgZone, _angular_router.Router, _angular_router.ActivatedRoute])
], CollectionsPanelComponent);
Angular2Component.new("collectionsPanel", CollectionsPanelComponent)
    .setInitializeAngularComponent(false)
    .register();
_smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
    navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
        .setRoute("/collections")
        .setRequiresAuthentication(true)
        .setType("backoffice")
        .setIcon("fa fa-database")
        .setI18nLabel("backoffice.navigation.collections")
        .setRequiredRole("administrator")
        .setComponent(CollectionsPanelComponent)
        .setIndex(50)
        .setChildOfRoute("manage")
        .setSubEntriesAvailable(true));
});

var template$14 = "<section class=\"content-header\"><h1>Internationalization</h1></section><section class=\"content\"><div class=\"box\"><div class=\"box-header\"><h3 class=\"box-title\">Table</h3></div><div class=\"box-body\"><table class=\"table table-striped\"><thead><tr><th>Key</th><th *ngFor=\"let language of languages\">{{language.key}}</th><th>Actions</th></tr></thead><tbody><tr *ngFor=\"let localization of localizations\"><td>{{localization.key}}</td><td *ngFor=\"let language of languages\"><input type=\"text\" [(ngModel)]=\"localization[language.key]\" class=\"form-control\"></td><td><button class=\"btn btn-danger\" (click)=\"removeLocalization(key)\">remove</button> <button class=\"btn btn-success\" (click)=\"saveLocalization(localization)\">save</button></td></tr></tbody></table></div></div></section>";

var __decorate$23 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$23 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var I18NBackoffice = (function () {
    function I18NBackoffice(ngZone) {
        var _this = this;
        this.ngZone = ngZone;
        this.localizations = [];
        this.localizationService = _smallstack_coreCommon.IOC.get("localizationService");
        this.languageService = _smallstack_coreCommon.IOC.get("languageService");
        this.dataBridge = _smallstack_coreCommon.IOC.get("dataBridge");
        var langQuery = this.languageService.getAllLanguages({}, { entriesPerPage: 100 });
        langQuery.subscribe(function () {
            var locaQuery = _this.localizationService.getLocalizations({}, { entriesPerPage: 15000 });
            locaQuery.subscribe(function () {
                _this.languages = langQuery.getModels();
                var localizations = {};
                locaQuery.getModels().forEach(function (localizedText) {
                    if (!localizations[localizedText.key])
                        localizations[localizedText.key] = {};
                    localizations[localizedText.key][localizedText.language] = localizedText.value;
                });
                _this.ngZone.run(function () {
                    _this.localizations = [];
                    _.each(localizations, function (localObj, key) {
                        localObj.key = key;
                        _this.localizations.push(localObj);
                    });
                });
            });
        });
    }
    I18NBackoffice.prototype.saveLocalization = function (localization) {
        this.dataBridge.callMethod("localizations-updateLocalization", localization, function (error$$1, saved) {
            if (error$$1)
                _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error$$1);
            else
                _smallstack_coreCommon.NotificationService.instance().notification.success("Localization '" + localization.key + "' saved!");
        });
    };
    I18NBackoffice.prototype.removeLocalization = function (key) {
        this.dataBridge.callMethod("localizations-removeLocalization", key, function (error$$1, saved) {
            if (error$$1)
                _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error$$1);
            else
                _smallstack_coreCommon.NotificationService.instance().notification.success("Localization '" + key + "' removed!");
        });
    };
    return I18NBackoffice;
}());
I18NBackoffice = __decorate$23([
    _angular_core.Component({
        template: template$14
    }),
    __metadata$23("design:paramtypes", [_angular_core.NgZone])
], I18NBackoffice);
Angular2Component.new("i18nPanel", I18NBackoffice)
    .setInitializeAngularComponent(false)
    .register();
_smallstack_coreCommon.IOC.onRegister("navigationService", function (navigationService) {
    navigationService.addNavigationEntry(_smallstack_coreCommon.NavigationEntry.new()
        .setComponent(I18NBackoffice)
        .setRoute("/internationalization")
        .setRequiresAuthentication(true)
        .setType("backoffice")
        .setIcon("fa fa-globe")
        .setI18nLabel("backoffice.navigation.i18n")
        .setRequiredRole("administrator")
        .setIndex(30)
        .setChildOfRoute("manage"));
});

var template$15 = "<div *ngIf=\"!currentModel\"><i><small>{{emptyMessage}}</small></i></div><div *ngIf=\"currentModel\"><EntityForm [model]=\"currentModel\" (onSubmit)=\"handleOutput($event)\"><div class=\"row\"><div *ngFor=\"let field of fields\" class=\"col-xs-12 col-sm-6 col-md-4 col-lg-3\"><EntityFormField [name]=\"field\"></EntityFormField></div></div><div class=\"row\"><button class=\"btn btn-success\" type=\"submit\">speichern</button></div></EntityForm><div class=\"col-xs-12\" *ngIf=\"showModelPreview\"><strong>Complete Model Preview</strong><br><button class=\"btn btn-default btn-xs\" data-toggle=\"collapse\" data-target=\"#editorModelPreview\">Show</button><pre class=\"collapse\" id=\"editorModelPreview\"> {{modelAsString}} </pre></div></div>";

var __extends$7 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Editor = (function (_super) {
    __extends$7(Editor, _super);
    function Editor() {
        var _this = _super.call(this) || this;
        _this.editorContent = "not loaded";
        _this.fields = [];
        _this.typesystem = _smallstack_coreCommon.IOC.get("typesystem");
        return _this;
    }
    Editor.prototype.afterInitialization = function () {
        this.syncDataIfAvailable(Editor.configurationNames.emptyMessage);
        this.syncDataIfAvailable(Editor.configurationNames.showModelPreview);
        this.syncDataIfAvailable(Editor.configurationNames.fieldsToShow);
        this.syncDataIfAvailable(Editor.configurationNames.updateMethod);
        this.syncDataIfAvailable(Editor.configurationNames.updateMethodName);
        this.syncDataIfAvailable(Editor.configurationNames.type);
        this.syncDataIfAvailable(Editor.configurationNames.typeName);
        if (this.typeName !== undefined) {
            this.type = this.typesystem.getTypeByName(this.typeName);
            this.evaluateType();
        }
        else if (this.type !== undefined) {
            this.evaluateType();
        }
    };
    Editor.prototype.onSocketEvent = function (socketName, socketData) {
        switch (socketName) {
            case Editor.socketNames.typeName:
                this.typeName = socketData;
                this.type = this.typesystem.getTypeByName(this.typeName);
                this.evaluateType();
                break;
            case Editor.socketNames.type:
                this.type = socketData;
                this.evaluateType();
                break;
            case Editor.socketNames.id:
                this.id = socketData;
                this.loadModel(this.id);
                break;
            case Editor.socketNames.model:
                this.currentModel = socketData;
                if (socketData !== undefined && typeof socketData.getModelName === 'function') {
                    var type = this.typesystem.getTypeByName(socketData.getModelName());
                    if (type === undefined)
                        console.error("Could not find type called : ", socketData);
                    else
                        this.type = type;
                }
                break;
        }
        // this.loadModel(this.id);
    };
    Editor.prototype.handleOutput = function (formJson) {
        var _this = this;
        // TODO: use the model's fromDocumet() method
        _.each(formJson, function (value, key) {
            _this.currentModel[key] = value;
        });
        this.updateModel();
    };
    Editor.prototype.evaluateType = function () {
        var _this = this;
        if (this.type) {
            if (this.fieldsToShow === undefined) {
                this.schema = this.type.model.schema;
            }
            else {
                this.schema = [];
                _.each(this.fieldsToShow, function (fieldToShow) {
                    fieldToShow = fieldToShow.trim();
                    _.each(_this.type.model.schema, function (field) {
                        if (field.name === fieldToShow)
                            _this.schema.push(field);
                    });
                });
            }
            var orderIndex = 1;
            this.fields = [];
            _.each(this.schema, function (schemaEntry) {
                _this.fields.push(schemaEntry.name);
                // let defaultOptions: any = {
                //     key: schemaEntry.name,
                //     label: schemaEntry.name,
                //     value: this.model ? this.model[schemaEntry.name] : undefined,
                //     required: this.model && this.model[schemaEntry.name] ? this.model[schemaEntry.name].optional === false : true,
                //     order: orderIndex++
                // }
                // let lowerCaseType: string = schemaEntry.type.toLowerCase();
                // switch (lowerCaseType) {
                //     case "string":
                //         //fields.push(new StringFormField(defaultOptions));
                //         break;
                //     case "number":
                //         fields.push(new NumberFormField(defaultOptions));
                //         break;
                //     case "object":
                //         fields.push(new ObjectFormField(defaultOptions));
                //         break;
                //     default:
                //         Logger.error("Editor", "Could not find editor for type : " + lowerCaseType);
                // }
            });
        }
    };
    Editor.prototype.loadModel = function (id) {
        var _this = this;
        if (this.type !== undefined && id !== undefined) {
            if (this.type.collection && this.type.collection.name) {
                var collection = this.collectionsService.getCollectionByName(this.type.collection.name);
                var getter = collection.getForeignGetter();
                var service = this.type.getService();
                var queryObject = service[getter]({ ids: [id] }, { reactive: false });
                queryObject.subscribe(function (cursor) {
                    _this.ngZone.run(function () {
                        _this.currentModel = queryObject.getModels()[0];
                    });
                });
            }
        }
    };
    Editor.prototype.updateModel = function () {
        switch (this.updateMethod) {
            case "method":
                if (this.updateMethodName !== undefined)
                    this.dataBridge.callMethod(this.updateMethodName, this.currentModel, _smallstack_coreCommon.NotificationService.instance().getStandardCallback("Could not update model!", "Model successfully updated!"));
                else
                    _smallstack_coreCommon.Logger.error("Editor", "No updateMethodName given and type is not set. No clue how to store the model!");
                break;
            case "event":
                //this.onSave.emit(this.currentModel);
                //this.eventService.dispatchSocketEvent(Editor.socketNames.output, this.currentModel);
                break;
            case "service":
            default:
        }
    };
    return Editor;
}(Angular2BaseComponentController));
Editor.socketNames = {
    typeName: "typeName",
    type: "type",
    id: "id",
    model: "model",
    output: "output"
};
Editor.configurationNames = {
    typeName: "typeName",
    type: "type",
    emptyMessage: "emptyMessage",
    showModelPreview: "showModelPreview",
    fieldsToShow: "fieldsToShow",
    updateMethod: "updateMethod",
    updateMethodName: "updateMethodName"
};
_smallstack_coreCommon.IOC.onRegister("typesystem", function () {
    var possibleTypes = [];
    _.each(_smallstack_coreCommon.IOC.get("typesystem").getAllTypes(), function (type) {
        possibleTypes.push({ value: type.model.name, label: type.model.name });
    });
    Angular2Component.new("Editor", Editor)
        .setLabel("Model Editor")
        .setTemplate(template$15)
        .setDescription("Editor for all smallstack models!")
        .addSocket(_smallstack_coreClient.ComponentSocket.createInput(Editor.socketNames.type, _smallstack_coreClient.ComponentSocketType.STRING))
        .addSocket(_smallstack_coreClient.ComponentSocket.createInput(Editor.socketNames.typeName, _smallstack_coreClient.ComponentSocketType.STRING))
        .addSocket(_smallstack_coreClient.ComponentSocket.createInput(Editor.socketNames.id, _smallstack_coreClient.ComponentSocketType.STRING))
        .addSocket(_smallstack_coreClient.ComponentSocket.createInput(Editor.socketNames.model, _smallstack_coreClient.ComponentSocketType.STRING))
        .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createSelectConfiguration(Editor.socketNames.typeName, undefined, possibleTypes))
        .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createStringConfiguration(Editor.configurationNames.emptyMessage, "No model loaded!"))
        .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createStringConfiguration(Editor.configurationNames.fieldsToShow))
        .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createStringConfiguration(Editor.configurationNames.updateMethodName))
        .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createStringConfiguration(Editor.configurationNames.updateMethod))
        .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createBooleanConfiguration(Editor.configurationNames.showModelPreview, false))
        .addTags(["data"])
        .register();
});

var template$16 = "<StringFormField *ngIf=\"editor === 'string'\" [schemaFieldName]=\"schemaFieldName\" [type]=\"type\" [value]=\"value\" (onChange)=\"onChange($event)\"></StringFormField>";

var __decorate$25 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$25 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var EntityFormField = (function () {
    function EntityFormField() {
    }
    EntityFormField.prototype.setType = function (type, schemaFieldName) {
        this.type = type;
        this.schemaFieldName = schemaFieldName;
        this.editor = this.type.getSchemaEntryByName(schemaFieldName).type;
    };
    EntityFormField.prototype.setValue = function (value) {
        this.value = value;
    };
    EntityFormField.prototype.onChange = function (newValue) {
        if (this.onChangeCallback)
            this.onChangeCallback(newValue);
    };
    return EntityFormField;
}());
__decorate$25([
    _angular_core.Input(),
    __metadata$25("design:type", String)
], EntityFormField.prototype, "name", void 0);
Angular2Component.new("EntityFormField", EntityFormField)
    .setTemplate(template$16)
    .register();

var __decorate$24 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$24 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var EntityForm = (function () {
    function EntityForm() {
        this.onSubmit = new _angular_core.EventEmitter();
        this.changes = {};
        this.typesystem = _smallstack_coreCommon.IOC.get("typesystem");
    }
    EntityForm.prototype.ngAfterContentInit = function () {
        var _this = this;
        setTimeout(function () { _this.processForm(); }, 0);
    };
    EntityForm.prototype.ngOnChanges = function () {
        var _this = this;
        setTimeout(function () { _this.processForm(); }, 0);
    };
    EntityForm.prototype.doSubmit = function () {
        this.onSubmit.emit(this.changes);
        return false;
    };
    EntityForm.prototype.processForm = function () {
        var _this = this;
        if (this.model && this.fields) {
            var type_1 = this.typesystem.getTypeByName(this.model.getModelName());
            if (!type_1)
                _smallstack_coreCommon.Logger.error("EntiyForm", "No type found for model '" + this.model.getModelName() + "'!");
            else {
                this.fields.forEach(function (entityFormField) {
                    var schemaEntry = type_1.getSchemaEntryByName(entityFormField.name);
                    if (!schemaEntry)
                        _smallstack_coreCommon.Logger.error("EntiyForm", "No schema found for a model property called '" + entityFormField.name + "'!");
                    else {
                        entityFormField.setType(type_1, entityFormField.name);
                        entityFormField.setValue(_this.model[entityFormField.name]);
                        entityFormField.onChangeCallback = function (newValue) {
                            _this.changes[entityFormField.name] = newValue;
                        };
                    }
                });
            }
        }
    };
    return EntityForm;
}());
__decorate$24([
    _angular_core.Input(),
    __metadata$24("design:type", Object)
], EntityForm.prototype, "model", void 0);
__decorate$24([
    _angular_core.Output(),
    __metadata$24("design:type", Object)
], EntityForm.prototype, "onSubmit", void 0);
__decorate$24([
    _angular_core.ContentChildren(EntityFormField),
    __metadata$24("design:type", _angular_core.QueryList)
], EntityForm.prototype, "fields", void 0);
Angular2Component.new("EntityForm", EntityForm)
    .setTemplate("<form (ngSubmit)='doSubmit()'><ng-content></ng-content></form>")
    .register();

var __decorate$26 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$26 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var BaseFormField = (function () {
    function BaseFormField() {
        this.onChange = new _angular_core.EventEmitter();
    }
    BaseFormField.prototype.ngOnChanges = function (changes) {
        if (this.type) {
            var i18nPrefix = "models." + this.type.model.name.toLowerCase() + "." + this.schemaFieldName + ".";
            var i18nLabel = i18nPrefix + "label";
            var translatedLabel = this.localizationService.getTranslation(i18nLabel, { showMissingKey: false });
            if (translatedLabel)
                this.label = translatedLabel;
            else
                this.label = _smallstack_coreCommon.Utils.capitalize(this.schemaFieldName);
            this.placeholder = this.localizationService.getTranslation(i18nPrefix + "placeholder", { showMissingKey: false });
            this.helptext = this.localizationService.getTranslation(i18nPrefix + "helptext", { showMissingKey: false });
        }
    };
    BaseFormField.prototype.valueChanged = function (newValue) {
        // if value is valid etc.
        this.onChange.emit(newValue);
    };
    return BaseFormField;
}());
__decorate$26([
    _smallstack_coreCommon.Autowired(),
    __metadata$26("design:type", _smallstack_coreCommon.LocalizationService)
], BaseFormField.prototype, "localizationService", void 0);
__decorate$26([
    _angular_core.Input(),
    __metadata$26("design:type", Object)
], BaseFormField.prototype, "value", void 0);
__decorate$26([
    _angular_core.Input(),
    __metadata$26("design:type", _smallstack_coreCommon.Type)
], BaseFormField.prototype, "type", void 0);
__decorate$26([
    _angular_core.Input(),
    __metadata$26("design:type", String)
], BaseFormField.prototype, "schemaFieldName", void 0);
__decorate$26([
    _angular_core.Output(),
    __metadata$26("design:type", Object)
], BaseFormField.prototype, "onChange", void 0);

var __extends$8 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var StringFormField = (function (_super) {
    __extends$8(StringFormField, _super);
    function StringFormField() {
        return _super.apply(this, arguments) || this;
    }
    return StringFormField;
}(BaseFormField));
Angular2Component.new("StringFormField", StringFormField)
    .setTemplate("\n        <div class=\"form-group\">\n            <label>{{label}}</label>\n            <input type=\"text\" class=\"form-control\" [(ngModel)]=\"value\" (ngModelChange)=\"valueChanged($event)\" placeholder=\"{{placeholder}}\">\n            <p class=\"form-text text-muted\">{{helptext}}</p>\n        </div>")
    .register();

var __extends$9 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var NumberFormField = (function (_super) {
    __extends$9(NumberFormField, _super);
    function NumberFormField() {
        return _super.apply(this, arguments) || this;
    }
    return NumberFormField;
}(BaseFormField));
Angular2Component.new("NumberFormField", NumberFormField)
    .setTemplate("<div class=\"form-group\"><label>{{label | translate}}</label><input type=\"number\" class=\"form-control\" [(ngModel)]=\"value\"></div>")
    .register();

var template$17 = "<div></div>";

var __extends$10 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ObjectFormField = (function (_super) {
    __extends$10(ObjectFormField, _super);
    function ObjectFormField() {
        return _super.apply(this, arguments) || this;
    }
    return ObjectFormField;
}(BaseFormField));
Angular2Component.new("ObjectFormField", ObjectFormField)
    .setTemplate(template$17)
    .register();

var __decorate$27 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$27 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ComponentDirective = (function () {
    function ComponentDirective() {
        this.restrict = 'E';
        this.scope = {
            componentId: "@"
        };
        this.pagesService = _smallstack_coreCommon.IOC.get("pagesService");
        console.log("component, yeah");
    }
    return ComponentDirective;
}());
ComponentDirective = __decorate$27([
    _angular_core.Component({
        selector: "component",
        template: "<div>yeah</div>"
    }),
    __metadata$27("design:paramtypes", [])
], ComponentDirective);

// smallstack.angular.app.directive("component", ComponentDirective.factory());

var template$18 = "<table class=\"table table-hover\" *ngIf=\"!entryTemplate\"><thead *ngIf=\"fields\"><tr><th *ngFor=\"let field of fields\">{{field}}</th></tr></thead><tbody *ngIf=\"models && models.length > 0\"><tr *ngFor=\"let model of models\"><td *ngFor=\"let field of fields\" style=\"cursor:pointer\" (click)=\"selectEntry(model)\">{{model[field]}}</td></tr></tbody></table><div *ngIf=\"models.length === 0\">{{emptyMessage | i18n}}</div><div #listEntries></div>";

var __extends$11 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate$28 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$28 = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ListEntry = (function (_super) {
    __extends$11(ListEntry, _super);
    function ListEntry() {
        return _super.apply(this, arguments) || this;
    }
    return ListEntry;
}(Angular2BaseComponentController));
var ListComponent = (function (_super) {
    __extends$11(ListComponent, _super);
    function ListComponent() {
        var _this = _super.apply(this, arguments) || this;
        _this.models = [];
        return _this;
    }
    ListComponent.prototype.renderEntryTemplates = function (models) {
        var _this = this;
        this.listEntriesContainer.clear();
        if (this.entryTemplate) {
            _.each(models, function (model) {
                _this.listEntriesContainer.createEmbeddedView(_this.entryTemplate, { model: model });
            });
        }
    };
    ListComponent.prototype.afterInitialization = function () {
        this.syncDataIfAvailable(ListComponent.configurationNames.templateUrl);
        this.syncDataIfAvailable(ListComponent.configurationNames.emptyMessage);
        // this.syncDataIfAvailable(ListComponent.configurationNames.useTemplateUrl);
        // if (this.$templateCache.get(this.$scope.templateUrl) === undefined) {
        //     NotificationService.instance().notification.error("Template could not be found : " + this.$scope.templateUrl);
        // }
        // else {
        //     this.$timeout(() => {
        //         this.$scope.templateExists = true;
        //     });
        // }
    };
    ListComponent.prototype.onSocketEvent = function (socketName, socketData) {
        var _this = this;
        switch (socketName) {
            case ListComponent.socketNames.models:
                if (!(socketData instanceof Array))
                    _smallstack_coreCommon.Logger.debug("ListComponent", "socketData for socket 'models' should be instanceof Array but got : " + JSON.stringify(socketData));
                else {
                    this.ngZone.run(function () {
                        _this.setModels(socketData);
                    });
                }
                break;
            case ListComponent.socketNames.fields:
                this.fields = socketData;
                break;
        }
    };
    ListComponent.prototype.selectEntry = function (entry) {
        this.sendOutput(ListComponent.socketNames.selectedEntry, entry);
    };
    ListComponent.prototype.setModels = function (models) {
        var _this = this;
        _smallstack_coreCommon.Logger.info("List", "Got models: ", models);
        if (this.fields === undefined && models instanceof Array && models.length > 0) {
            this.fields = [];
            _.each(models[0].toDocument(), function (value, key) {
                _this.fields.push(key);
            });
        }
        this.models = models;
        this.renderEntryTemplates(models);
    };
    return ListComponent;
}(Angular2BaseComponentController));
ListComponent.configurationNames = {
    templateUrl: "templateUrl",
    // useTemplateUrl: "useTemplateUrl",
    emptyMessage: "emptyMessage"
};
ListComponent.socketNames = {
    models: "models",
    selectedEntry: "selectedEntry",
    fields: "fields"
};
__decorate$28([
    _angular_core.ContentChild("entryTemplate"),
    __metadata$28("design:type", _angular_core.TemplateRef)
], ListComponent.prototype, "entryTemplate", void 0);
__decorate$28([
    _angular_core.ViewChild("listEntries", { read: _angular_core.ViewContainerRef }),
    __metadata$28("design:type", _angular_core.ViewContainerRef)
], ListComponent.prototype, "listEntriesContainer", void 0);
Angular2Component.new("ListEntry", ListEntry)
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput("model", _smallstack_coreClient.ComponentSocketType.OBJECT))
    .setTemplate("list entry!")
    .register();
Angular2Component.new("List", ListComponent)
    .setTemplate(template$18)
    .setLabel("List Component")
    .setDescription("The List Component is the base for all components with a list functionality! Header and List Entry templates can either be set via configuration or via slots!")
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createStringConfiguration(ListComponent.configurationNames.templateUrl, "/packages/smallstack:cms-components/list/list.template.ng.html"))
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createI18nStringConfiguration(ListComponent.configurationNames.emptyMessage, { de: "Keine Daten vorhanden", en: "No Data loaded" }))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(ListComponent.socketNames.fields, _smallstack_coreClient.ComponentSocketType.STRING_ARRAY))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(ListComponent.socketNames.models, _smallstack_coreClient.ComponentSocketType.OBJECT_ARRAY))
    .addSocket(_smallstack_coreClient.ComponentSocket.createOutput(ListComponent.socketNames.selectedEntry, _smallstack_coreClient.ComponentSocketType.OBJECT))
    .register();

var __extends$12 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ServiceQueryComponentController = (function (_super) {
    __extends$12(ServiceQueryComponentController, _super);
    function ServiceQueryComponentController() {
        var _this = _super.apply(this, arguments) || this;
        // private serviceName: string;
        // private queryName: string;
        // private parameters: string;
        // private options: string;
        _this.currentPage = 1;
        _this.entriesPerPage = 10;
        _this.reactive = false;
        return _this;
    }
    ServiceQueryComponentController.prototype.afterInitialization = function () {
        this.query();
    };
    ServiceQueryComponentController.prototype.onSocketEvent = function (socketName, socketData) {
        switch (socketName) {
            case ServiceQueryComponentController.socketNames.currentPage:
                this.currentPage = socketData;
                this.query();
                break;
        }
        // if (that.serviceName !== undefined && that.queryName !== undefined) {
        //     that.queryData(that.serviceName, that.queryName);
        // }
    };
    ServiceQueryComponentController.prototype.query = function () {
        var query = this.getData(ServiceQueryComponentController.configurationNames.query);
        this.entriesPerPage = this.getData(ServiceQueryComponentController.configurationNames.pageSize);
        this.reactive = this.getData(ServiceQueryComponentController.configurationNames.reactive);
        if (query !== undefined) {
            var querySplit = query.split(".");
            this.queryData(querySplit[0], querySplit[1], {}, { currentPage: this.currentPage, entriesPerPage: this.entriesPerPage, reactive: this.reactive });
        }
    };
    ServiceQueryComponentController.prototype.queryData = function (serviceName, queryName, parameters, options$$1, expands) {
        var _this = this;
        // send totals
        this.dataBridge.callMethod("server-counts", { queryName: queryName, parameters: parameters }, function (error$$1, result) {
            if (error$$1)
                _smallstack_coreCommon.NotificationService.instance().getStandardErrorPopup(error$$1, "Could not get total count for query!");
            else {
                _this.sendOutput(ServiceQueryComponentController.socketNames.totalCount, result);
                _this.sendOutput(ServiceQueryComponentController.socketNames.totalPages, Math.ceil(result / _this.entriesPerPage));
            }
        });
        // get the service
        if (serviceName === undefined)
            throw new Error("No Service Name given!");
        serviceName = _smallstack_coreCommon.Utils.decapitalize(serviceName);
        var evaluatedService = _smallstack_coreCommon.IOC.get(serviceName);
        if (evaluatedService === undefined)
            throw new Error("Service not found : " + serviceName);
        // get the method
        if (typeof evaluatedService[queryName] !== "function") {
            var getQueryName = "get" + _smallstack_coreCommon.Utils.capitalize(queryName);
            if (typeof evaluatedService[getQueryName] !== "function")
                throw new Error("Query not found : " + queryName + " or " + getQueryName);
            else
                queryName = getQueryName;
        }
        // evaluate parameters
        parameters = (parameters !== undefined && parameters !== "") ? parameters : {};
        _smallstack_coreCommon.Logger.debug("ServiceQueryComponentController", "   -> Parameters : ", parameters);
        // evaluate options
        options$$1 = (options$$1 !== undefined && options$$1 !== "") ? options$$1 : {};
        _smallstack_coreCommon.Logger.debug("ServiceQueryComponentController", "   -> Options : ", options$$1);
        // do some work
        var queryObject = evaluatedService[queryName](parameters, options$$1);
        queryObject.subscribe(function () {
            _this.reactiveOrNot(function () {
                if (expands !== undefined && expands !== "") {
                    // if (!(expands instanceof Array)) {
                    //     expands = expands.split(",");
                    // }
                    //    this.collectionsService.subscribeForeignKeys(evaluatedService.getCollection()["smallstackCollection"], queryObject.cursor, expands, () => {
                    //         this.sendOutput(ServiceQueryComponentController.socketNames.models, queryObject.vals());
                    //     });
                    throw new Error("NOT IMPLEMENTED YET!");
                }
                else
                    _this.sendOutput(ServiceQueryComponentController.socketNames.models, queryObject.getModels());
            });
        });
    };
    ServiceQueryComponentController.prototype.reactiveOrNot = function (fn) {
        if (this.reactive)
            this.dataBridge.reactiveContext(fn);
        else
            fn();
    };
    return ServiceQueryComponentController;
}(Angular2BaseComponentController));
ServiceQueryComponentController.configurationNames = {
    query: "query",
    pageSize: "pageSize",
    reactive: "reactive"
};
ServiceQueryComponentController.socketNames = {
    models: "models",
    currentPage: "currentPage",
    totalCount: "totalCount",
    totalPages: "totalPages",
};
_smallstack_coreCommon.IOC.onRegister("typesystem", function (typesystem) {
    var possibleTypes = [];
    _.each(typesystem.getAllTypes(), function (type) {
        if (type.service) {
            _.each(type.service.queries, function (query) {
                var serviceName = type.getServiceName();
                var queryName = serviceName + "." + query.name;
                if (serviceName === undefined)
                    _smallstack_coreCommon.Logger.error("QueryComponent", "service name is undefined for type: ", type);
                possibleTypes.push({ value: queryName, label: serviceName + "->" + query.name });
            });
        }
    });
    Angular2Component.new("ServiceQuery", ServiceQueryComponentController)
        .setLabel("Service Query")
        .setTemplate("<span>data query</span>")
        .setDescription("This component queries the database and sends smallstack models to other components!")
        .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createSelectConfiguration(ServiceQueryComponentController.configurationNames.query, undefined, possibleTypes))
        .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createNumberConfiguration(ServiceQueryComponentController.configurationNames.pageSize, 10))
        .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createBooleanConfiguration(ServiceQueryComponentController.configurationNames.reactive, false))
        .addSocket(_smallstack_coreClient.ComponentSocket.createOutput(ServiceQueryComponentController.socketNames.models, _smallstack_coreClient.ComponentSocketType.OBJECT_ARRAY))
        .addSocket(_smallstack_coreClient.ComponentSocket.createOutput(ServiceQueryComponentController.socketNames.totalCount, _smallstack_coreClient.ComponentSocketType.NUMBER))
        .addSocket(_smallstack_coreClient.ComponentSocket.createOutput(ServiceQueryComponentController.socketNames.totalPages, _smallstack_coreClient.ComponentSocketType.NUMBER))
        .addSocket(_smallstack_coreClient.ComponentSocket.createInput(ServiceQueryComponentController.socketNames.currentPage, _smallstack_coreClient.ComponentSocketType.NUMBER))
        .addTags(["data", "query", "internal"])
        .register();
});

var template$19 = "<div align=\"center\"><button class=\"btn btn-default\" [disabled]=\"!hasPrevious()\" (click)=\"previous()\"><span aria-hidden=\"true\">&laquo;</span></button> {{currentPage}} / {{pageCount}} <button class=\"btn btn-default\" [disabled]=\"!hasNext()\" (click)=\"next()\"><span aria-hidden=\"true\">&raquo;</span></button></div>";

var __extends$13 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ListPagerComponent = (function (_super) {
    __extends$13(ListPagerComponent, _super);
    function ListPagerComponent() {
        var _this = _super.apply(this, arguments) || this;
        _this.pageCount = 1;
        _this.currentPage = 1;
        return _this;
    }
    ListPagerComponent.prototype.onSocketEvent = function (socketName, socketData) {
        var _this = this;
        switch (socketName) {
            case ListPagerComponent.socketNames.pageCount:
                this.ngZone.run(function () {
                    _this.pageCount = socketData;
                });
                break;
            case ListPagerComponent.socketNames.currentPage:
                this.ngZone.run(function () {
                    _this.currentPage = socketData;
                });
                break;
        }
    };
    ListPagerComponent.prototype.selectPage = function (pageNumber) {
        this.currentPage = pageNumber;
        this.sendOutput(ListPagerComponent.socketNames.pageChange, pageNumber);
    };
    ListPagerComponent.prototype.getNumberArray = function (totalCount) {
        return new Array(totalCount);
    };
    ListPagerComponent.prototype.hasPrevious = function () {
        return this.currentPage > 1;
    };
    ListPagerComponent.prototype.hasNext = function () {
        return this.currentPage < this.pageCount;
    };
    ListPagerComponent.prototype.next = function () {
        if (this.hasNext())
            this.selectPage(this.currentPage + 1);
    };
    ListPagerComponent.prototype.previous = function () {
        if (this.hasPrevious())
            this.selectPage(this.currentPage - 1);
    };
    return ListPagerComponent;
}(Angular2BaseComponentController));
ListPagerComponent.configurationNames = {
    numbersCount: "numbersCount"
};
ListPagerComponent.socketNames = {
    currentPage: "currentPage",
    pageCount: "pageCount",
    pageChange: "pageChange"
};
Angular2Component.new("ListPager", ListPagerComponent)
    .setLabel("List Pager Component")
    .setTemplate(template$19)
    .setDescription("The Pager Component can be used as UI for the service query paging!")
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(ListPagerComponent.socketNames.pageCount, _smallstack_coreClient.ComponentSocketType.NUMBER))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(ListPagerComponent.socketNames.currentPage, _smallstack_coreClient.ComponentSocketType.NUMBER))
    .addSocket(_smallstack_coreClient.ComponentSocket.createOutput(ListPagerComponent.socketNames.pageChange, _smallstack_coreClient.ComponentSocketType.NUMBER))
    .register();

var template$20 = "<div class=\"loading-container\"><div class=\"loading-image\" ng-if=\"!image\"></div><img src=\"{{image}}\" ng-if=\"image\"><div class=\"loading-text\">{{text}}</div></div>";

var __extends$14 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var LoadingComponentController = (function (_super) {
    __extends$14(LoadingComponentController, _super);
    function LoadingComponentController() {
        return _super.apply(this, arguments) || this;
    }
    return LoadingComponentController;
}(_smallstack_coreClient.BaseComponentController));
Angular2Component.new("Loading", LoadingComponentController)
    .setTemplate(template$20)
    .setLabel("Loading")
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput("text", _smallstack_coreClient.ComponentSocketType.STRING))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput("image", _smallstack_coreClient.ComponentSocketType.STRING))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput("size", _smallstack_coreClient.ComponentSocketType.NUMBER))
    .setDescription("A Loading Circle")
    .register();

var SpacerComponent = (function () {
    function SpacerComponent() {
    }
    return SpacerComponent;
}());
Angular2Component.new("Spacer", SpacerComponent)
    .setTemplate("<div style='height:{{height}}px;display: inline-block;width:100%'></div>")
    .setLabel("Spacer")
    .setDescription("An invisible Spacer")
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput("height", _smallstack_coreClient.ComponentSocketType.STRING))
    .register();

var template$21 = "<div class=\"text-component\"><span *ngIf=\"text\">{{text}}</span> <span *ngIf=\"i18nKey\">{{i18nKey | translate}}</span></div>";

var __extends$15 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var TextComponent = (function (_super) {
    __extends$15(TextComponent, _super);
    function TextComponent() {
        return _super.apply(this, arguments) || this;
    }
    TextComponent.prototype.afterInitialization = function () {
        this.syncDataIfAvailable("i18nKey");
        this.syncDataIfAvailable("text");
    };
    TextComponent.prototype.onSocketEvent = function (socketName, socketData) {
        switch (socketName) {
            case TextComponent.sockets.i18nKey:
                this.i18nKey = socketData;
                break;
            case TextComponent.sockets.text:
                this.text = socketData;
                break;
        }
    };
    TextComponent.prototype.saveText = function () {
        this.saveData({ text: this.text, i18nKey: this.i18nKey });
    };
    return TextComponent;
}(Angular2BaseComponentController));
TextComponent.sockets = {
    i18nKey: "i18nKey",
    text: "text"
};
Angular2Component.new("TextComponent", TextComponent)
    .setTemplate(template$21)
    .setLabel("Text Field")
    .setDescription("A static text field!")
    .addTags(["element", "desktop", "mobile"])
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(TextComponent.sockets.i18nKey, _smallstack_coreClient.ComponentSocketType.STRING))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(TextComponent.sockets.text, _smallstack_coreClient.ComponentSocketType.STRING))
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createTextareaConfiguration(TextComponent.sockets.text, undefined))
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createStringConfiguration(TextComponent.sockets.i18nKey, undefined))
    .register();

var template$22 = "<div class=\"header-component\"><div class=\"header-component-text\"><TextComponent [id]=\"id\" [i18nKey]=\"i18nKey\" [text]=\"text\"></TextComponent></div></div>";

var style$2 = ".header-component {\n  height: 100px;\n  padding-top: 15px;\n  margin-bottom: 10px;\n  padding: 0.5rem 1rem; }\n\n.header-component-text {\n  font-size: 50px;\n  font-weight: 100;\n  overflow: hidden;\n  white-space: nowrap; }\n";

Angular2Component.new("PageHeader", Angular2BaseComponentController)
    .setTemplate(template$22)
    .setStyles([style$2])
    .setLabel("Page Header")
    .setDescription("Responsive header component!")
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(TextComponent.sockets.i18nKey, _smallstack_coreClient.ComponentSocketType.STRING))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(TextComponent.sockets.text, _smallstack_coreClient.ComponentSocketType.STRING))
    .register();

var template$23 = "<div><div *ngIf=\"stickyFooter && !isBackofficeMode()\" class=\"page-footer-bottom-spacer\" [ngStyle]=\"{'height': footerHeight + 'px'}\"></div><footer id=\"pageFooter\" class=\"page-footer\" [ngStyle]=\"{'height': footerHeight + 'px'}\" [ngClass]=\"{ 'page-footer-bottom': stickyFooter && !isBackofficeMode(), 'none': !stickyFooter  }\"><div [ngClass]=\"{'container': !isBackofficeMode()}\"><div class=\"row\"><ng-content></ng-content></div><div class=\"page-footer-version-text\" *ngIf=\"showVersions\">v{{versions.project}}, compile time : {{versions.compileDate | date : 'yyyy-MM-dd, HH:mm Z'}}, powered by <a target=\"_blank\" href=\"http://smallstack.io\">smallstack.io</a> v{{versions.smallstack}}</div></div></footer></div>";

var style$3 = ".page-footer {\n  width: 100%;\n  padding: 5px;\n  padding-right: 10px;\n  background-color: #292b2c;\n  color: #98978b;\n  border: none; }\n\n.page-footer-version-text {\n  margin-top: 20px;\n  font-size: 10px;\n  text-align: right;\n  position: relative;\n  bottom: 0px; }\n\n.page-footer-version-text a {\n  text-decoration: none; }\n\n.page-footer-bottom {\n  position: absolute;\n  bottom: 0px; }\n\n.page-footer-bottom-spacer {\n  margin-top: 20px; }\n";

var __extends$16 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var PageFooterComponent = (function (_super) {
    __extends$16(PageFooterComponent, _super);
    function PageFooterComponent() {
        var _this = _super.apply(this, arguments) || this;
        _this.stickyFooter = true;
        _this.footerHeight = 100;
        _this.showVersions = false;
        return _this;
        // public onPageChange(page: Page) {
        //     this.$timeout(() => {
        //         this.children = this.getChildren();
        //         console.log("set page footer children to : ", this.children);
        //     });
        // }
        // public onDrop(scope: any, componentName: string) {
        //     if (componentName) {
        //         Meteor.call("cms-components-createinstance", componentName, function (error: Meteor.Error, componentInstanceId: string) {
        //             if (error)
        //                 NotificationService.instance().getStandardErrorPopup(error);
        //             else {
        //                 scope.componentIds.push(componentInstanceId);
        //                 Meteor.call("setComponentData", scope.id, { children: scope.componentIds }, NotificationService.instance().getStandardCallback("Could not add child component to page footer!", "Successfully added child component to page footer!"));
        //                 scope.$apply();
        //             }
        //         });
        //     }
        // }
    }
    PageFooterComponent.prototype.afterInitialization = function () {
        this.syncDataIfAvailable(PageFooterComponent.configuration.stickyFooter);
        this.syncDataIfAvailable(PageFooterComponent.configuration.footerHeight);
        this.syncDataIfAvailable(PageFooterComponent.configuration.showVersions);
        var displayHeight = $$1(document).height();
        var footerTop = $$1('#pageFooter').offset().top;
        var footerHeight = $$1('#pageFooter').height();
        if ((footerTop + footerHeight) < displayHeight) {
            $$1('#pageFooter').addClass('page-footer-bottom');
        }
    };
    return PageFooterComponent;
}(Angular2BaseComponentController));
PageFooterComponent.configuration = {
    stickyFooter: "stickyFooter",
    footerHeight: "footerHeight",
    showVersions: "showVersion"
};
Angular2Component.new("PageFooter", PageFooterComponent)
    .setLabel("Page Footer")
    .setTemplate(template$23)
    .setStyles([style$3])
    .setDescription("Page Footer Component with optional version footer!")
    .addTags(["container", "desktop", "mobile"])
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createBooleanConfiguration(PageFooterComponent.configuration.stickyFooter, true))
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createStringConfiguration(PageFooterComponent.configuration.footerHeight, undefined))
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createBooleanConfiguration(PageFooterComponent.configuration.showVersions, true))
    .register();

var template$24 = "<div class=\"smallstack-onlinestatus text-center\" [ngClass]=\"{'offline' : (status ==='waiting'), 'connecting' : (status ==='connecting') }\" *ngIf=\"!connected\"><span>Connection lost to server!</span> <span *ngIf=\"status == 'waiting'\">Reconnecting in {{nextConnection}}s! <button (click)=\"reconnect()\" class=\"btn btn-xs\">Reconnect Now</button></span> <span *ngIf=\"status == 'connecting'\">Trying to connect...</span></div>";

var style$4 = ".smallstack-onlinestatus {\n  position: fixed;\n  bottom: 0px;\n  width: 100%;\n  text-align: center;\n  z-index: 50000;\n  font-size: 15px;\n  padding: 5px; }\n\n.smallstack-onlinestatus.offline {\n  background-color: #373737;\n  color: white; }\n\n.smallstack-onlinestatus.connecting {\n  background-color: rgba(220, 180, 10, 0.9);\n  color: rgba(0, 0, 0, 0.9); }\n\n.smallstack-onlinestatus .reconnect {\n  cursor: pointer; }\n";

var __extends$17 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var OnlineStatusComponent = (function (_super) {
    __extends$17(OnlineStatusComponent, _super);
    function OnlineStatusComponent() {
        return _super.apply(this, arguments) || this;
    }
    OnlineStatusComponent.prototype.afterInitialization = function () {
        var _this = this;
        var connectionTimer;
        Tracker.autorun(function () {
            var status = Meteor.status();
            _this.ngZone.run(function () {
                _this.connected = status["connected"];
                Meteor.clearInterval(connectionTimer);
                if (!_this.connected) {
                    _this.status = status.status;
                    connectionTimer = Meteor.setInterval(function () {
                        _this.ngZone.run(function () {
                            _this.nextConnection = Math.round((status.retryTime - (new Date()).getTime()) / 1000);
                        });
                    }, 1000);
                }
            });
        });
    };
    OnlineStatusComponent.prototype.reconnect = function () {
        Meteor.reconnect();
    };
    return OnlineStatusComponent;
}(Angular2BaseComponentController));
Angular2Component.new("OnlineStatus", OnlineStatusComponent)
    .setLabel("Online Status")
    .setDescription("Shows the current connection status!")
    .setTemplate(template$24)
    .setStyles([style$4])
    .register();

_smallstack_coreCommon.IOC.onRegister("localizationService", function (localizationService) {
    localizationService.addTranslation("de", {
        "components": {
            "login": {
                "login": "Anmelden",
                "headline": "Melden Sie sich mit Ihrem Account an",
                "mail": "E-Mail",
                "password": "Passwort",
                "notregistered": "Noch kein Konto?",
                "registerhere": "Hier registrieren!",
                "forgotpassword": "Passwort vergessen",
                "alreadyloggedin": "Sie sind bereits angemeldet!"
            },
            "register": {
                "headline": "Neues Konto anlegen",
                "confirmpassword": "Passwort bestätigen",
                "register": "Registrieren",
                "registered": "Bereits registriert?",
                "backtologin": "Hier geht's zur Anmeldung",
                "alreadyloggedin": "Sie sind derzeit bereits angemeldet. Falls Sie einen weiteren Benutzer registieren möchten, melden Sie sich bitte zuerst ab!"
            }
        }
    });
});

_smallstack_coreCommon.IOC.onRegister("localizationService", function (localizationService) {
    localizationService.addTranslation("en", {
        "components": {
            "login": {
                "login": "Login",
                "headline": "Sign into your account",
                "mail": "E-Mail",
                "password": "Password",
                "notregistered": "Not registered yet?",
                "registerhere": "Register here!",
                "forgotpassword": "Forgot password",
                "alreadyloggedin": "You are already logged in!"
            },
            "register": {
                "headline": "Add new account",
                "confirmpassword": "Confirm password",
                "register": "Register",
                "registered": "Already registered?",
                "backtologin": "Go to login",
                "alreadyloggedin": "You are currently logged in. If you want to register another user, please log out first!"
            }
        }
    });
});

var template$25 = "<div *ngIf=\"!isLoggedIn\" class=\"row\"><div *ngIf=\"showLogin\" [ngClass]=\"{'col-md-6': showRegistration, 'col-md-12' : !showRegistration}\"><div class=\"input-group mb-1\"><input class=\"form-control\" placeholder=\"{{'components.login.mail' | translate}}\" type=\"text\" [(ngModel)]=\"mail\"></div><div class=\"input-group mb-1\"><input class=\"form-control\" placeholder=\"{{'components.login.password' | translate}}\" type=\"password\" [(ngModel)]=\"password\"></div><div class=\"text-center\"><button class=\"btn btn-primary btn-block\" (click)=\"loginWithPassword(mail, password)\">{{\"components.login.login\" | translate}}</button></div><div class=\"text-center\"><p>{{\"components.login.notregistered\" | translate}} <a (click)=\"showRegistrationOverlay()\">{{\"components.login.registerhere\" | translate}}</a></p><p><a href=\"{{passwordResetLink}}\">{{\"components.login.forgotpassword\" | translate }}</a></p></div></div><div *ngIf=\"showRegistration\" [ngClass]=\"{'col-md-6': showLogin, 'col-md-12' : !showLogin}\"><div class=\"form-group\"><input type=\"email\" class=\"form-control\" [(ngModel)]=\"mail\" placeholder=\"{{'components.login.mail' | translate}}\"></div><div class=\"form-group\"><input type=\"password\" class=\"form-control\" [(ngModel)]=\"password\" placeholder=\"{{'components.login.password' | translate}}\"></div><div class=\"form-group\"><input type=\"password\" class=\"form-control\" [(ngModel)]=\"confirmpassword\" placeholder=\"{{'components.register.confirmpassword' | translate}}\"></div><div class=\"text-center\"><button class=\"btn btn-primary btn-block\" (click)=\"register(mail, password, confirmpassword)\">{{\"components.register.register\" | translate}}</button></div><div class=\"text-center\"><p>{{\"components.register.registered\" | translate}} <a (click)=\"showLoginOverlay()\">{{\"components.register.backtologin\" | translate}}</a></p><p><a href=\"{{passwordResetLink}}\">{{\"components.login.forgotpassword\" | translate }}</a></p></div></div><div *ngIf=\"!formOverlayActive && (isFacebookConfigured || isGoogleConfigured || isTwitterConfigured || isLinkedInConfigured)\" align=\"center\" class=\"row\"><div class=\"col-xs-offset-2 col-xs-8\"><a class=\"btn btn-block btn-social btn-github\" *ngIf=\"showLoginAsButton\" (click)=\"showLoginOverlay()\"><span class=\"fa fa-envelope\"></span> Email</a><hr></div><div class=\"col-xs-offset-2 col-xs-8\"><a class=\"btn btn-block btn-social btn-github\" *ngIf=\"showRegistrationAsButton\" (click)=\"showRegistrationOverlay()\"><span class=\"fa fa-envelope\"></span> Email</a><hr></div><div class=\"col-xs-offset-2 col-xs-8\"><a class=\"btn btn-block btn-social btn-facebook\" *ngIf=\"isFacebookConfigured\" (click)=\"loginWithFacebook()\"><span class=\"fa fa-facebook\"></span>Facebook</a></div><div class=\"col-xs-offset-2 col-xs-8\"><a class=\"btn btn-block btn-social btn-google\" *ngIf=\"isGoogleConfigured\" (click)=\"loginWithGoogle()\"><span class=\"fa fa-google\"></span>Google Plus</a></div><div class=\"col-xs-offset-2 col-xs-8\"><a class=\"btn btn-block btn-social btn-twitter\" *ngIf=\"isTwitterConfigured\" (click)=\"loginWithTwitter()\"><span class=\"fa fa-twitter\"></span>Twitter</a></div><div class=\"col-xs-offset-2 col-xs-8\"><a class=\"btn btn-block btn-social btn-linkedin\" *ngIf=\"isLinkedInConfigured\" (click)=\"loginWithLinkedIn()\"><span class=\"fa fa-linkedin\"></span>LinkedIn</a></div></div></div><div class=\"text-center\" *ngIf=\"isLoggedIn\"><h6>{{\"components.login.alreadyloggedin\" | translate}}</h6><button (click)=\"logout()\">Logout</button></div>";

var style$5 = "a {\n  cursor: pointer; }\n";

var __extends$18 = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var LoginComponent = (function (_super) {
    __extends$18(LoginComponent, _super);
    function LoginComponent() {
        var _this = _super.call(this) || this;
        _this.redirect = true;
        // private socialLoginOptions: any = Meteor.isMobile ? { "loginStyle": "redirect" } : {};
        _this.socialLoginOptions = { "loginStyle": "popup" };
        _this.configurationService = _smallstack_coreCommon.IOC.get("configurationService");
        return _this;
    }
    LoginComponent.prototype.afterInitialization = function () {
        var _this = this;
        this.syncDataIfAvailable(LoginComponent.configuration.showLogin);
        this.syncDataIfAvailable(LoginComponent.configuration.showLoginAsButton);
        this.syncDataIfAvailable(LoginComponent.configuration.showRegistration);
        this.syncDataIfAvailable(LoginComponent.configuration.showRegistrationAsButton);
        this.passwordResetLink = "/passwordreset";
        this.isEmailLoginAllowed = true;
        this.formOverlayActive = false;
        // social logins
        this.isFacebookConfigured = this.configurationService.get("login.facebook.isconfigured", "false") === "true";
        this.isGoogleConfigured = this.configurationService.get("login.google.isconfigured", "false") === "true";
        this.isTwitterConfigured = this.configurationService.get("login.twitter.isconfigured", "false") === "true";
        this.isLinkedInConfigured = this.configurationService.get("login.linkedin.isconfigured", "false") === "true";
        // isLoggedIn
        Tracker.autorun(function () {
            _this.ngZone.run(function () {
                _this.isLoggedIn = Meteor.userId() !== undefined && Meteor.userId() !== null;
            });
        });
    };
    LoginComponent.prototype.showRegistrationOverlay = function () {
        this.showLogin = false;
        this.formOverlayActive = true;
        this.showRegistration = true;
    };
    LoginComponent.prototype.showLoginOverlay = function () {
        this.showRegistration = false;
        this.formOverlayActive = true;
        this.showLogin = true;
    };
    LoginComponent.prototype.redirectAfterSuccessfulLogin = function () {
        var _this = this;
        this.ngZone.run(function () {
            var routeBeforeLogin = _this.dataBridge.getSessionVariable("routeBeforeLogin");
            if (routeBeforeLogin !== undefined) {
                _this.dataBridge.setSessionVariable("routeBeforeLogin", undefined);
                console.log("redirectAfterSuccessfulLogin redirect to : ", routeBeforeLogin);
                _this.router.navigate([routeBeforeLogin]);
            }
            else
                _this.router.navigate([_this.configurationService.get("login.success.redirect", _smallstack_coreCommon.NavigationService.instance().getDefaultNavigatioNentry().getRoute())]);
        });
    };
    LoginComponent.prototype.redirectAfterSuccessfulRegistration = function () {
        var _this = this;
        this.ngZone.run(function () {
            var routeBeforeRegistration = _this.dataBridge.getSessionVariable("routeBeforeRegistration");
            if (routeBeforeRegistration !== undefined) {
                _this.dataBridge.setSessionVariable("routeBeforeRegistration", undefined);
                console.log("redirectAfterSuccessfulLogin redirect to : ", routeBeforeRegistration);
                _this.router.navigate([routeBeforeRegistration]);
            }
            else
                _this.router.navigate([_this.configurationService.get("registration.success.redirect", _smallstack_coreCommon.NavigationService.instance().getDefaultNavigatioNentry().getRoute())]);
        });
    };
    LoginComponent.prototype.register = function (mail, password, confirmpassword) {
        var _this = this;
        if (_smallstack_coreCommon.Utils.isNonEmptyString(mail) && _smallstack_coreCommon.Utils.isNonEmptyString(password)) {
            if (password !== confirmpassword) {
                this.notificationService.popup.error("Passwords don't match!");
                return;
            }
            try {
                Accounts.createUser({
                    email: mail,
                    password: password,
                    profile: {
                        displayName: mail
                    }
                }, function (e) {
                    if (e) {
                        console.error(e);
                        _this.notificationService.getStandardErrorPopup(e, "Error while registering new user!");
                    }
                    else
                        _this.redirectAfterSuccessfulRegistration();
                });
            }
            catch (e) {
                console.error(e);
                this.notificationService.getStandardErrorPopup(e, "Error while registering new user!");
            }
        }
        else {
            this.notificationService.popup.error("Please fill out E-Mail and Password!");
        }
    };
    LoginComponent.prototype.loginWithPassword = function () {
        var _this = this;
        if (_smallstack_coreCommon.Utils.isNonEmptyString(this.mail) && _smallstack_coreCommon.Utils.isNonEmptyString(this.password)) {
            Meteor.loginWithPassword(this.mail, this.password, function (error$$1) {
                if (error$$1)
                    _this.notificationService.getStandardErrorPopup(error$$1);
                else if (_this.redirect !== false)
                    _this.redirectAfterSuccessfulLogin();
            });
        }
        else {
            this.notificationService.popup.error("Please fill out E-Mail and Password!");
        }
    };
    LoginComponent.prototype.loginWithFacebook = function (redirect) {
        var _this = this;
        Meteor.loginWithFacebook(this.socialLoginOptions, function (error$$1) {
            if (error$$1)
                _this.notificationService.getStandardErrorPopup(error$$1, "Could not login via Facebook!");
            else if (redirect !== false)
                _this.redirectAfterSuccessfulLogin();
        });
    };
    LoginComponent.prototype.loginWithGoogle = function (redirect) {
        var _this = this;
        Meteor.loginWithGoogle(this.socialLoginOptions, function (error$$1) {
            if (error$$1)
                _this.notificationService.getStandardErrorPopup(error$$1, "Could not login via Google!");
            else if (redirect !== false)
                _this.redirectAfterSuccessfulLogin();
        });
    };
    LoginComponent.prototype.loginWithTwitter = function (redirect) {
        var _this = this;
        Meteor.loginWithTwitter(this.socialLoginOptions, function (error$$1) {
            if (error$$1)
                _this.notificationService.getStandardErrorPopup(error$$1, "Could not login via Twitter!");
            else if (redirect !== false)
                _this.redirectAfterSuccessfulLogin();
        });
    };
    LoginComponent.prototype.loginWithLinkedIn = function (redirect) {
        var _this = this;
        Meteor["loginWithLinkedIn"](this.socialLoginOptions, (function (error$$1, success$$1) {
            if (error$$1) {
                console.error('Login error - ', error$$1);
                _this.notificationService.getStandardErrorPopup(error$$1, "Could not login via LinkedIn!");
            }
            else {
                if (redirect !== false)
                    _this.redirectAfterSuccessfulLogin();
            }
        }));
    };
    LoginComponent.prototype.logout = function () {
        Meteor.logout();
    };
    return LoginComponent;
}(Angular2BaseComponentController));
LoginComponent.configuration = {
    // passwordResetLink: "passwordResetLink",
    // emailLoginAllowed: "emailLoginAllowed",
    // emailLogin: "emailLogin"
    showLogin: "showLogin",
    showLoginAsButton: "showLoginAsButton",
    showRegistration: "showRegistration",
    showRegistrationAsButton: "showRegistrationAsButton",
};
Angular2Component.new("Login", LoginComponent)
    .setLabel("Login Form")
    .setDescription("Standard Login Form")
    .setTemplate(template$25)
    .setStyles([style$5])
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createBooleanConfiguration(LoginComponent.configuration.showLogin, true))
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createBooleanConfiguration(LoginComponent.configuration.showLoginAsButton, true))
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createBooleanConfiguration(LoginComponent.configuration.showRegistration, false))
    .addConfiguration(_smallstack_coreClient.ComponentConfiguration.createBooleanConfiguration(LoginComponent.configuration.showRegistrationAsButton, false))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(LoginComponent.configuration.showLogin, _smallstack_coreClient.ComponentSocketType.BOOLEAN))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(LoginComponent.configuration.showLoginAsButton, _smallstack_coreClient.ComponentSocketType.BOOLEAN))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(LoginComponent.configuration.showRegistration, _smallstack_coreClient.ComponentSocketType.BOOLEAN))
    .addSocket(_smallstack_coreClient.ComponentSocket.createInput(LoginComponent.configuration.showRegistrationAsButton, _smallstack_coreClient.ComponentSocketType.BOOLEAN))
    .register();

// components

exports.initMeteorClient = initMeteorClient$$1;
exports.getAngular2Declarations = getAngular2Declarations$$1;
exports.Angular2Router = Angular2Router;
exports.Angular2Component = Angular2Component;
exports.Angular2BaseComponentController = Angular2BaseComponentController;
exports.Angular2RootModule = Angular2RootModule$$1;
exports.bootstrapAngular = bootstrapAngular$$1;
exports.NAV_DROPDOWN_DIRECTIVES = NAV_DROPDOWN_DIRECTIVES;
exports.SIDEBAR_TOGGLE_DIRECTIVES = SIDEBAR_TOGGLE_DIRECTIVES;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=client.umd.js.map
