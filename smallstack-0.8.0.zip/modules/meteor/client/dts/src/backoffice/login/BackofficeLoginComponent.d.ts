export declare class BackofficeLoginComponent {
    constructor();
}
