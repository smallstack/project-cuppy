/**
* Allows the aside to be toggled via click.
*/
export declare class AsideToggleDirective {
    constructor();
    toggleOpen($event: any): void;
}
