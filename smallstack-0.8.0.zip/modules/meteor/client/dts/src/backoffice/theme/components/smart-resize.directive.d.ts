/**
* Smart body resize
*/
export declare class SmartResizeDirective {
    private hasClass(target, elementClassName);
    private body;
    private html;
    private height;
    constructor();
    onResize(event: any): void;
}
