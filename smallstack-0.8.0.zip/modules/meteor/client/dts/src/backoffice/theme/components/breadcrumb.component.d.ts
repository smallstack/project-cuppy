import { Router, ActivatedRoute } from '@angular/router';
export declare class BreadcrumbsComponent {
    private router;
    private route;
    breadcrumbs: Array<Object>;
    constructor(router: Router, route: ActivatedRoute);
    ngOnInit(): void;
}
