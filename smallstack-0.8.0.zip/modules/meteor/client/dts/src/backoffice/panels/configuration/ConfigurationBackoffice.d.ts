import { Configuration } from "@smallstack/core-common";
import { Angular2BaseComponentController } from "../../../../client";
export declare class ConfigurationBackoffice extends Angular2BaseComponentController {
    private configurationService;
    configurations: Configuration[];
    newConfiguration: Configuration;
    constructor();
    loadConfiguration(): void;
    saveConfiguration(key: string, value: string, scope: string): void;
}
