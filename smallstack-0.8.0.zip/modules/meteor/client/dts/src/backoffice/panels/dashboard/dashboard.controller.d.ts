import { InitializationAware } from "@smallstack/core-client";
import { Angular2BaseComponentController } from "../../../../client";
export declare class BackofficeDashboardController extends Angular2BaseComponentController implements InitializationAware {
    statistics: any;
    statisticsLoading: boolean;
    afterInitialization(): void;
    doPing(): void;
}
