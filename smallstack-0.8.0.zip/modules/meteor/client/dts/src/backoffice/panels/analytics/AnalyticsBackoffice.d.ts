import { Angular2BaseComponentController } from "../../../../client";
export declare class AnalyticsPanelController extends Angular2BaseComponentController {
    private configurationService;
    gaTrackingId: string;
    constructor();
    saveTracking(): void;
}
