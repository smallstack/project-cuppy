import { NgZone } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import "./i18n";
export declare class CollectionsPanelComponent {
    private ngZone;
    private router;
    private route;
    private notificationService;
    private dataBridge;
    collections: {
        count: number;
        name: string;
    }[];
    constructor(ngZone: NgZone, router: Router, route: ActivatedRoute);
}
