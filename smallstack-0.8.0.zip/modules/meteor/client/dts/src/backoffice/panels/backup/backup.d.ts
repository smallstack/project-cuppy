import { Angular2BaseComponentController } from "../../../../client";
import { InitializationAware } from "@smallstack/core-client";
export declare class BackupPanelController extends Angular2BaseComponentController implements InitializationAware {
    allCollections: any[];
    backupCollectionNames: {
        [collectionName: string]: boolean;
    };
    backupAvailable: boolean;
    restoreCollectionNames: {
        [collectionName: string]: boolean;
    };
    restoreCurrentCollectionNames: string[];
    restoreFile: any;
    restoreFileName: string;
    restoreLogs: any;
    restorePerformed: boolean;
    dropCollections: boolean;
    afterInitialization(): void;
    getCollectionCountFor(collectionName: string): number;
    createBackup(): void;
    selectAll(): void;
    selectNone(): void;
    toggleRestoreCheckboxes(event: any): void;
    uploadFile(event: any): void;
    restoreBackup(): void;
}
