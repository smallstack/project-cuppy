import { Type } from "@smallstack/core-common";
import { NgZone } from "@angular/core";
import { Router } from "@angular/router";
import "./i18n";
export declare class CollectionPanelComponent {
    private ngZone;
    private router;
    private typesystem;
    private eventService;
    private collectionsService;
    private dataBridge;
    collectionName: string;
    searchText: string;
    type: Type;
    models: any[];
    keys: string[];
    searchError: string;
    currentModel: any;
    constructor(ngZone: NgZone, router: Router);
    searchModels(): void;
    private evaluateSearchResult(models);
    prettyPrint(object: any): string;
    loadModel(model: any): void;
    saveModel(): void;
    removeModel(): void;
    createNewModel(): void;
}
