import { Page, InitializationAware } from "@smallstack/core-client";
import { Role } from "@smallstack/core-common";
import { Angular2BaseComponentController } from "../../../../client";
export declare class DynamicModulePanelController extends Angular2BaseComponentController implements InitializationAware {
    dynModule: any;
    pages: Page[];
    roles: Role[];
    afterInitialization(): void;
    createDynamicModule(): void;
}
