import { NgZone } from "@angular/core";
export declare class SocialNetworkBackofficeController {
    private notificationService;
    rootUrl: string;
    facebookAppId: string;
    facebookSecret: string;
    googleClientId: string;
    googleSecret: string;
    twitterConsumerKey: string;
    twitterSecret: string;
    linkedInClientId: string;
    linkedInSecret: string;
    private dataBridge;
    constructor(ngZone: NgZone);
    saveFacebook(): void;
    saveTwitter(): void;
    saveGoogle(): void;
    saveLinkedIn(): void;
}
