import { NgZone } from "@angular/core";
export declare class UsersBackofficeController {
    private ngZone;
    private selectedUser;
    private dataBridge;
    constructor(ngZone: NgZone);
    getUser(userString: any): any;
    setPassword(userId: string, newPassword: string): void;
    addRole(userId: string, newRole: string): void;
    createUser(newUser: any): void;
    hasSelectedUser(): boolean;
}
