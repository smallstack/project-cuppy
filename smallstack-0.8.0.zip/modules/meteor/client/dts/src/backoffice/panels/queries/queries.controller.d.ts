export declare class QueriesBackofficeController {
    private dataBridge;
    contentType: string;
    constructor();
    addQuery(path: string, contentType: string, response: string): void;
}
