import { OnInit, NgZone, OnDestroy } from "@angular/core";
import { Router } from "@angular/router";
import { NavigationEntry } from "@smallstack/core-common";
import { User } from "@smallstack/core-common";
export declare class BackofficeComponent implements OnInit, OnDestroy {
    private ngZone;
    private router;
    private dataBridge;
    private configurationService;
    private userService;
    private navigationService;
    private rolesService;
    projectName: string;
    applicationName: string;
    navigationEntries: NavigationEntry[];
    currentUser: User;
    isLoading: boolean;
    constructor(ngZone: NgZone, router: Router);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private loadNavigationEntries();
    isNavigationEntryActive(entry: NavigationEntry): void;
    getSubEntries(entry: NavigationEntry): NavigationEntry[];
    logout(): void;
    hasRole(role: string): boolean;
}
