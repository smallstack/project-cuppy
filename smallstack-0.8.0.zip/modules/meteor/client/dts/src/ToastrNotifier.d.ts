import { INotifier } from "@smallstack/core-common";
export declare class ToastrNotifier implements INotifier {
    constructor();
    private getOptions();
    private log(title, message, level);
    info(title: string, message?: string): void;
    success(title: string, message?: string): void;
    debug(title: string, message?: string): void;
    warn(title: string, message?: string): void;
    error(title: string, message?: string): void;
    confirmation(title: string, message: string, callback: any): void;
}
