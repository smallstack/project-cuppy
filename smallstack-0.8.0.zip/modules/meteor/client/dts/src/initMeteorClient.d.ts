export declare function initMeteorClient(): void;
export declare function getAngular2Declarations(): any[];
