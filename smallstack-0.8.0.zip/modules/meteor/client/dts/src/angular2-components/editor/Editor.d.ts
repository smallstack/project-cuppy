import { Angular2BaseComponentController } from "../../../client";
import { InitializationAware } from "@smallstack/core-client";
import { Type, SmallstackModel } from "@smallstack/core-common";
export declare class Editor extends Angular2BaseComponentController implements InitializationAware {
    private typesystem;
    static socketNames: {
        typeName: string;
        type: string;
        id: string;
        model: string;
        output: string;
    };
    static configurationNames: {
        typeName: string;
        type: string;
        emptyMessage: string;
        showModelPreview: string;
        fieldsToShow: string;
        updateMethod: string;
        updateMethodName: string;
    };
    private id;
    private fieldsToShow;
    currentModel: SmallstackModel;
    updateMethod: string;
    updateMethodName: string;
    emptyMessage: string;
    showModelPreview: boolean;
    typeName: string;
    type: Type;
    schema: any;
    editorContent: string;
    fields: string[];
    constructor();
    afterInitialization(): void;
    onSocketEvent(socketName: string, socketData: any): void;
    handleOutput(formJson: any): void;
    private evaluateType();
    private loadModel(id);
    updateModel(): void;
}
