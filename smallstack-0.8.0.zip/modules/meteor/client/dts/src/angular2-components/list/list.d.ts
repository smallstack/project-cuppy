import { TemplateRef, ViewContainerRef } from "@angular/core";
import { Angular2BaseComponentController } from "../../../client";
import { SocketEventAware } from "@smallstack/core-client";
import { InitializationAware } from "@smallstack/core-client";
import { SmallstackModel } from "@smallstack/core-common";
export declare class ListEntry extends Angular2BaseComponentController {
}
export declare class ListComponent extends Angular2BaseComponentController implements InitializationAware, SocketEventAware {
    models: any[];
    fields: string[];
    entryTemplate: TemplateRef<any>;
    listEntriesContainer: ViewContainerRef;
    static configurationNames: {
        templateUrl: string;
        emptyMessage: string;
    };
    static socketNames: {
        models: string;
        selectedEntry: string;
        fields: string;
    };
    renderEntryTemplates(models: any[]): void;
    afterInitialization(): void;
    onSocketEvent(socketName: string, socketData: any): void;
    selectEntry(entry: any): void;
    setModels(models: SmallstackModel[]): void;
}
