export declare class ComponentDirective {
    private pagesService;
    restrict: string;
    scope: {
        componentId: string;
    };
    constructor();
}
