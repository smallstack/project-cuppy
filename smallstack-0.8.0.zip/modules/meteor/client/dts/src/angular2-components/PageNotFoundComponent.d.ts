export declare class PageNotFoundComponent {
}
