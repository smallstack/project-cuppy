import { Angular2BaseComponentController } from "../../../client";
import { SocketEventAware } from "@smallstack/core-client";
export declare class ListPagerComponent extends Angular2BaseComponentController implements SocketEventAware {
    static configurationNames: {
        numbersCount: string;
    };
    static socketNames: {
        currentPage: string;
        pageCount: string;
        pageChange: string;
    };
    pageCount: number;
    currentPage: number;
    onSocketEvent(socketName: string, socketData: any): void;
    selectPage(pageNumber: any): void;
    getNumberArray(totalCount: number): any[];
    hasPrevious(): boolean;
    hasNext(): boolean;
    next(): void;
    previous(): void;
}
