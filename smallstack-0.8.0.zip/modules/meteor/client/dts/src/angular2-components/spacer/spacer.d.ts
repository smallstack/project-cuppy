export declare class SpacerComponent {
}
