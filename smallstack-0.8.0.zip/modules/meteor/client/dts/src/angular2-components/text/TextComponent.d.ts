import { Angular2BaseComponentController } from "../../../client";
export declare class TextComponent extends Angular2BaseComponentController {
    static sockets: {
        i18nKey: string;
        text: string;
    };
    i18nKey: string;
    text: string;
    afterInitialization(): void;
    onSocketEvent(socketName: string, socketData: any): void;
    saveText(): void;
}
