import { Angular2BaseComponentController } from "../../../client";
import { InitializationAware } from "@smallstack/core-client";
export declare class OnlineStatusComponent extends Angular2BaseComponentController implements InitializationAware {
    connected: boolean;
    status: string;
    nextConnection: number;
    timer: any;
    $meteorAutorun: Function;
    afterInitialization(): void;
    reconnect(): void;
}
