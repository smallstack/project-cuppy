import { Angular2BaseComponentController } from "../../../client";
import { InitializationAware, SocketEventAware } from "@smallstack/core-client";
export declare class ServiceQueryComponentController extends Angular2BaseComponentController implements SocketEventAware, InitializationAware {
    static configurationNames: {
        query: string;
        pageSize: string;
        reactive: string;
    };
    static socketNames: {
        models: string;
        currentPage: string;
        totalCount: string;
        totalPages: string;
    };
    private currentPage;
    private entriesPerPage;
    private reactive;
    afterInitialization(): void;
    onSocketEvent(socketName: string, socketData: any): void;
    private query();
    private queryData(serviceName, queryName, parameters?, options?, expands?);
    private reactiveOrNot(fn);
}
