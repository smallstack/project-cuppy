import { BaseComponentController } from "@smallstack/core-client";
export declare class LoadingComponentController extends BaseComponentController {
}
