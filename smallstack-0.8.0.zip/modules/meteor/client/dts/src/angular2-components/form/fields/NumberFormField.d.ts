import { BaseFormField } from './BaseFormField';
export declare class NumberFormField extends BaseFormField {
}
