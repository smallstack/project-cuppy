import { BaseFormField } from './BaseFormField';
export declare class ObjectFormField extends BaseFormField {
}
