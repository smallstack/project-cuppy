import { OnChanges, EventEmitter, AfterContentInit, QueryList } from '@angular/core';
import { SmallstackModel } from "@smallstack/core-common";
import { EntityFormField } from './EntityFormField';
export declare class EntityForm implements AfterContentInit, OnChanges {
    private typesystem;
    model: SmallstackModel;
    onSubmit: EventEmitter<{}>;
    fields: QueryList<EntityFormField>;
    private changes;
    ngAfterContentInit(): void;
    ngOnChanges(): void;
    doSubmit(): boolean;
    constructor();
    private processForm();
}
