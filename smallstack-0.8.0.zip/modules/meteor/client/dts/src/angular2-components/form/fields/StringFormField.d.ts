import { BaseFormField } from './BaseFormField';
export declare class StringFormField extends BaseFormField {
}
