import { Type } from "@smallstack/core-common";
export declare class EntityFormField {
    onChangeCallback: Function;
    name: string;
    type: Type;
    schemaFieldName: string;
    value: any;
    editor: string;
    setType(type: Type, schemaFieldName: string): void;
    setValue(value: any): void;
    onChange(newValue: any): void;
}
