import { EventEmitter } from "@angular/core";
import { Type } from "@smallstack/core-common";
export declare class BaseFormField {
    private localizationService;
    value: any;
    type: Type;
    schemaFieldName: string;
    onChange: EventEmitter<{}>;
    label: string;
    placeholder: string;
    helptext: string;
    ngOnChanges(changes: any): void;
    valueChanged(newValue: any): void;
}
