import { Angular2BaseComponentController } from "../../../client";
export declare class PageFooterComponent extends Angular2BaseComponentController {
    static configuration: {
        stickyFooter: string;
        footerHeight: string;
        showVersions: string;
    };
    stickyFooter: boolean;
    footerHeight: number;
    showVersions: boolean;
    afterInitialization(): void;
}
