import { ErrorHandler } from "@angular/core";
export declare class Angular2ErrorHandler implements ErrorHandler {
    handleError(error: any): boolean;
}
