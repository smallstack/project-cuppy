import { PipeTransform } from "@angular/core";
export declare class TranslatePipe implements PipeTransform {
    private localizationService;
    transform(i18nKey: string): string;
}
