import { PipeTransform } from '@angular/core';
export declare class I18nPipe implements PipeTransform {
    private localizationService;
    constructor();
    transform(i18nObject: any): string;
}
