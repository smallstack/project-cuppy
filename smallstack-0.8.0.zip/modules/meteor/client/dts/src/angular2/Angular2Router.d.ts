import { NavigationEntry } from "@smallstack/core-common";
import { ModuleWithProviders } from "@angular/core";
export declare class Angular2Router {
    private navigationService;
    private routes;
    constructor();
    getRouterModule(): ModuleWithProviders;
    addAngularRoute(navigationEntry: NavigationEntry): void;
    private getRouteByRoute(routePath, routes?);
}
