export declare function Angular2RootModule(bootstrapComponent: any, additionalComponents: any[]): any;
export declare function bootstrapAngular(rootComponent: any, additionalComponents: any[], callback: () => void): void;
