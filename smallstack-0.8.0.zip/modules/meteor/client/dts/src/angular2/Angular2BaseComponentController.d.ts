import { OnInit, OnDestroy, OnChanges, NgZone, Injector, SimpleChanges } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { DataBridge } from "@smallstack/core-common";
import { BaseComponentController, Component, SocketEventAware } from "@smallstack/core-client";
export declare class Angular2BaseComponentController extends BaseComponentController implements OnInit, OnDestroy, OnChanges, SocketEventAware {
    data: any;
    componentId: string;
    protected injector: Injector;
    protected ngZone: NgZone;
    protected dataBridge: DataBridge;
    protected router: Router;
    protected route: ActivatedRoute;
    private routeCallbacks;
    private subscriptions;
    constructor();
    onCurrentRoute(callback: (route: ActivatedRoute) => void): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    getRouteParameter(parameterName: string, callback: (value: string) => void): void;
    onSocketEvent(socketName: string, socketData: any): void;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Synchronizes data from the components data storage to the current controller if data is available.
     * Use {localKey} if the property on the controller should have a different name than the data key!
     */
    syncDataIfAvailable(dataKey: string, localKey?: string): void;
    /**
     * Synchronizes data from the components data storage to the current controller.
     * Use {@param localKey} if the property on the controller should have a different name than the data key!
     */
    syncData(dataKey: string, localKey?: string): void;
    getComponent(): Component<any>;
    getComponentName(): string;
    sendOutput(socketName: string, socketData: any): void;
}
