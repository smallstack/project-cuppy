import { Component, ComponentType } from "@smallstack/core-client";
export declare class Angular2Component extends Component<Angular2Component> {
    component: any;
    template: any;
    styles: any;
    initializeAngularComponent: boolean;
    static new(componentName: string, component: any): Angular2Component;
    constructor(componentName: string, component: any);
    setTemplate(template: any): Angular2Component;
    setStyles(styles: any): Angular2Component;
    setInitializeAngularComponent(initializeAngularComponent: boolean): Angular2Component;
    getType(): ComponentType;
    instantiate(): void;
    register(): void;
}
