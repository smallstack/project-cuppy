import { MediaService, MediaFormat, Media } from "@smallstack/core-common";
export declare class S3MediaService extends MediaService {
    private region;
    private keyId;
    private accessKey;
    private bucketName;
    private s3;
    constructor();
    private tryS3Init();
    getUrlForMediaId(mediaId: string, mediaFormatName: string): string;
    storeMediaFromDataUrl(media: Media, dataUrlString: string, mediaFormat: MediaFormat): boolean;
    storeMediaFromURL(media: Media, url: string, mediaFormat: MediaFormat): boolean;
    storeMedia(media: Media, typedBuffer: any, mediaFormat: MediaFormat): boolean;
    convertMedia(media: Media, fromFormat: MediaFormat, toFormat: MediaFormat): void;
    removeMediaFormat(media: Media, mediaFormatName: string): void;
    removeMedia(media: Media): void;
}
