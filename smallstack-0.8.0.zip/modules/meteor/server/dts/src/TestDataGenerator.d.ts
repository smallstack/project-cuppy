import { Media } from "@smallstack/core-common";
import { User, Address } from "@smallstack/core-common";
export declare class TestDataGenerator {
    private mediaService;
    private userService;
    static teamNames: string[];
    static zipCodesMunich: number[];
    /**
     * @param {Function} afterCreationCallback Will be called with the new userId as parameter after the user was created
     */
    createTestUser(): User;
    createMediaFromUrl(ownerId: string, url: string, formats: string[]): Media;
    getRandomUserIds(count: number, withoutIds?: string[]): string[];
    getRandomTeamName(withoutNames?: string[]): string;
    getRandomZipCode(): number;
    getRandomAddress(): Address;
    getRandomCompanyName(): string;
    getRandomCompanyType(): string;
}
