export declare function createDefaultAdministrator(): void;
