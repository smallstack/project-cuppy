export declare function configureAWS(): void;
export declare function initMeteorServer(): void;
