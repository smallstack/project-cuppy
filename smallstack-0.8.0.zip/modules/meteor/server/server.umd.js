(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@smallstack/core-common'), require('chance'), require('request'), require('underscore'), require('aws-sdk')) :
	typeof define === 'function' && define.amd ? define(['exports', '@smallstack/core-common', 'chance', 'request', 'underscore', 'aws-sdk'], factory) :
	(factory((global['smallstack-meteor-server'] = global['smallstack-meteor-server'] || {}),global._smallstack_coreCommon,global.Chance,global.request,global.underscore,global.AWS));
}(this, (function (exports,_smallstack_coreCommon,Chance,request,_,AWS) { 'use strict';

function createDefaultAdministrator() {
    Meteor.startup(function () {
        if (Meteor.users.find().count() === 0) {
            _smallstack_coreCommon.IOC.onRegister("rolesService", function (rolesService) {
                var administratorRole = rolesService.getRoleByName({ name: "administrator" }).getModels()[0];
                if (!administratorRole)
                    administratorRole = rolesService.createRole("administrator");
                var userId = Accounts.createUser({
                    username: "admin",
                    email: "admin@smallstack.io",
                    password: "nimda",
                    profile: {
                        displayName: "Super Admin"
                    }
                });
                Meteor.users.update(userId, {
                    $set: {
                        roleIds: [administratorRole.id]
                    }
                });
                _smallstack_coreCommon.Logger.info("DefaultAdmin", "Created Administrator Account : admin@smallstack.io/nimda");
            });
        }
    });
}

var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TestDataGenerator = (function () {
    function TestDataGenerator() {
    }
    /**
     * @param {Function} afterCreationCallback Will be called with the new userId as parameter after the user was created
     */
    TestDataGenerator.prototype.createTestUser = function () {
        var chance = new Chance();
        var firstName = chance.first();
        var lastName = chance.last();
        var name = firstName + " " + lastName;
        var email = firstName + "_" + lastName + "_" + _.random(3, 4000000) + "@smallstack.io";
        var avatarUrl = this.userService.getDefaultAvatarUrl();
        try {
            var response = request.get("http://uifaces.com/api/v1/random");
            avatarUrl = response.data.image_urls.epic;
        }
        catch (e) { }
        // create the user
        var userId = Accounts.createUser({
            email: email,
            password: "demouser",
            profile: {
                displayName: name,
                firstName: firstName,
                lastName: lastName,
                avatarUrl: avatarUrl,
                isTestUser: true
            }
        });
        return this.userService.getUserById({ id: userId }).getModels()[0];
    };
    TestDataGenerator.prototype.createMediaFromUrl = function (ownerId, url, formats) {
        var _this = this;
        var media = new _smallstack_coreCommon.Media();
        media.ownerId = ownerId;
        media.createdAt = new Date();
        var savedMediaId = this.mediaService.save(media);
        var savedMedia = this.mediaService.getMediaById({ id: savedMediaId }).getModels()[0];
        _.each(formats, function (format) {
            _this.mediaService.storeMediaFromURL(savedMedia, url, _smallstack_coreCommon.MediaFormat.byName(format));
        });
        return savedMedia;
    };
    TestDataGenerator.prototype.getRandomUserIds = function (count, withoutIds) {
        var someRands = [];
        this.userService.getAllUsers().getModels().forEach(function (user) {
            if (someRands.length < count) {
                if (!_.contains(withoutIds, user.id) && !_.contains(someRands, user.id))
                    someRands.push(user.id);
            }
        });
        return someRands;
    };
    TestDataGenerator.prototype.getRandomTeamName = function (withoutNames) {
        var athousand = 0;
        var randName = undefined;
        do {
            athousand++;
            randName = _.sample(TestDataGenerator.teamNames);
            if (withoutNames === undefined || !_.contains(withoutNames, randName))
                return randName;
        } while (athousand < 1000);
        return "no team name";
    };
    TestDataGenerator.prototype.getRandomZipCode = function () {
        return _.sample(TestDataGenerator.zipCodesMunich);
    };
    TestDataGenerator.prototype.getRandomAddress = function () {
        var chance = new Chance();
        var address = new _smallstack_coreCommon.Address();
        address.city = chance.city();
        address.street = chance.street({ country: "de" });
        address.streetNumber = _.random(1, 500) + _.sample(["", "", "", "", "", "", "", "", "a", "b", "c"]);
        address.zip = this.getRandomZipCode();
        return address;
    };
    TestDataGenerator.prototype.getRandomCompanyName = function () {
        return _.sample(TestDataGenerator.teamNames) + " " + this.getRandomCompanyType();
    };
    TestDataGenerator.prototype.getRandomCompanyType = function () {
        return _.sample(["Inc", "AG", "GmbH", "Limited", "UG", "OHG", "Ltd.", "GbR"]);
    };
    return TestDataGenerator;
}());
TestDataGenerator.teamNames = ["Brutal Giants", "Hard Chargers", "Malevolent $4.99ers", "Cold Toes", "Husky Dingleberries", "Frodo’s Landscapers", "Bombadils’ Ranchers", "Blundering Professional Whistlers", "Unfair Bastards", "Cruel Bartenders", "Team A-N-N-A", "The Extendables", "The Expendables", "The Pretendables", "Thunder Chicken", "Roaring Kiwi Muddlers", "Farting Worms", "Yelling Blue Tits", "Columbia Bananaquits", "Jumbo Cuckoos", "Infantile Great Bustards", "Multiple Scorgasms", "Victorious Secret", "Big Test Icicles", "The Abusement Park", "Wii Not Fit", "Smokin Trees & Strokin 3s", "Scared Hitless", "Here for Beer", "Wacky Waving Inflatable Flailing Arm Tube Men", "Fire Breathing Rubber Duckies", "Cuban Raft Riders", "Designated Drinkers", "The Mighty Morphin Flower Arrangers", "Cunning Stunts", "The Master Batters", "Team Knight Rider", "Coconut Buts", "Norfolk-in-Chance", "The Muffin Stuffers", "Cow Tipping Dwarfs", "Viscious and Delicious", "Team 42", "The Flaming Pink Flamingos", "Legionnaires", "The A Team", "Oblivion", "Penalty Box Heroes", "Got The Runs", "Wolverines", "Bone Crushin Ballerinas", "Kamikaze Kangaroos", "Golden Gladiators", "Legion of Doom", "Wii Unfit", "Bad News Badgers", "Holy Rollers", "Degenerates 101", "Team Omega", "Raging Bulls", "Team Injection", "Team Erection", "Silver Panthers", "The Executioners", "Team 17", "More Beer Please"];
TestDataGenerator.zipCodesMunich = [80995, 80997, 80999, 81247, 81249, 80331, 80333, 80335, 80336, 80469, 80538, 80539,
    81541, 81543, 81667, 81669, 81671, 81675, 81677,
    81243, 81245, 81249,
    81671, 81673, 81735, 81825,
    81675, 81677, 81679, 81925, 81927, 81929,
    80933, 80935, 80995,
    80689, 81375, 81377,
    80686, 80687, 80689,
    80335, 80336, 80337, 80469,
    80333, 80335, 80539, 80636, 80797, 80798, 80799, 80801, 80802,
    80807, 80809, 80937, 80939,
    80637, 80638, 80992, 80993, 80997,
    80634, 80636, 80637, 80638, 80639,
    81539, 81541, 81547, 81549,
    80687, 80689, 81241, 81243, 81245, 81247,
    81539, 81549, 81669, 81671, 81735, 81737, 81739,
    80538, 80801, 80802, 80803, 80804, 80805, 80807, 80939,
    80796, 80797, 80798, 80799, 80801, 80803, 80804, 80809,
    80335, 80339,
    80336, 80337, 80469, 81369, 81371, 81373, 81379,
    80686, 81369, 81373, 81377, 81379,
    81379, 81475, 81476, 81477, 81479,
    81735, 81825, 81827, 81829,
    81543, 81545, 81547];
__decorate([
    _smallstack_coreCommon.Autowired(),
    __metadata("design:type", _smallstack_coreCommon.MediaService)
], TestDataGenerator.prototype, "mediaService", void 0);
__decorate([
    _smallstack_coreCommon.Autowired(),
    __metadata("design:type", _smallstack_coreCommon.UserService)
], TestDataGenerator.prototype, "userService", void 0);

var __extends = (undefined && undefined.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var S3MediaService = (function (_super) {
    __extends(S3MediaService, _super);
    function S3MediaService() {
        var _this = _super.call(this) || this;
        _this.region = "eu-central-1";
        var that = _this;
        if (Meteor.isServer) {
            that.configurationService.onSet("media.s3.keyid", function (value) {
                that.keyId = value;
                that.tryS3Init();
            });
            that.configurationService.onSet("media.s3.accesskey", function (value) {
                that.accessKey = value;
                that.tryS3Init();
            });
            that.configurationService.onSet("media.s3.bucketname", function (value) {
                that.bucketName = value;
                that.tryS3Init();
            });
        }
        if (Meteor.isClient) {
            that.configurationService.onSet("media.s3.bucketname", function (value) {
                that.bucketName = value;
            });
        }
        return _this;
    }
    S3MediaService.prototype.tryS3Init = function () {
        if (this.keyId && this.accessKey && this.bucketName) {
            AWS.config.update({ credentials: new AWS.Credentials(this.keyId, this.accessKey), region: this.region });
            _smallstack_coreCommon.Logger.debug("S3MediaService", "S3 Storage initialized!");
            this.s3 = new AWS.S3({ params: { Bucket: this.bucketName } });
        }
    };
    S3MediaService.prototype.getUrlForMediaId = function (mediaId, mediaFormatName) {
        return "https://s3." + this.region + ".amazonaws.com/" + this.bucketName + "/" + mediaId + "_" + mediaFormatName;
    };
    S3MediaService.prototype.storeMediaFromDataUrl = function (media, dataUrlString, mediaFormat) {
        return this.storeMedia(media, this.decodeBase64Image(dataUrlString), mediaFormat);
    };
    S3MediaService.prototype.storeMediaFromURL = function (media, url, mediaFormat) {
        var response = HTTP.call('GET', url, { npmRequestOptions: { encoding: null } });
        return this.storeMedia(media, { type: response.headers["content-type"], buffer: new Buffer(response.content) }, mediaFormat);
    };
    S3MediaService.prototype.storeMedia = function (media, typedBuffer, mediaFormat) {
        if (media === undefined || media.id === undefined)
            throw new Meteor.Error("404", "Media has to exist and get stored before files can be attached![stored:" + (media.id !== undefined) + "]");
        if (this.s3 === undefined)
            throw new Meteor.Error("501", "S3 Media Storage is not initialized yet!");
        var buffer = this.processImage(typedBuffer, mediaFormat);
        var params = { Key: media.id + "_" + mediaFormat.name, Body: buffer, ACL: "public-read", ContentType: typedBuffer.type };
        var upload = Meteor.wrapAsync(this.s3.upload, this.s3);
        upload(params);
        media.addAvailableFormatIds([mediaFormat.id]);
        media.update();
        return true;
    };
    S3MediaService.prototype.convertMedia = function (media, fromFormat, toFormat) {
        if (media === undefined || media.id === undefined)
            throw new Meteor.Error("404", "Media has to exist and get stored before files can be attached![stored:" + (media.id !== undefined) + "]");
        if (this.s3 === undefined)
            throw new Meteor.Error("501", "S3 Media Storage is not initialized yet!");
        this.storeMediaFromURL(media, this.getUrlForMediaId(media.id, fromFormat.name), toFormat);
    };
    S3MediaService.prototype.removeMediaFormat = function (media, mediaFormatName) {
        if (this.s3 === undefined)
            throw new Meteor.Error("501", "S3 Media Storage is not initialized yet!");
        var mediaFormat = this.getCollection().findOne({ name: mediaFormatName });
        if (!mediaFormat)
            throw new Meteor.Error("404", "MediaFormat with name '" + mediaFormatName + "' does not exist!");
        Meteor.wrapAsync(this.s3.deleteObject, this.s3)({ "Key": media.id + "_" + mediaFormatName });
        media.availableFormatIds = _.without(media.availableFormatIds, mediaFormat.id);
        media.update();
    };
    S3MediaService.prototype.removeMedia = function (media) {
        var _this = this;
        if (this.s3 === undefined)
            throw new Meteor.Error("501", "S3 Media Storage is not initialized yet!");
        var objectKeys = [];
        _.each(media.availableFormatIds, function (formatId) {
            var mediaFormat = _this.getCollection().findOne(formatId);
            if (mediaFormat)
                objectKeys.push({ "Key": media.id + "_" + mediaFormat.name });
        });
        if (objectKeys.length > 0)
            Meteor.wrapAsync(this.s3.deleteObjects, this.s3)({ "Delete": { "Objects": objectKeys } });
        media.delete();
    };
    return S3MediaService;
}(_smallstack_coreCommon.MediaService));

function configureAWS() {
    var configurationService = _smallstack_coreCommon.IOC.get("configurationService");
    if (configurationService.contains("aws.accesskeyid") && configurationService.contains("aws.secretaccesskey") && configurationService.contains("aws.region")) {
        AWS.config.update({
            accessKeyId: configurationService.get("aws.accesskeyid"),
            secretAccessKey: configurationService.get("aws.secretaccesskey"),
            region: configurationService.get("aws.region"),
        });
        _smallstack_coreCommon.Logger.info("AWS", "successfully setup!");
    }
}
function initMeteorServer() {
    var configurationService = _smallstack_coreCommon.IOC.get("configurationService");
    configurationService.onSet("aws.accesskeyid", configureAWS);
    configurationService.onSet("aws.secretaccesskey", configureAWS);
    configurationService.onSet("aws.region", configureAWS);
    _smallstack_coreCommon.IOC.onRegister("collectionsService", function () {
        _smallstack_coreCommon.IOC.onRegister("rolesService", function () {
            _smallstack_coreCommon.IOC.register("mediaService", new S3MediaService());
        });
    });
    createDefaultAdministrator();
}

_smallstack_coreCommon.IOC.onRegister("collectionsService", function (collectionsService) {
    if (Meteor.isServer) {
        Meteor.methods({
            "backoffice-backup": function (collectionNames) {
                _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
                var backup = {};
                _.each(collectionsService.getAllCollections(), function (collection, name) {
                    if (!(collectionNames instanceof Array) || collectionNames.indexOf(name) !== -1) {
                        try {
                            backup[name] = collection.find({}, { transform: null }).fetch();
                        }
                        catch (e) {
                            console.error("Error during backup job for collection '" + name + "' : ", e);
                        }
                    }
                });
                return backup;
            },
            "backoffice-collectionCounts": function (collectionNames) {
                _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
                var counts = [];
                _.each(collectionsService.getAllCollections(), function (collection, name) {
                    if (name !== "counts") {
                        if (!(collectionNames instanceof Array) || collectionNames.indexOf(name) !== -1) {
                            try {
                                counts.push({ count: collection.find().count(), name: name });
                            }
                            catch (e) {
                                console.error("Error during counts job for collection '" + name + "' : ", e);
                            }
                        }
                    }
                });
                return counts;
            },
            "backoffice-restore": function (data) {
                _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
                // check collections
                if (!data.restore)
                    throw new Meteor.Error("501", "restore object is not defined!");
                if (typeof data.restore !== 'object')
                    throw new Meteor.Error("501", "restore object is not an object!");
                _.each(data.restore, function (values, collectionName) {
                    if (!collectionsService.getCollectionByName("" + collectionName))
                        throw new Meteor.Error("501", "unknown collection '" + collectionName + "'!");
                });
                // do upserts
                var logs = [];
                _.each(data.restore, function (documents, collectionName) {
                    if (data.dropCollections) {
                        logs.push("Info: Dropping collection " + collectionName);
                        _smallstack_coreCommon.Logger.info("BackupRestoreJob", "Dropping collection " + collectionName);
                        collectionsService.getCollectionByName(collectionName).remove({});
                    }
                    var importError = false;
                    _.each(documents, function (doc) {
                        try {
                            collectionsService.getCollectionByName(collectionName).upsert(doc["_id"], { $set: doc });
                        }
                        catch (e) {
                            importError = true;
                            logs.push("Error: Could not import document into '" + collectionName + "': " + JSON.stringify(doc) + "! Error was " + e.toString());
                            _smallstack_coreCommon.Logger.warning("BackupRestoreJob", "Could not import document into '" + collectionName + "': " + JSON.stringify(doc) + "!", e);
                        }
                    });
                    if (!importError) {
                        logs.push("Info: Successfully imported " + documents.length + " documents into collection '" + collectionName + "'!");
                        _smallstack_coreCommon.Logger.info("BackupRestoreJob", "Successfully imported " + documents.length + " documents into collection '" + collectionName + "'!");
                    }
                });
                // in case of everything went wrong, create a default admin again
                if (Meteor.users.find().count() === 0) {
                    var userId = Accounts.createUser({
                        username: "admin",
                        email: "admin@smallstack.io",
                        password: "nimda",
                        profile: {}
                    });
                    Meteor.users.update(userId, {
                        $set: {
                            roles: ["administrator"]
                        }
                    });
                    _smallstack_coreCommon.Logger.info("DefaultAdmin", "Created Administrator Account : admin@smallstack.io/nimda");
                    throw new Meteor.Error("501", "Something went wrong, the user database is empty after the restore. The default administrator got restored, please log in with admin@smallstack.io/nimda");
                }
                return {
                    success: true,
                    logs: logs
                };
            }
        });
    }
});

_smallstack_coreCommon.IOC.onRegister("dataBridge", function (dataBridge) {
    dataBridge.addServerMethod("backoffice-analytics-saveTracking", function (trackingId) {
        _smallstack_coreCommon.Utils.check(trackingId, "string", "trackingId");
        if (!_smallstack_coreCommon.RolesService.userHasRole(this.userId, "administrator"))
            throw new Error("Administration Role needed for updating configuration!");
        _smallstack_coreCommon.IOC.get("collectionsService").getCollectionByName("configuration").upsert({ "key": "googleanalytics.trackingid" }, {
            $set: {
                "key": "googleanalytics.trackingid",
                "value": trackingId,
                "scope": "everywhere"
            }
        });
    });
});

_smallstack_coreCommon.IOC.onRegister("dataBridge", function (dataBridge) {
    dataBridge.addServerMethod("configurations-getCompleteConfiguration", function () {
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        return _smallstack_coreCommon.IOC.get("collectionsService").getCollectionByName("configuration").find().fetch();
    });
    dataBridge.addServerMethod("configurations-updateConfiguration", function (data) {
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        _smallstack_coreCommon.Utils.check(data.key, "string", "key");
        _smallstack_coreCommon.Utils.check(data.value, "string", "value");
        _smallstack_coreCommon.Utils.check(data.scope, "string", "scope");
        if (data.scope !== "server" && data.scope !== "everywhere")
            throw new Error("Scope should be 'server' or 'everywhere'!");
        var configurationService = _smallstack_coreCommon.ConfigurationService.instance();
        if (configurationService.getCollection().find({
            "key": data.key
        }).count() === 0) {
            configurationService.getCollection().insert(_smallstack_coreCommon.Configuration.fromDocument({
                "key": data.key,
                "value": data.value,
                "scope": data.scope
            }));
        }
        else {
            configurationService.set(data.key, data.value, data.scope);
        }
    });
});

if (Meteor.isServer) {
    Meteor.methods({
        "backoffice-dashboard-statistics": function () {
            _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
            var statistics = {
                totalUsers: Meteor.users.find().count(),
                newUsersThisMonth: Meteor.users.find({}).count()
            };
            return statistics;
        }
    });
}

Meteor.methods({
    "backoffice-add-dynamic-module": function (dynModule) {
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        _smallstack_coreCommon.Utils.check(dynModule.menuLabel, String, "menuLabel");
        _smallstack_coreCommon.Utils.check(dynModule.role, String, "role");
        _smallstack_coreCommon.Utils.check(dynModule.route, String, "route");
        _smallstack_coreCommon.Utils.check(dynModule.pageId, String, "pageId");
        if (dynModule.route.indexOf("/manage/") !== 0)
            throw new Meteor.Error("400", "Dynamic module route should start with '/manage/'!");
        // create navigation entry
        var navigationEntry = new _smallstack_coreCommon.NavigationEntry();
        navigationEntry.setLabel(dynModule.menuLabel);
        navigationEntry.setIcon("fa fa-gear");
        navigationEntry.setRoute(dynModule.route);
        navigationEntry.setRequiresAuthentication(true, "backoffice_login");
        navigationEntry.setPageId(dynModule.pageId);
        navigationEntry.setType("backoffice");
        navigationEntry.setRequiredRole(dynModule.role);
        navigationEntry.setIndex(5);
        navigationEntry.save();
    }
});

if (Meteor.isServer) {
    var ddpEvents = new EventDDP('backoffice-jobs-log');
    ddpEvents.matchEmit('push', {}, 'Hello world!');
    Meteor.methods({
        "backoffice-jobs-getalljobs": function () {
            _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
            return _smallstack_coreCommon.IOC.get("backofficeJobRegistry").getAllJobs();
        },
        "backoffice-jobs-execute": function (name) {
            _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
            _smallstack_coreCommon.IOC.get("backofficeJobRegistry").executeJob(name, function (message) {
                ddpEvents.matchEmit('push', {}, message);
            });
        }
    });
}

Meteor.methods({
    "backoffice-queries-add": function (queryPath, contentType, response) {
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        try {
            var deleteObject = {};
            deleteObject[queryPath] = false;
            HTTP["methods"](deleteObject);
        }
        catch (e) {
            console.error(e);
        }
        var queryObject = {};
        queryObject[queryPath] = function () {
            this.setContentType(contentType);
            if (contentType === "application/json")
                return JSON.parse(response);
            return response;
        };
        HTTP["methods"](queryObject);
    }
});

Meteor.methods({
    "backoffice-socialnetworks": function () {
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        var configurationService = _smallstack_coreCommon.ConfigurationService.instance();
        return {
            "facebookAppId": configurationService.get("accounts.services.facebook.appid", ""),
            "facebookSecret": configurationService.get("accounts.services.facebook.secret", ""),
            "googleClientId": configurationService.get("accounts.services.google.clientid", ""),
            "googleSecret": configurationService.get("accounts.services.google.secret", ""),
            "linkedInClientId": configurationService.get("accounts.services.linkedin.clientid", ""),
            "linkedInSecret": configurationService.get("accounts.services.linkedin.secret", ""),
            "twitterConsumerKey": configurationService.get("accounts.services.twitter.consumerkey", ""),
            "twitterSecret": configurationService.get("accounts.services.twitter.secret", ""),
        };
    },
    "backoffice-socialnetworks-savefacebook": function (data) {
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        var configurationService = _smallstack_coreCommon.ConfigurationService.instance();
        if (_smallstack_coreCommon.Utils.isNonEmptyString(data.facebookAppId) && _smallstack_coreCommon.Utils.isNonEmptyString(data.facebookSecret)) {
            configurationService.set("accounts.services.facebook.appid", data.facebookAppId, "everywhere");
            configurationService.set("accounts.services.facebook.secret", data.facebookSecret, "server");
            ServiceConfiguration.configurations.remove({
                service: "facebook"
            });
            ServiceConfiguration.configurations.insert({
                service: "facebook",
                appId: data.facebookAppId,
                secret: data.facebookSecret
            });
            configurationService.set("login.facebook.isconfigured", "true", "everywhere");
            console.log("utils -> Facebook login configured!");
            return true;
        }
        throw new Error("Wrong parameters given!");
    },
    "backoffice-socialnetworks-savegoogle": function (clientId, secret) {
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        if (_smallstack_coreCommon.Utils.isNonEmptyString(clientId) && _smallstack_coreCommon.Utils.isNonEmptyString(secret)) {
            var configurationService = _smallstack_coreCommon.ConfigurationService.instance();
            configurationService.set("accounts.services.google.clientid", clientId, "everywhere");
            configurationService.set("accounts.services.google.secret", secret, "server");
            ServiceConfiguration.configurations.remove({
                service: "google"
            });
            ServiceConfiguration.configurations.insert({
                service: "google",
                clientId: clientId,
                secret: secret
            });
            configurationService.set("login.google.isconfigured", "true", "everywhere");
            console.log("utils -> Google login configured!");
            return true;
        }
        throw new Error("Wrong parameters given!");
    },
    "backoffice-socialnetworks-savelinkedin": function (clientId, secret) {
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        if (_smallstack_coreCommon.Utils.isNonEmptyString(clientId) && _smallstack_coreCommon.Utils.isNonEmptyString(secret)) {
            var configurationService = _smallstack_coreCommon.ConfigurationService.instance();
            configurationService.set("accounts.services.linkedin.clientid", clientId, "everywhere");
            configurationService.set("accounts.services.linkedin.secret", secret, "server");
            ServiceConfiguration.configurations.remove({
                service: "linkedin"
            });
            ServiceConfiguration.configurations.insert({
                service: "linkedin",
                clientId: clientId,
                secret: secret
            });
            configurationService.set("login.linkedin.isconfigured", "true", "everywhere");
            console.log("utils -> LinkedIn login configured!");
            return true;
        }
        throw new Error("Wrong parameters given!");
    },
    "backoffice-socialnetworks-savetwitter": function (data) {
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        if (_smallstack_coreCommon.Utils.isNonEmptyString(data.twitterKey) && _smallstack_coreCommon.Utils.isNonEmptyString(data.twitterSecret)) {
            var configurationService = _smallstack_coreCommon.ConfigurationService.instance();
            configurationService.set("accounts.services.twitter.consumerKey", data.twitterKey, "everywhere");
            configurationService.set("accounts.services.twitter.secret", data.twitterSecret, "server");
            ServiceConfiguration.configurations.remove({
                service: "twitter"
            });
            ServiceConfiguration.configurations.insert({
                service: "twitter",
                consumerKey: data.twitterKey,
                secret: data.twitterSecret
            });
            configurationService.set("login.twitter.isconfigured", "true", "everywhere");
            console.log("utils -> Twitter login configured!");
            return true;
        }
        throw new Error("Wrong parameters given!");
    }
});

Meteor.methods({
    "localizations-removeLocalization": function (key) {
        _smallstack_coreCommon.Utils.check(key, String, "key");
        if (!_smallstack_coreCommon.RolesService.instance().userHasRole(this.userId, "administrator"))
            throw new Meteor.Error("403", "Administration Role needed for removing localizations!");
        return _smallstack_coreCommon.LocalizationService.instance().getCollection().remove({
            "key": key
        }) === 1;
    },
    "localizations-updateLocalization": function (localizations) {
        _smallstack_coreCommon.Utils.check(localizations.key, String, "localizations.key");
        if (!_smallstack_coreCommon.RolesService.instance().userHasRole(this.userId, "administrator"))
            throw new Meteor.Error("403", "Administration Role needed for updating localizations!");
        _.each(localizations, function (localizationValue, languageKey) {
            if (languageKey !== "key") {
                if (_smallstack_coreCommon.LocalizationService.instance().getCollection().find({
                    "key": localizations.key,
                    "language": languageKey
                }).count() === 0) {
                    _smallstack_coreCommon.LocalizationService.instance().getCollection().insert(_smallstack_coreCommon.LocalizedText.fromDocument({
                        "key": localizations.key,
                        "language": languageKey,
                        "value": localizationValue
                    }));
                }
                else {
                    _smallstack_coreCommon.LocalizationService.instance().getCollection().update({
                        "key": localizations.key,
                        "language": languageKey
                    }, {
                        "$set": {
                            "value": localizationValue
                        }
                    });
                }
            }
        });
    }
});

_smallstack_coreCommon.IOC.onRegister("dataBridge", function (dataBridge) {
    dataBridge.addServerMethod("collections-search", function (data) {
        _smallstack_coreCommon.Utils.check(data.collectionName, "string", "collectionName");
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        if (data.queryString === undefined || data.queryString === null || data.queryString === "")
            return _smallstack_coreCommon.IOC.get("collectionsService").getCollectionByName(data.collectionName).find().fetch();
        else
            return _smallstack_coreCommon.IOC.get("collectionsService").getCollectionByName(data.collectionName)["_easySearchIndex"].search(data.queryString).fetch();
    });
    dataBridge.addServerMethod("collections-update", function (data) {
        _smallstack_coreCommon.Utils.check(data.collectionKey, String, "collectionKey");
        _smallstack_coreCommon.Utils.check(data.model, Object, "model");
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        if (data.model.id !== undefined)
            return _smallstack_coreCommon.IOC.get("collectionsService").getCollectionByName(data.collectionKey).update({ "_id": data.model.id }, { $set: data.model }) === 1;
        else
            return _smallstack_coreCommon.IOC.get("collectionsService").getCollectionByName(data.collectionKey).insert(data.model) !== undefined;
    });
    dataBridge.addServerMethod("collections-remove", function (data) {
        _smallstack_coreCommon.Utils.check(data.collectionKey, String, "collectionKey");
        _smallstack_coreCommon.Utils.check(data.model, Object, "model");
        _smallstack_coreCommon.RolesService.checkRole(this.userId, "administrator");
        if (data.collectionKey === "users" && data.model.id === this.userId)
            throw new Error("501 - You should not delete your own user while being logged in!");
        return _smallstack_coreCommon.IOC.get("collectionsService").getCollectionByName(data.collectionKey).remove(data.model.id) === 1;
    });
});

exports.createDefaultAdministrator = createDefaultAdministrator;
exports.TestDataGenerator = TestDataGenerator;
exports.configureAWS = configureAWS;
exports.initMeteorServer = initMeteorServer;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=server.umd.js.map
