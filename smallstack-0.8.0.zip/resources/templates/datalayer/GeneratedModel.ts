/**
 * THIS FILE IS AUTO-GENERATED AND WILL BE REPLACED ON ANY RE-COMPILE
 */

import * as _ from "underscore";
import { QueryObject, QueryOptions, SmallstackModel, DataBridge } from "<%=functions.getPackagesPathRelative(root.rootDirectory, "../../", root.packagesPathRelative, "./common", "@smallstack/core-common")%>";
import { NotificationService } from "<%=functions.getPackagesPathRelative(root.rootDirectory, "../../", root.packagesPathRelative, "./common", "@smallstack/core-common")%>";
import { IOC } from "<%=functions.getPackagesPathRelative(root.rootDirectory, "../../", root.packagesPathRelative, "./common", "@smallstack/core-common")%>";

import { <%=modelClassName%> } from "../../models/<%=modelClassName%>";
<% if (!skipServiceGeneration) {
%>import { <%=serviceClassName%> } from "../../services/<%=serviceClassName%>";<%}

// check for unknown properties
functions.checkSchema(config.model.schema, config.model.name);

var importedClasses = [];

_.forEach(config.model.schema, function(schema) {
	
	if (schema.type === "foreign" || schema.type === "foreign[]") {	
        if (schema.foreignType === undefined)
            throw new Error("schema." + schema.name + " is of type foreign or foreign[] but doesn't set a foreignType property!!!");
        if (others[schema.foreignType] === undefined)
            throw new Error("Type '" + schema.foreignType + "' is unknown!");
			
		if (others[schema.foreignType].modelClassName !== modelClassName && importedClasses.indexOf(others[schema.foreignType].modelClassName ) === -1) {
			importedClasses.push(others[schema.foreignType].modelClassName );
			
if (!others[schema.foreignType].skipServiceGeneration) {%>
import { <%=others[schema.foreignType].serviceClassName%> } from "<% 
if (others[schema.foreignType].generate === false)
	print("@smallstack/core");
else 
	print(functions.relativePath(modelsGeneratedDirectory,others[schema.foreignType].servicesDirectory + "/" + others[schema.foreignType].serviceClassName));
%>";<% } %>
import { <%=others[schema.foreignType].modelClassName%> } from "<% 
if (others[schema.foreignType].generate === false)
	print("@smallstack/core");
else 
	print(functions.relativePath(modelsGeneratedDirectory,others[schema.foreignType].modelsDirectory + "/" + others[schema.foreignType].modelClassName));
%>";<%}
	}else if (!functions.isPrimitiveType(schema.type)){
		var foreignType = schema.type.replace("[]","");
		if (others[foreignType] === undefined)
            throw new Error("Type '" + foreignType + "' is unknown!");
		if (importedClasses.indexOf(foreignType) === -1) {
			importedClasses.push(foreignType);
        %>
import { <%=foreignType%> } from "<%
if (others[foreignType].generate === false)
	print("@smallstack/core");
else 
	print(functions.relativePath(modelsGeneratedDirectory,others[foreignType].modelsDirectory + "/" + foreignType));
%>";<%
    	}
	}
});


var enumsFound = false;
var foreignKeysFound = false;

_.forEach(config.model.schema, function(schema) {
	if (schema.type === "foreign" || schema.type === "foreign[]") {
		foreignKeysFound = true;
	}
});



var subTypes = [];

function addSubtype(currentArray, split, schema) {
	var subType = split[0];
	if (currentArray[subType] === undefined)
		currentArray[subType] = {};
	if (split.length > 1)
		addSubtype(currentArray[subType], _.drop(split, 1), schema);
	else 
		currentArray[subType] = schema.type;
}

function getSubTypes(schema) {
	_.forEach(schema, function(schema) {
		if (schema.name.indexOf(".") !== -1) {
			var split = schema.name.split(".");
			addSubtype(subTypes, split, schema);
		}
	});
	return subTypes;
}

// check model properties

%>

export <% if(config.model.abstract === true) print("abstract "); %>class <%= generatedModelClassName %><% if (config.model.extends !== undefined) {%> extends <%=config.model.extends%><%}%> implements SmallstackModel<% if (config.model.implements !== undefined) {%>, <%=config.model.implements%><%}%> {
	
	protected dataBridge: DataBridge;

	// generated model properties
	public id: string;
	<% _.forEach(config.model.schema, function(schema) {
		if (typeof schema.name !== "string")
				throw new Error(config.filename + " --> model.schema : All schemas must have a non-empty string as 'name'!");
		if (typeof schema.type !== "string")
				throw new Error(config.filename + " --> model.schema." + schema.name + ".type must be a non-empty string!");
		if (schema.allowedValues !== undefined)
			enumsFound = true;
		if (schema.name.indexOf(".") === -1) {
            %>public <%=functions.getModelPropertyName(schema) %>: <%=functions.getTypescriptType(schema.type) %><% if (schema.defaultValue !== undefined) {%> = <%=JSON.stringify(schema.defaultValue)%><%}%>; 
	<% }
	else {
		throw new Error(config.filename + " --> model.schema." + schema.name + ".name : dot annotation is not yet supported!");
		}
	});
	 %>	
	// internal properties
	private _hasSubDocuments: boolean = <%=foreignKeysFound%>;
	private _isStored: boolean = false;
	
	<% if (enumsFound) {%>
	// generated enums
	public static enums = {
		<% for(var s = 0; s < config.model.schema.length; s++) {
		if (config.model.schema[s].allowedValues !== undefined) {
			%>"<%=config.model.schema[s].name%>": { <%for(var a = 0; a < config.model.schema[s].allowedValues.length; a++){
	 			%>"<% if (config.model.schema[s].type === "string") print(config.model.schema[s].allowedValues[a].toUpperCase()); else print(config.model.schema[s].allowedValues[a])%>": <% 
				 if (config.model.schema[s].type === "string") 
				 	print("\"" + config.model.schema[s].allowedValues[a] + "\"");
				else
					print(config.model.schema[s].allowedValues[a]);
				if (a !== (config.model.schema[s].allowedValues.length - 1)) {%>,<%}
				};
			 %>}<% if (s !== (config.model.schema.length - 1)) {%>,
		<%}
		}		
		};
		%>
	}<%
	} %>
	constructor() {
		this.dataBridge = IOC.get<DataBridge>("dataBridge");
	}
	
	public static fromDocument<T>(doc: any): T {
		<% if(config.model.abstract === true) { %>
		throw new Error("<%= generatedModelClassName %> is abstract and cannot be instanciated!");
		<%} else {%>
		let ModelConstructor = this.getModelClass();
		let model = new ModelConstructor();
		if (doc._id !== undefined) {
			model._isStored = true; 
			model.id = doc._id;		
		}
		<% _.forEach(config.model.schema, function(schema) {
	 		%>model["<%=functions.getModelPropertyName(schema) %>"] = doc["<%=functions.getModelPropertyName(schema) %>"]; 
		<%});
		%>return model;
		<% } %>
	}
	
	public toDocument(identifierKey: string = "_id") {
		var doc = {};
		<% _.forEach(config.model.schema, function(schema) {
			if (functions.isPrimitiveType(schema.type) || schema.type === "foreign" || schema.type === "foreign[]") {
	 		%>doc["<%=functions.getModelPropertyName(schema) %>"] = this["<%=functions.getModelPropertyName(schema) %>"]; 
		<%} else {
			if (schema.type.indexOf("[]") === -1) {
			%>if (this["<%=functions.getModelPropertyName(schema) %>"])
			doc["<%=functions.getModelPropertyName(schema) %>"] = this["<%=functions.getModelPropertyName(schema) %>"].toDocument();
		<%
			} else {
			%>doc["<%=functions.getModelPropertyName(schema) %>"] = [];
		_.each(this["<%=functions.getModelPropertyName(schema) %>"],(subModel:any) => { 
			doc["<%=functions.getModelPropertyName(schema) %>"].push(subModel.toDocument());
		});
		<%
			}
		}
	
		});%>
		if (this.id)
			doc[identifierKey] = this.id;
		return doc;
	}
	<% _.forEach(config.model.schema, function(schema) {
		if (schema.type === "foreign" || schema.type === "foreign[]") {
			if (typeof schema.foreignType !== "string")
				throw new Error(config.filename + " --> model.schema." + schema.name + ".foreignType must be a non-empty string when using 'foreign' or 'foreign[]' as type!");                    
        if (schema.type === "foreign[]") {                    
    %>
	/** 
	 * Adds a reference to <%=functions.capitalize(schema.name) %> 
	 */
    public add<%= functions.capitalize(functions.getModelPropertyName(schema)) %>(ids:string[]) {
        if (this.<%=functions.getModelPropertyName(schema)%> === undefined)
            this.<%=functions.getModelPropertyName(schema)%> = [];
		_.each(ids, function(id) {
			if (!_.contains(this.<%=functions.getModelPropertyName(schema)%>, id))
				this.<%=functions.getModelPropertyName(schema)%>.push(id);
		}, this);
	}
<%}%>
    public <%=functions.getForeignModelGetterName(schema,false,others, functions) %>(options?:QueryOptions): QueryObject<<%=others[schema.foreignType].modelClassName%>> {
		return IOC.get<<%=others[schema.foreignType].serviceClassName%>>("<%=functions.lowerCaseFirst(others[schema.foreignType].serviceClassName)%>").<%=functions.getForeignModelGetterName(schema,true, others) %>({id<% if (schema.type === "foreign[]") {%>s<%}%> : this.<%=functions.getModelPropertyName(schema)%>}, options);
	}
		<%
	}
	}) %>
	
	/**
	 * Returns true if the model can contain sub documents
	 */
	public hasSubDocuments(): boolean {
		return this._hasSubDocuments; 
	}
	
	/**
	 * Returns true if model is stored in database
	 */
	public isStored(): boolean {
		return this._isStored;
	}
    <%
	if (config.service) { 
	_.forEach(config.service.securedmethods, function(method){
        if (method.modelAware === true) {%>
	public <%=method.name%>(<%=functions.arrayToCommaSeparatedString(method.parameters, true, true, false)%>callback?: (error: Error, result: <%=method.returns%>) => void): void {
		if (callback === undefined && this.dataBridge.isClient())  {
			var that = this;
			callback = function(error: Error, result: <%=method.returns%>) {
				if (error)
					NotificationService.instance().getStandardErrorPopup(error, "Could not execute action '<%=method.name%>' for <%=config.model.name%> with ID '" + that.id + "'!");
				else
					NotificationService.instance().notification.success("Successfully executed '<%=method.name%>' for <%=config.model.name%> with ID '" + that.id + "'!");
			}
		}
        return <%=functions.getServiceName(config)%>.instance().<%=method.name%>(this.id, <%=functions.arrayToCommaSeparatedString(method.parameters,false, true, false)%>callback);
	}					
	<%}}); }%>
	public static getModelName() {
		return "<%= modelClassName %>";
	}

	public getModelName() {
		return "<%= modelClassName %>";
	}

	public static getModelClass():any {
		return IOC.get("<%=modelClassName%>");
	}

	public getModelClass():any {
		return IOC.get("<%=modelClassName%>");
	}

	<% if (config.service) { %>
	public delete(callback?:(error: Error, numberOfRemovedDocuments:number) => void): number {
		if (callback === undefined && this.dataBridge.isClient())  {
			var that = this;
			callback = function(error: Error, numberOfRemovedDocuments:number) {
				if (error)
					NotificationService.instance().getStandardErrorPopup(error, "Could not delete <%=config.model.name%> with ID '" + that.id + "'!");
				else
					NotificationService.instance().notification.success("Successfully removed <%=config.model.name%> with ID '" + that.id + "'!");
			}
		}
		return <%=functions.getServiceName(config)%>.instance().delete(<any> this, callback);
	}
	
	public update(callback?:(error: Error, numberOfSavedDocuments:number) => void): number {
		if (callback === undefined && this.dataBridge.isClient())  {
			callback = (error: Error, numberOfSavedDocuments:number) => {
				if (error)
					NotificationService.instance().getStandardErrorPopup(error, "Could not update <%=config.model.name%> with ID '" + this.id + "'!");
				else
					NotificationService.instance().notification.success("Successfully updated <%=config.model.name%> with ID '" + this.id + "'!");
			}
		}
		return <%=functions.getServiceName(config)%>.instance().update(<any> this, callback);
	}
	
	public save(callback?:(error: Error, savedId:string) => void): string {
		if (this.isStored())
			throw new Error("Model is already saved!");
		if (callback === undefined && this.dataBridge.isClient())  {
			callback = (error: Error, savedId:string) => {
				if (error)
					NotificationService.instance().getStandardErrorPopup(error, "Could not save <%=config.model.name%>!");
				else {
					this.id = savedId;
					this._isStored = true;
					NotificationService.instance().notification.success("Successfully saved <%=config.model.name%>!");
				}
			}
		}
		if (this.dataBridge.isClient())
			<%=functions.getServiceName(config)%>.instance().save(<any> this, callback);
		if (this.dataBridge.isServer()) {
			this.id = <%=functions.getServiceName(config)%>.instance().save(<any> this, callback);
			this._isStored = true;
			return this.id;
		}		
	} <% } %>

	public static getSchema(): any {
		return {
			"_id": {
				"type": String,
				"optional": true	
			},<% 
		_.forEach(config.model.schema, function(schema) {%>
			"<%=functions.getModelPropertyName(schema, others)%>" : {
				"type" : <%=functions.getSchemaType(schema.type)%><% 
				if (schema.allowedValues !== undefined) {%>,
				"allowedValues" : <%= functions.toArrayString(schema.allowedValues) %><%}%><% 
				if (schema.defaultValue !== undefined) {%>,
				"defaultValue" : <%= JSON.stringify(schema.defaultValue) %><%}%><% 
				if (schema.decimal !== undefined) {%>,
				"decimal" : <%= schema.decimal %><%}%><% 
				if (schema.optional !== undefined) {%>,
				"optional" : <%= schema.optional %><%}%><% 
				if (schema.blackbox !== undefined) {%>,
				"blackbox" : <%= schema.blackbox %><%}%><% 
				if (schema.index !== undefined) {%>,
				"index" : <%= schema.index %><%}%><% 
				if (schema.unique !== undefined) {%>,
				"unique" : <%= schema.unique %><%}%><% 
				if (schema.minCount !== undefined) {%>,
				"minCount" : <%= schema.minCount %><%}%><% 
				if (schema.maxCount !== undefined) {%>,
				"maxCount" : <%= schema.maxCount %><%}%>
			},<%})%>
		};
	}
}

