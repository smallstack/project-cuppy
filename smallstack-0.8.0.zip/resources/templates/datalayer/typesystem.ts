import { Type, Typesystem, IOC } from "@smallstack/core";

/**
 * THIS FILE IS AUTO-GENERATED AND WILL BE REPLACED ON ANY RE-GENERATION
 */

export function initializeTypesystem () {
    IOC.onRegister("typesystem", (typesystem: Typesystem) => {
    
        <% 
        _.forEach(configuration, function(config){
            print('typesystem.addType(Type.fromDocument('+JSON.stringify(config.config)+'));\n\n\t');
        }); %>
    });
}
