/**
 * THIS FILE IS AUTO-GENERATED AND WILL BE REPLACED ON ANY RE-GENERATION
 */

import { Utils, IOC, CollectionsService } from "@smallstack/core";

IOC.onRegister("collectionsService", (collectionsService: CollectionsService) => {

    Meteor.methods({
        "server-counts": function (data: { queryName: string, parameters: any}) {
            Utils.check(data.queryName, "string", "queryName");
            let parameters:any = data.parameters;

            switch (data.queryName) {
                <%
                _.forEach(configuration, function (conf) {
                    if (conf.config.service && conf.config.service.queries) {
                        _.forEach(conf.config.service.queries, function (query) {
                            var evaluatedQuery = functions.evaluateQuery(query, "this.userId");
                            %>case "<%=query.name%>":
        return collectionsService.getCollectionByName("<%=conf.config.collection.name%>").find(<%=evaluatedQuery.parsedSelector %>).count();
                            
                <%
                        });
                    }
                });           
                %>
            }
        }
    });
});
