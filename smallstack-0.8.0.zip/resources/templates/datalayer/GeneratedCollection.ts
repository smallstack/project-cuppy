/**
 * THIS FILE IS AUTO-GENERATED AND WILL BE REPLACED ON CODE GENERATION
 */

declare var EasySearch: any;

import { Logger, Autowired, IOC }  from "<%=functions.getPackagesPathRelative(root.rootDirectory, "../../", root.packagesPathRelative, "./common", "@smallstack/core-common")%>";
import { Collection, CollectionsService, Type }  from "<%=functions.getPackagesPathRelative(root.rootDirectory, "../../", root.packagesPathRelative, "./common", "@smallstack/core-common")%>";
import { BaseCollection }  from "<%=functions.getPackagesPathRelative(root.rootDirectory, "../../", root.packagesPathRelative, "./common", "@smallstack/core-common")%>";

import { <%=modelClassName%> } from "<%= relativePathFromServiceToModel %>";
import { <%=generatedModelClassName%> } from "../models/<%=generatedModelClassName%>";


// TODO: get rid of meteor references
declare var Package: any;

export class <%= generatedCollectionClassName %> extends BaseCollection<<%=modelClassName%>> implements Collection<<%=modelClassName%>> {
	
	public name = "<%=collectionName%>";
	protected _easySearchIndex:any;
	
	public static queries = {<% 
		_.forEach(config.service.queries, function(query, index) {%>
		"<%=query.name%>": {name : "<%=query.name%>", parameters : {<% 
		var parameters = functions.getAllQueryParameters(query);
		for (var p = 0; p < parameters.length; p++) {
			print(parameters[p] + " : \"" + parameters[p] + "\"");
			if (p !== (parameters.length - 1))
				print(", ");
		}
		%>}}<% if (index !== (config.service.queries.length - 1)) {%>,<%}		
		});%>
	}
	
	public static expandables = {<% 
		var expandables = functions.getExpandablesArray(config.model.schema); 
		for(var e = 0; e < expandables.length; e++) {
		%>"<%=expandables[e]%>": "<%=expandables[e]%>"<% if (e !== (expandables.length - 1)) {%>,<%}		
	};%>}
	
	constructor() {		
		super();
		
		// create collection
		this.createCollection();
		
		// allow/deny
		this.configureAllowDenyRules();
		
		// create search index
        this.createSearchIndex();
		
		// attach collection to smallstack.collections
		this.collectionsService.registerCollection("<%=collectionName%>", this);
		
		// Add publishing methods
		this.createPublications();
	}	
	
	protected createPublications() {
		if (this.dataBridge.isServer()) {
			<% _.forEach(config.service.queries, function(query) {
            if (typeof query.name !== 'string' || query.name.length === 0)
                throw new Error("query.name is empty for query : " + query);
			var selector = query.selector !== undefined ? query.selector : {};
			var options = {};
			if (query.sorting)
				options.sort = query.sorting; 
			if (query.fields)
				options.fields = query.fields;                       
			%>this.collectionsService.addPublisher("<%=config.collection.name%>", "<%=query.name%>", <%=JSON.stringify(selector)%>, <%=JSON.stringify(options)%>);
		<%});%>}
	}
    
    protected createSearchIndex() {
        if (Package["easysearch:core"]) {
			Logger.debug("EasySearch", "Creating search index for collection '<%=collectionName%>' and fields '<%=functions.getSearchableFieldsArray(config.model.schema)%>'!");
			this._easySearchIndex = new EasySearch.Index({
				collection: this._collection,
				fields: <%=JSON.stringify(functions.getSearchableFieldsArray(config.model.schema))%>,
				engine: new EasySearch.MongoDB()
			});
		}
    }
	
	protected createCollection() {
		this._collection = this.collectionsService.createCollection("<%=collectionName%>", function(doc){
			return <%=modelClassName%>.fromDocument(doc);
		});
	}
	
	protected configureAllowDenyRules():void {

		var allow = this.getCollectionAllowRules();
		if (allow !== undefined)
			this._collection.allow(allow);
		else {
			var deny = this.getCollectionDenyRules();
			if (deny !== undefined)
				this._collection.deny(deny);
			else
				console.warn("No allow/deny rules set for collection : <%=collectionName%>");
		}
	}
	
		
	/**
	 * If return value is not undefined these rules will get applied 
	 */
	protected getCollectionAllowRules(): any {
		var that = this;
		return {
            insert: function(userId, doc) {
                // the user must be logged in, and the document must be owned by the user
                return (userId && doc.ownerId === userId);
            },
            update: function(userId, doc, fields, modifier) {
                // can only change your own documents
                return doc.ownerId === userId;
            },
            remove: function(userId, doc) {
                // can only remove your own documents
                return doc.ownerId === userId;
            },
            fetch: ['ownerId']
        }
	}
	
	/** 
	 * Only if getCollectionAllowRules return undefined this method will be used. If return value is not undefined, these deny rules will apply.
	 */
	protected getCollectionDenyRules(): any {
		return undefined;
	}

	protected getSchema(): any {
		return <%=generatedModelClassName%>.getSchema();
	}	
	
	public getForeignCollection(typeName: string): string {
		switch(typeName) {
			<% _.forEach(config.model.schema, function(schema) {
				if(schema.type === "foreign" || schema.type === "foreign[]") {%>
			case "<%=functions.getModelPropertyName(schema)%>": 
				return this.typesystem.getTypeByName("<%=schema.foreignType%>").getCollectionName();<%
			}
			})%>
		}
		return undefined;
	}
	
	public getForeignGetter(): string {
		return "<%=functions.getByIdsGetter(modelClassName)%>";
	}
	
	public static getForeignGetter(): string {
		return "<%=functions.getByIdsGetter(modelClassName)%>";
	}

	public getModelName() {
		return "<%= modelClassName %>";
	}

	public getServiceName(): string {
		return "<%=functions.lowerCaseFirst(serviceClassName)%>";
	}

	public getQueries():{[queryName: string]: any} {
		return <%= generatedCollectionClassName %>.queries;
	}

	public getCollectionName(): string {
		return "<%=collectionName%>";
	}

	public static getCollection(): Collection<<%=modelClassName%>> {
		return IOC.get<CollectionsService>("collectionsService").getCollectionByName<<%=modelClassName%>>("<%=collectionName%>");
	}
}
