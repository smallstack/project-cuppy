/**
 * THIS FILE IS AUTO-GENERATED AND WILL BE REPLACED DURING CODE GENERATION
 */

import * as _ from "underscore";
import { IOC, Logger } from "<%=functions.getPackagesPathRelative(root.rootDirectory, "../../", root.packagesPathRelative, "./common", "@smallstack/core-common")%>";
import { AnalyticsService } from "<%=functions.getPackagesPathRelative(root.rootDirectory, "../../", root.packagesPathRelative, "./common", "@smallstack/core-common")%>";
import { QueryOptions, QueryObject, CollectionsService, Collection, QueryUtils, DataBridge, SmallstackModel } from "<%=functions.getPackagesPathRelative(root.rootDirectory, "../../", root.packagesPathRelative, "./common", "@smallstack/core-common")%>";

import { <%=serviceClassName%> } from "../../services/<%=serviceClassName%>";

export class <%= generatedServiceClassName %><ModelClass extends SmallstackModel> {

    protected collectionsService: CollectionsService;

    protected dataBridge: DataBridge;
    
    constructor() {
        this.collectionsService = IOC.get<CollectionsService>("collectionsService");
        this.dataBridge = IOC.get<DataBridge>("dataBridge");
    }

    static instance(): <%= serviceClassName %> {
        return IOC.get<<%= serviceClassName %>>("<%= functions.lowerCaseFirst(serviceClassName) %>");
    }
	
	public getCollection(): Collection<ModelClass> {
        return this.collectionsService.getCollectionByName<ModelClass>("<%= collectionName %>");
	}    
<% 
		_.forEach(config.service.queries, function(query){ 
			// scan selector for possible variables
            var evaluatedQuery = functions.evaluateQuery(query);
            
            // one or many?
            if (query.sorting)
                throw new Error("Please use query.sort instead of query.sorting!");
            var sorting = query.sort !== undefined ? JSON.stringify(query.sort) : "{}";
            var mongoQuery = "this.getCollection().find(" + evaluatedQuery.parsedSelector + ", selectorOptions)";
            // if (query.returnOne === true)
            //     mongoQuery = "smallstack.collections[\"" + collectionName + "\"].findOne(" + parsedSelector + ")";
%>
    public <%= query.name %>(parameters?: {<%=evaluatedQuery.parameters%>}, queryOptions?: QueryOptions): QueryObject<ModelClass> {
        return new QueryObject<ModelClass>().create(<%=evaluatedQuery.parsedSelector%>, "<%=query.name%>", queryOptions, parameters, <%=sorting%>, this.getCollection());
    }			
<% })


	_.forEach(config.service.securedmethods, function(method){
        var params = [];
        if (method.modelAware === true) {
            params.push("modelId:string");
        }
        if (method.parameters)
            params = _.union(params, _.clone(method.parameters))
        %>
        
	public <%=method.name%>(<%=functions.convertMethodParametersToTypescriptMethodParameters(params, true)%>callback?: (error: Error, result: <%=method.returns%>) => void): void {
        if (IOC.isRegistered("analyticsService"))
            IOC.get<AnalyticsService>("analyticsService").event("<%=method.name%>", { category: "methodcall"});
        this.dataBridge.callMethod("<%=collectionName%>-<%=method.name%>", <%=functions.convertMethodParametersToObject(params)%>, callback);
	}					
	<%});%>    
	// Model Operations
    public save(model: ModelClass, callback?: (error: Error, savedId:string) => void): string {
        return this.getCollection().insert(model, callback);
	}

	public update(model: ModelClass, callback?: (error: Error, numberOfUpdatedDocuments:number) => void):number {
        return this.getCollection().update(model.id, <%=functions.getMongoUpdateJson(others[modelClassName].config.model.schema) %>, callback);
	}
	
	public delete(model: ModelClass, callback?: (error: Error, numberOfRemovedDocuments:number) => void):number {
        return this.getCollection().remove(model.id, callback);
	}
}
